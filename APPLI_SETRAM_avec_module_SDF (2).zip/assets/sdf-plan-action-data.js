/* =========================================================
   sdf-plan-action-data.js — Plan d'Action SDF (Sûreté de Fonctionnement)
   Fichier de données partagé, à déposer sur le lecteur réseau
   dans le même dossier "assets" que comptes.js et chat-messages.js.
   Mis à jour automatiquement par l'outil Suivi Contrôle SDF —
   ne pas modifier ce fichier manuellement pendant qu'il est
   ouvert par un utilisateur (écriture concurrente possible).
   ========================================================= */
window.SETRAM_SDF_DATA = [
];
window.SETRAM_SDF_HISTORIQUE = [
];
