/* =========================================================
   chat-button.js — Bulle flottante de discussion
   Plateforme Maintenance SETRAM
   -----------------------------------------------------------
   Bulle en bas à droite façon Messenger. Un clic ouvre le chat
   dans une PETITE FENÊTRE POP-UP (pas une iframe) : c'est
   nécessaire car les navigateurs bloquent le sélecteur de
   fichier (showOpenFilePicker/showDirectoryPicker) à l'intérieur
   d'une iframe. Une vraie fenêtre reste indispensable pour que
   la connexion au fichier partagé et aux pièces jointes marche.
   ========================================================= */
(function () {
  "use strict";
  document.addEventListener("setram-auth-ready", function () {
    // Ne jamais créer la bulle depuis une page chargée en iframe (ex: les pages
    // de département affichées dans le tableau de bord d'index.html) : sinon
    // chaque iframe crée sa propre bulle en plus de celle de la page hôte,
    // ce qui donne l'icône "doublée" visible en bas à droite.
    if (window.top !== window.self) return;
    if (document.getElementById("setram-chat-btn")) return;
    var isChatPage = /chat\.html$/.test(location.pathname);
    if (isChatPage) return;
    var depth = (location.pathname.match(/\/departements\//) ? "../../" : "");
    var chatUrl = depth + "chat.html?embed=1";

    var style = document.createElement("style");
    style.textContent =
      "#setram-chat-btn{position:fixed;bottom:22px;right:22px;z-index:99998;width:52px;height:52px;border-radius:50%;" +
      "background:#2f6690;color:#fff;border:none;font-size:22px;cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,.28);" +
      "display:flex;align-items:center;justify-content:center;}" +
      "#setram-chat-btn:hover{background:#25547a;}";
    document.head.appendChild(style);

    var btn = document.createElement("button");
    btn.id = "setram-chat-btn";
    btn.type = "button";
    btn.title = "Discussion d'équipe";
    btn.textContent = "💬";
    document.body.appendChild(btn);

    var chatWin = null;
    btn.addEventListener("click", function () {
      if (chatWin && !chatWin.closed) { chatWin.focus(); return; }
      // Position façon Messenger : petite fenêtre collée en bas à droite de l'écran.
      var w = 380, h = 580;
      var left = Math.max(0, (window.screen.availWidth || window.screen.width) - w - 16);
      var top = Math.max(0, (window.screen.availHeight || window.screen.height) - h - 16);
      chatWin = window.open(
        chatUrl,
        "setram_chat",
        "width=" + w + ",height=" + h + ",left=" + left + ",top=" + top +
        ",resizable=yes,scrollbars=yes,menubar=no,toolbar=no,location=no,status=no"
      );
      if (chatWin) chatWin.focus();
      else window.location.href = depth + "chat.html"; // bloqueur de pop-up : on repasse en page complète
    });
  });
})();
