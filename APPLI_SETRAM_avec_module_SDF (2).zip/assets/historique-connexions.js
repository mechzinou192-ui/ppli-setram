/* =========================================================
   historique-connexions.js — Historique des connexions
   Plateforme Maintenance SETRAM
   Dernière écriture : 07/09/2026 09:55:19
   -----------------------------------------------------------
   Alimenté automatiquement par assets/auth.js à chaque connexion,
   depuis n'importe quel poste connecté à ce fichier partagé.
   Ne pas éditer à la main.
   ========================================================= */
window.SETRAM_HISTORIQUE = [
  { id: "h_1788689557300_2mqnop", username: "Brahim.BOUNOUA", nom: "Brahim.BOUNOUA", role: "user", loginAt: 1788689557300, lastSeenAt: 1788709062042, logoutAt: null, logoutReason: null },
  { id: "h_1788702778090_fkgmrv", username: "admin", nom: "Administrateur", role: "admin", loginAt: 1788702778090, lastSeenAt: 1788702778090, logoutAt: null, logoutReason: null },
  { id: "h_1788698883072_qo684i", username: "Salaheddine.SEDDAOUI", nom: "Salaheddine.SEDDAOUI", role: "user", loginAt: 1788698883072, lastSeenAt: 1788707959279, logoutAt: null, logoutReason: null },
  { id: "h_1788679730865_q7lhhy", username: "Brahim.BOUNOUA", nom: "Brahim.BOUNOUA", role: "user", loginAt: 1788679730865, lastSeenAt: 1788709144036, logoutAt: 1788722930865, logoutReason: "expiration" },
  { id: "h_1788678931025_mh9svz", username: "Billel.CHIKH", nom: "Billel.CHIKH", role: "user", loginAt: 1788678931025, lastSeenAt: 1788708928354, logoutAt: null, logoutReason: null },
  { id: "h_1788704273418_q21l38", username: "admin", nom: "Administrateur", role: "admin", loginAt: 1788704273418, lastSeenAt: 1788707972832, logoutAt: null, logoutReason: null },
  { id: "h_1788704748902_5v6vp9", username: "admin", nom: "Administrateur", role: "admin", loginAt: 1788704748902, lastSeenAt: 1788707823409, logoutAt: null, logoutReason: null },
  { id: "h_1788708430155_l36w3r", username: "admin", nom: "Administrateur", role: "admin", loginAt: 1788708430155, lastSeenAt: 1788708707371, logoutAt: 1788751630156, logoutReason: "expiration" },
  { id: "h_1788760360752_x20dms", username: "admin", nom: "Administrateur", role: "admin", loginAt: 1788760360752, lastSeenAt: 1788762225933, logoutAt: null, logoutReason: null },
  { id: "h_1788761242041_ii9c5a", username: "admin", nom: "Administrateur", role: "admin", loginAt: 1788761242041, lastSeenAt: 1788761878927, logoutAt: null, logoutReason: null },
  { id: "h_1788762422637_ngu4fh", username: "admin", nom: "Administrateur", role: "admin", loginAt: 1788762422637, lastSeenAt: 1788764782954, logoutAt: null, logoutReason: null },
  { id: "h_1788763893033_2nqoz1", username: "Brahim.BOUNOUA", nom: "Brahim.BOUNOUA", role: "user", loginAt: 1788763893034, lastSeenAt: 1788771092174, logoutAt: null, logoutReason: null },
  { id: "h_1788763926843_wh3hho", username: "Salaheddine.SEDDAOUI", nom: "Salaheddine.SEDDAOUI", role: "user", loginAt: 1788763926844, lastSeenAt: 1788771319037, logoutAt: null, logoutReason: null },
  { id: "h_1788765641795_pkof0a", username: "admin", nom: "Administrateur", role: "admin", loginAt: 1788765641795, lastSeenAt: 1788770462007, logoutAt: null, logoutReason: null },
  { id: "h_1788765738667_m4289j", username: "Billel.CHIKH", nom: "Billel.CHIKH", role: "user", loginAt: 1788765738667, lastSeenAt: 1788766353436, logoutAt: null, logoutReason: null },
  { id: "h_1788766394888_n1mk1p", username: "Billel.CHIKH", nom: "Billel.CHIKH", role: "user", loginAt: 1788766394888, lastSeenAt: 1788771085586, logoutAt: null, logoutReason: null },
  { id: "h_1788771155071_mcb3wc", username: "admin", nom: "Administrateur", role: "admin", loginAt: 1788771155071, lastSeenAt: 1788771155071, logoutAt: null, logoutReason: null }
];
