/* =========================================================
   export-charte.js — Génère des fichiers Excel avec la charte
   SETRAM (logo + bandeau Référence / Date / Titre) en en-tête,
   commune à tous les exports Excel de l'application.
   -----------------------------------------------------------
   Utilisation, à la place de XLSX.utils.json_to_sheet / writeFile :

     await window.SETRAM_EXPORT_XLSX(
       [
         {
           name: "Nom de feuille",           // onglet Excel (31 car. max)
           titre: "Titre affiché dans la charte",
           columns: [ { header: "Colonne 1", key: "col1", width: 18 }, ... ],
           rows: [ { col1: "valeur", ... }, ... ]
         }
       ],
       "Nom_du_fichier.xlsx",
       { reference: "Référence : ..." }        // optionnel
     );

   Une feuille par élément du tableau ; chaque feuille démarre par la
   charte SETRAM (logo, référence, date du jour, titre du document
   rempli automatiquement), suivie du tableau de données.

   Inclusion (2 niveaux sous la racine, ex: departements/xxx/page.html) :
     <script src="../../assets/export-charte.js"></script>
   ========================================================= */
(function () {
  "use strict";

  // Logo SETRAM (identique à celui de la charte officielle Charte.xlsx),
  // encodé en base64 pour ne dépendre d'aucun fichier externe à l'export.
  var LOGO_BASE64 = "iVBORw0KGgoAAAANSUhEUgAAAWAAAADNCAYAAAHxk5peAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAIdUAACHVAQSctJ0AAFtLSURBVHhe7Z0JnBxFvfg33CBnQgiBJZtsZqaPmU0Im93pno0G5fDA4/kQ1PdX3lMEFUX0qQhe68GRZHe6eyGgEURFuaIgjyOcYY7eBISAcsilEAhJdnpmc0C4A9n/71dT1dvTUz3XHklIfT+f32emq6qru6t//etfVdfRJBAIBDsHzVpyX0U3vijFzek0aMdE7bKGUBTNOB5/j5qz8AglYWzD/9OOMabSZNsfWTMtPCm66Z443STICXPAH1YVSTM20r8EWUvOh1t3Kd1siLCW7MQTkRPJJ2kQOWH6t4Rw3IzjxdHN6tR9hTWAeaK0dvZ8iAY1fhyWGcvA/4t4//sJ2o/9Qmk9xLYnz1+8P/5HWHwQbXaeHx90IG+GlTKvtr/3t7XDmIv/Zx5jHCPpxmfwfxDcE8ZMvMLCvHGgwz9l//0S6kxq3m1Jtx7AXzlh/RJ/vfnBA3UVWINH8b+k934YfydJCw9QEtYX8L8f1c4/Rv+WEsvktnmvBv+zE8D/KGE718r+02TuBdFNsp90d+EIJZu/05vOvw/5075kT7nTPA3NGdkGWlq696F/CbH+/E/p31Iww2gm/1n2nwRS2DaeMAkAMKzkJGznOrYds/MFEgiwsJK0nguMJMyvk9947zwS4COWcd6if/lE7UKSnUzMHvgyhrGDVTphyHhD1M7n8X/rqo0HkUAgaucexl9vWkTWrK34y04efyWq2wgL9+9HKDlwNveuu50a2gN/2LZfJUr2Czhhbxrv/6nt3YfKunUB/vee9OFH901m24h3nxIwgkWGsq9Mxv+o1ywOfxspYW8a739G8eRO2R3/4wtlRnzRLPyv6OYbvPTjTq0nQdItXUouZLuDJxPN5N6mmz6GJhQvamgCDdhxwBPzC6jWeTRaIBAIBALB+IPNB1IieTLd3DGRE8ZL6FZKCfMR/CX/deNy9p8m2zHAE8L2NLrpOu9e6j5pueOiSfQvQdaMF6F2sJRuNoy/BJW4+fWgk6vrpL212NGCnYD3RPC/1BncLoHuJv1bDu7MMmMnHItbU+REsX3LeyA/kMat2aoJ41mly4jKCatP0azTw/OM40k43d+bT6U8EajAvkP/lgMPwmtwoufK8b72sThhyJ+oVD0njHBLGXdk4j9hb1wjQg4Q6tub/AJuGMD+R+I9Hw11LtBIoI9AtWBVFPwfzeSfkI5ekMAMpY7kf7E4JtFsfjGmw3ivvqvp3EaWB/7G0s6tJGLVqj3JL+A/YbV9wTSwxW6zqqIbJWrA8isB2yJimbyN/1tSzuEk0EM0myONHmznUOqlZvyN2Q5p5y1eRO4R/I+46Zatn0wChoYmRNPrTyP/AXbS/l8GnPQq+pd/wgyMhBO/DH+9Cf0nLPW/dgT+MmJ2/k1vkxLvIN4w/wkivDAECuVv9O8wrIGkLZN7V8nm3FZEdhDvCaPEss6VuM2odMKxFQUZf71hCDtBpcP8AP5K0pUHoDqgYByKfx8XMB9bMVLJ5v+C2/jfm9hfwjG4MPxl4MlWO2HEG46EEsaJimasw/9yh6nD82Di/1a95zBsRPGnH3fUrHN2rSex3U+WMam/cEClk8G4HeZkvYDe97OT8wqNFggEAoFAIBAIBAKGkjBvY1XdSiInjLebms50W1UEAbR0LD7cLThsqlK796JRbus6SqSrvB+PrCcvZPFQrR+kwQJESpjXscJBocElsDg5YV5DgwKJdPZ9qlJeIwYbKitljnHeliYavF1g58BE1sweGuUiaclNLJ4G1cRktdvtiVk/87v38J5YyNMUXV7AxbRQqF+kAQS2L92sGbCNm/37kfw1g7T4tbYvOAi35UTfV3Abv/DhdkvHopIGYpKmy9rA/qNMO+aCsi7ULI5u1kXzyjX7YrNP1M49Q4Nqg5ycbr2K/6FAzyXb8b52ul1SwOx7AvsIwsAwb7pawQ8l/v1IXgnjWfyPH06Kx7P6yLZmnY7b7CMKgtt4nnTTPRdVTU6kQYRIe++hJC/d2kSD6mZyytkfCzm2In8SDaqMezI+qVbAXgG7RwqpEYGL3coLZyJ3GieWbGsm6R48ba5BGuNb41YYt8nJUVhaOK8f0SCCpBmf8KdthJobMIsuSX0EaXDtdO/R2m5Nw3+K3juHBI06S/ZkhUwDCGBuprHwSuL9/MgjajtGzS3ERN0zuW2xdK6bCY1y71Q0m8vKsYt0dgLkE0pm4wdo3DtRO38VCuu0G7ML14JcF8sODJDtbP5NzE++b+Ck6MMvL22mj+5MePwxHv8j+B9F7c/d4H59uW8gXsxj4FlvUzjdpWnGvbkp3m0GmJLn8FxbZ/UcRoMIGEb/4gvv795tP/B+KPmiw4jZzrW8YwbCThqFdRxWMzny0Y4kCADj2WcmhBUw3XTBsJbU6n14ceQzVNYZJN/PPP3REeyMHJQf/UvAbdh3C910AU18yl+Actw8A16U7idXjK9UyJG4NQvHHtFNAh6Pd15lkETdQ7vRTYJqOy+RE6ZfRWmwS1smdxX9S/bnFTCk+S2mi6Wdf5I0mfzrGE/iOAKFvAELmvXyZlQqYO83QDjnb5Iw0GYa5OGU3bEAJd28ggY0qeByeV+KLbPNg1lBY7isG1uULvMV7/tB7kySD/hgHv5KzmnpE27FJRC8cJJ4qNghGr/c4rZ673oVt/E/pHHwP4LbJD2FxFfQYDQf/vT0rwv9kDqiAkbgWBkM93bB9zGBFJTPg8AwMBVtdBNqcb3fwC74rGC9Es04/4fHCKfXKzR57UyzNx9C/9ZOKrUHES9DQ+Vd7TGMiZ+lEAYSWvbs3ig01KXWMET+29pJWAC8m8IjohlfwcKUEtYGbKuAd8ulcAN+B/8fA00ejIBLSJOWKdcuDbw/fsIKpCW16WAaXDdqxvkflk/7qnX70WCBF3jjr2GFhBLLFq6XM/nyGl7KCcE74wFv2qhd+A2NFtRDaPmLM6Npx1AyTgpcyLvAtv5M6t92AI0WCAQCgUAgEAgEAoFAIBAIBAKBQFAL0UTfTJyZECf5UxLG+0MfGe6LJ2iI+XvIXcbbvC/FflG6rN/RnQTVCMdNpbQAjW1SwrzY29020tkzI5Lo+xQU7NPetHLCeJBmI+Ah69arrLAkzfwqDSZ4C5IGuUxt797PGz+yfsHvUVjhgLb+iwa5hDvMD7jxek/gTCxHdFw0iaWDmyUmAGSwQkGhQSVIiaRri2lQRVhaSTd/RoNGF7BFr2Evc7pZgqp274X2jPyv8YTHElYYTGhwCSwOe1/SoKpUym/EYMayXjrPN0PWzH9jfFgzT8Nf7IlIo8YduNGrWEEwoVElVIqrTHdJJ8lRA08mqIB3JPA8FW3YO+AVYgj836C4Wohmcy/F7PyddLN2wEVZyw6MY8hoMIGEeQqYd4It87v3Iek6jRNpUM34jwma+KY3f//x/NuIrJvEY8D/LN6fBoFKxaMkrsGxb6xLFd2sDTlhnuE9KRQlYZL+vAhuVyvgSHuvTPf7Pg2qkaFil1Kw8zSgaoH6txFvGPaU5KVB2M0LdfaR6anqpX3V0J5YwLFsjgzQqQn/yfC2d+QClhK9n8RtWS7ODKhoyZX+NIyg8HqoW4v9B+Vt78gFrGjFztJ0E/v8nupPwwgKr4eYXfhNzQUMj8yl7KB+oUnISfEK2CshvffjvPBq0qpbMV54kIA5c98V9HS4hcYLQ4LC6wULWLHzp9JNPuG5Ris7IE9osqoFDBe93B9Wo7wLGv8uJ9wVRTd/XPwtegfgFt6MvzPn9h5FTwdt7luSbv2BbhLY/nTTheQBL0S62RSJL5ql6pd8PqxZn8ZxGjS4KsQOZ5z76CYfONnz/cNRayHo5GsFalIfxF/Q+jEaI1e5gGuRcGdyNt2FCxZw1HZKxpOUEdGSZPxBWzpPRs0wUVOO27gxM7PhKHK3bGeN/yRi/fmrvft5x7C5YVmHjI9jSImFR5D9NTOLv15tQpTMwOlsXzWTKy6J88TQXjgDIQmnQ8y8RO18gc1kyACNPgXzhyfkJhpEwCcBV/lojS8MK/PMOKahUSWgHceWOLpZBp5LNJNzn+qKkIuxc33uIMQlxSk+Q6nXmklGdm5r1C5cRQqGSnPzd/aFwrsC49Ho4yBE1R48n+SVdh4lgxBxMCJnEZrw3EVkjPEMqPXBfmvZFKRwwsvI8bLOZnDos/gfBQsX88HRlSB01NLwMhEsHd10YedKNwmynnzSG4b/p7VdXGHwT3fpAB8KHk/NOk/RzcoUE+fvhov9q3fMHIZjzYVucvFfGG6D/JhuErBwQF5WMnkyMpQGE+AmfJeF4W/MHvw0iaBg2MzlA1G6SSDpssODDkHT3/bni4D9JiM96aaLNwy8F9LwQzfLgCfsQvq3hOK55hbRzcrA2/Ac3IGJ1L+ZLIqD/9nsp0FgGvqXQPMoKeBoJn8/hoP2kUGJNLjIEF24hP36IPtlnT/RTYKazq3ypo1mCkTz6WYJWHjoxtFNQrFA3dlPmJsYOGbbfwPCy53ZeDz5jvKBNFWBx/4+drL46xeSyIM/jKYr1+Bs7mV8pALzqKOAJ6eG9gez8nu6ScB0Sjb3H3TTJRI3f1AsoOJ6PwhURE6XE0m3QNUu8wVSyHQFJj+SZpzN3lcIPD1k/DXdDAZOfHXQRbHfiG80JWT+ezAl7jcr//64rWach8gwWkiL9pOkgQJkBcyTegoY8/WndfPhIHnaKRj4sovFLHfYLcYzweq0kjBexsqPN5wmLZ5TpVnGGfDWv4N3UiyMZNTvnEsCKRgGhfYK3XTTMnDbLzQKp+gdFQ3mFbCazd2AYWrA+GEo5LJJP5SE9a7XTQWbvR7TYJMraPN3WMHKWu/Nkp78EqaBF/gP8DjNd64pmeiDT3f3bpg4lh24i4bgQG/3rY8NGvifjZSMZhyyWFp45eCRuI2wtAzcBiEmQlmxvgW3Y5n8C7jNLWBWsCMsYATDeG4cAypExBOK6FYHDUJ37ruyZvybbhaXItWMPG+sMsaTY3COHYiaKXyI7cTbGbyLV71x8MYm07ow/OlpOtcGhx/cXJw/Iu38c6wLGNL9gqQHl5EGcYHCK5CCjlsl03lFdONSnD9C6TJO9dbq4CV5n9JpvB8Hq2P+OO80jaodqdpOOGCbh39wd3HAd+lSZriN4ThonDcYnIYFDvqmK/W5wHbQYHAsABT13oFOGhQIrjkr64aNha0kko/K8eRvsW0GXoB3QgVlsxI3bmVVcripKzBfrEyRnXdlWCGDRnfRoBEBnhUZ61zTi21XgRUymLSnaVBDsHxAg8tmU9nlwVUZ3QKyCyUdT6oBL3RSOSrum/8zDRb4CWXXq6ygioXlvKmk13/Uvz4n2nQ1M+jODcGERguqodobp/kLr5J4WxQFDRC1B08Du/oXNZ1Lgwm4WunPf4xGCQQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBYNeme7eW+MXTZd04T9GL603XLsY2RTefgX2/EdaS7iBUgWDMUPSeD+AIYb5Cjp4oCethVUuG6GEFgkbp3iOiJ2/kKpluvKNo1kqcY4wmJoS05Hx+evMZmqSMcNyMS5r5BM5TwN83adCkAkF15HjyDFyI369Ispb8KU3CR+3ey78P2U836hov3NLSvQ/sczkvr0jC+BRNJhCUAlbyFp7SNDWdSaZjqwZYSq61ptENI2nGH8vyTZiX0WjBro7cZX2zTEGoSDVaz4mdfQfy9seKHk0yYnAiGX/+UmdxNs0dHqg8uDOoKwlzLQ2uCVkbXocF8wnryc+xbZSZHUbJ/H+7ErJubvWWhV+grG+jSSsC1jfl3zeiGV+h0aOKovcex44xSVpY/yxH2wOvTwb+UW1TkzKKPtWLOCMcVErOwiBFt1K4Xo7SZdU/7f97gBlzFs1i5YmidJkPYdOWN4yE6+aX6S4V8e8n6dYDNGpcmHrLuv3o3/EB11uLxJOPQ232eSqraBSXWhQ4FLdOkBLGs6puXEmDApHiyZPlhPkvsDC9NGiMwVVtzIdxkn0aUMb0OT0tcD5P4Vxq3vkwGWHNOB7XTwIhU/b6AaX5OTZzRTqNL9IgLmHd/LxX2aA8v4Hh3jAmleY5ZkDF6pf+/ZpCZ4/LGnpqZqDTO5tMJJsb08VsJoBDvtF/sV4Bxd6IK4LR9C7VFDgWt6Z48wHltGhUGWxRAyagNHUublAvQxPgfMj0lsVzG14UwYv3nFR4EGkwQekyot54OWGVTJKoaNbp3vjwPIPMU+0n0nnJh7zp0JDQqCZ4MNxzZHJIwDJTXvDN5t0HyvNHNGpcULO5n3qVOJRdP5lGjS7wmnrFe6Fyl3kaKitOmQm+GJmJ142L97XT3QhCgUdHgUvcBN/82/gm9OaBMnn+4orzYzU3J/f1tt+iT93UlOJOnD6WRLO525kCw/93mm9Ysy+NGj28BYP+Jw0mgIKeWxIvFHjUFRjdExaPs0rTYBd0Tbx5UJlGo7moXQumedMrXcntVqeIZfMFpsRqxql5Mb+aAf+s1H0AC4BPcLHhum+ULbDVh/nyRJprSiVpwfrz0o2WYFOS9/WMChwCH9GbBld+9J4T+vLeNGpnn+qNh3O+xLs/KOSXvfGRedZxtGgIkxJXHlBahlaMRrnAm3CiNw+SLt7znzSaS0S33BYBlGltl1dY0mJsiawodDAFRolkBmbQqMaBSkvJUsK1ykgVOEhAka5ma4mMh0DF7Y3WjoVzeXG1ipJIXitrwcs5SQnrZDZPf3HbfIsWi4sc7z2hUjxD1S0yzTwTWe+9gUZxgTrNJ1ha/LxMg7cbbM0ElGg2fykNboyIZn7bvbhEcjUong2vsf5aJDxnQUntV44bK9x4zXSn3Gf4FRjSrWXpJc3MQmXlHEW3bsRtPI9Iwlwy7ZgLpkL4zyEszdKOlshd1iJ44/xyOMy4FZewIjdcTy7zpg0UzfwF9kXA/5JmZcENuapV7zkMHsBloGjLFM34Gra/kviElQEl70VLTouESyhUeYV9XNCzpBw1y10PgkdYS3YOl7n1Opzjn+EBeQHOqeIaaF6Bt8EmSH+dEjfjNNuGidr5pR4FLlvxui5wrbNI+5JD6aYLTrSr3rOuTGh0RdSUc3jrii2HNTX17Y2uABO5M6mVFEpH0pq4bPDA2P1bpviFHa/1roHDcGEl7zl4pRWkbPb8AJQu63V2bLgRn5XjyQfZNj5ANFkVwFfO5Ke2/L245kUloulBBcriI9H0+qrNXPUCCjjAzh1FnttT5m4w5I5L3aXNaxFJ63sRlTyi9/5E1cyvwv//BYNyOTzgj7K3LFYKwwnzaHqIuoh5WiSi6RqXMquA+xlRzTomyzhIeDNCK5ncp/zpcN056egFCX/heKUJLE3MHnbqeRLL5G1cqIoXxxNckm3KXQPvo6fmEr2/cKw8t9f173GdOLCS7pcpZW7vbdEVpesiMWLZAbK0QyWRV+RPKqbND/LimeCKYUfcs5Ys6urHPzs3DeYytX3JfugOsPMHf7uswudFggo5uU5wl2iQi6uUmrGOBtUErjGCFd+WuDmdBtVENOv0DpeH49DgkeNmms0/RoOqEss4G9z9+vN3e+ecP2rOwiNwBZtSMT/c1L6kpOMJ2z+azXEXwfIqMLxyuO2X2K7IVgdCiaWdX9IoXP7iTRKezQ9JduG/aLCLYg8ez/ZDaYE3CIZL/QXJGy7bgxrZgQFvBpydnMWrmfzr4XvXHAkW5srWezaWtM02r1yzL/h+61jaWH++rNcYGgdcsIylCaUGKy75PMPnkkkVujR6K5ATQ30H0mBCON5DFoREAQUP7FIZxIz4olnwMFVeddNDzM49wq5RaWRx9SCimdy3WcZ+idrOVtkulFTaYv3O2SxeTZcrRq24x6hBgUFKVqjzA0r0GkuL2/C038y2K9Z4f7d6H1a5gIeSLGkF2y/jtprOBS7hh0QzGxLsGGp/wX1weOAaMiwtDSoBymAzi4/ZhRU0OJCZiUU6Uz6igAnzszSqDHjtr8Y04M+uoUEuYMH/5M2nZXZ3zevyMuSE8bakJauuUsKuDyVqFz5Bg0eR7u7d1DvXTGxJDe0Dijs7lhn4t/egk6kbAa/3y7zhQQJOu7uEIA833SgoMK6Dw9LitndlQJIgiKGhCWyJLXyreLfh/Ctal9ZVGw9ix/AvF1bG0qHdo2nnXCWdfz8NKaEts5Esdlo8j9y2qit3AX5LDP7qeTSqDKjzkI5BoMSfo0EuYMG/VZJPwtrA+1xeCWx9Amtf9oAwov35xez6UGhw4+BrCxfhIwvxeVahLQMqSuygUbByGORVYDWbewlu9GqeVFuW3M13BC6EdHPhAK8LofTnL8JwrwKDvz0AbkQuSNjreywVGB4wsv4dipzNR2hwCVCxeYalUdOVj+1F0Yor76IoXebrNLgMuau4fKbcZZ5Pg4bB9mq6Oq9XwEJfQ1tPSpevI9un7N4yv3ufafMuPwRckP8g6RPJ8g9BS4b2ZNeFEvQQ1wX4uzmWIQ0KBJS0xJqBIl/CttUH1qskUQAsHdvXCwuv0QJXFFDSN71Wy6vAtcp4KXDMtwatC139k4madv5IY6oSOrpvMiiQ2zwG1pD7xorMtTqoYkLlr7w/cCixaKa3kliPSJp5e7jTOAlX66TZNeHyqqA/W4evqVCxY1jNRLMbulimoECP0OAy5NTA51g6bBnAMOnmpw5gYeh7koQcoKZ5IUsHspQGu7C4miyw7fwcFRRFuT8fZuEkLu28SHdx2dFciJoUGAhlX5nM0qHAddxNo2oG/OHNTKkiCethGlxCqLPvQGyFQAnFkyfT4BLAmv8Y88A0Ec1w15Ukbd00fyaYRkpY7hdNSDYB3SZv5bQNDGExh1FC9a1ihwKWbEXMHrgDrOzr3nC4me4q1UhLCio/rJbvpsltAiV/AcLdLy4kPJPjWgM3vkEfWE2tCeG+bj72cCvKzqrASGjZtr2xWdDNG/5XdPMCiMQXzfJ+vcPuopHOSzgV2u7dIrp1FnYYAlegAJb0+0HD6SeGug88ouPSSe2+FiUkEk9ei8eR473tEY+BJNeQzdXY3t4A2DsIar7XeQ+IAjfyReX+l8M0GZ+hod2gtv5db4GTfdPOAzPuzblLmvMYPg5/kenQcmcmSwMK8gsaXIayYmOL90mHtKsVTwWUJuPjUVg1k9tYotDZfIGm4lKiwJw3jBfwaf/I0qr3Vna7GHAeL7B9yH7Z3OdpVEOg4skJ49dMocGN2EpGL2vJqksj+8EHAVswwP9+BT9uSFrf2fAgkA9LUG5uhZqcd7rwSbKTYNdDyeQ/4H044f+78oqBwK9vI6F1Vs9hyty+OUo8+TFcFB1HGUtx81jSwUpLVl3CH1zGu72KC4o8QKMEuzoxu6Q+QSSacZI0ersxzd58CLiM7kctJpHUurJuCgJBk7xy8NOx7HCvLibgY/4Q3TmabEyZlslPhXrNWv85YJMqTSIQVCE1tAcozA1+JUIBi/gW1EGuC68cHJV5zdrS+Y+CD/8o/1j5N6XMhgRNKhA0hpzNzwf/+BWekvEEP0q1ZZwN0XQ+D9Z0I/wnFddqgj54zB7ob6RVRCCoHfx0nXE+rGQH/hKzS1sFahWwrv/CzlHYGkRzFQgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQ7DoMTYi09x6q6H1zZN04SdKS/yVr5mmybn5eiZsfDXddMnvavIsPoYkFgu2Lqi7eX4r3HAtKerOimW+wteFqEUWzXokkktdG5vZ0TG3v3o9mKRCMPbJufRwVEJd+5SlnvYKLGMoJ05E7TJ0eQiAYbbr3AEt7lcxZbX40BZT5dXhAfkIPKhCMHPBnL+ApGxNcOV5JmDdFNOt0qcu6npdG1owXm5u/s28I/OOIlvy2oht34xKyvLQokOc7mB89BYGgfqbN6pkRZHElzdokx83/pUldQDHf5KUPz724lSbx0b2HpJsL4SHZwtsPRUpcegRNLBDUhtRlXM/zcZVE8vGZc3uPoslKiMWtKf70ZB+wtDRJRUKdPaqiWwVeHqjkNJlAUImlu4MSPVemQFryxYjeK9NEXMCNuMy/H9lX76trlc1QZ1JDt6Qsn4T5CFhssfihgM8R8kWTyprDwApHEubXaZKKSAljoGRfEDlhbqbRdQNuxSL/W0DRzTdCnd0H0iQCQZHQvAsnexWFCVS+/k2TVIW3vxRP/oxGN8pukmZu9efb1HTK7jResKvTMts8OKjyBeGX0mQVmdmR/Ahvf6yk0SQN09LSvY/cZfzbmy9W+mi0YFcHlGGjVzm8ImvJT9NkFZE1s8xvxqYyGj0qoA9ckn/CGKRRtXH8PQfRf+MPnOwf8KQlPZmkQTUDr6Cvoi8FhfwQVlJCxyyaic1DUOnYHDr6wsk02S4JVNjWe5XCL9PnmhJNWhFui8Xcvjk0etSAh+15N/+E+W5T05l70qjqnHpXF/03vkjx3k96Cyai93TQqKo0q8mJ3n2LFQPrXXe7y6zZx3uvARW2X3jLhitaciJNHsiMmDWFp8A0etSRdHMN5i8nrKU0qDZOvesD9N/4IndZ3/QWDCjhSTSqKq2zeg7z7guvNbNkO2Gtpkl3KUKJRTO95RAk+MaiuwQS0cr9X7hHl9PoMWFaWwO92nZGBUZAaZOybr4K+/0TKxURzeiC/xuxAwk2ntNkuxTMirllmjAe9G4zockrIuvWn0r3M7Y1pGCNsnRodyLV2FkVWFBKJGF+1lueimYsgArSdd4wJnSXiihdxsvefcCdeJlGjTmx/sLcNjs/hFJViUdNgZuT+2KlDArtX2Adn0cJa8bxNLaM2hS4ezfwiZaDY/+UNPvi6TQwgKW7w2tvJVrkGXFrCg0cU+BY52GbKhw3sIOKrPf+SkoYz4b1Hu4DqnSZd0lwzthpnAa5TEosPEDSrL9LuvVAtdc+Kpi3PLFNFcptiTesKMY2uktF/PvBA/EXGjXmRDO5dUyBo9lc5Y8mo6HAclcSlJHfjxRuwH/RZCXUosAQtnQ43nqVBnOBB+Z+lhZuZn1NMQ2g6OYH2PFQQAHLPskqid4Sq4ijG2gUARQszeLwa5T/kyoozToWX+njQ6jTOJGlI2lhG8OhMnuhN5xK1T4M+DD595NqbLkYDWJZ5wqmwChSOtdGo8oZqQKDdTjFf7Flohtn0uQutSgwWnFvGhrMBXzft1g62O8dGjxmqAnjbO+58dpWwbpe4U0z64Se99EoAlyz21aLzUehUN/eNIqASu3dnwaX4W0tgHxciwX5n+ndHwX84hyNDiTcUfpwYv40atyI2rmtrhW2c8/Q4HJGqsDe5qtKAhWMks+PQoFHR4Gnz+lp8SqwHLfOolEBLQnWGhodSFgrvTeQ/+M0atyIZpyk1wo3r1zDb/obiQK3zu2JlVyobhbkY4ypzVpyX7wZJXEaviKHEQo8OgosaebioDShub1zvHEotSgw+OTkA5Nnnwto1LjRklq9j1eBo1nn1zSqlJEosN99iOjGF2kUwRsnFHiMFDiRdDunw1vuHhpMaOlYdLh3fyJgZGh0IFB+rm+Ogl0hadS4omZyDzEFjtl5fj+JkSgwPJmf814o3NT/R6MI3jihwKOvwP7KllzW0nHmnt54Kq/TyEDkhPWkd5/t1V83cp/T5bXCTbesKh/pPCILnLBO9l4ozhdAowjeOKHAo6/AUtz8n9L4ckXzxg+nqwxY9Vw96ceK5hvW7BvL5LYxBQa/+Oc0apiRKDA2HXkvFJT0FSVuhbGrXHv7kpKnfzQUGPPEvP2CbaR+BQ5KOyoyv3sf2VfRgZt+sjcNKiMoYIkCt7YvOIjFN83v3qNEgeGcVbV7fzcerx+spXd/UigeFD15I4uDvLivWHAryjqk06hAZD25iaXFe0CDtwugtG95FPhpGjxMIwrcGl8YljWjxDpUk9FQ4CABV+asoHbosRC5y3gNrqd6p5kKgq0ykp4MHPSIIxRKOiglTIcWiwucg9vdESz4TTS4BCjXRSwNExoVCKRxRxbDW/XPNHi7ELXzS5kCx7JO+dfAehX4yM4Fzd5mm1plLBU40nnJDF74WImSSH5MhsoQL65WQf81qBzB9Xhl2tE9qjcs2mUeS4vFxWspofzK2toR/ADhzQdlkrTwABrNBdK4CgwPxo9o8HZByjgJV4EzuXebUkOlnenrVWBJM59gF1ePjJUCY1MeWKrNvLixEKjg/Bqs0s28uFql2PHI8rymk++w/2CZXw13mEd7lRvqGn+lRVICPETul7ZmtZvbThoKnb23v60e+07TaC6gtG55hvXez9NgSvcebUUj9v5QPHky1nvgQfqcnDBODB3TN7OpvY6+vLWwbNveTIFRJqec/WlMkXoVmL2qic+pWw/AxfbXKGmaBQFu4qne+Na4NY9GufgVGB6erLuPZvxG0q1zhvOw7sRWEbljkY43fDh8lEQz74roxjewqQq34RgZ+L+wZXb3wRB+acm5BYhKzsv6oRumG3djRWymZhyD2/Bw/BJ+Lx6ON2+B6wzsT4Iwf7kSoGyD3nKMJIxP0SgucB4OS4t+Ntzrv0EeJX0tKgk+MNi/Q9KMs6VEZWtfC14FDj2yvnSwQv0KDMqrGX+km2OKX4Fp8LgByjUdJ7pjgw1DnX0HRjqSH8HKGEmwkwAPesnMOlLCvJpGcVE062lv+pEKPAB3QLYl/UDqAV0HpsCz7Q1RGlykXgVGy0D/ukyzXzxEvWfdNL+0rthyGE0SyKSbCwfE7t8ypSmV2iOm98ros6HIHZdGwMKV9G/F9GrKORzTeyWaWXsUOyZ2mPFu+6X1roGq54TA2+VLwzfAeG2yunh/uHbyKkYLU+uwpdalzx0UvnfNkU3dQxXbUqdcPfA+NTPwIckeOHbismdHdYj5dH1xC7sWFElLVhw8CQq33Ju+kmBTn5xIPgj7WGBwzgHl/xo8MD8HK38rhLmWvJ6R0H6i2eF+EbMzg500uEi9CjxDS7o9g6SVuTbs7sYy90s0ky/5MuQlZjsXxDxNJPKDG2LoJ3sLxytSIvlaCP0hT7sgT+R71k6CJ/ZlXpwrkEc0PfBM2H5pNj2dMkBZH/YeH2+Odzuolx3SZm8+BGrM9/mPC+Xxels2X1IpkjP5k2J2vlCWFso1ahc+QZNxUbP575D0UI4z71zLnVmHAedfMkIZfWMaVQa4EH0sHbo54bgZD4HfC5Zbgm0y+gV+36nFfUEUvacF3RDw2cuMXy2MqgIPA5bO02OIJ9GMU67AaGkzzov+tMrft0TBspW0e3pF0ZIXy/ag5t/PL6jAlR4qv6h24Tx6ZsMMwbX99/XfVnWzeGwcKAruA1pecj6aMaTc/uJnQ8udsspQ2N44m3ccr8QyebBGQxOk/pclXrxXotl84BB4UPBnWDo1k/8DDeYCPumV3vKM6OZ/0Kgywpr1aZZO1vtKWjfkuHUCi8O+FjS4JsAn/g3UFW6nmzUTyw67ENH0oEKDizSqwNG0c66baSa3Ts3mfhpL57q9El05WPJlDonazvNsP/zKgtYSwv46/eHXW4IUGGq5y8i+Weeatqyz0t0/7dwatfNXeWXKXQPv8yow7hOzC9cxgXNd5rX8KPL9gyeQk6PgeWH49B8tbwnPXeSpRJ2yu9xpnBR7eOMsjEffDJWdRjbJfyPWf/jLUTb3DljiB8mxs86gNw7eQGukVOFYN62dfwPPFTutgKV+zZtWsfPcDvNgIO4f3j+XocFcWtTFJf0i4I0WmH6KZ8whdsinwYSJoe4D3Tit/sGz4F78Qe6y6hpbx64RpaxXWqMKDEqQYpnSoKrI2YGPe09G6i+UdJKGV9d34AK/ywQ/UEyH1w+NJkTT+XPY/vCQcCdP9iowDfIzASzbRSyNmnHeZu2L8GCexcJBQV4jqX3AQ7DWTQMPJA3GV3qOhaPiNi0tHUWBPjgo2jvuvpn8Z6OZwvdlO1f2GVrODJzk5gUPHG9oDRzjejdNdmCABgeidFmrmfLh24QGc3HTQYWOBrnAG8k1NPBmqnv8IbiK6xXNOJVuVmbJqj3ZNaKggaIxRRpVYDntnDZcePlB9PlQqeF/j5Qa4A7/gTRPsn2UTL6hA4OlchUYFIw7wVwNCkzwPoRKOv9RDAMFfp2FqanNIZKQA/itb7B0WKgtULlk22A9A8ePlTTM205J27gfUMo7WVrlvoE4DXaB6/8+i0ehwYHI83rbmeKhyJr1HRpVhtRl3M7S0SAXucs8n8XhqBEaXBfok9cyymNmJn8Muz7yxhvphwwvqp1/1VuAXgFFuBf9XZqU4MbD65EG1c1oKnAktU5m6cAK34QtBe522in7dOtF9Qx7CdvObNj+jLtvfz5QMRBSmaNpaRCXWLboqqCAa/EnGuwiwxuIxZO8nhjai0YFgi0QrvIlkoEPWkgf7ks8c+5lJRVEcDHex+JIPrpR0f/mEdbM09CS+4dZ+Ymm8r9n1wdu6iYaPMyIFHjpE3vxatBMVNt5iSYluHGZXE1zy/IYTQWeumpoPzevbO7hSf2FAzzbWZqMC1jvb7K0csY5Ed4832LbSjZ3HE3GBdyXx1laLEMaXM6qIff1CeWMbaklkFYZGo8Cb5GP0ahgWrr38SqfpPd+mMaUwb4GKrpp0CAXUL6SjvTo7tGomsEPLDholW5yARfNfdNB5bc87UgUmIGKAP7sAWDRDgWl+p63UMFtuJImK3HGKwlNzmV0LXChxAK33rPxILYNhWXTZFzgus5maeE8PlxyXv2FD9JkXLwKHFr2bGBzFhLJOl1wbucFDS9HN8Q9bjpfU8cb/KroKh/xhfn9fSNx8+uYxt8NoAiOGDdec/PBdAnjhzSyJmRtEWntwCUKaFApUDbeyqxqF75BY4YZDQX2A4owDf0VPCjxWyjsRKoJTc5lNBUYXsvLWTq0Xl4FrmaBQam+4aYdQwWGt9h52GaN7g4NKsHrysBboKJP7cXbVRM/y9PgMkB5SceesGb8Nw1ykTqMuSwPNy89eSONrgnaNQF0pNyVKHORoEJHo4apV4Hxq1tLatPBLanVB9MgLtF+5xp2YLm/2FrAtlGpQXmeh5u+ukzSAxUrBZBmVBQYFONClgb+b8XKgVeB8eNAG7YqBAhcg/uxZCwV2M0zk9tIg0oI3z+osDQokczADBpVETleWqHDjxU0qoSZ8Z5ji4ppvMmbv1fSkwu9+aDICfOtSOcv4TyIZfcr5oQm7Cs+f/H+WImLdCUfJ/v4BkMg4DatYNelBlx/3QrMMoSbcDMN4jIzs/YoljZmF8gTzrZBASp+ygyn1+NNuQp85avUBwofosGEehUYXvVXYD5Ufgvb/4fKwOKJpHOfxP1KFLgOGRcFtjkVGGRoaIL3Ndtm51bRmKpImvnVYaUz3qbBZci6WZxmiiwHUE5Et9yO9V7BPNHNwI5AKLJubMEHwf0g5BFJ83XIB4MyfE1wH9NOmR9OaFSBY9ncYhrEJbRs8EA3re1ci2FsG25gxUlKopnBE4fTOiVT4derwNUEP8DQ3XZOBQZK3Ah4u2HljkZVxfuFDizn6ziinEaVAAr4KEmjJy+kQSVAPjexfOoRVGh4QD6P/SlwRkyaHZaR206P0nznKA2rdwsq61Qc3QoK/gWWFpxv8jkSFMttxPd+wfIDFvISlg7bTWkwYbQUGF5PW+QVAzG6C6FUgXMl3T/9xPoLX2Npt7cCI3A/hj+3ZvJ1TVEqx5O/ZQoFyrQVlJirLKBsRIl5rRIIWNjzvCNjpC7z9sPn9U1uwU5avomsi2JsawqdvTcOv4L4DfhGoFmV6Eos4zxBg8upV4HxowXLWEptCpyvDJTQ9RFpEJ5UloX5LasXlfWxgFdj88o1JRahXgVWU87+2EKC4j0+vnaxbwXdheBV4B2lFcLNs5oCe/xFlCPuWTuJRtUEvMK/xhQLrO228ByztM8BBeJYZ55BXusFDoWCeFLxK/nIAYrK8h8WY5tEJiV3+5iTtyGU5VXea4kFVGAJ9SowPN1fcTPPOm9JqfVzaRRh6i3r9oMb+hxLE007/6RRTa2pNTF3XxCoyZ9PowjY7RAqVMPKx/Hn6lVgGuQC5/NXFocSS+fcfhA7swJPuvkptw0bBd6AXH+1Ejhze0mPwOJIkDIlbW23poF1/ZeSMN9VdMukwSVApVCRdWsZ+rvo/zIlrSQ4kxB+1UQ3yL2WjLOBZsmnXgVG4AY85i0suHl5rBzB/0dLwjO5t6X+p0p65IPl/bU3DfY0gvxWw0m/UhJOJrIodzNGqsAIxN/O4lEitkNGg+zMCoxATf23LD2Kksl/lkbVBbgCl3sU692gJblwjTlwJ24C/xWt6K3Fzv+cWTTbz9wTl/uiY/FK7ikODkAlxxk8cRsMpMPOH9+Ss/x9H/w0osAIKOJqb2H5BT+Xwmubu5xoLFu4Ht0D3n4ocOIv41cxmryE0VBgJJYqfeXCuc7d2RUYgWsf9h3BONRToStlyZ7gD9+CPjFTZnAbLg3yj5umdu+HPqySSN4J/uwLERyKpBnfiXT2fCjUtqC5zN1Qu/eCdJ9UwTKD1X+IBGWGmzZRoIJ9A0lbiUYVGJGz+fl+y0kOnHEuqDYxsbJ8fYv3RqJgrys1mz+j0ugFxfOlD9yNsnF0iJrJv8bS0CAuUHu/m6VDAffiPz3/H6DJuEDhFjuTgyjp9R9V07nvutvZQsVPybDvUyxtrQqM10SDKtK2cpPb+YXsBw8zjWqM9iV7RuLmR8FKrmWKLHeZG0CZfw5KWedyW927Sbr5ZVkzn4P93wEX5LHw7OSRGAP34iPe8wYDiNcbWNF3OWUZVwfqAxQOO5Kj/0tD6qOWqeQZ2HoxBOlRgmDxvs5EXFhaENIvgW37ukKWUXoeE7AMUBmJQlZoYSHAcdy0VWDpaknLIG84rzKAy0ejRoyk9ybAKv8KrOcA+rXY1gvKjd00cVDrdeh+oKXGX6iU/RnC+iH9GvStwUI/AWG9kXgvKN2w8sPbTyrxe0HCdi5gIXEfxy/dqcYnCmoklh141qsQUbtQscN7o2C7cXie0Spryfk42lnSjc9gp3/waefiMKRqw47U7Ho1ajuu24OupWrnT6HRgl0Z8JtLhnyBi/YCjdohaEvlyoaIRVOVP5AJdiGw7duvIFhBVoO+ao0j/gobCrwlAjsVCXZRsBWCW9G2nfKuieMAzqwTzTollXcUCOulSQSCcqAi9y+/0oBLsaH1HpxLY3yQs8PjDYfPIfcuWOP/oUkEgmBiWedKvwIRJbKdJ8sGS44iUDH7FBz7Td6xcSwhTSYQVEfO5I/Bj0w8ZYqBlQZr+N9N3fwRGvWAH6LAul6mZvnjJuGhubWepkGBoARwKS7lKZYr2dxT0f7C96O2M3vKP6pbZxzkEM1u6IJ8F8NDUNrf2iM4/F9J50d9xXvBrsjQ0G5gje8oaYetIFE79w7IZnAHCiCDYLG3VOoS4BWopL0aywyUTaErEIyY5pXb9gUFO8vfbjwaAnk+MjPlBM6vIRCMKm2pwWawlOfHMvknwIetybp6BUdJq3buNgUqbjgtAM1WINg+tKSG9sF5LmIZ5/wozj+XyS1T07k0bKfAat8MYZfA9pmzUqWjWwQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAsEY06wlJ87UexNywjxD0Q1T1pPLlITxuJKw1sJ2Xu6yNsD/zbJubJF161U5YbzmCm5DuJIwN8sJawOkdZQuc62UMB+BsJukLnNhJG59YWa8t71p6pL96CEFAoFgF2F+9x5gBGdFEubX5S7zT2gcZc3YCEZ2m9plDY23gDF/F4y9o+jm/XBOS2D7CzO1ZIierUAgEOyctMz/3T7hhHm0rJs/AA/1QSlhvM0zgjuqKF3WK5Jm3C7pyS+F5xmtTU2n7E4vTSAQCHY0undrbbemSbpxJRiwV/wGrVZBbxg9U0U33gHj/RZ4qG8pCfNdXlqeFPc3n4I8HpN1q6Dq5huQz1bMrxjXuLctJ5I5SUt+v6m9G5swJhSvWyAQCLYDkxILD5D1vm+At/g0GLg3eUarkpDqf8K8DfY9R5rbm5Di5vTW9gUHNbUv2RPzn9Z28SEQt0rtqs1oEiMbN39MTo5Dc3Ny39DRfZOluQulcML6mKwnL8TmB/B0t/DyqyToIcP5L5fj1gmQ9W7FIwgEAsEYMm0eMYrngPFazTNMPCFtrbr5D7nLWhTWjOPRsNLsKgLGeQkvP56g8QXv2wyF+vamu9eNfIwxVdasT8uacZWcsP4FHvRW3rH8IiWSb8u6YYMh/wQaeZqdQCAQjAan7B7RjQ9FEsnHeQbIL2AM35QSxrPY/htp7z2UZlIXYNRO5uUdJIqevLFpBMY3iBbwyuVO8xJJN9fgi4R37FIxtsmaeXNr3ApjswzNRiAQCOpkavd+YHgWQjX9Db6xGRbSzpowbwrHTQUMzx40h4YItS1oLjY98I/lFylh/RV2G/s2WbV7r4jeexyUx2O88/AKtjVjE4ukLfovurdAIBBUp6Vj0eFgTK8DeZ1nXLyCfW/RO25qWjpqvQTAg/y2lDDf4h3PL4pmrZw5t/couuu40dLSvU9YN06C66/6opBIv2XzQuERCwSCQJrV5EQ5nvxtrcYPRdHMu+juo8JBLd0Hg0f7L96x/IKDL8Kdydl01+3GtLbLD4Gaws/AMy7wztMrWKMIhboPpLsKBIJdnant3fspupWst4sWeMjvRrrMb9NsRgXwFi/nHcsv6FUqcTNOd9thwI+MkpZ8sWLPDd14JxJPniX6Fo8JS/Yko33i5kdndPRGxrPagV9xJb33wxHN6Jo8f/H+NHgYqDbJ8b52eAt/ePrchRINFezCSHHzk+BJbuIaiiqiJKy1oc4FGs1qxIQ6k5qsGe/wjuUVRU++KWm9Z9PddkjACLcV27H5hhivE15gFzc1zR9Re3kgJ98Rpf92DbBrDY5dLy9wY5usm7+arHaXG8RRQk4YXwHv5eXS4+LHCfOFSHvvvJbZ3QeD0qZ4X3GlhHHZWJ6bYMekVb/8MNDLW2r7ss+XiJZc2Tw7eSTNckRg9zE5Yf26Fi88ols3TtxJqvERbVGXnEg+6b8GbF+H8v88TTb6nHrXB+i/XQO5y/pmkPLIOo53tz5Gk44qrfGFYUUz8rzj4vkouvl78HJ+xItHgTSDMngeNDvBe58Jst77cdDHqh/Yqgl4zr+bOpWMChsxoc4eVUokn+UdxyvgbOSOSiw8gu62szBB7jROxO5pYIzvBMP7g7HoMleCMMAepQEDDHISTTrqgBf7w4DjYjvZR3F0kZwwuR824JxvCnWKjwK7BqQ/70U4cICnC/WKgsNyR4mIZpwb9PwwwVnPoprRRXcRVEIYYI/ijLEBRvBDClTNOiTN+H/Yib3YH7Okb+QE7K4T1ntOUnTji+AVHyt3XDSJxgne4zQ3f2ffSNy4laefKKCfeZw8R0n0XcOL50mks/c/aPYj5JTdQScf5R2DCY5KAwPc19R0Jhmm/F5CzuYjsWyuW80M/CGazf8wlBpsplGNs8Ma4PYz95yGH6vmmhI2lDOJxBfNCs/FWY8a69A92gaYeK0dvREcH4/T+NHgEYNzrkoJU1LbrWmw+R6cUOSU3aXEpUfgC6hV7zms4Y+gavdeWPZ4D8j8BHWC7e4RvVeW4hdPR52jwbUyIawlj8T9Q/P6JuN2Mbgxph1zwVT8BsDTTRScFhKfB0wLevo7XhqeSB3GXHKAESLpPZ/BHhW8YzABA/38dNBbust7glB2/WTVzqXb7PyQV2KZ3LtoiJuahhq/7zuMAQbjBR7hB6WEleHdWL/ImvHvSJc1r94Hd7QMMDx4nUrCKhtnD/vfoXYsOpwmqxslkfyYrCXL2ooh/NqDwFjQZDsv7Uv2lPXkJWXXh7NqadY3a72f+HEHDNJN/o9TimauUzTjeJoskEi70QXHHPTuS/bXzXTo6AvRmAYyZVbP++A+/9q/r6ybr4bjyc/RZHXSvUfx43BpnkXB0VrGg975C+SEafHTlgpc45sts8E5GCnwclJ060beMZjgcwXlcibd4z2DnNoQA0O72m+AmUQzTrJp2bONtRXvAAZ4AijeD7CzNu+mVhMyjLDT/DLNqyqjYYBx3Dy+AHh5qKiECbOXJq2L8NzLW4NGNUmaCVU7839p0p0WfEDBSHKHzEpgwPDDE01aESinxbw8UCDuKahBBE62grNsBXXGxxcBGBoTPWuavAzwuP8H7gX3PuELIZy45P00aY2cCS8lw+blhwIvlL9MmfLd99HEBHxm/C8fvhiDo9GEhTWMagMYpIRx73h25xxP2uzNrdGsU+Aa4GzunVg291OatD62pwGe2t59KHaRCTKI9Qh+LZY186eTpIUH0Oy5jIYBjsWtKVjV4uWBgt4JTVoXYNhl2Jc7uokYhoQ5ah9Ttg9DE+AFdXbQNeLHG/D+P00TV0TpMq/g5UEkYTw764SeEoPlRekyoniveftiFVtOWH2VZutSNOt0MEaB8y6E51X3wBk4VBbbTIN0EvS6v3UWNtGUEtGMU2uZnhEcmzXcvuZ1IunWKXh/eMdAgXLbXP+LZ+dCvicfiWXyT3CNsJ17R+3Pf4cmrZ3tZYCxOgVKfD/vZjKBh+wV8PyySty6Fm7wNShQ7bwaq2O89CjkIdatGD1MGcIAb0+EAfaDUyOCPpb1DUfBWhbP+CKReO888IzX8fbzyugY4Pl7FCf74Q++wOcJyuOmiZ197/leOko6/341k9vINcKZ/GtRe/A/adLa2F4GGN7sH+PdTBQcfYI3nCYtA274ubz9ULB6i6PIaNIyhAHenggD7AV7xAQ1ZclQ3Q93LDqaJi1j5pxkCJyTJ3j7+mTtSLsv4sdNuN5bOHkTgTJ7HXv10OTveeRs/uNqNreVZ4RjduGRUOql2ntHbC8DDG/mz/FuJgo8HFskzQqcHk4Y4J0VYYCH6d4NjOyvePtD+FY4vwsqdeUKgbcpJZJ/5e3vFbiezUFedK1gbyRZMx/i5Y+i6NZzODMbTb5LEM06v4hlc+/yjHA0m19Mk1VHGOBhEQZ4rBEGmBGO98TROPL2h9rfGjCwVb0oHKnF279E4HpQr+guDTFjVm+kOHENJ38QRTMW0KS7DNgHOGbnH+AZYDXjvB1NFz5Ik1ZmuxnguHVC4FdcMJDwgPxODfgSjYaIux/IjmCAIc6kSeuiqgHWje/RpDsp1Q2wotc2aAAe+t/w8kABj+wZrN7TpGVUNMBQzvgCDdI9ZOQGuLtCmyrovmZ8hSasCPbvBUem6nI8kU6cB7hxcNIoeGbKuuyhKF3W6/LcnsBvLu9lVLtwZiyT28Yzwm3Z3O2TU071tvfxNsA4llzR+35GxlrDA8e7qUxIVSxhvAQGtx+2sX9wBjyf+6SA4booO4YHDOcM5wn/yTlXE6nLzIY18zQsm0ADjJ6ZZvy7nnx3HDGzeA/BuM4Bg3EW3D++ASYzTxmPQ9o0bHPyKQqWARjA9fC/LA8UqahX5ftp5v1SPPldNBiBBph4wEnQOcN3DmYWzn1ZcSY760uVDDAaLKoqXGbELpyC58LbF9t1p8y6OtB791Np4AYTOW6eQZM3RDie/JiSSHI/FEI5rdhVp2ucdtuLh8Qy+Rd4BljN5nOR+5zqw7HHwwDjtI+g8DYYplEZ215JdgQDXK+A4dkYmWt1yJrZw4t/LwgaChzxBrWe24LKf6wFvTVJ701gTSLoJVBJcJIWvP9gJG/nxaMoceNWtlpwEKQHA6dPLRp/eHnUVZ0Px83/hH0qPlcR3bgUjGSgR18N7KkB+fCXsCfDjndd1KxzNs8AxzLOW1G78L2moSqj5MbSAGM7Gnh0PbJW26qloyE7kwHGKigxTO0LpsF5XwzbdS8ZvqMLGC1cg2wxduQHXVjOSzPWgk1d6KnNnLM4JOngAVepefkFq/loxOAFEgv6GIUGHT+qYb9eqiaBYFMTGM2yGcXgHAeLywbVziHYQ0GzVvrz8grqGHrddJe6kTuNk+DcyjxgrAUomvE1mmyXpHXFlsNUO5/nGWE1W7ih+YY1lVdfHksDLOEk0nUq+0hlRzfA1Bi8DA/Nb6BmMA+8379w04ByS7rxT6gO59BQ+9PsyILnC9X0NdjcgNcIBvhhXhoI3wzXeT/qSOD3gBEIGMRXoayvm6ktPAaO83t/DQz1AF96cB6PgZf3Q7nLdIpx+A3C3IofnmSt9ysz4+axkmaVdflyryFhLsFJ9Kl61MjZeytx8+uQx92gs3eRYdiNTRk5AfTkHEVLBr688aOeHO8NfCaqMbO951h4wWzw5wv3bLMST34MXzqStPAAnJOjqNPmaejJq7q1FPTgAXgBrJa70A7UXvOB9G9DuazHgVrwjFwla8lvwgtcb5ltHkw/kO4w86PEbGc5zwDH7NwjrfdsrDw/yVgaYLgR57MCLRoVYxW2n+FkHdKchUdg15XRlhlgHPEjBz2FMvDjDHarCdy3wtdvRjUDDMp3GebFyx+Pj8pKJhrilAFOwlPuRZ2yO/bFxCq8P/2OJjjsFT9g4YOC1+cv6xnxC6dgnH/im1Do7L3x2nnl1ohgeWFXLfzvL2c8htxx6SQ6XLn4IMM5s/LF88CHHNdew32x3de7P0lHrqFyU8N4MX1OTwu8YJ7h6SIKefZGMCVl8eOw8VJZ3vgCG4MXZzVxX5xdxjr4f2tEN0dptrfGAAN8Bc8ARzO5daHlL86kyfiMtQHGOQwi4CHgShQ0eKfnCDAy+EGMpxwo+BWdJn3PgYYSvMWz8WMReLivopcJ8g/wFr/KZoMLHbNoJnhl10M5OPigkF/w9Gd2GLvW8ivjiKQnv1TJwwQD+mijLwx86cD+gaNPdwTBFwGUwQNh7ZJOetrjRjSbuwiHIvsNcCybH2zLbDqGJuMzpk0QUK0LQ9UB/nKrC2325kOkjHNyNJNfqmZzT4HLvr5Widr5P09dta7uKlto2bN7qyudkJrNn6H2526IZvOPR7POaiLp/APSo29KctsCDd6sg7R6WSKyntyEv7hgH1cR4CFQ5iz8RdOqVXvG+gu/VO38827+lSSTW1t2jVnn/6bZLx4i3TEwvS2T/7c/vprgGziG+2Wdv8UyA1dDOZ8eSRXk5pVV2qUCKM5AZtzLu24UWe+9JZLo+xR6KLx4rMZG4j0fpdk1hJpyDodrOwHu28UxO39nLOM8EUs7L4IXsqYNdEhN59LwQFyKQ0KV5etbmlJDVacIVVdunhi5L3cc5HmpmnYeVW1nM+tkj1MOQtm9oqTz/4jZg5cpKwrH4fSEVT+uVGHKXQPvk+E6QD8Wwv2xYinnS3htNLohQC+v45V7UYxt8Dw21F47WV28P7xE/8y/r9hcgy9iaw0c/ylI8yjI40qX9TSG0WYgdz9Ig97409imHumyTpfm9iZwSs9Kkx/5mdq+ZD91TjJEFtbUre/CdV2Px4Rz3EAMMTgHOFshJB2XZgrQw5+AzpWNjIPnb+Os7GDlBUnH0gDj3L1YWHTTRbp/03RQugcD+9DVINGMcw8obM1j3MPp9QoOEyw+UPzj4kOs/H1LVDp6QQJuZENLwaAShueYCj5gYBxSbSO4RjCetnzP2klhO9cKN3gzL00jAmX/LuT3EpThybR4akKFBxE8WewGF3Ttt8ld1qf5DyoY6LixUVF+UfeST9My+alwzv+Hwz/r0hlIi/cbX+7hzECZZwR5ng3G9eV69RDTw75vqnbhgkamIcTrUTO5h/zHBcO/taEJXSj4MVfWjX/yyh4FXoADLbMvbmhqSqjJnFPWht5lvYLfeWgSLmCAP19qgOFFkLDuOUIem0UGps3DNR9xDT3yYnjyqDljvywS3LcL4Hkq94DtfEHtdwKHkxPG0gDzaE3nw9hHzn+y9Qo8APfVYoCVbO44qAr8q5aHDA2w9NCWtkYNMCj/Hfi1Gb1WOL/l9T7YfgEDef9YGGCvQNVps5JxqgzwGJqgpJyvg0e+Vn1g8I/yKVefKbcv+gfUBt7Gr/9geB/Dfsys/by13ZoGYdfImrkRHtx35HjvJkh3tdK9/NTYysF/EANmD9whpQYqGgPZLrSDh/go77wbkajtvKRkC6S9EDzk03hp6hW4R6+p2fUWeMQ1T8MYXjl4JDwDj3Hzyzqkq1ujhOPW58BQcj98w8vzHbgnPY2sVjFTM47B2p8/P0U3f0yTcCG9X/TSqTuJTiSMbppkTIi09x4KOrcYaqpvyprxx7Fsr4d79mvevUR7otrrcEGFYMbbAEM17+ayE806g0p2ID7Sap2X0AODB0I18nr/sZiodm4VGOZvgREPTb1l1X7tq1bt2bQEBEADjDfOqzR+IUqkGxvhJj8CSv1T/FBDDoyQh7F4Lbx+gvDQvj0Lr7eYdkKgUIIMMJTlj5q64Vh4vCBZtmxvqb9whJIeOBWu+TaoFr3tzwcF7sGTkRXryoaszrxz7VFw7Kz3ZYKeWvSBDVeF//5aTSvtKis2fiC6ovCM93goUP5bwChyZ4+K9he+j30py/bBGoyde1bN5H+C3sXkJ4b2b1q6dHe8VmxaUcgL3jlbTedWQd6cdjncv3Dr7NSmg+HBuQa8lDcxHGe4gn2ukzP5kyKpdYeSsqNMvWXdftH0+o5Yv2PCOW3w54kCL7Jn5BUbahoR1nznmomx7MBdvNoRnNPjk/oLFadUrYbchR+/+bUQ0Nt8uNNoYNrI7j0U3fqDPz8cUAWRFV8+EdK/vfx8wEM9b6znDw7PTh6paCbpew7P608qjZBsFDXj3O2/jyjwTP0ttGyw8kRI42+AnWvKTzT/Bij4aS2p1Qe3wIOhrlwzkbR9giKqS5+ouwM57gPG6Xdlx8GHN5u/q+mJoYY7pddL1M6f4z8PMGhbwQgnaJKqVPCAK3ofQZB2R2p4vIIvpfC9g8NGddm2vWPp8vHuUKV/B85/CTaz0JRVgfQfBuO/yZ8Xyc/ODa+iAC8e2F7ISxfN5B0wsHNoyqqEV752JNZEuHllcxk4VkNLSKnZwS9hu3BZnmnngardjhDUTzt3CZxD2QsCX5DwsuqgKRsGvNULFT3J/06hWetbZ11e9wQ9pL+6b0gydn+bEV80iyYJBD+QefdDkRPWW7j4aKVeS6NFpMM6Dmplm+GYa3FgGA0eMc13bsaX6YD/PpLmLzt/NX5zokn5jLcBRiML3sZTZSccIKikcCFbwKt5Hryic6f8Y1vVh15O506A9K/684KH5g8NLx3SIDuiASZGLps/w99EgtvYnkVTwbk7P/fGM4E036BJ6iKa2XBUm11Y5c8Pru1h8JJbMI20wknAS7JMoZWMc0vT0qH6h7xCDaHNzvX580OR7cHTaKq6wXkA/PmR8ss44NVVJ9qf/yzOH+vPAwWej5GPLmvp3gd7H3nbX70CnvCqklpbjZD+uLpZMrAKZ2WDqIq114je06FwlvAi++vGP7G7H006ZoTnXtwK3vBDMpnu1vjDZLV7xBPVy5ncV3j3MGY74FQ6Z0GSyrX68TbASPPKzROjqdziRj9QYXUv2u+cTKrfHOCN1OPfBx7qN+V711XuEjIG7JAGGMCaBpxD2ez+sf6C3bRqaM8Qer9Z50F/PBrLpu5UYx5Ld/du8GL8QZuvaQHOw1EyeaKIaNig9vJ6SXzW2Ry1C58geTQA9lqAaykbsw8vmN80ei3YTMFrjoDj3Bekl17IbFoB8wjgC2hmygnRpI3Tfuaesmb28owe9haAKvn/1Vslx+6kkOfNXsMukYE0xqdokkBwCHZQ+zQYxC3YlEeTjhl4vfiRDo8pJ8wBKW4eS6PqBifbgZfl07x7COFr5Uy+ur3ZHgZ4mKEJkWxuFjx054HS3YjKC9Xb22LpwnXYnQi8iecgrKyqzATeMk+G+p2yjs6g2Jf505KqXTZ3O+xzXVs2d0OtombyN+GHPJp13eywBvjvpA30cX+e8PJagVVkrEqDsSyrqWDPDJpF/YDnDffzbH/bLhoyKI8PYzyWlz8ewvJQ+6ltej8Oras2HgRGvexa4fr/VLWKWAElk/sUnPcLIG+DU7AV7tFLSn++5l4e8JD+xH9O5LzSubdBT88jbdujAI64QwPnN3ooOFKt3h4J6DnLerJkYAb2E8b2VpokEFwgFAzfU959vYIj4GTdOqvSmn4jBvuy40dhMkDFfAO8ejD89TeDgP580V+LdO9h1rkGm/Bo0mC2rwGuDam/IIEHhF3Iyi4W+7uqqY3zaFICzwCPRGL2QM2LfvrZUQ1wzM5/mdcEoWTzF2G8MMC1MjSBNI2ggIdPA2sjtXqfWDb3rP+8UMAA/xObbGjKERPSkvPR4PCMHs6fLGkXt9GkNXLK7uBBr/J6wrANulF9ZrRmtXuiQma84zePMAFDfDmuQE13G1XwHPCl4R6PLCha+WOiF9IfPTNgc+9d2nkrvNyZTZNWZmcwwEXg4SQfcvJO2QX35//hHZQx+gY4/54ywNH+QRzE8IY/PzjGw21QNcY0QQZYzeZXxu7NTWlEUGmxjRSOXVKr2VkNcDRb+CJ+n3Dzs513oKa1rJ6BLlDj+7y/ycXND86PJhsVcHi2oidv5BliMJ5b5C6zrjZxXGkD57Hw5oO9gqbrPaQ9vwoTJD15Cg6e8O7vFzDCW8Er/jekO2O0jTHkd5iSSLrt0opm3I9dKGl0RVCPodZT9hGV3Dfb+TlNVp2xNMCqPXA1eK4PY5cgItj1y87fMc3e3PCwZFyPCR7W8q5U2ZzbgZ3bBJHNv4pGb8b9uSlyJj+1VsFeAc0rtxUfKDAQZVKFsTTAcE0/KqbgnRf53Q27UGFfRLW/8Els5oFqL7cbGhiOp5XlA+5Q4SADPBaysxpgKM/fl+Vp5zbFVhRqXoGC9PrJODdxq7IQBjWGH5B7OXpMkDqTp/h7M7hGSDfurtGAMnAyoO+BR+v29YU8no/M7ampJ0dxmLO1FLt1es8jSNBgwsvicuzChh8EJd38spQw/p+qW6dEE9bJKHAun40kkl+IaNbpUtz8FjYxhDXTknXzT/DyuVPWzH+AQSfD5P1euKwnl1Vrjoj2OyeCvpZ9QMV7CDqxoqWeEY1jaoB53mrWaWi1CAYdYVa+NHQ2d0PR8AR4wNjn9P71CsmkAbBnRVmeIFBl/xZNwmUsDfBoCCjMFvDkzqWHchEGuDqjYYARcCoiUNZlvXZQwEPeLOEH51GGrEqeMHvBY+XOiwxGbQFvFGsQ0lxTQu+3JA/NvLrWOWBCnQuawSjeAee0fSb3wRkKdbOAPTzgPK6CU+K+9HC8Ani4/O6UcA+V9Pr6RnqOpQHmtW+B0t5FoxsitNyZqaadsvk3wbO+jCbBB6O7LB7eTvJ96+fTJHWjZJ0v+vNEia4Y+BxNwmVHNcBQRi/Idu7T2OOBHqaEIAMMypcHw3UNfsyEl+n1dYntXMsbILGrG2AEax9QQ+Q+2FBuhbb71jc8nWQlcOY98EB/6zd8aJTAu8SJlsADr51wh3k0eKdPsnzAmL0F24tq/ciFH9/AkF9W9E6Hz4cn2DwBL4oXaDNCQ1MHwEtiMXtJtMzuPhg9YCyLiG6VfXjHuUVU23mUW1sBKenPXitjaYCVjPMz/ok632Teaj2gUQCP886y/DK5jYq9wa0+x+7NzeK1FYMRy2KzAk1WM8RD4QyJxS4o0t2Fiv0Xx9IA45sYDNsa8JJe8goaLFAS7oqtkH5QsfNVJ8QJNMBQhjRJ/cA9B+P6Tb+BFQa4iJod/Azu788TBdvsQXerzlXdKFPbew+VNeMCSSvvLQGe4RtyIvlbMl1rjaidPSr2D2YeNhi118Go3YjLbtEklWk/c0+ps++DYGDvBSmZgwK3Zd34CU3pYWgCDn2O6Mbd3vR8IWvv/RHX1cNVUiC/RdgsweIlzfohzZRARlhmBtby7g08c1uxJxdNWh9jaYCPuGftJHiI7/a/MUDJ3kHlnXFvruYbqmQH47E0p9+qnX8THt7SuU6XLt0d20f9DzIKvKVeiq3In9Qe4Pl5mbpqaD8wVl/mGb+YXdiiZAZOr9Y+N6YG2G0DLofsk3Hugf24HwpwLgI5ldNo8jKCDLDoBTHMaBtgBMr8S5BH2cxaJG/QAfzwR5OODe1L9pTiyZPBA36U1y4Lxvg5nPoS51qme1RG7d6r+LHNWMG8WtjeBAbv17hGYKXVp71gWtj/UpxJjRl18uEQjaiW/KqaMD8JRvNrYPRxDb+Sc25EsO2YHropmhk8MZrmr3qBAnrQg/3mafL6GEsDjEx8dvBAUJxMkNseyw6sx3H9OEParLsG3teSGtoHvyLjMORwZrATjO514M3yvxKDIQdD8r/0UGVA3t8CL5GvzOQlkHuwLZs/Q1q+VlLvXDNR/tvLk6SVuTaoJv9vND1QNncBEzQQSn+hasdzZCwNMEjVXhDTV0C1CXsu0OkV/QKG7RkptX4uTe4iDHB1xsIAI+Btvd/bu8IvEHd5Q6MC6+bsvaWuS74KHid3VRZFM/JQhf9+sXdCbV3wcLIq2OdiMJQ5bJ7Apg6c5EfWe3+FXeFa5v9unxrzmnDUMYtmgrf7RbnL/JWiWylFs54GT3stGPuXcHQdLsUka+af5S7rclVPXgj/zwf5NrxEviXHzR/AsXth+z5Jt9wpM/EX8nisaQpcE+ij2p8/I/CFiL1e0k7Z95O6GGsDzMCRTjiwgnch9QoaT8Ue+Eso+8pkmn0gM+59bgq2WQZ5gvUIGk7woPta73mu+nh/yvY2wAwptXo6dpEKapoAY/s8VLHc9ciEAa7OWBlgRE7ndCiTdf78maiZ3EO8QUhjBRrZsLagU+oyrse24RJDTIwomff3cWwaCM81Wulu1ZiA7a8tcVMBQ3iarFt/gv2fB0P6ChjRHBpR2L5G1vvOnBnvbccVSnCf4q6jAC6lhD04dCNPDe9auaP34xgVvnfNkaCHKV7Zo2CzJxmNO1LGywAzivPy5i/Hh4p3YUGChgMe/idA6b+Fs0nR7GqGDBvE+Q/sHHdAR6BA2limYMO+n69lcm8/O4oBZkipTdNxXgVst+Lkhwb2CckuHFs0wOVzdggDPMxYGmAElz2H2iF3pi0UKMu3sBlqJNfQKFOndu+Hs6oRb1a3HuCNtAOjNignrOXEKOvmB3C5Krp7zeDQYVyBJjzPaA3pvXPImnPx3hPAQJ8oa33zcUJ3DEejj0tJcb1ntXsvXLYJ5y4Gr7sXPOD7Fc18Bb169HbBiz7PnYuie2g3OeP8Nzxv3LZ4FLgnz0npXJ0DVwIYbwNcytAENMjRbOHr8AAugQfvFnDrl4OxuzuWGbgR53SA8JNb7xqoe+amaqipof3RK4cH5tugyKaacq4Ej+8KbM+B8zlLzQx2Nt2wcsTDIRV78Hi4YX+AN+ZvmcTswhU4DSZNUpVI6pVD4aVxmTcPzDOaHmh4fgQ8vpxyfl2aZ1HA4P1OzQ78si2TX+ALv0q1B8+nWTSEct/a47x5osBL8TI5NUCmcoTz+oiazv8R7vs1TOD+XBHKDtb28YYDmU4y6/R684R7fb1qF77RyEuVofRv+FrULlzryffaWLZw5VH9lT/M1gWcn5oe+EHMdsoGzjABHX4mBh4z3WO7IssXTZL13o+Dl2woWnKlkrDW4ge4EsOsmW9IXdbfFc24TNaMr8Dv8TijWqSzZ4basZisySclFh6APSJIGzGulsEEtsm6isX4iTgsGo1vuGPR0REt+RE49jfAG/8VGNq/oSeNg07AWL8GRnc9yMPwMvg1GuJQZ3dZG3abXWgHPSl7UbsCjgG88C4d1dkUP7OsYb0WCATjBM4RjLU3rmFAgZoavAyeUZYP9wbasThldzSgOHoOPdhIwjoXP6CBl7wCu5HB78sqHaFXbA7wCq4kzgSXVjK3wi941+a/wMPul7Xkn+F/Dxjyr0X03uMU8Haxn3Nx4dfq7cn0g/UTlWrG4AQMtlInQSAQ7IosWbUneGhf9DfReAWNSCyT/7vcv2N4xDsyyor8nJidXxH0oR4F4t+AF993x3MOcYFAsIOjZvM/BWNbNim8V2K4FFc29wU19cSI5719r9CSWr2PaudPiaZzgb2cUKB8X43a+UsaXcBWIBC81+lO7aGQtm1+N00m2GsIl2HCqnbT0Hh0X9vBGBraDedniGWd63FaWl4ZMQGP900oq2vxoz3dWyAQCILBvvNgiL8eDZhVjQk2T4BX9yp2R5Qz4784wXgTyQzMQKML11195WuIVzPO+VP+UfsyWwKBQDAMeLfR1MCxqp1Lc42MT8A4vQnyoJrNfafaCtU7A6Fl6yfjatexjJMCY8pd7skvMdv5GxmaP0qT3wsEAgF259sfjNE5OMCmqvfnEfyAF80438N+rqFlz9Y23Hg7QNpyU04IXiBfAiO6PFrHQCsw0C9C+h/Ws6isQCAQNMYTQ3upduGrYHg21GOMXcnCfrZzRcwePAEHteCAGZrz2IPH6h7aTe3fdHQsnevGrnbcc6wgeM3o7cO+32u6ZXjhBoFAIBhXcOUYOTWoxbK53weMrqxJ0ONEg46jwlQbpxjNL1Wz+UU4/wr2Mohl8/OjtjN7ZmpNqC31UjMujCrj5Fwp53Cc1jGyoiCrmYFO8NA/omac/4H8fgSe9xLYvhuM/T8h73X4cbGhFwaImnZeh3O5EddzxNoAvXyBQCDYccBuVnLGOZFMD5DJPQ1GsGIvgR1RwEjjNAUvkJGa/YVP4ioj9PIEAoFg5wLbRqG6jh/zLoOq+5PFpgvnrUa90dEQPDa+HMCr3gTe8rOxDFnu7BPT7BcbXt5MIBAIdg6WDu2Oc2rgvCyxe3K6ks5/C4zz9ThhUyybexn7GvMMZ70CRva1aNZZDcb/tmgm/2MlWzgulHqpGaeqHcm8HQKBQLBrAMYaeylINxcOIIuOrtw8Edt/SRsw/G8DrxV7WKBBb1q1qurCCAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCwXuGpqb/D92CoqrEGsh+AAAAAElFTkSuQmCC";

  var TEAL = "FF2F6690";
  var NAVY = "FF2B3593";

  function ensureExcelJS() {
    if (window.ExcelJS) return Promise.resolve();
    if (window.__setramExcelJSLoading) return window.__setramExcelJSLoading;
    window.__setramExcelJSLoading = new Promise(function (resolve, reject) {
      var s = document.createElement("script");
      s.src = "https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.4.0/exceljs.min.js";
      s.onload = function () { resolve(); };
      s.onerror = function () { reject(new Error("Impossible de charger la bibliothèque Excel (ExcelJS).")); };
      document.head.appendChild(s);
    });
    return window.__setramExcelJSLoading;
  }

  function fmtDateFr(d) {
    d = d || new Date();
    var dd = String(d.getDate()).padStart(2, "0");
    var mm = String(d.getMonth() + 1).padStart(2, "0");
    return dd + "/" + mm + "/" + d.getFullYear();
  }

  function thinBorder() {
    var s = { style: "thin", color: { argb: TEAL } };
    return { top: s, bottom: s, left: s, right: s };
  }

  // Ajoute la charte SETRAM en haut de la feuille "ws" et renvoie le
  // numéro de la première ligne libre pour la suite du contenu.
  // "nbCols" = nombre de colonnes du tableau qui suit, pour que le
  // bandeau (Référence/Date/Titre) soit aussi large que le tableau.
  function addCharte(ws, opts, nbCols) {
    opts = opts || {};
    nbCols = Math.max(nbCols || 3, 3);
    var titre = opts.titre || "";
    var reference = opts.reference || "Référence : Site-Structure-Type Doc-00xx-20xx";
    var code = (opts.code !== undefined) ? opts.code : "Code : ";
    var date = opts.date || fmtDateFr();

    for (var r = 1; r <= 9; r++) { ws.getRow(r).height = 17; }
    ws.getRow(9).height = 30; // le titre peut être plus long ⇒ prévoir la place pour 2 lignes

    // Logo SETRAM, centré au-dessus de la charte
    var logoWidthCols = 2.3; // largeur approximative du logo, en unités de colonne
    var logoCol = Math.max((nbCols - logoWidthCols) / 2, 0.2);
    var imgId = ws.workbook.addImage({ base64: LOGO_BASE64, extension: "png" });
    ws.addImage(imgId, { tl: { col: logoCol, row: 0.05 }, ext: { width: 150, height: 52 } });

    // Ligne 5 : Code du document, centré sous le logo
    if (code) {
      ws.mergeCells(5, 1, 5, nbCols);
      var codeCell = ws.getCell(5, 1);
      codeCell.value = code;
      codeCell.font = { name: "Montserrat", size: 11, color: { argb: "FF333333" } };
      codeCell.alignment = { horizontal: "center", vertical: "center" };
    }

    // Ligne 6 : filet de séparation sous le logo, sur toute la largeur du tableau
    for (var c1 = 1; c1 <= nbCols; c1++) {
      ws.getCell(6, c1).border = { bottom: { style: "medium", color: { argb: TEAL } } };
    }

    // Ligne 8 : Référence (colonnes 1-2 fusionnées, plus de place pour l'écrire) + Date (reste des colonnes)
    ws.mergeCells(8, 1, 8, 2);
    if (nbCols > 2) ws.mergeCells(8, 3, 8, nbCols);
    ws.getCell(8, 1).value = reference;
    ws.getCell(8, 3).value = "Date : " + date;
    for (var c2 = 1; c2 <= nbCols; c2++) {
      ws.getCell(8, c2).border = thinBorder();
      ws.getCell(8, c2).font = { name: "Montserrat", size: 11 };
      ws.getCell(8, c2).alignment = { vertical: "center" };
    }
    ws.getCell(8, 1).alignment = { vertical: "center", horizontal: "left", indent: 1 };
    ws.getCell(8, 3).alignment = { vertical: "center", horizontal: "center" };

    // Colonnes 1-2 : largeur minimale garantie pour pouvoir écrire la référence
    ws.getColumn(1).width = Math.max(ws.getColumn(1).width || 0, 20);
    ws.getColumn(2).width = Math.max(ws.getColumn(2).width || 0, 20);

    // Ligne 9 : Titre du document — rempli automatiquement, sur toute la largeur
    ws.mergeCells(9, 1, 9, nbCols);
    var titreCell = ws.getCell(9, 1);
    titreCell.value = titre;
    titreCell.font = { name: "Montserrat", size: 11, bold: true, color: { argb: NAVY } };
    titreCell.alignment = { horizontal: "center", vertical: "center", wrapText: true };
    for (var c3 = 1; c3 <= nbCols; c3++) { ws.getCell(9, c3).border = thinBorder(); }

    return 11; // première ligne libre pour le tableau de données
  }

  var ACCENT = "FF2B3593";
  var ROW_ALT = "FFF4F8FC";
  var BORDER_COL = "FFD7E1EE";

  // Bandeau "titre du module" + sous-titre (nb de lignes / date de génération),
  // identique visuellement sur toutes les feuilles exportées par l'application.
  // Renvoie la ligne à partir de laquelle placer l'en-tête du tableau.
  function addBandeau(ws, row, titre, nbCols, rowCount) {
    ws.mergeCells(row, 1, row, nbCols);
    var titleCell = ws.getCell(row, 1);
    titleCell.value = "  " + titre;
    titleCell.font = { name: "Montserrat", size: 11, bold: true, color: { argb: "FFFFFFFF" } };
    titleCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: ACCENT } };
    titleCell.alignment = { vertical: "middle", horizontal: "left" };
    ws.getRow(row).height = 26;

    ws.mergeCells(row + 1, 1, row + 1, nbCols);
    var subCell = ws.getCell(row + 1, 1);
    var dstr = new Date().toLocaleString("fr-FR");
    subCell.value = "  " + rowCount + " ligne(s)   •   Généré le " + dstr;
    subCell.font = { name: "Montserrat", size: 11, italic: true, color: { argb: "FF5B6472" } };
    subCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFEAF9FD" } };
    subCell.alignment = { vertical: "middle" };
    ws.getRow(row + 1).height = 18;

    ws.getRow(row + 2).height = 6; // ligne d'espacement
    return row + 3;
  }

  function addDataTable(ws, startRow, columns, rows, titre) {
    var nbCols = columns.length;
    var headerRowIdx = addBandeau(ws, startRow, titre, nbCols, rows.length);

    var headerRow = ws.getRow(headerRowIdx);
    columns.forEach(function (col, i) {
      var cell = headerRow.getCell(i + 1);
      cell.value = col.header;
      cell.font = { name: "Montserrat", size: 11, bold: true, color: { argb: "FFFFFFFF" } };
      cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: ACCENT } };
      cell.alignment = { vertical: "center", horizontal: "center", wrapText: true };
      cell.border = { top: { style: "thin", color: { argb: ACCENT } }, bottom: { style: "medium", color: { argb: ACCENT } }, left: { style: "thin", color: { argb: ACCENT } }, right: { style: "thin", color: { argb: ACCENT } } };
      var w = ws.getColumn(i + 1).width || 0;
      ws.getColumn(i + 1).width = Math.max(w, col.width || 16);
    });
    headerRow.height = 22;

    rows.forEach(function (row, ri) {
      var r = ws.getRow(headerRowIdx + 1 + ri);
      var bandFill = ri % 2 === 1 ? ROW_ALT : "FFFFFFFF";
      columns.forEach(function (col, i) {
        var c = r.getCell(i + 1);
        c.value = row[col.key];
        c.font = { name: "Montserrat", size: 11 };
        c.fill = { type: "pattern", pattern: "solid", fgColor: { argb: bandFill } };
        c.border = { top: { style: "hair", color: { argb: BORDER_COL } }, bottom: { style: "hair", color: { argb: BORDER_COL } }, left: { style: "hair", color: { argb: BORDER_COL } }, right: { style: "hair", color: { argb: BORDER_COL } } };
      });
      r.height = 17;
    });

    if (rows.length > 0) {
      ws.autoFilter = { from: { row: headerRowIdx, column: 1 }, to: { row: headerRowIdx, column: nbCols } };
    }
    ws.views = [{ state: "frozen", ySplit: headerRowIdx, showGridLines: false }];
  }

  // Insère un tableau de valeurs brutes (tableau de tableaux, comme
  // XLSX.utils.aoa_to_sheet) à partir de la ligne "startRow", avec le même
  // bandeau titre/sous-titre que les autres exports.
  // Si "freeform" est vrai (texte libre, pas un vrai tableau), la 1ère ligne
  // n'est pas traitée comme un en-tête de colonnes (pas de fond, pas de gras).
  function addDataAoa(ws, startRow, aoa, colWidths, titre, freeform) {
    aoa = aoa || [];
    var nbCols = (aoa[0] || []).length || (colWidths || []).length || 1;
    var headerRowIdx = addBandeau(ws, startRow, titre, nbCols, Math.max(aoa.length - (freeform ? 0 : 1), 0));

    aoa.forEach(function (rowArr, ri) {
      var r = ws.getRow(headerRowIdx + ri);
      var isHeader = !freeform && ri === 0;
      var bandFill = !isHeader && (ri % 2 === 0) ? ROW_ALT : "FFFFFFFF";
      (rowArr || []).forEach(function (val, ci) {
        var c = r.getCell(ci + 1);
        c.value = val;
        if (isHeader) {
          c.font = { name: "Montserrat", size: 11, bold: true, color: { argb: "FFFFFFFF" } };
          c.fill = { type: "pattern", pattern: "solid", fgColor: { argb: ACCENT } };
          c.alignment = { vertical: "center", horizontal: "center", wrapText: true };
          c.border = { top: { style: "thin", color: { argb: ACCENT } }, bottom: { style: "medium", color: { argb: ACCENT } }, left: { style: "thin", color: { argb: ACCENT } }, right: { style: "thin", color: { argb: ACCENT } } };
        } else {
          c.font = { name: "Montserrat", size: 11 };
          if (!freeform) {
            c.fill = { type: "pattern", pattern: "solid", fgColor: { argb: bandFill } };
            c.border = { top: { style: "hair", color: { argb: BORDER_COL } }, bottom: { style: "hair", color: { argb: BORDER_COL } }, left: { style: "hair", color: { argb: BORDER_COL } }, right: { style: "hair", color: { argb: BORDER_COL } } };
          }
        }
      });
      if (isHeader) r.height = 22;
    });

    (colWidths || []).forEach(function (w, i) {
      var cur = ws.getColumn(i + 1).width || 0;
      ws.getColumn(i + 1).width = Math.max(cur, w);
    });

    if (!freeform && aoa.length > 1) {
      ws.autoFilter = { from: { row: headerRowIdx, column: 1 }, to: { row: headerRowIdx, column: nbCols } };
    }
    ws.views = [{ state: "frozen", ySplit: headerRowIdx, showGridLines: false }];
  }

  function downloadWorkbook(wb, filename) {
    return wb.xlsx.writeBuffer().then(function (buf) {
      var blob = new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      var url = URL.createObjectURL(blob);
      var a = document.createElement("a");
      a.href = url; a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
    });
  }

  // sheets: [{ name, titre, columns:[{header,key,width}], rows:[{...}] }]
  async function exportWithCharte(sheets, filename, opts) {
    opts = opts || {};
    await ensureExcelJS();
    var wb = new ExcelJS.Workbook();
    wb.creator = "SETRAM";
    wb.created = new Date();
    sheets.forEach(function (sheetDef) {
      var ws = wb.addWorksheet((sheetDef.name || "Feuille1").slice(0, 31));
      var startRow = addCharte(ws, {
        titre: sheetDef.titre || filename,
        reference: opts.reference,
        date: opts.date
      }, sheetDef.columns.length);
      addDataTable(ws, startRow, sheetDef.columns, sheetDef.rows || [], sheetDef.titre || filename);
    });
    await downloadWorkbook(wb, filename);
  }

  // sheets: [{ name, titre, aoa:[[...], ...], colWidths:[...], freeform? }]
  // Pour les exports qui construisent déjà leurs lignes "à la main"
  // (résumés, tableaux multi-en-têtes) plutôt qu'à partir d'objets.
  // "freeform: true" pour du texte libre (pas un vrai tableau à en-tête).
  async function exportWithCharteAoa(sheets, filename, opts) {
    opts = opts || {};
    await ensureExcelJS();
    var wb = new ExcelJS.Workbook();
    wb.creator = "SETRAM";
    wb.created = new Date();
    sheets.forEach(function (sheetDef) {
      var ws = wb.addWorksheet((sheetDef.name || "Feuille1").slice(0, 31));
      var nbCols = (sheetDef.aoa && sheetDef.aoa[0] ? sheetDef.aoa[0].length : 0) || (sheetDef.colWidths || []).length;
      var startRow = addCharte(ws, {
        titre: sheetDef.titre || filename,
        reference: opts.reference,
        date: opts.date
      }, nbCols);
      addDataAoa(ws, startRow, sheetDef.aoa, sheetDef.colWidths, sheetDef.titre || filename, !!sheetDef.freeform);
    });
    await downloadWorkbook(wb, filename);
  }

  window.SETRAM_EXPORT_XLSX = exportWithCharte;
  window.SETRAM_EXPORT_XLSX_AOA = exportWithCharteAoa;
  window.SETRAM_ADD_CHARTE = addCharte; // ws, {titre, reference, date} -> renvoie la 1ère ligne libre
})();
