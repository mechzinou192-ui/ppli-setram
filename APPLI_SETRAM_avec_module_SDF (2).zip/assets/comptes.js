/* =========================================================
   comptes.js — Comptes autorisés · Plateforme Maintenance SETRAM
   Généré depuis admin.html le 07/09/2026 09:54:17
   -----------------------------------------------------------
   ⚠️ À déposer dans assets/comptes.js sur le serveur pour appliquer
   ces changements à tout le monde.
   ========================================================= */
window.SETRAM_COMPTES = [
  {
    username: "admin",
    email: "admin@setram.dz",
    nom: "Administrateur",
    telephone: "",
    role: "admin",
    hash: "7b94ac195f7565fe34ea6ebe7a85135d7494ce80c4167bcea6071f549cfa605f",
    actif: true,
    permissions: ["all"]
  },
  {
    username: "Brahim.BOUNOUA",
    email: "brahim.bounoua@setram-dz.com",
    nom: "Brahim.BOUNOUA",
    telephone: "",
    role: "user",
    hash: "8b5e3be56931bc92c74015c077bcffd172f60242e131481063fb7557e4f0aded",
    actif: true,
    permissions: ["frame-6","frame-1","frame-3","frame-3:section:dashboard","frame-3:section:kpis","frame-3:section:corrective","frame-3:section:preventive","frame-3:section:equipements","frame-3:section:stock","frame-3:section:comparaison","frame-3:section:tendances","frame-3:section:rh-import","frame-3:unit:__none__","frame-4","frame-4:section:overview","frame-4:section:ramaudit","frame-4:section:taux","frame-4:section:ram","frame-4:section:reformuler","frame-4:section:preventifs","frame-4:section:correctifs","frame-4:section:pieces","frame-4:section:synthese","frame-2","frame-5","frame-7"]
  },
  {
    username: "Salaheddine.SEDDAOUI",
    email: "salaheddine.seddaoui@setram-dz.com",
    nom: "Salaheddine.SEDDAOUI",
    telephone: "",
    role: "user",
    hash: "8b5e3be56931bc92c74015c077bcffd172f60242e131481063fb7557e4f0aded",
    actif: true,
    permissions: ["frame-6","frame-1","frame-3","frame-3:section:dashboard","frame-3:section:kpis","frame-3:section:corrective","frame-3:section:preventive","frame-3:section:equipements","frame-3:section:stock","frame-3:section:comparaison","frame-3:section:tendances","frame-3:section:rh-import","frame-3:unit:__none__","frame-4","frame-4:section:overview","frame-4:section:ramaudit","frame-4:section:taux","frame-4:section:ram","frame-4:section:reformuler","frame-4:section:preventifs","frame-4:section:correctifs","frame-4:section:pieces","frame-4:section:synthese","frame-2","frame-5","frame-7"]
  },
  {
    username: "Mohammed.MOUMENI",
    email: "mohammed.moumeni@setram-dz.com",
    nom: "Mohammed.MOUMENI",
    telephone: "",
    role: "user",
    hash: "8b5e3be56931bc92c74015c077bcffd172f60242e131481063fb7557e4f0aded",
    actif: true,
    permissions: ["frame-6","frame-1","frame-3","frame-4","frame-2","frame-5","frame-7"]
  },
  {
    username: "Abdelkader.NASRI",
    email: "abdelkader.nasri@setram-dz.com",
    nom: "Abdelkader.NASRI",
    telephone: "",
    role: "user",
    hash: "8b5e3be56931bc92c74015c077bcffd172f60242e131481063fb7557e4f0aded",
    actif: true,
    permissions: ["frame-6","frame-1","frame-3","frame-3:section:dashboard","frame-3:section:kpis","frame-3:section:corrective","frame-3:section:preventive","frame-3:section:equipements","frame-3:section:stock","frame-3:section:comparaison","frame-3:section:tendances","frame-3:section:rh-import","frame-3:unit:__none__","frame-4","frame-4:section:overview","frame-4:section:ramaudit","frame-4:section:taux","frame-4:section:ram","frame-4:section:reformuler","frame-4:section:preventifs","frame-4:section:correctifs","frame-4:section:pieces","frame-4:section:synthese","frame-2","frame-5","frame-7"]
  },
  {
    username: "Billel.CHIKH",
    email: "billel.chikh@setram-dz.com",
    nom: "Billel.CHIKH",
    telephone: "",
    role: "user",
    hash: "8b5e3be56931bc92c74015c077bcffd172f60242e131481063fb7557e4f0aded",
    actif: true,
    permissions: ["frame-6","historique","frame-1","frame-3","frame-3:section:dashboard","frame-3:section:kpis","frame-3:section:corrective","frame-3:section:preventive","frame-3:section:equipements","frame-3:section:stock","frame-3:section:comparaison","frame-3:section:tendances","frame-3:section:rh-import","frame-3:section:conso","frame-3:unit:__none__","frame-4","frame-4:section:overview","frame-4:section:ramaudit","frame-4:section:taux","frame-4:section:ram","frame-4:section:reformuler","frame-4:section:preventifs","frame-4:section:correctifs","frame-4:section:pieces","frame-4:section:synthese","frame-2","frame-8","frame-5","frame-7"]
  },
  {
    username: "Ahlem.DJOUHRI",
    email: "ahlem.djouhri@setram-dz.com",
    nom: "Ahlem.DJOUHRI",
    telephone: "",
    role: "user",
    hash: "8b5e3be56931bc92c74015c077bcffd172f60242e131481063fb7557e4f0aded",
    actif: true,
    permissions: ["frame-6","historique","frame-3","frame-3:section:dashboard","frame-3:section:kpis","frame-3:section:corrective","frame-3:section:preventive","frame-3:section:equipements","frame-3:section:stock","frame-3:section:comparaison","frame-3:section:tendances","frame-3:section:rh-import","frame-3:section:conso","frame-3:unit:__none__","frame-4","frame-4:section:overview","frame-4:section:ramaudit","frame-4:section:taux","frame-4:section:ram","frame-4:section:reformuler","frame-4:section:preventifs","frame-4:section:correctifs","frame-4:section:pieces","frame-4:section:synthese","frame-2","frame-8","frame-5","frame-7"]
  }
];

/* Journal des réinitialisations de mot de passe, affiché dans
   admin.html (Gestion des comptes). Alimenté automatiquement. */
window.SETRAM_NOTIFICATIONS = [

];
