/* =========================================================
   chat-messages.js — Discussion d'équipe · Plateforme Maintenance SETRAM
   Mis à jour automatiquement le 23/08/2026 14:57:14
   ========================================================= */
window.SETRAM_CHAT = [
  {"username": "admin", "nom": "Administrateur", "date": "2026-08-23T12:23:48.732Z", "message": "", "attachment": {"name":"1_0_liste_signalements_correctifs_mr_alg_2026-08-23T08_01_14.1288945+01_00.xlsx","storedName":"1787487826237_rcu5ak_1_0_liste_signalements_correctifs_mr_alg_2026-08-23T08_01_14.1288945_01_00.xlsx","size":1123891,"mime":"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}},
  {"username": "admin", "nom": "Administrateur", "date": "2026-08-23T12:23:54.746Z", "message": "alo"},
  {"username": "Brahim.BOUNOUA", "nom": "Brahim.BOUNOUA", "date": "2026-08-23T12:25:39.969Z", "message": "oui"},
  {"username": "admin", "nom": "Administrateur", "date": "2026-08-23T12:26:30.991Z", "message": "🚨"},
  {"username": "Brahim.BOUNOUA", "nom": "Brahim.BOUNOUA", "date": "2026-08-23T12:26:54.997Z", "message": "Test"},
  {"username": "Salaheddine.SEDDAOUI", "nom": "Salaheddine.SEDDAOUI", "date": "2026-08-23T12:27:13.780Z", "message": "allo"},
  {"username": "Abdelkader.NASRI", "nom": "Abdelkader.NASRI", "date": "2026-08-23T13:57:14.063Z", "message": "test"}
];
