/* =========================================================
   portal-navbar.js — Barre de navigation du portail
   -----------------------------------------------------------
   Injecte, en haut de la page, une barre identique (mêmes styles,
   mêmes icônes) à celle du portail (index.html) affichée quand on
   navigue dans les outils Ingénierie.

   Utilisée sur les applications qui s'ouvrent en dehors de l'iframe
   du portail (Suivi des Documents Maintenance, Suivi des Contrôles
   SDF, Suivi des Requêtes SDF, ...) afin qu'on puisse aussi naviguer
   vers les autres applications sans repasser par l'accueil.

   Inclusion (2 niveaux sous la racine, ex: departements/xxx/page.html) :
     <script src="../../assets/portal-navbar.js"></script>
   À placer après auth.js (utilise window.SETRAM_USER / SETRAM_HAS_ACCESS
   et l'évènement "setram-auth-ready" déjà déclenché par auth.js).
   ========================================================= */
(function () {
  "use strict";

  // ---------------------------------------------------------------
  // Racine du site, calculée depuis l'emplacement de ce script, pour
  // que la barre fonctionne quelle que soit la profondeur de la page.
  // ---------------------------------------------------------------
  var scriptEl = document.currentScript;
  var ROOT = "../../";
  if (scriptEl && scriptEl.src) {
    ROOT = scriptEl.src.replace(/assets\/portal-navbar\.js.*$/, "");
  }

  // ---------------------------------------------------------------
  // Liste des applications du portail (identique à la navigation
  // affichée dans index.html, complétée des applications qui n'y
  // figurent pas encore en tant que bouton : Suivi des Documents
  // Maintenance, Suivi des Contrôles SDF, Suivi des Requêtes SDF).
  // "perm" correspond à l'identifiant de permission utilisé par
  // auth.js (SETRAM_HAS_ACCESS) / comptes.js.
  // ---------------------------------------------------------------
  var ICONS = {
    import: '<path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>',
    trend: '<path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 5-7"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06A1.65 1.65 0 004.6 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06A1.65 1.65 0 009 4.6a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06A1.65 1.65 0 0019.4 9c.14.36.5.6.9.6H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/>',
    bars: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
    check: '<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/>',
    contract: '<path d="M16 4h2a2 2 0 012 2v14a2 2 0 01-2 2H6a2 2 0 01-2-2V6a2 2 0 012-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M9 12h6M9 16h6"/>',
    dailyReport: '<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><path d="M14 2v6h6"/><path d="M9 13h6M9 17h6M9 9h1"/>',
    fileText: '<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
    clipboardCheck: '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>',
    inbox: '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
    history: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>'
  };

  // Remarque : cette barre n'est injectée que sur les pages autonomes
  // (Suivi des Documents Maintenance, Suivi des Contrôles/Requêtes SDF).
  // Les onglets Ingénierie (Centre d'Import, Analyse MBF, Suivi des
  // Performances, Rapport d'Activité, Contrats, Rapport Journalier) ne
  // concernent que le département Ingénierie et n'apparaissent donc
  // pas ici.
  //
  // De plus, chaque outil est rattaché à un département ("dept") :
  // Maintenance et Planification (SDF) ne doivent pas se mélanger.
  // Sur la page "Suivi des Documents Maintenance", seuls les outils
  // "maintenance" (+ Historique, commun) s'affichent ; sur les pages
  // SDF, seuls les outils "planification" (+ Historique) s'affichent.
  var NAV_ITEMS = [
    { perm: "frame-7", label: "Suivi des Documents Maintenance", href: "departements/maintenance/suivi-documents.html", icon: ICONS.fileText, dept: "maintenance" },
    { perm: "frame-9", label: "Suivi des Contrôles (SDF)", href: "departements/planification/suivi-sdf.html", icon: ICONS.clipboardCheck, dept: "planification" },
    { perm: "frame-10", label: "Suivi des Requêtes (SDF)", href: "departements/planification/suivi-requetes-sdf.html", icon: ICONS.inbox, dept: "planification" },
    { perm: "historique", label: "Historique des connexions", href: "historique.html", icon: ICONS.history }
  ];

  // Département de la page courante, déduit de son chemin
  // (.../departements/maintenance/... ou .../departements/planification/...).
  var CURRENT_DEPT = (function () {
    var m = location.pathname.match(/\/departements\/([^/]+)\//);
    return m ? m[1] : null;
  })();

  // On ne garde que les outils du même département que la page courante ;
  // les entrées sans "dept" (ex: Historique) restent toujours visibles.
  var VISIBLE_NAV_ITEMS = NAV_ITEMS.filter(function (item) {
    return !item.dept || item.dept === CURRENT_DEPT;
  });

  function svg(inner, extraClass) {
    return '<svg class="' + (extraClass || "") + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + inner + "</svg>";
  }

  function isCurrent(href) {
    var here = location.pathname.replace(/\/+$/, "").split("/");
    var target = href.replace(/^\.\.\//g, "").split("/");
    var hereFile = here[here.length - 1];
    var hereDir = here[here.length - 2];
    var targetFile = target[target.length - 1];
    var targetDir = target[target.length - 2];
    return hereFile === targetFile && hereDir === targetDir;
  }

  function buildStyle() {
    return (
      "<style>" +
      ".setram-pnav{flex:none;height:64px;background:linear-gradient(135deg,#0a1930 20%,#2f6690 100%);" +
      "border-bottom:1px solid rgba(255,255,255,.08);box-shadow:inset 0 -2px 0 #2f6690,0 2px 6px rgba(0,0,0,.15);" +
      "display:flex;align-items:center;padding:0 24px;position:sticky;top:0;z-index:1000;" +
      "font-family:'Montserrat',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;}" +
      ".setram-pnav *{box-sizing:border-box;}" +
      ".setram-pnav-brand{display:flex;align-items:center;gap:14px;cursor:pointer;background:none;border:none;padding:0;flex:none;text-decoration:none;}" +
      ".setram-pnav-brand img{display:block;width:104px;height:auto;}" +
      ".setram-pnav-brand-caption{font-family:'Montserrat',monospace;font-size:9.5px;letter-spacing:.6px;text-transform:uppercase;" +
      "color:#7a8aaa;font-weight:700;line-height:1.3;border-left:1px solid rgba(255,255,255,.08);padding-left:14px;}" +
      ".setram-pnav-nav{display:flex;align-items:center;gap:2px;margin-left:26px;padding-left:26px;" +
      "border-left:1px solid rgba(255,255,255,.08);overflow-x:auto;scrollbar-width:none;}" +
      ".setram-pnav-nav::-webkit-scrollbar{display:none;}" +
      ".setram-pnav-btn{appearance:none;border:none;background:transparent;cursor:pointer;flex:none;" +
      "display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;color:#7a8aaa;" +
      "padding:9px 14px;border-radius:8px;transition:color .15s,background .15s;position:relative;" +
      "text-decoration:none;white-space:nowrap;font-family:inherit;}" +
      ".setram-pnav-btn svg{width:15px;height:15px;flex:none;opacity:.8;transition:transform .2s ease;}" +
      ".setram-pnav-btn:hover svg{transform:scale(1.12) rotate(-4deg);}" +
      ".setram-pnav-btn:hover{color:#dde8ff;background:rgba(255,255,255,.05);}" +
      ".setram-pnav-btn::after{content:'';position:absolute;left:14px;right:14px;bottom:2px;height:2px;border-radius:2px;" +
      "background:linear-gradient(90deg,#8fd8ec,#2f6690);transform:scaleX(0);transform-origin:left;transition:transform .25s ease;}" +
      ".setram-pnav-btn.is-active::after{transform:scaleX(1);}" +
      ".setram-pnav-btn.is-active{color:#f8fafc;background:rgba(37,99,235,.16);box-shadow:inset 0 0 0 1px rgba(37,99,235,.4);}" +
      ".setram-pnav-dropdown{position:relative;flex:none;}" +
      ".setram-pnav-dropdown-toggle .chevron{width:11px;height:11px;opacity:.7;margin-left:-2px;transition:transform .2s ease;}" +
      ".setram-pnav-dropdown.open .chevron{transform:rotate(180deg);}" +
      ".setram-pnav-dropdown-menu{position:absolute;top:calc(100% + 8px);left:0;min-width:248px;background:#0a1930;" +
      "border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:6px;display:flex;flex-direction:column;gap:2px;" +
      "box-shadow:0 16px 32px rgba(0,0,0,.4);opacity:0;visibility:hidden;transform:translateY(-6px);" +
      "transition:opacity .15s ease,transform .15s ease,visibility .15s;z-index:1010;}" +
      ".setram-pnav-dropdown.open .setram-pnav-dropdown-menu{opacity:1;visibility:visible;transform:translateY(0);}" +
      ".setram-pnav-dropdown-item{appearance:none;border:none;background:transparent;cursor:pointer;display:flex;" +
      "align-items:center;gap:9px;width:100%;font-size:13px;font-weight:600;color:#7a8aaa;text-align:left;" +
      "padding:9px 12px;border-radius:8px;transition:color .15s,background .15s;text-decoration:none;font-family:inherit;}" +
      ".setram-pnav-dropdown-item svg{width:15px;height:15px;flex:none;opacity:.8;}" +
      ".setram-pnav-dropdown-item:hover{color:#dde8ff;background:rgba(255,255,255,.06);}" +
      ".setram-pnav-dropdown-item.is-active{color:#f8fafc;background:rgba(37,99,235,.16);box-shadow:inset 0 0 0 1px rgba(37,99,235,.4);}" +
      ".setram-pnav-right{display:flex;align-items:center;gap:14px;margin-left:auto;flex:none;padding-left:14px;}" +
      ".setram-pnav-whoami{font-size:12px;color:#a9c6d9;font-family:'Montserrat',monospace;}" +
      ".setram-pnav-admin{color:#a9c6d9;text-decoration:none;font-size:11.5px;font-weight:700;white-space:nowrap;}" +
      ".setram-pnav-admin:hover{color:#fff;}" +
      ".setram-pnav-logout{appearance:none;border:1px solid rgba(255,255,255,.25);background:transparent;color:#f8fafc;" +
      "padding:5px 12px;border-radius:6px;font-size:11.5px;font-weight:700;cursor:pointer;font-family:inherit;white-space:nowrap;}" +
      ".setram-pnav-logout:hover{background:rgba(255,255,255,.08);}" +
      ".setram-pnav-clock{font-family:'Montserrat',monospace;font-size:12px;color:#7a8aaa;white-space:nowrap;}" +
      "@media (max-width:900px){.setram-pnav-brand-caption{display:none;}.setram-pnav-whoami{display:none;}}" +
      "</style>"
    );
  }

  function buildNavItemHtml(item) {
    if (item.dropdown) {
      var subHtml = item.items.map(function (sub) {
        return (
          '<a class="setram-pnav-dropdown-item" data-perm="' + sub.perm + '" href="' + ROOT + sub.href + '">' +
          svg(sub.icon) + sub.label + "</a>"
        );
      }).join("");
      return (
        '<div class="setram-pnav-dropdown" data-dropdown>' +
        '<button type="button" class="setram-pnav-btn setram-pnav-dropdown-toggle">' +
        svg(item.icon) + item.dropdown + svg('<path d="M6 9l6 6 6-6"/>', "chevron") +
        "</button>" +
        '<div class="setram-pnav-dropdown-menu">' + subHtml + "</div>" +
        "</div>"
      );
    }
    return (
      '<a class="setram-pnav-btn" data-perm="' + item.perm + '" href="' + ROOT + item.href + '">' +
      svg(item.icon) + item.label + "</a>"
    );
  }

  function init() {
    if (document.querySelector(".setram-pnav")) return; // déjà injectée

    var navHtml = VISIBLE_NAV_ITEMS.map(buildNavItemHtml).join("");

    var barHtml =
      buildStyle() +
      '<div class="setram-pnav" id="setramPortalNavbar">' +
      '<a class="setram-pnav-brand" href="' + ROOT + 'index.html" title="Retour à l\'accueil">' +
      '<img src="' + ROOT + 'assets/setram-logo.png" alt="SETRAM">' +
      '<span class="setram-pnav-brand-caption">Plateforme<br>Maintenance</span>' +
      "</a>" +
      '<nav class="setram-pnav-nav">' + navHtml + "</nav>" +
      '<div class="setram-pnav-right">' +
      '<span class="setram-pnav-whoami" id="pnavWhoami"></span>' +
      '<a href="' + ROOT + 'admin.html" id="pnavAdminLink" class="setram-pnav-admin" style="display:none;">Gestion des comptes</a>' +
      '<button id="pnavLogoutBtn" class="setram-pnav-logout" style="display:none;" onclick="window.SETRAM_LOGOUT && window.SETRAM_LOGOUT()">Déconnexion</button>' +
      '<span class="setram-pnav-clock" id="pnavClock"></span>' +
      "</div>" +
      "</div>";

    document.body.insertAdjacentHTML("afterbegin", barHtml);

    // Surbrillance de la page courante
    document.querySelectorAll(".setram-pnav-btn[href], .setram-pnav-dropdown-item[href]").forEach(function (el) {
      var href = el.getAttribute("href");
      if (isCurrent(href.replace(ROOT, ""))) {
        el.classList.add("is-active");
        var dd = el.closest(".setram-pnav-dropdown");
        if (dd) dd.querySelector(".setram-pnav-dropdown-toggle").classList.add("is-active");
      }
    });

    // Dropdown "Rapport d'Activité"
    var dropdown = document.querySelector(".setram-pnav-dropdown[data-dropdown]");
    if (dropdown) {
      var toggle = dropdown.querySelector(".setram-pnav-dropdown-toggle");
      toggle.addEventListener("click", function (e) {
        e.stopPropagation();
        dropdown.classList.toggle("open");
      });
      document.addEventListener("click", function (e) {
        if (!dropdown.contains(e.target)) dropdown.classList.remove("open");
      });
      document.addEventListener("keydown", function (e) {
        if (e.key === "Escape") dropdown.classList.remove("open");
      });
    }

    // Horloge
    function tick() {
      var now = new Date();
      var d = now.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric" });
      var t = now.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
      var clockEl = document.getElementById("pnavClock");
      if (clockEl) clockEl.textContent = d + " — " + t;
    }
    tick();
    setInterval(tick, 30000);

    // Session utilisateur : nom, lien admin, déconnexion, filtrage par permissions
    function applyUser(user) {
      var whoamiEl = document.getElementById("pnavWhoami");
      if (whoamiEl && user) whoamiEl.textContent = user.nom || user.username || "";
      var adminLink = document.getElementById("pnavAdminLink");
      var logoutBtn = document.getElementById("pnavLogoutBtn");
      if (logoutBtn) logoutBtn.style.display = "inline-block";
      if (adminLink && user && user.role === "admin") adminLink.style.display = "inline-block";

      if (user && user.role !== "admin" && window.SETRAM_HAS_ACCESS) {
        document.querySelectorAll(".setram-pnav-btn[data-perm], .setram-pnav-dropdown-item[data-perm]").forEach(function (el) {
          if (!window.SETRAM_HAS_ACCESS(el.dataset.perm)) el.style.display = "none";
        });
        var dd = document.querySelector(".setram-pnav-dropdown[data-dropdown]");
        if (dd) {
          var anyVisible = Array.prototype.some.call(dd.querySelectorAll(".setram-pnav-dropdown-item"), function (it) {
            return it.style.display !== "none";
          });
          if (!anyVisible) dd.style.display = "none";
        }
      }
    }

    if (window.SETRAM_USER) applyUser(window.SETRAM_USER);
    document.addEventListener("setram-auth-ready", function (e) {
      applyUser(e.detail || window.SETRAM_USER);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
