/* =========================================================
   conso-mensuelle.js — Consommations mensuelles (Electricite, Eau, Gaz)
   Plateforme Maintenance SETRAM — genere automatiquement
   -----------------------------------------------------------
   ⚠️ A deposer dans assets/conso-mensuelle.js sur le serveur pour
   appliquer ces changements a TOUS les utilisateurs.
   ========================================================= */
window.SETRAM_CONSO_MENSUELLE = {};
