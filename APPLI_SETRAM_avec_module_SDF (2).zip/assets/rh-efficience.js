/* =========================================================
   rh-efficience.js — Efficience RH : Charge RAM (saisie mensuelle) + historique
   Plateforme Maintenance SETRAM — genere automatiquement
   -----------------------------------------------------------
   ⚠️ A deposer dans assets/rh-efficience.js sur le serveur pour
   appliquer ces changements a TOUS les utilisateurs.
   ========================================================= */
window.SETRAM_RH_EFFICIENCE = {};
