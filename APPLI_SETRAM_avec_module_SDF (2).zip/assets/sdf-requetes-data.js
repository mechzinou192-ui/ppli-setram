/* =========================================================
   sdf-requetes-data.js — Suivi des Requêtes DG → Directeur de Maintenance → UO
   Fichier de données partagé, à déposer sur le lecteur réseau
   dans le même dossier "assets" que comptes.js et sdf-plan-action-data.js.
   Mis à jour automatiquement par l'outil Suivi des Requêtes —
   ne pas modifier ce fichier manuellement pendant qu'il est
   ouvert par un utilisateur (écriture concurrente possible).
   ========================================================= */
window.SETRAM_SDF_REQUETES = [
];
window.SETRAM_SDF_REQUETES_HISTORIQUE = [
];
