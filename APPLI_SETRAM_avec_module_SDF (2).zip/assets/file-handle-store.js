/* =========================================================
   file-handle-store.js — Mémorisation du fichier comptes.js
   -----------------------------------------------------------
   Stocke le "handle" (référence native) vers comptes.js dans
   IndexedDB, pour que le navigateur s'en souvienne d'une fois
   sur l'autre — l'utilisateur ne le sélectionne qu'UNE SEULE
   FOIS sur un poste/navigateur donné. Ensuite, seule une petite
   confirmation de permission peut réapparaître de temps en temps
   (comportement du navigateur, pas de fenêtre de sélection).
   ========================================================= */
window.SetramFileHandleStore = (function () {
  var DB_NAME = "setram-file-handles";
  var STORE = "handles";

  function openDb() {
    return new Promise(function (resolve, reject) {
      var req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = function () {
        req.result.createObjectStore(STORE);
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error); };
    });
  }

  async function save(key, handle) {
    var db = await openDb();
    return new Promise(function (resolve, reject) {
      var tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(handle, key);
      tx.oncomplete = function () { resolve(true); };
      tx.onerror = function () { reject(tx.error); };
    });
  }

  async function load(key) {
    var db = await openDb();
    return new Promise(function (resolve, reject) {
      var tx = db.transaction(STORE, "readonly");
      var req = tx.objectStore(STORE).get(key);
      req.onsuccess = function () { resolve(req.result || null); };
      req.onerror = function () { reject(req.error); };
    });
  }

  // Récupère un handle utilisable en écriture pour le fichier "key" :
  // réutilise celui déjà connu si la permission est encore valide
  // (silencieux, aucune fenêtre), sinon ouvre le sélecteur de fichier
  // (une seule fois par fichier/navigateur). Retourne un objet détaillé
  // { handle, reason } où reason vaut "ok", "user_cancelled" (fenêtre
  // fermée sans choisir), "permission_denied", ou "unsupported".
  async function getWritableHandle(key, pickerOptions) {
    var handle = null;
    try { handle = await load(key); } catch (e) {}

    if (handle) {
      try {
        var perm = await handle.queryPermission({ mode: "readwrite" });
        if (perm === "granted") return { handle: handle, reason: "ok" };
        if (perm === "prompt") {
          var granted = await handle.requestPermission({ mode: "readwrite" });
          if (granted === "granted") return { handle: handle, reason: "ok" };
        }
        // Handle connu mais permission refusée : on retente une sélection propre plutôt que d'abandonner.
      } catch (e) {
        // Le handle stocké n'est plus valide (fichier déplacé/supprimé) → on repasse par le sélecteur.
      }
    }

    if (!window.showOpenFilePicker) return { handle: null, reason: "unsupported" };
    var picked;
    try {
      var handles = await window.showOpenFilePicker(pickerOptions || {
        types: [{ description: "comptes.js", accept: { "text/javascript": [".js"] } }],
        excludeAcceptAllOption: false
      });
      picked = handles[0];
    } catch (e) {
      return { handle: null, reason: "user_cancelled" }; // fenêtre fermée / Échap / bouton Annuler
    }
    var grant;
    try {
      grant = await picked.requestPermission({ mode: "readwrite" });
    } catch (e) {
      return { handle: null, reason: "permission_denied", detail: e && e.message };
    }
    if (grant !== "granted") return { handle: null, reason: "permission_denied" };
    try { await save(key, picked); } catch (e) {}
    return { handle: picked, reason: "ok" };
  }

  // Récupère un handle SANS jamais ouvrir de sélecteur (silencieux) :
  // renvoie le handle si un a déjà été connecté et que la permission
  // est encore valide, sinon null.
  async function tryGetHandleSilently(key) {
    var handle = null;
    try { handle = await load(key); } catch (e) { return null; }
    if (!handle) return null;
    try {
      var perm = await handle.queryPermission({ mode: "readwrite" });
      if (perm === "granted") return handle;
      if (perm === "prompt") {
        var granted = await handle.requestPermission({ mode: "readwrite" });
        if (granted === "granted") return handle;
      }
    } catch (e) {}
    return null;
  }

  async function clear(key) {
    var db = await openDb();
    return new Promise(function (resolve) {
      var tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).delete(key);
      tx.oncomplete = function () { resolve(true); };
      tx.onerror = function () { resolve(false); };
    });
  }

  return { save: save, load: load, clear: clear, getWritableHandle: getWritableHandle, tryGetHandleSilently: tryGetHandleSilently };
})();
