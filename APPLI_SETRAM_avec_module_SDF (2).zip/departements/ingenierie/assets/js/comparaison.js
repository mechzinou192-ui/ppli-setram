/* =========================================================
   COMPARAISON — Comparaison sous-systemes entre unites
   Extrait de suivi-performances.html (refactor de maintenabilite,
   aucun changement de comportement). Ce fichier est charge en
   <script src="assets/js/comparaison.js"> APRES le script principal
   de la page (il utilise des fonctions communes comme debounce,
   getFilters, pct... definies plus haut), donc ces fonctions
   restent globales et disponibles partout comme avant.
   ========================================================= */
let CMP_AGG = null;       // dernier agrégat calculé (pour export XLSX)
let CMP_FULL_PREV = null; // TITRE_BT par unité/code, filtré par DATE_PREVUE (memes filtres que la page) — pour export XLSX

// La périodicité n'est PAS déduite des écarts entre dates (peu fiable : il faut au moins 2 dates valides
// pour le même équipement). Elle est lue directement dans le libellé du BT (TITRE_BT), qui précise
// explicitement le type de visite, ex : "Visite Annuelle Coffret d'arrêt d'urgence (CAU) -SST00" → Annuelle.
const CMP_PERIOD_KEYWORDS = [
  { label: 'Hebdomadaire',  days: 7,   re: /hebdo/i },
  { label: 'Mensuelle',     days: 30,  re: /mensuel/i },
  { label: 'Bimestrielle',  days: 60,  re: /bimestriel/i },
  { label: 'Trimestrielle', days: 91,  re: /trimestriel/i },
  { label: 'Semestrielle',  days: 182, re: /semestriel/i },
  { label: 'Annuelle',      days: 365, re: /\bannuel/i }
];
// Cherche le type de visite (mot-clé de périodicité) dans le titre d'UN BT
function cmpExtractPeriodFromTitre(titre) {
  if (!titre) return null;
  for (const p of CMP_PERIOD_KEYWORDS) if (p.re.test(titre)) return p;
  return null;
}
// Pour un ensemble de codes équipement présents dans la cellule (sous-système x unité), sur la période filtrée :
// on regarde les TITRE_BT de chaque équipement DANS LA PERIODE FILTREE (DATE_PREVUE) et on lit directement
// le type de visite indiqué dans le libellé. On remonte la liste de tous les types de visite distincts
// rencontrés pour ces équipements sur la période.
function cmpPeriodInfoForCodes(codes, fullTitresMap) {
  const labels = new Set();
  const daysList = [];
  codes.forEach(code => {
    const titres = (fullTitresMap && fullTitresMap[code]) || [];
    const foundLabels = new Set();
    titres.forEach(t => { const p = cmpExtractPeriodFromTitre(t); if (p) foundLabels.add(p.label); });
    foundLabels.forEach(lbl => {
      labels.add(lbl);
      const kw = CMP_PERIOD_KEYWORDS.find(k => k.label === lbl);
      if (kw) daysList.push(kw.days);
    });
  });
  daysList.sort((a, b) => a - b);
  const medianDays = daysList.length ? daysList[Math.floor(daysList.length / 2)] : null;
  return { labels: [...labels].sort(), medianDays, nbWithData: daysList.length };
}
// Historique complet (tous les TITRE_BT, sans filtre de période) des visites par équipement, pour une unité
// TITRE_BT par équipement à partir des lignes préventives déjà filtrées (par date DATE_PREVUE, système, etc.)
function cmpBuildFullPrevTitres(prevRows) {
  const map = {};
  (prevRows || []).forEach(r => {
    const code = (r['CODE_EQUIPEMENT'] || '').trim();
    if (!code) return;
    const titre = (r['TITRE_BT'] || '').trim();
    if (!titre) return;
    map[code] = map[code] || [];
    map[code].push(titre);
  });
  return map;
}
function cmpFindDurKey(r) {
  return Object.keys(r).find(k => /dur.{0,3}e.*interv|interv.*min/i.test(k.normalize('NFD').replace(/[\u0300-\u036f]/g, '')));
}
// DAT et DTT désignent le même sous-système (orthographes différentes selon les unités) → on les fusionne pour la comparaison
function cmpNormSousSysteme(ss) {
  const up = (ss || '').trim().toUpperCase();
  if (up === 'DAT' || up === 'DTT') return 'DAT/DTT';
  return ss;
}

function renderComparaisonPage() {
  const container = document.getElementById('comp-content');

  // ── Collecte des données par unité (respecte la plage de dates + filtre système globaux) ──
  const byUnit = {};
  UNITS.forEach(u => { byUnit[u] = getFilteredData(u); });
  const totalRows = UNITS.reduce((a, u) => a + byUnit[u].corrRows.length + byUnit[u].prevRows.length, 0);
  if (totalRows === 0) {
    container.innerHTML = `<div class="empty-state"><div class="es-icon">⚖️</div><div class="es-title">Aucune donnée</div></div>`;
    return;
  }

  // ── Filtre de date local (en plus du filtre de dates global) : DATE_DI pour le correctif, DATE_PREVUE pour le préventif ──
  const fDateStart = document.getElementById('cmp-fil-date-start')?.value || '';
  const fDateEnd   = document.getElementById('cmp-fil-date-end')?.value   || '';
  if (fDateStart || fDateEnd) {
    const ds = fDateStart ? new Date(fDateStart + 'T00:00:00') : new Date(2000, 0, 1);
    const de = fDateEnd   ? new Date(fDateEnd   + 'T23:59:59') : new Date(2099, 11, 31);
    UNITS.forEach(u => {
      byUnit[u].corrRows = filterByDate(byUnit[u].corrRows, 'DATE_DI', ds, de);
      byUnit[u].prevRows = filterByDate(byUnit[u].prevRows, 'DATE_PREVUE', ds, de);
    });
  }

  // ── Historique des TITRE_BT par équipement, pour chaque unité — respecte le filtre de date (global + local) sur DATE_PREVUE ──
  const fullPrevByUnit = {};
  UNITS.forEach(u => { fullPrevByUnit[u] = cmpBuildFullPrevTitres(byUnit[u].prevRows); });
  CMP_FULL_PREV = fullPrevByUnit;

  // ── Agrégation : agg[systeme][sousSysteme][unite] = { corrNb, corrH, prevNb, prevH, prevCodes:Set() } ──
  const agg = {};
  function bucket(sys, ss, u) {
    agg[sys] = agg[sys] || {};
    agg[sys][ss] = agg[sys][ss] || {};
    agg[sys][ss][u] = agg[sys][ss][u] || { corrNb: 0, corrH: 0, prevNb: 0, prevH: 0, prevCodes: new Set() };
    return agg[sys][ss][u];
  }
  UNITS.forEach(u => {
    byUnit[u].corrRows.forEach(r => {
      const code = (r['CODE_EQUIPEMENT'] || r['EQUIPEMENT'] || '').trim();
      const p = parseCodeEquipement(code);
      if (p.systeme === '— N/A —' || p.sousSysteme === '— N/A —') return;
      const s = normState(r['ETAT_DI']);
      if (!(isTraitee(s) || isRealisee(s) || isTransmis(s) || isTransmettre(s))) return;
      const b = bucket(p.systeme, cmpNormSousSysteme(p.sousSysteme), u);
      b.corrNb++;
      const dk = cmpFindDurKey(r);
      const d = dk ? parseFloat(String(r[dk]).replace(',', '.')) : NaN;
      if (!isNaN(d) && d > 0) b.corrH += d / 60;
    });
    byUnit[u].prevRows.forEach(r => {
      const code = (r['CODE_EQUIPEMENT'] || '').trim();
      const p = parseCodeEquipement(code);
      if (p.systeme === '— N/A —' || p.sousSysteme === '— N/A —') return;
      const b = bucket(p.systeme, cmpNormSousSysteme(p.sousSysteme), u);
      b.prevNb++;
      const dk = cmpFindDurKey(r);
      const d = dk ? parseFloat(String(r[dk]).replace(',', '.')) : NaN;
      if (!isNaN(d) && d > 0) b.prevH += d / 60;
      if (code) b.prevCodes.add(code);
    });
  });
  CMP_AGG = agg;

  // ── Filtres locaux ──
  const allSystemesRaw = Object.keys(agg).sort();
  const fSys = document.getElementById('cmp-fil-systeme')?.value || 'all';
  const fSS  = document.getElementById('cmp-fil-soussysteme')?.value || 'all';

  // Sous-systèmes disponibles selon le système choisi (ou tous si 'all')
  const allSousSystemesRaw = [...new Set(
    (fSys !== 'all' ? [fSys] : allSystemesRaw).flatMap(s => Object.keys(agg[s] || {}))
  )].sort();

  const filterBarHtml = `
    <div class="filter-card" style="margin:0 0 18px;width:auto;flex-wrap:wrap;gap:10px" id="cmp-filter-bar">
      <div class="fc-icon">⚖️</div>
      <div class="filter-group">
        <span class="filter-label">Système</span>
        <select id="cmp-fil-systeme" onchange="
          const ss=document.getElementById('cmp-fil-soussysteme'); if(ss) ss.value='all';
          renderComparaisonPage()" style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;cursor:pointer;outline:none;font-weight:500;">
          <option value="all" ${fSys === 'all' ? 'selected' : ''}>Tous</option>
          ${allSystemesRaw.map(s => `<option value="${s}" ${fSys === s ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
      </div>
      <div class="filter-group">
        <span class="filter-label">Sous-système</span>
        <select id="cmp-fil-soussysteme" onchange="renderComparaisonPage()"
          style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;cursor:pointer;outline:none;font-weight:500;max-width:220px">
          <option value="all" ${fSS === 'all' ? 'selected' : ''}>Tous</option>
          ${allSousSystemesRaw.map(ss => `<option value="${ss}" ${fSS === ss ? 'selected' : ''}>${ss}</option>`).join('')}
        </select>
      </div>
      <div class="fc-divider"></div>
      <div class="filter-group">
        <span class="filter-label">Début</span>
        <input type="date" id="cmp-fil-date-start" value="${fDateStart}" onchange="renderComparaisonPage()"
          style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;outline:none;">
      </div>
      <div class="filter-group">
        <span class="filter-label">Fin</span>
        <input type="date" id="cmp-fil-date-end" value="${fDateEnd}" onchange="renderComparaisonPage()"
          style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;outline:none;">
      </div>
      <div style="margin-left:auto;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
        <button class="btn btn-ghost btn-sm" onclick="exportComparaisonXLSX()">📥 Export XLSX</button>
        <button class="btn btn-ghost btn-sm" onclick="
          const s=document.getElementById('cmp-fil-systeme'); if(s) s.value='all';
          const q=document.getElementById('cmp-fil-soussysteme'); if(q) q.value='all';
          const ds=document.getElementById('cmp-fil-date-start'); if(ds) ds.value='';
          const de=document.getElementById('cmp-fil-date-end');   if(de) de.value='';
          renderComparaisonPage()">✕ Reset</button>
      </div>
    </div>`;

  // ── Construction des sections par système ──
  let systemes = fSys !== 'all' ? allSystemesRaw.filter(s => s === fSys) : allSystemesRaw;

  const sectionsHtml = systemes.map(sys => {
    let sousSystemes = Object.keys(agg[sys]).sort();
    if (fSS !== 'all') sousSystemes = sousSystemes.filter(ss => ss === fSS);
    if (sousSystemes.length === 0) return '';

    const rowsHtml = sousSystemes.map(ss => {
      const perUnit = agg[sys][ss];

      // Infos périodicité par unité (à partir de l'historique complet de chaque équipement présent sur la période) ──
      const periodInfo = {};
      UNITS.forEach(u => {
        const b = perUnit[u];
        periodInfo[u] = b ? cmpPeriodInfoForCodes([...b.prevCodes], fullPrevByUnit[u]) : null;
      });
      // Médiane inter-unités (à partir de la médiane de chaque unité) pour repérer les écarts
      const unitMedians = UNITS.map(u => periodInfo[u]?.medianDays).filter(v => v != null).sort((a, b) => a - b);
      const globalMedian = unitMedians.length ? unitMedians[Math.floor(unitMedians.length / 2)] : null;

      const corrCells = UNITS.map(u => {
        const b = perUnit[u];
        if (!b || b.corrNb === 0) return `<td style="text-align:center;color:var(--text3);font-size:11px">—</td>`;
        return `<td style="text-align:center;font-size:11px"><b>${b.corrNb}</b> panne${b.corrNb > 1 ? 's' : ''}<br><span style="color:var(--text3);font-size:10px">${b.corrH.toFixed(1)}h</span></td>`;
      }).join('');

      const prevCells = UNITS.map(u => {
        const b = perUnit[u];
        if (!b || b.prevNb === 0) return `<td style="text-align:center;color:var(--text3);font-size:11px">—</td>`;
        const info = periodInfo[u];
        let cellStyle = '';
        let flag = '';
        if (info && info.medianDays != null && globalMedian != null && globalMedian > 0) {
          const ratio = info.medianDays / globalMedian;
          if (ratio > 1.4 || ratio < 0.7) { cellStyle = 'background:rgba(217,119,6,0.12);border-radius:6px'; flag = '⚠️ '; }
        }
        let labelTxt;
        if (!info || info.labels.length === 0) {
          labelTxt = 'type de visite non identifie (TITRE_BT)';
        } else if (info.labels.length === 1) {
          labelTxt = `${info.labels[0]}${info.medianDays != null ? ` (~${Math.round(info.medianDays)}j)` : ''}`;
        } else {
          labelTxt = `${info.labels.length} fréquences: ${info.labels.join(' + ')}`;
        }
        return `<td style="text-align:center;font-size:11px;${cellStyle}">
          <b>${b.prevNb}</b> BT<br>
          <span style="font-size:10px">${flag}${labelTxt}</span>
        </td>`;
      }).join('');

      return `
        <tr style="border-top:2px solid var(--border,#e5eaf3)">
          <td rowspan="2" style="font-size:11px;font-weight:700;color:#0a1930;vertical-align:middle">${ss}</td>
          <td style="font-size:10.5px;color:var(--text3)">🔧 Correctif</td>
          ${corrCells}
        </tr>
        <tr>
          <td style="font-size:10.5px;color:var(--text3)">🛡️ Préventif</td>
          ${prevCells}
        </tr>`;
    }).join('');

    if (!rowsHtml) return '';

    return `
      <div class="card" style="margin-bottom:18px">
        <div class="card-title">⚙️ Système ${sys}</div>
        <div class="table-wrap">
          <table style="width:100%;border-collapse:collapse">
            <thead><tr>
              <th style="text-align:left">Sous-système</th>
              <th style="text-align:left"></th>
              ${UNITS.map(u => `<th style="text-align:center">${u}</th>`).join('')}
            </tr></thead>
            <tbody>${rowsHtml}</tbody>
          </table>
        </div>
      </div>`;
  }).join('');

  container.innerHTML = filterBarHtml + (sectionsHtml || `<div class="empty-state"><div class="es-icon">⚖️</div><div class="es-title">Aucun résultat</div><div class="es-sub">Essayez d'élargir les filtres</div></div>`) +
    `<div class="card" style="margin-top:4px;background:rgba(217,119,6,0.06);border-color:rgba(217,119,6,0.25)">
      <div style="font-size:11px;color:var(--text3)">
        La périodicité de chaque équipement est calculée sur son historique complet de visites (pas seulement la période filtrée), car une fenêtre courte ne suffit pas toujours à voir 2 passages d'un équipement peu fréquent.
        Si les équipements d'une même cellule ont des fréquences différentes, elles sont toutes listées (ex: "2 fréquences: Mensuelle + Trimestrielle").
        ⚠️ = périodicité de cette unité qui s'écarte de plus de 40% de la médiane observée pour ce sous-système entre les unités.
      </div>
    </div>`;
}

async function exportComparaisonXLSX() {
  if (!CMP_AGG) { alert("Aucune donnée à exporter."); return; }
  const rows = [];
  Object.keys(CMP_AGG).sort().forEach(sys => {
    Object.keys(CMP_AGG[sys]).sort().forEach(ss => {
      UNITS.forEach(u => {
        const b = CMP_AGG[sys][ss][u];
        if (!b || (b.corrNb === 0 && b.prevNb === 0)) return;
        const info = cmpPeriodInfoForCodes([...b.prevCodes], (CMP_FULL_PREV && CMP_FULL_PREV[u]) || {});
        rows.push({
          SYSTEME: sys, SOUS_SYSTEME: ss, UNITE: u,
          NB_PANNES_CORRECTIF: b.corrNb, DUREE_H_CORRECTIF: +b.corrH.toFixed(2),
          NB_BT_PREVENTIF: b.prevNb, DUREE_H_PREVENTIF: +b.prevH.toFixed(2),
          PERIODICITE_MEDIANE_JOURS: info.medianDays != null ? Math.round(info.medianDays) : '',
          FREQUENCES_DETECTEES: info.labels.join(' + ') || ''
        });
      });
    });
  });
  if (rows.length === 0) { alert("Aucune donnée à exporter sur le périmètre filtré."); return; }

  showLoading();
  try {
    const logoBuf = await setramLogoBuffer();
    const wb = new ExcelJS.Workbook();
    wb.creator = 'SETRAM — Direction Ingénierie';
    wb.created = new Date();

    // ── Synthese par systeme (toutes unites confondues) ──
    const bySys = {};
    rows.forEach(r => {
      bySys[r.SYSTEME] = bySys[r.SYSTEME] || { corr: 0, corrH: 0, prev: 0, prevH: 0 };
      bySys[r.SYSTEME].corr  += r.NB_PANNES_CORRECTIF;
      bySys[r.SYSTEME].corrH += r.DUREE_H_CORRECTIF;
      bySys[r.SYSTEME].prev  += r.NB_BT_PREVENTIF;
      bySys[r.SYSTEME].prevH += r.DUREE_H_PREVENTIF;
    });
    const summaryRows = Object.keys(bySys).sort().map(s => ({
      'Systeme': s,
      'Nb pannes correctif': bySys[s].corr,
      'Duree correctif (h)': +bySys[s].corrH.toFixed(2),
      'Nb BT preventif': bySys[s].prev,
      'Duree preventif (h)': +bySys[s].prevH.toFixed(2)
    }));
    writeSetramSummarySheet(wb, summaryRows, {
      sheetName: 'Synthese',
      title: '⚖️ Comparaison sous-systèmes — Synthèse',
      subtitle: `Toutes unités : ${UNITS.join(', ')}`,
      logoBuf
    });

    // ── Detail complet (1 ligne = 1 sous-systeme x unite) ──
    writeSetramSheet(wb, 'Comparaison', rows, {
      title: '⚖️ Comparaison sous-systèmes entre unités — Détail',
      subtitle: `Toutes unités : ${UNITS.join(', ')}`,
      accentColor: SETRAM_XLSX.navy,
      logoBuf
    });

    const dstr = new Date().toISOString().slice(0, 10);
    await downloadSetramWorkbook(wb, `Comparaison_SousSystemes_Unites_${dstr}.xlsx`);
  } catch (e) {
    console.error(e);
    alert("Erreur lors de la génération du fichier Excel : " + e.message);
  } finally {
    hideLoading();
  }
}
