// =============================================================================
// SUIVI DES PERFORMANCES — module 09/10 : perf-09-rh-c-ia.js
// Extrait mecaniquement (meme code, meme ordre) du script principal historique
// pour ameliorer la maintenabilite (le fichier faisait ~8300 lignes en un bloc).
// Contenu : Efficience RH (suite) : diagnostic assiste, detail par systeme/sous-systeme, rapport general
// IMPORTANT : ce fichier partage la portee globale avec les autres modules
// perf-XX-*.js et doit rester charge dans l'ORDRE (01 -> 10), car certaines
// fonctions utilisent des constantes/fonctions definies dans les modules precedents.
// =============================================================================
async function launchRHAIUnit(unit) {
  const data = calcRHEfficienceUnit(unit); if (!data) return;
  const panel   = document.getElementById('rh-ai-panel');
  const loader  = document.getElementById('rh-ai-loader');
  const content = document.getElementById('rh-ai-content');
  panel.style.display  = 'block';
  loader.style.display = 'block';
  content.innerHTML    = '';
  panel.scrollIntoView({ behavior:'smooth', block:'start' });

  const surcharges  = data.techList.filter(t=>t.statut==='surcharge').map(t=>`${t.technicien} (${t.tauxOccupationPct.toFixed(0)}%)`).join(', ');
  const sousCharges = data.techList.filter(t=>t.statut==='sous-charge').map(t=>`${t.technicien} (${t.tauxOccupationPct.toFixed(0)}%)`).join(', ');

  const prompt = 'Tu es un expert en gestion des ressources humaines de maintenance industrielle.\n\n' +
    'Analyse l\'efficience RH de l\'unite ' + unit + ' :\n' +
    '- ' + data.nbTech + ' techniciens, charge totale ' + data.chargeReelleTotale.toFixed(0) + 'h, norme ' + data.norme + 'h/mois\n' +
    '- Besoin theorique : ' + data.besoinTheorique.toFixed(2) + ' postes, delta : ' + (data.deltaUnite>0?'+':'') + data.deltaUnite.toFixed(2) + '\n' +
    '- Taux moyen occupation : ' + (data.tauxMoyenOccupation*100).toFixed(1) + '%\n' +
    '- En surcharge (>105%) : ' + (surcharges||'aucun') + '\n' +
    '- En sous-charge (<75%) : ' + (sousCharges||'aucun') + '\n' +
    '- Equilibres : ' + data.nbEquilibre + '\n\n' +
    'Genere des recommandations concretes au format JSON strict (sans markdown, sans backticks) :\n' +
    '{\n' +
    '  "recommandations": [{ "type": "transfert" | "avertissement" | "ok", "titre": "...", "description": "...", "detail": "...", "unite_source": "' + unit + '", "unite_cible": "...", "impact": "..." }],\n' +
    '  "synthese": "...",\n' +
    '  "priorite": "haute" | "moyenne" | "basse"\n' +
    '}';

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model:'claude-sonnet-4-20250514', max_tokens:1000, messages:[{ role:'user', content:prompt }] })
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const apiData  = await response.json();
    const rawText  = (apiData.content||[]).filter(b=>b.type==='text').map(b=>b.text).join('');
    const cleanJson = rawText.replace(/```json|```/g,'').trim();
    renderRHAIResult(JSON.parse(cleanJson));
  } catch (err) {
    console.warn('Fallback local :', err.message);
    renderRHAIResult(generateLocalRHAnalysisUnit(data));
  } finally { loader.style.display = 'none'; }
}

function generateLocalRHAnalysisUnit(data) {
  const recos = []; const unit = data.unit;
  data.techList.filter(t=>t.statut==='surcharge').forEach(t => {
    recos.push({ type:'avertissement', titre:`${t.technicien} — Surcharge ${t.tauxOccupationPct.toFixed(0)}%`,
      description:`Charge de ${t.chargeReelle.toFixed(1)}h pour une norme de ${t.norme}h. Excedent de ${t.delta.toFixed(1)}h sur ${t.nbInterventions} interventions.`,
      detail:'Risque operationnel. Delestage recommande.', unite_source:unit, unite_cible:'',
      impact:`Delestage de ~${(t.delta*0.6).toFixed(0)}h recommande` });
  });
  data.techList.filter(t=>t.statut==='sous-charge').forEach(t => {
    recos.push({ type:'transfert', titre:`${t.technicien} — Capacite disponible ${(100-t.tauxOccupationPct).toFixed(0)}%`,
      description:`Ce technicien dispose d'une capacite de ${Math.abs(t.delta).toFixed(1)}h non utilisee (${t.tauxOccupationPct.toFixed(0)}% de la norme).`,
      detail:'Peut absorber des interventions supplementaires ou etre mobilise en renfort.', unite_source:unit, unite_cible:'',
      impact:`Capacite d'absorption : ~${Math.abs(t.delta).toFixed(0)}h` });
  });
  if (data.nbEquilibre > 0 && recos.length === 0) {
    recos.push({ type:'ok', titre:`Unite ${unit} — Charge globalement equilibree`,
      description:`Taux moyen d'occupation de ${(data.tauxMoyenOccupation*100).toFixed(1)}% pour ${data.nbTech} techniciens.`,
      detail:'', unite_source:unit, unite_cible:'', impact:'Maintenir la configuration actuelle' });
  }
  const priorite = data.nbSurcharge > data.nbTech*0.5 ? 'haute' : data.nbSurcharge > 0 ? 'moyenne' : 'basse';
  return { recommandations:recos,
    synthese:`Unite ${unit} : ${data.nbTech} techniciens, charge ${data.chargeReelleTotale.toFixed(0)}h, norme ${data.norme}h/mois. Besoin : ${data.besoinTheorique.toFixed(1)} postes pour ${data.nbTech} disponibles. ${data.nbSurcharge} en surcharge, ${data.nbSousCharge} en sous-charge.`,
    priorite };
}

// =====================================================================
// HELPERS UI RH
// =====================================================================
function rhKpiCard(label, value, sub, colorClass) {
  return `<div class="kpi-card ${colorClass}">
    <div class="kpi-label">${label}</div>
    <div class="kpi-value" style="font-size:26px">${value}</div>
    <div class="kpi-sub">${sub}</div>
  </div>`;
}

function rhStatutBadge(statut) {
  if (statut === 'surcharge')  return `<span class="badge badge-red">🔴 Surcharge</span>`;
  if (statut === 'sous-charge') return `<span class="badge badge-yellow">🟡 Sous-charge</span>`;
  return `<span class="badge badge-green">🟢 Equilibre</span>`;
}

function renderRHAIResult(parsed) {
  const content = document.getElementById('rh-ai-content');
  if (!parsed) { content.innerHTML = '<div class="empty-state"><div class="es-icon">❌</div><div class="es-title">Erreur</div></div>'; return; }
  const recos   = parsed.recommandations || [];
  const pColors = { haute:'#dc2626', moyenne:'#d97706', basse:'#059669' };
  const pColor  = pColors[parsed.priorite] || '#475569';
  let html = '';
  if (parsed.synthese) {
    html += `<div class="alert-panel warn" style="margin-bottom:16px"><div class="alert-panel-title" style="color:${pColor}">📋 Synthese — Priorite <span style="text-transform:uppercase;font-weight:900">${parsed.priorite||'?'}</span></div>
      <div class="alert-item"><span class="ai-msg" style="font-size:12.5px;color:#0f172a">${parsed.synthese}</span></div>
    </div>`;
  }
  recos.forEach(r => {
    const tagCls = r.type==='transfert' ? 'ai-tag-transfer' : r.type==='avertissement' ? 'ai-tag-warning' : 'ai-tag-ok';
    const tagLbl = r.type==='transfert' ? '🔄 Mobilite recommandee' : r.type==='avertissement' ? '⚠️ Attention' : '✅ Situation stable';
    const routeHtml = (r.unite_source && r.unite_cible && r.type==='transfert')
      ? `<span class="ai-reco-pill">📍 ${r.unite_source} → ${r.unite_cible}</span>` : '';
    html += `<div class="ai-reco-card">
      <div class="ai-tag ${tagCls}">${tagLbl}</div>
      <div class="ai-reco-title">${r.titre||'—'}</div>
      <div class="ai-reco-body">${r.description||''}${r.detail?`<br><span style="color:var(--text3);font-size:11.5px;margin-top:4px;display:block">${r.detail}</span>`:''}</div>
      <div class="ai-reco-meta">${routeHtml}${r.impact?`<span class="ai-reco-pill">💡 ${r.impact}</span>`:''}</div>
    </div>`;
  });
  content.innerHTML = html || `<div class="empty-state"><div class="es-icon">✅</div><div class="es-title">Aucune recommandation</div></div>`;
}

function updateRHDiag() {
  const card   = document.getElementById('rh-diag-card');
  const diagEl = document.getElementById('rh-diag');
  if (!card || !diagEl) return;
  card.style.display = 'block';
  const sections = [];
  UNITS.forEach(u => {
    const cr = RH_DB.corrRows[u]||[], pr = RH_DB.prevRows[u]||[];
    if (cr.length===0 && pr.length===0) return;
    const s = cr[0] || pr[0];
    sections.push(`<div style="margin-bottom:8px">
      <strong style="color:${UNIT_COLORS[u]}">${u}</strong>
      — Corr: ${cr.length} lignes · Prev: ${pr.length} lignes<br>
      <span style="color:var(--text2)">Ex → Tech: <strong>${rhGetTech(s)}</strong> | Heures: <strong>${rhParseHours(s).toFixed(2)}h</strong></span>
    </div>`);
  });
  diagEl.innerHTML = sections.length ? sections.join('') : '<span style="color:#94a3b8">Aucun fichier RH charge</span>';
}

function toggleRHUnit(unit, checked) {
  if (checked) {
    if (!RH_ACTIVE_UNITS.includes(unit)) RH_ACTIVE_UNITS.push(unit);
  } else {
    RH_ACTIVE_UNITS = RH_ACTIVE_UNITS.filter(u => u !== unit);
    if (RH_ACTIVE_UNITS.length === 0) RH_ACTIVE_UNITS = [unit];
  }
  renderRHPage();
}

function showRHSystemDetail(unit, systeme) {
  const panel = document.getElementById('rh-system-detail-panel');
  if (!panel) return;

  // Toggle : si déjà affiché pour ce système, fermer
  if (panel._currentKey === `${unit}:${systeme}` && panel.style.display !== 'none') {
    panel.style.display = 'none';
    panel._currentKey = null;
    return;
  }
  panel._currentKey = `${unit}:${systeme}`;

  const rhStart = document.getElementById('rh-date-start')?.value;
  const rhEnd   = document.getElementById('rh-date-end')?.value;
  const { start: gStart, end: gEnd } = getFilters();
  const start = rhStart ? new Date(rhStart + 'T00:00:00') : gStart;
  const end   = rhEnd   ? new Date(rhEnd   + 'T23:59:59') : gEnd;
  const norme = rhNormeProratee(parseFloat(document.getElementById('rh-norme').value) || RH_NORME_DEFAULT, start, end);

  const allRows = [
    ...rhFilterByDate(RH_DB.corrRows[unit]||[], start, end),
    ...rhFilterByDate(RH_DB.prevRows[unit]||[], start, end)
  ].filter(r => {
    const p = parseCodeEquipement(r['CODE_EQUIPEMENT']||r['EQUIPEMENT']||'');
    return p.systeme === systeme;
  });

  if (allRows.length === 0) { showToast(`Aucune donnée pour ${unit} / ${systeme}`, 'warn'); return; }

  // Agrégation sous-systèmes
  const ssMap = {};
  allRows.forEach(row => {
    const heures = rhParseHours(row);
    const parsed = parseCodeEquipement(row['CODE_EQUIPEMENT']||row['EQUIPEMENT']||'');
    const ss     = parsed.sousSysteme;
    const tech   = rhGetTech(row);
    if (!ssMap[ss]) ssMap[ss] = { heures:0, nbInterv:0, techs:new Set() };
    ssMap[ss].heures   += heures;
    ssMap[ss].nbInterv += 1;
    ssMap[ss].techs.add(tech);
  });

  const grandH  = Object.values(ssMap).reduce((s,v)=>s+v.heures,0);
  const ssList  = Object.entries(ssMap).sort((a,b)=>b[1].heures-a[1].heures);
  const uL      = unit.toLowerCase();

  panel.style.display = 'block';
  panel.innerHTML = `
    <div class="card" style="border:2px solid rgba(47, 102, 144,0.25);animation:page-in 0.3s ease">
      <div class="card-title" style="justify-content:space-between">
        <span>
          🔍 <span class="unit-tag bg-${uL} u-${uL}">${unit}</span>
          <span style="margin:0 6px;color:var(--text3)">›</span>
          <span style="background:#dbeafe;color:#1e40af;padding:3px 10px;border-radius:8px;font-weight:800;font-size:13px">${systeme}</span>
          <span style="margin:0 6px;color:var(--text3)">— Sous-systèmes</span>
        </span>
        <button class="btn btn-ghost btn-sm" onclick="document.getElementById('rh-system-detail-panel').style.display='none';document.getElementById('rh-system-detail-panel')._currentKey=null;">✕ Fermer</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Sous-système</th>
              <th style="text-align:center">Charge (h)</th>
              <th style="text-align:center">% Total</th>
              <th style="text-align:center">Nb Interv.</th>
              <th style="text-align:center">Nb Tech.</th>
              <th style="text-align:center">Moy. h/Interv.</th>
              <th style="min-width:130px">Taux Occupation</th>
              <th style="text-align:center">Détail Tech.</th>
            </tr>
          </thead>
          <tbody>
            ${ssList.map(([ss, sv]) => {
              const pctSS    = grandH>0?(sv.heures/grandH*100).toFixed(1):'0';
              const beSS     = Math.ceil(sv.heures/norme);
              const nbTech   = sv.techs.size;
              const delta    = beSS - nbTech;
              const dCls     = delta>0?'badge-red':delta<-1?'badge-yellow':'badge-green';
              const dLbl     = delta>0?`+${delta}`:String(delta);
              const moy      = sv.nbInterv>0?(sv.heures/sv.nbInterv).toFixed(2):'—';
              const tauxOcc  = norme>0?sv.heures/(norme*Math.max(nbTech,1)):0;
              const barCls   = tauxOcc>1.05?'rh-bar-over':tauxOcc<0.75?'rh-bar-under':'rh-bar-ok';
              return `<tr>
                <td style="font-weight:700;font-size:12px">
                  <span style="display:inline-flex;align-items:center;gap:6px">
                    <span style="width:8px;height:8px;border-radius:50%;background:#24537a;flex-shrink:0;box-shadow:0 0 5px rgba(36, 83, 122,0.4)"></span>
                    ${ss}
                  </span>
                </td>
                <td style="text-align:center;font-weight:700">${sv.heures.toFixed(1)}h</td>
                <td style="text-align:center">
                  <div style="display:flex;align-items:center;gap:4px;justify-content:center">
                    <div style="width:32px;height:4px;background:var(--border);border-radius:2px;overflow:hidden">
                      <div style="width:${Math.min(parseFloat(pctSS),100)}%;height:100%;background:linear-gradient(90deg,#24537a,#2f6690);border-radius:2px"></div>
                    </div>
                    <span style="font-size:11px;font-weight:700;color:#24537a">${pctSS}%</span>
                  </div>
                </td>
                <td style="text-align:center;font-weight:600">${sv.nbInterv}</td>
                <td style="text-align:center;font-weight:600">${nbTech}</td>
                <td style="text-align:center;font-size:11px;color:#6b7fa8">${moy}h</td>
                <td>
                  <div style="display:flex;align-items:center;gap:6px;min-width:120px">
                    <div style="flex:1;height:5px;background:var(--border);border-radius:3px;overflow:hidden">
                      <div class="unit-bar-fill ${barCls}" style="width:${Math.min(tauxOcc*100,150)}%"></div>
                    </div>
                    <span style="font-size:10px;font-weight:700">${(tauxOcc*100).toFixed(0)}%</span>
                  </div>
                </td>
                <td style="text-align:center">
                  <button class="btn btn-ghost btn-sm" style="font-size:10px;padding:4px 9px"
                    onclick="showRHSousSystemeDetail('${unit}','${systeme}',encodeURIComponent('${ss}'),this)">
                    + Techs
                  </button>
                </td>
              </tr>
              <tr id="rh-ss-detail-${unit}-${systeme}-${ss.replace(/[^a-zA-Z0-9]/g,'_')}" style="display:none">
                <td colspan="10" style="padding:0;background:rgba(237,233,254,0.25)"></td>
              </tr>`;
            }).join('')}
            <tr style="background:#f8faff;font-weight:800;border-top:2px solid var(--border)">
              <td>TOTAL ${systeme}</td>
              <td style="text-align:center;color:#24537a">${grandH.toFixed(1)}h</td>
              <td style="text-align:center;color:#24537a">100%</td>
              <td style="text-align:center;color:#24537a">${allRows.length}</td>
              <td style="text-align:center;color:#24537a">${new Set(allRows.map(r=>rhGetTech(r))).size}</td>
              <td style="text-align:center;font-size:11px;color:#6b7fa8">
                ${allRows.length>0?(grandH/allRows.length).toFixed(2):'—'}h
              </td>
              <td colspan="2"></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>`;

  panel.scrollIntoView({ behavior:'smooth', block:'start' });
}

function showRHSousSystemeDetail(unit, systeme, sousSystemeEncoded, btn) {
  const sousSysteme = decodeURIComponent(sousSystemeEncoded);
  const ssKey       = sousSysteme.replace(/[^a-zA-Z0-9]/g,'_');
  const rowId       = `rh-ss-detail-${unit}-${systeme}-${ssKey}`;
  const detailRow   = document.getElementById(rowId);
  if (!detailRow) return;

  // Toggle
  if (detailRow.style.display !== 'none') {
    detailRow.style.display = 'none';
    btn.textContent = '+ Techs';
    return;
  }

  const rhStart = document.getElementById('rh-date-start')?.value;
  const rhEnd   = document.getElementById('rh-date-end')?.value;
  const { start: gStart, end: gEnd } = getFilters();
  const start = rhStart ? new Date(rhStart + 'T00:00:00') : gStart;
  const end   = rhEnd   ? new Date(rhEnd   + 'T23:59:59') : gEnd;
  const norme = rhNormeProratee(parseFloat(document.getElementById('rh-norme').value) || RH_NORME_DEFAULT, start, end);

  const allRows = [
    ...rhFilterByDate(RH_DB.corrRows[unit]||[], start, end),
    ...rhFilterByDate(RH_DB.prevRows[unit]||[], start, end)
  ].filter(r => {
    const p = parseCodeEquipement(r['CODE_EQUIPEMENT']||r['EQUIPEMENT']||'');
    return p.systeme === systeme && p.sousSysteme === sousSysteme;
  });

  if (allRows.length === 0) {
    showToast(`Aucune donnée pour ${sousSysteme}`, 'warn');
    return;
  }

  // Agrégation techniciens
  const techMap = {};
  allRows.forEach(row => {
    const tech   = rhGetTech(row);
    const heures = rhParseHours(row);
    if (!techMap[tech]) techMap[tech] = { heures:0, nbInterv:0 };
    techMap[tech].heures   += heures;
    techMap[tech].nbInterv += 1;
  });

  const grandH    = Object.values(techMap).reduce((s,t)=>s+t.heures,0);
  const techList  = Object.entries(techMap).sort((a,b)=>b[1].heures-a[1].heures);

  detailRow.style.display = '';
  btn.textContent = '− Fermer';

  detailRow.querySelector('td').innerHTML = `
    <div style="padding:10px 20px 14px 40px;background:rgba(237,233,254,0.18);border-left:3px solid rgba(36, 83, 122,0.3)">
      <div style="font-size:11px;font-weight:800;color:#24537a;text-transform:uppercase;letter-spacing:1px;margin-bottom:10px">
        👤 Techniciens — ${sousSysteme}
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Technicien</th>
              <th style="text-align:center">Charge (h)</th>
              <th style="text-align:center">% SS</th>
              <th style="text-align:center">Δ Norme</th>
              <th style="min-width:140px">Taux Occupation</th>
              <th style="text-align:center">Nb Interv.</th>
              <th style="text-align:center">Moy. h/Interv.</th>
              <th style="text-align:center">Statut</th>
            </tr>
          </thead>
          <tbody>
            ${techList.map(([tech, tv], i) => {
              const taux    = norme>0?tv.heures/norme:0;
              const delta   = tv.heures - norme;
              const statut  = taux>1.05?'surcharge':taux<0.75?'sous-charge':'equilibre';
              const barCls  = statut==='surcharge'?'rh-bar-over':statut==='sous-charge'?'rh-bar-under':'rh-bar-ok';
              const dColor  = delta>0?'#dc2626':delta<-10?'#d97706':'#059669';
              const pctSS   = grandH>0?(tv.heures/grandH*100).toFixed(1):'0';
              const moy     = tv.nbInterv>0?(tv.heures/tv.nbInterv).toFixed(2):'—';
              return `<tr style="background:rgba(255,255,255,0.7)" onmouseover="this.style.background='rgba(237,233,254,0.35)'" onmouseout="this.style.background='rgba(255,255,255,0.7)'">
                <td style="color:var(--text3);font-size:11px">${i+1}</td>
                <td style="font-weight:700;font-size:12px">${tech}</td>
                <td style="text-align:center;font-weight:700">
                  ${tv.heures.toFixed(2)}h
                  <div style="font-size:9px;color:${dColor};font-weight:700;margin-top:1px">${delta>0?'+':''}${delta.toFixed(1)}h vs norme</div>
                </td>
                <td style="text-align:center">
                  <div style="display:flex;align-items:center;gap:3px;justify-content:center">
                    <div style="width:28px;height:4px;background:var(--border);border-radius:2px;overflow:hidden">
                      <div style="width:${Math.min(parseFloat(pctSS),100)}%;height:100%;background:#24537a;border-radius:2px"></div>
                    </div>
                    <span style="font-size:10px;font-weight:700;color:#24537a">${pctSS}%</span>
                  </div>
                </td>
                <td style="text-align:center;color:${dColor};font-weight:700;font-size:11px">
                  ${delta>0?'+':''}${delta.toFixed(1)}h
                </td>
                <td>
                  <div style="display:flex;align-items:center;gap:7px;min-width:130px">
                    <div style="flex:1;height:6px;background:var(--border);border-radius:3px;overflow:hidden">
                      <div class="unit-bar-fill ${barCls}" style="width:${Math.min(taux*100,150)}%"></div>
                    </div>
                    <span style="font-size:11px;font-weight:800;min-width:42px">${(taux*100).toFixed(1)}%</span>
                  </div>
                </td>
                <td style="text-align:center;font-weight:600">${tv.nbInterv}</td>
                <td style="text-align:center;font-size:11px;color:#6b7fa8">${moy}h</td>
                <td style="text-align:center">${rhStatutBadge(statut)}</td>
              </tr>`;
            }).join('')}
            <tr style="background:#f8faff;font-weight:800;border-top:2px solid var(--border)">
              <td colspan="2">TOTAL ${sousSysteme}</td>
              <td style="text-align:center;color:#24537a">${grandH.toFixed(1)}h</td>
              <td style="text-align:center;color:#24537a">100%</td>
              <td></td>
              <td></td>
              <td style="text-align:center;color:#24537a">${allRows.length}</td>
              <td style="text-align:center;font-size:11px;color:#6b7fa8">
                ${allRows.length>0?(grandH/allRows.length).toFixed(2):'—'}h
              </td>
              <td></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>`;
}

// =====================================================================
// NOUVELLE FONCTION : Afficher les techniciens filtrés par système
// avec les mêmes colonnes que le tableau principal
// =====================================================================
function showRHTechsBySystem(unit, systeme) {
  const panel = document.getElementById('rh-system-detail-panel');
  if (!panel) return;

  // Toggle : si déjà affiché pour ce système, fermer
  if (panel._currentKey === `TECH:${unit}:${systeme}` && panel.style.display !== 'none') {
    panel.style.display = 'none';
    panel._currentKey = null;
    return;
  }
  panel._currentKey = `TECH:${unit}:${systeme}`;

  const rhStart = document.getElementById('rh-date-start')?.value;
  const rhEnd   = document.getElementById('rh-date-end')?.value;
  const { start: gStart, end: gEnd } = getFilters();
  const start = rhStart ? new Date(rhStart + 'T00:00:00') : gStart;
  const end   = rhEnd   ? new Date(rhEnd   + 'T23:59:59') : gEnd;
  const norme = rhNormeProratee(parseFloat(document.getElementById('rh-norme').value) || RH_NORME_DEFAULT, start, end);

  // Récupérer toutes les lignes pour cette unité et ce système
  const allRows = [
    ...rhFilterByDate(RH_DB.corrRows[unit]||[], start, end),
    ...rhFilterByDate(RH_DB.prevRows[unit]||[], start, end)
  ].filter(r => {
    const p = parseCodeEquipement(r['CODE_EQUIPEMENT']||r['EQUIPEMENT']||'');
    return p.systeme === systeme;
  });

  if (allRows.length === 0) { showToast(`Aucune donnée pour ${unit} / ${systeme}`, 'warn'); return; }

  // Agrégation par technicien (mêmes colonnes que le tableau principal)
  const techMap = {};
  allRows.forEach(row => {
    const tech   = rhGetTech(row);
    const heures = rhParseHours(row);
    if (!techMap[tech]) techMap[tech] = { heures:0, nbInterv:0 };
    techMap[tech].heures   += heures;
    techMap[tech].nbInterv += 1;
  });

  const grandH   = Object.values(techMap).reduce((s,v)=>s+v.heures,0);
  const techList = Object.entries(techMap).sort((a,b)=>b[1].heures-a[1].heures);
  const uL       = unit.toLowerCase();
  const nbTechTotal = techList.length;

  panel.style.display = 'block';
  panel.innerHTML = `
    <div class="card" style="border:2px solid rgba(36, 83, 122,0.25);animation:page-in 0.3s ease">
      <div class="card-title" style="justify-content:space-between">
        <span>
          👤 <span class="unit-tag bg-${uL} u-${uL}">${unit}</span>
          <span style="margin:0 6px;color:var(--text3)">›</span>
          <span style="background:linear-gradient(135deg,#ede9fe,#dbeafe);color:#24537a;padding:4px 12px;border-radius:10px;font-weight:800;font-size:14px">${systeme}</span>
          <span style="margin:0 6px;color:var(--text3)">— Techniciens par Système</span>
          <span style="font-size:11px;color:#6b7fa8;background:#f0f4ff;padding:2px 8px;border-radius:8px">${allRows.length} interventions · ${nbTechTotal} tech.</span>
        </span>
        <button class="btn btn-ghost btn-sm" onclick="document.getElementById('rh-system-detail-panel').style.display='none';document.getElementById('rh-system-detail-panel')._currentKey=null;">✕ Fermer</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th style="min-width:140px">Technicien</th>
              <th style="text-align:center">Charge (h)</th>
              <th style="text-align:center">% Total</th>
              <th style="text-align:center">Nb Interv.</th>
              <th style="text-align:center">Moy. h/Interv.</th>
              <th style="min-width:130px">Taux Occupation</th>
              <th style="text-align:center">Statut</th>
            </tr>
          </thead>
          <tbody>
            ${techList.map(([tech, tv], idx) => {
              const pctTech   = grandH>0?(tv.heures/grandH*100).toFixed(1):'0';
              const moy       = tv.nbInterv>0?(tv.heures/tv.nbInterv).toFixed(2):'—';
              const tauxOcc   = norme>0?tv.heures/norme:0;
              const tauxPct   = tauxOcc*100;
              const statut    = tauxOcc>1.05?'surcharge':tauxOcc<0.75?'sous-charge':'equilibre';
              const barCls    = statut==='surcharge'?'rh-bar-over':statut==='sous-charge'?'rh-bar-under':'rh-bar-ok';
              const dColor    = tv.heures-norme>0?'#dc2626':tv.heures-norme<-10?'#d97706':'#059669';

              return `<tr style="background:rgba(255,255,255,0.7)" onmouseover="this.style.background='rgba(237,233,254,0.4)'" onmouseout="this.style.background='rgba(255,255,255,0.7)'">
                <td style="font-weight:700;font-size:12px;padding:10px 14px">
                  <span style="display:inline-flex;align-items:center;gap:8px">
                    <span style="width:28px;height:28px;border-radius:8px;background:linear-gradient(135deg,#24537a,#2f6690);display:flex;align-items:center;justify-content:center;color:white;font-size:12px;font-weight:800">${idx+1}</span>
                    <span style="color:#0a1930">${tech}</span>
                  </span>
                </td>
                <td style="text-align:center;font-weight:700;font-size:13px">
                  <span style="color:#0a1930">${tv.heures.toFixed(2)}h</span>
                  <div style="font-size:9px;color:${dColor};font-weight:700;margin-top:2px">${tv.heures-norme>0?'+':''}${(tv.heures-norme).toFixed(1)}h vs norme</div>
                </td>
                <td style="text-align:center">
                  <div style="display:flex;align-items:center;gap:5px;justify-content:center">
                    <div style="width:40px;height:5px;background:var(--border);border-radius:3px;overflow:hidden">
                      <div style="width:${Math.min(parseFloat(pctTech),100)}%;height:100%;background:linear-gradient(90deg,#24537a,#2f6690);border-radius:3px"></div>
                    </div>
                    <span style="font-size:11px;font-weight:700;color:#24537a">${pctTech}%</span>
                  </div>
                </td>
                <td style="text-align:center;font-weight:700">${tv.nbInterv}</td>
                <td style="text-align:center;font-size:11px;color:#6b7fa8">${moy}h</td>
                <td>
                  <div style="display:flex;align-items:center;gap:7px;min-width:130px">
                    <div style="flex:1;height:6px;background:var(--border);border-radius:3px;overflow:hidden">
                      <div class="unit-bar-fill ${barCls}" style="width:${Math.min(tauxPct,150)}%"></div>
                    </div>
                    <span style="font-size:11px;font-weight:800;min-width:42px">${tauxPct.toFixed(1)}%</span>
                  </div>
                </td>
                <td style="text-align:center">${rhStatutBadge(statut)}</td>
              </tr>`;
            }).join('')}
            <tr style="background:linear-gradient(90deg,rgba(47, 102, 144,0.12),rgba(36, 83, 122,0.08));border-top:3px solid rgba(47, 102, 144,0.3)">
              <td style="padding:10px 14px;font-weight:900;font-size:13px;color:#1e40af">
                🏁 TOTAL ${systeme}
              </td>
              <td style="text-align:center;font-weight:900;color:#1e40af;font-size:14px">${grandH.toFixed(1)}h</td>
              <td style="text-align:center;font-weight:900;color:#1e40af">100%</td>
              <td style="text-align:center;font-weight:900;color:#1e40af">${allRows.length}</td>
              <td style="text-align:center;font-size:11px;color:#6b7fa8">${allRows.length>0?(grandH/allRows.length).toFixed(2):'—'}h</td>
              <td colspan="2" style="font-size:11px;font-weight:700;color:#1e40af;text-align:center">
                Capacite: ${norme * nbTechTotal}h · Taux global: ${(grandH/(norme*nbTechTotal)*100).toFixed(1)}%
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>`;

  panel.scrollIntoView({ behavior:'smooth', block:'start' });
}

// ══════════════════════════════════════════════════════════════════════
// FIN MODULE EFFICIENCE RH
// ══════════════════════════════════════════════════════════════════════

// =====================================================================
// RAPPORT GENERAL EFFICIENCE RH — IA (telechargement HTML)
// =====================================================================
function collectRHGlobalData() {
  const { start, end } = getRHFilters();
  const norme = rhNormeProratee(parseFloat(document.getElementById('rh-norme').value) || RH_NORME_DEFAULT, start, end);

  const unitDetails = UNITS.map(u => {
    const data = calcRHEfficienceUnit(u);
    if (!data) return null;

    // Top sous-systemes par charge
    const allRows = [
      ...rhFilterByDate(RH_DB.corrRows[u]||[], start, end),
      ...rhFilterByDate(RH_DB.prevRows[u]||[], start, end)
    ];
    const sysMap = {};
    allRows.forEach(row => {
      const p = parseCodeEquipement(row['CODE_EQUIPEMENT']||row['EQUIPEMENT']||'');
      const key = p.sousSysteme;
      if (!sysMap[key]) sysMap[key] = { systeme:p.systeme, heures:0, nbInterv:0 };
      sysMap[key].heures   += rhParseHours(row);
      sysMap[key].nbInterv += 1;
    });
    const topSystemes = Object.entries(sysMap)
      .sort((a,b)=>b[1].heures-a[1].heures).slice(0,5)
      .map(([ss,v]) => ({ sousSysteme:ss, systeme:v.systeme, heures:v.heures, nbInterv:v.nbInterv }));

    return {
      unit: u, norme: data.norme,
      nbTech: data.nbTech, chargeReelleTotale: data.chargeReelleTotale,
      besoinEssentiel: data.besoinEssentiel, deltaUnite: data.deltaUnite,
      tauxMoyenOccupation: data.tauxMoyenOccupation,
      nbSurcharge: data.nbSurcharge, nbSousCharge: data.nbSousCharge, nbEquilibre: data.nbEquilibre,
      techListSurcharge:  data.techList.filter(t=>t.statut==='surcharge').map(t=>({nom:t.technicien, charge:t.chargeReelle, taux:t.tauxOccupationPct})),
      techListSousCharge: data.techList.filter(t=>t.statut==='sous-charge').map(t=>({nom:t.technicien, charge:t.chargeReelle, taux:t.tauxOccupationPct})),
      topSystemes
    };
  }).filter(Boolean);

  const totalTech      = unitDetails.reduce((s,d)=>s+d.nbTech,0);
  const totalH         = unitDetails.reduce((s,d)=>s+d.chargeReelleTotale,0);
  const totalEssentiel = unitDetails.reduce((s,d)=>s+d.besoinEssentiel,0);
  const nbSurcharge    = unitDetails.reduce((s,d)=>s+d.nbSurcharge,0);
  const nbSousCharge   = unitDetails.reduce((s,d)=>s+d.nbSousCharge,0);
  const nbEquilibre    = unitDetails.reduce((s,d)=>s+d.nbEquilibre,0);

  return { norme, start, end, unitDetails, totalTech, totalH, totalEssentiel, nbSurcharge, nbSousCharge, nbEquilibre };
}

async function generateRHGeneralReport() {
  const statusEl = document.getElementById('rh-general-report-status');
  const btn      = document.getElementById('btn-gen-rh-report');
  if (statusEl) {
    statusEl.style.display = 'flex'; statusEl.style.alignItems='center'; statusEl.style.gap='10px';
    statusEl.innerHTML = `<div class="loader" style="width:22px;height:22px;border-width:2px"></div>
      <span style="font-size:12.5px;color:var(--text2);font-weight:600">Analyse de l'efficience RH en cours…</span>`;
  }
  if (btn) btn.disabled = true;

  const data = collectRHGlobalData();
  if (data.unitDetails.length === 0) {
    if (statusEl) statusEl.innerHTML = `<span style="font-size:12.5px;color:#dc2626;font-weight:700">⚠️ Aucune donnee RH chargee</span>`;
    if (btn) btn.disabled = false;
    return;
  }

  const unitsSummary = data.unitDetails.map(d =>
    `${d.unit} : ${d.nbTech} techniciens, charge totale ${d.chargeReelleTotale.toFixed(1)}h (norme ${d.norme}h/mois/tech), ` +
    `besoin essentiel ${d.besoinEssentiel} postes, delta ${d.deltaUnite>0?'+':''}${d.deltaUnite.toFixed(1)}, ` +
    `taux occupation moyen ${(d.tauxMoyenOccupation*100).toFixed(1)}%, ` +
    `${d.nbSurcharge} en surcharge / ${d.nbSousCharge} en sous-charge / ${d.nbEquilibre} en equilibre. ` +
    `Surcharges : ${d.techListSurcharge.map(t=>`${t.nom} (${t.taux.toFixed(0)}%)`).join(', ')||'aucune'}. ` +
    `Sous-charges : ${d.techListSousCharge.map(t=>`${t.nom} (${t.taux.toFixed(0)}%)`).join(', ')||'aucune'}. ` +
    `Top systemes par charge : ${d.topSystemes.map(s=>`${s.sousSysteme} (${s.heures.toFixed(0)}h)`).join(', ')}`
  ).join('\n\n');

  const prompt = 'Tu es un expert senior en gestion des ressources humaines de maintenance industrielle ferroviaire.\n\n' +
    'DONNEES — periode du ' + fmtDateFR(data.start) + ' au ' + fmtDateFR(data.end) + ', norme de reference ' + data.norme + 'h/mois/technicien :\n\n' +
    'GLOBAL TOUTES UNITES :\n' +
    '- ' + data.totalTech + ' techniciens, charge totale ' + data.totalH.toFixed(1) + 'h\n' +
    '- Besoin essentiel total : ' + data.totalEssentiel + ' postes\n' +
    '- ' + data.nbSurcharge + ' techniciens en surcharge (>105%), ' + data.nbSousCharge + ' en sous-charge (<75%), ' + data.nbEquilibre + ' en equilibre\n\n' +
    'DETAIL PAR UNITE :\n' + unitsSummary + '\n\n' +
    'Produis un rapport JSON STRICT (sans markdown, sans backticks) destine a un directeur RH/maintenance, format exact :\n' +
    '{\n' +
    '  "titre": "...",\n' +
    '  "synthese_executive": "2-4 phrases",\n' +
    '  "equilibre_global_atteint": true|false,\n' +
    '  "score_global_sur_5": 0-5,\n' +
    '  "analyse_charge_globale": "...",\n' +
    '  "analyse_surcharges": "analyse des techniciens en surcharge, risques RPS/epuisement...",\n' +
    '  "analyse_sous_charges": "analyse des capacites disponibles non utilisees...",\n' +
    '  "analyse_repartition_systemes": "...",\n' +
    '  "points_forts": ["...","...","..."],\n' +
    '  "points_attention": ["...","...","..."],\n' +
    '  "risques_rh": ["...","..."],\n' +
    '  "rapports_unites": [{ "unite":"...", "score_sur_5":0-5, "resume":"...", "equilibre_atteint":true|false, "analyse_detaillee":"3-4 phrases", "actions_prioritaires":["...","..."], "mobilite_recommandee":"description d\'un transfert ou renfort recommande si pertinent, sinon chaine vide" }],\n' +
    '  "recommandations_strategiques": ["...","...","...","..."],\n' +
    '  "conclusion": "..."\n' +
    '}';

  let report;
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model:'claude-sonnet-4-20250514', max_tokens:3000, messages:[{ role:'user', content:prompt }] })
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const apiData   = await response.json();
    const rawText   = (apiData.content||[]).filter(b=>b.type==='text').map(b=>b.text).join('');
    const cleanJson = rawText.replace(/```json|```/g,'').trim();
    report = JSON.parse(cleanJson);
  } catch (err) {
    console.warn('Fallback local RH :', err.message);
    report = generateLocalRHGeneralReport(data);
  }

  downloadRHGeneralReport(report, data);

  if (statusEl) {
    statusEl.innerHTML = `<span style="font-size:12.5px;color:#059669;font-weight:700">✅ Rapport RH telecharge avec succes</span>`;
    setTimeout(() => { statusEl.style.display = 'none'; }, 4000);
  }
  if (btn) btn.disabled = false;
}

function generateLocalRHGeneralReport(data) {
  const equilibre = data.nbSurcharge === 0 && data.nbSousCharge <= data.totalTech*0.2;
  const score = Math.max(0, 5 - data.nbSurcharge - Math.floor(data.nbSousCharge/2));
  const pointsForts = [], pointsAttention = [], risques = [];

  if (data.nbSurcharge === 0) pointsForts.push('Aucun technicien en situation de surcharge sur la periode');
  else { pointsAttention.push(`${data.nbSurcharge} technicien(s) en surcharge (>105% de la norme)`); risques.push('Risque d\'epuisement professionnel et de degradation de la qualite des interventions'); }

  if (data.nbEquilibre >= data.totalTech*0.6) pointsForts.push(`Majorite des techniciens en charge equilibree (${data.nbEquilibre}/${data.totalTech})`);
  else pointsAttention.push('Repartition de charge heterogene entre techniciens');

  if (data.nbSousCharge > 0) pointsAttention.push(`${data.nbSousCharge} technicien(s) en sous-charge (<75% de la norme) — capacite disponible non exploitee`);

  if (data.totalEssentiel > data.totalTech) risques.push(`Sous-effectif global estime : ${data.totalEssentiel - data.totalTech} poste(s) manquant(s) au regard de la charge actuelle`);
  else if (data.totalEssentiel < data.totalTech) pointsForts.push('Effectif global suffisant voire en leger surplus par rapport au besoin theorique');

  const rapportsUnites = data.unitDetails.map(d => {
    const uScore = Math.max(0, 5 - d.nbSurcharge - Math.floor(d.nbSousCharge/2));
    const mobilite = (d.techListSousCharge.length>0 && d.deltaUnite>0)
      ? `Mobiliser ${d.techListSousCharge[0].nom} (${d.techListSousCharge[0].taux.toFixed(0)}% de charge) en renfort sur les sous-systemes en tension.`
      : '';
    return {
      unite: d.unit, score_sur_5: uScore,
      resume: `${d.nbTech} techniciens, ${d.chargeReelleTotale.toFixed(1)}h, besoin ${d.besoinEssentiel} postes (delta ${d.deltaUnite>0?'+':''}${d.deltaUnite.toFixed(1)})`,
      equilibre_atteint: d.nbSurcharge===0 && d.nbSousCharge<=Math.ceil(d.nbTech*0.2),
      analyse_detaillee: `Taux d'occupation moyen ${(d.tauxMoyenOccupation*100).toFixed(1)}%. ${d.nbSurcharge} en surcharge, ${d.nbSousCharge} en sous-charge, ${d.nbEquilibre} en equilibre. ` +
        (d.topSystemes[0] ? `Le sous-systeme le plus consommateur est ${d.topSystemes[0].sousSysteme} avec ${d.topSystemes[0].heures.toFixed(0)}h.` : ''),
      actions_prioritaires: d.nbSurcharge>0
        ? ['Delester les techniciens en surcharge vers les collegues disponibles', 'Revoir la planification des interventions preventives', 'Surveiller les signes d\'epuisement']
        : ['Maintenir la repartition actuelle', 'Capitaliser sur les marges disponibles pour les unites voisines'],
      mobilite_recommandee: mobilite
    };
  });

  return {
    titre: 'Rapport General d\'Efficience RH',
    synthese_executive: `Sur la periode analysee, ${data.totalTech} techniciens cumulent ${data.totalH.toFixed(1)}h pour un besoin theorique de ${data.totalEssentiel} postes. ` +
      `${data.nbSurcharge} technicien(s) en surcharge et ${data.nbSousCharge} en sous-charge ont ete identifies. ${equilibre ? 'L\'equilibre global est globalement satisfaisant.' : 'Des desequilibres significatifs necessitent une action corrective.'}`,
    equilibre_global_atteint: equilibre,
    score_global_sur_5: Math.min(5, Math.max(0, Math.round(score / Math.max(1,data.unitDetails.length) ))),
    analyse_charge_globale: `La charge totale de ${data.totalH.toFixed(1)}h repartie sur ${data.totalTech} techniciens donne un taux d'occupation moyen variable selon les unites. Le besoin essentiel calcule (${data.totalEssentiel} postes) ${data.totalEssentiel>data.totalTech?'depasse':'reste en-dessous de'} l'effectif actuel.`,
    analyse_surcharges: data.nbSurcharge>0
      ? `${data.nbSurcharge} technicien(s) depassent 105% de la norme mensuelle, ce qui expose a un risque d'epuisement et de baisse de qualite des interventions a moyen terme.`
      : 'Aucune situation de surcharge critique n\'a ete identifiee sur la periode.',
    analyse_sous_charges: data.nbSousCharge>0
      ? `${data.nbSousCharge} technicien(s) disposent d'une capacite residuelle (moins de 75% de la norme), representant un potentiel de renfort mobilisable pour les unites en tension.`
      : 'La quasi-totalite des techniciens est correctement chargee, sans marge significative disponible.',
    analyse_repartition_systemes: 'La charge se concentre sur certains sous-systemes specifiques par unite (voir detail par unite ci-dessous), ce qui peut justifier une specialisation ou une polyvalence accrue selon les cas.',
    points_forts: pointsForts.length ? pointsForts : ['Aucun point fort majeur identifie'],
    points_attention: pointsAttention.length ? pointsAttention : ['Aucun point d\'attention majeur detecte'],
    risques_rh: risques.length ? risques : ['Aucun risque RH majeur identifie sur la periode'],
    rapports_unites: rapportsUnites,
    recommandations_strategiques: [
      'Etablir un plan de mobilite interne entre unites en sous-charge et en surcharge',
      'Reviser periodiquement la norme horaire selon l\'evolution de la charge reelle',
      'Mettre en place une alerte automatique au-dela de 105% d\'occupation pour anticiper les surcharges',
      'Valoriser la polyvalence des techniciens sur plusieurs sous-systemes pour fluidifier les affectations'
    ],
    conclusion: `${equilibre ? 'La situation RH actuelle est maitrisee, avec des ajustements ponctuels a prevoir.' : 'Une action correctrice est necessaire pour retablir l\'equilibre de charge entre techniciens et unites.'} Un suivi mensuel de ces indicateurs est recommande.`
  };
}

// ── Construction et telechargement du rapport HTML RH ──
