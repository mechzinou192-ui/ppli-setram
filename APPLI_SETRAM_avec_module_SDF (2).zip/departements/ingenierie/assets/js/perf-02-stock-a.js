// =============================================================================
// SUIVI DES PERFORMANCES — module 02/10 : perf-02-stock-a.js
// Extrait mecaniquement (meme code, meme ordre) du script principal historique
// pour ameliorer la maintenabilite (le fichier faisait ~8300 lignes en un bloc).
// Contenu : Gestion de Stock (1/3) : normalisation des lignes stock, cache stats correctif/equipement, chargement des fichiers de correspondance (mapping), mise a jour badges import
// IMPORTANT : ce fichier partage la portee globale avec les autres modules
// perf-XX-*.js et doit rester charge dans l'ORDRE (01 -> 10), car certaines
// fonctions utilisent des constantes/fonctions definies dans les modules precedents.
// =============================================================================
function normalizeStockRow(r, unit) {
  const numOf = v => {
    if (v === '' || v === null || v === undefined) return 0;
    const n = parseFloat(String(v).replace(/\s/g,'').replace(',', '.'));
    return isNaN(n) ? 0 : n;
  };
  const get = (...names) => { for (const n of names) { if (r[n] !== undefined) return r[n]; } return ''; };
  const qte = Math.abs(numOf(get('Qte_Mouvementée','Qte_Mouvementee','QTE_MOUVEMENTEE')));
  const coutU = numOf(get('Coût_Unitaire','Cout_Unitaire','COUT_UNITAIRE'));
  let valeur = Math.abs(numOf(get('Valeur_MVT','VALEUR_MVT')));
  if (!valeur && coutU) valeur = coutU * qte;
  const d = parseDate(get('Date_MVT','DATE_MVT'));
  const codePiece = String(get('Code_Pièce','Code_Piece','CODE_PIECE')).trim();
  const famille = String(get('Famille_Pièce','Famille_Piece','FAMILLE_PIECE')).trim();
  const qteAvant = numOf(get('Qte_Avant_MVT','Qte_Avant','QTE_AVANT_MVT'));
  const qteApres = numOf(get('Qte_Après_MVT','Qte_Apres_MVT','Qte_Apres','QTE_APRES_MVT'));
  const valeurStockAvant = numOf(get('Valeur_Stock_Avant_MVT','Valeur_Stock_Avant','VALEUR_STOCK_AVANT_MVT'));
  const valeurStockApres = numOf(get('Valeur_Stock_Après_MVT','Valeur_Stock_Apres_MVT','Valeur_Stock_Apres','VALEUR_STOCK_APRES_MVT'));
  return {
    codePiece,
    designation: String(get('Désignation_Pièce','Designation_Piece','DESIGNATION_PIECE')).trim(),
    typePiece: String(get('Type_Pièce','Type_Piece','TYPE_PIECE')).trim().replace(/^\.+/, ''),
    famille: famille || 'Non classé',
    magasin: String(get('Magasin','MAGASIN')).trim(),
    qte, coutU, valeur,
    qteAvant, qteApres, valeurStockAvant, valeurStockApres,
    typeMvt: String(get('Type_Mouvement','TYPE_MOUVEMENT')).trim(),
    date: d,
    monthKey: d ? `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}` : null,
    year: d ? d.getFullYear() : null,
    motif: String(get('Motif','MOTIF')).trim(),
    responsable: String(get('Responsable_MVT','RESPONSABLE_MVT')).trim(),
    typeSortie: String(get('Type_Sortie','TYPE_SORTIE')).trim() || 'Non précisé',
    unit
  };
}
// Resout Systeme/Equipement d'une ligne stock via STOCK_MAPPING (dynamique : appliquee au rendu, pas a l'import)
function stockRowSysteme(row) { const m = STOCK_MAPPING[row.codePiece]; return (m && m.systeme) || null; }
function stockRowEquip(row)   { const m = STOCK_MAPPING[row.codePiece]; return (m && m.equipement) || null; }

// Dernier mouvement connu par pièce (sur l'ensemble fourni) → sert de proxy au stock actuel
// (Qte_Après_MVT / Valeur_Stock_Après_MVT de la sortie la plus récente de chaque pièce)
function stockLatestByPiece(rows) {
  const latest = {};
  rows.forEach(r => {
    if (!r.date) return;
    const cur = latest[r.codePiece];
    if (!cur || r.date > cur.date) latest[r.codePiece] = r;
  });
  return latest;
}

// Stats pannes/durée par équipement, calculées sur TOUT l'historique correctif chargé (toutes unités),
// indépendamment des filtres de la page Stock — sert au croisement stock ↔ criticité.
let EQ_CORR_STATS_CACHE = null;
function computeEquipementCorrStats() {
  if (EQ_CORR_STATS_CACHE) return EQ_CORR_STATS_CACHE;
  const map = {};
  UNITS.forEach(u => (DB.corrective[u]||[]).forEach(r => {
    const code = (r['CODE_EQUIPEMENT'] || r['EQUIPEMENT'] || '').trim();
    if (!code) return;
    const s = normState(r['ETAT_DI']);
    if (isAnnule(s)) return;
    if (!map[code]) map[code] = { code, pannes:0, dureeH:0 };
    if (isTraitee(s) || isRealisee(s) || isTransmis(s) || isTransmettre(s)) map[code].pannes++;
    const keys = Object.keys(r);
    const dk = keys.find(k => /dur.{0,3}e.*interv|interv.*min/i.test(k.normalize('NFD').replace(/[\u0300-\u036f]/g,'')));
    const d = dk ? parseFloat(String(r[dk]).replace(',','.')) : NaN;
    if (!isNaN(d) && d > 0) map[code].dureeH += d / 60;
  }));
  EQ_CORR_STATS_CACHE = map;
  return map;
}

// ── Chargement du fichier de correspondance Pièce → Système/Équipement ──
async function loadStockMappingFilesManual(fileList) {
  const files = Array.from(fileList || []);
  if (!files.length) return;
  STOCK_MAPPING = {}; STOCK_MAPPING_META = null;
  for (let i = 0; i < files.length; i++) {
    await loadStockMappingFile(files[i], i < files.length - 1, i > 0);
  }
}
function loadStockMappingFile(file, silent, merge) {
  return new Promise((resolve) => {
    showLoading();
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const wb = XLSX.read(e.target.result, { type:'binary' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const data = XLSX.utils.sheet_to_json(ws, { raw:false, defval:'' });
        const map = merge ? STOCK_MAPPING : {};
        data.forEach(row => {
          const keys = Object.keys(row);
          const getCol = (...names) => {
            for (const n of names) {
              const k = keys.find(kk => kk.trim().toLowerCase() === n.toLowerCase());
              if (k && String(row[k]).trim() !== '') return String(row[k]).trim();
            }
            return '';
          };
          let code = getCol('Code_Pièce','Code_Piece','CODE_PIECE','Code Piece');
          if (!code) {
            // Certains exports (ex: "liste_sortie_stock_par_systeme_equipement") ont une colonne
            // "Pièce" combinant code + désignation, ex: "SBA.PR.BILL.MON.002-Monnayeur - Trieur 5 voies"
            // → on extrait uniquement le code (avant le premier tiret) pour matcher le fichier de mouvements.
            const combo = getCol('Pièce','Piece','PIECE');
            if (combo) {
              const idx = combo.indexOf('-');
              code = (idx > -1 ? combo.slice(0, idx) : combo).trim();
            }
          }
          if (!code) return;
          map[code] = {
            systeme: getCol('Systeme','Système','SYSTEME','Sous-systeme','Sous-système') || 'Non classé',
            equipement: getCol('Code_Equipement','Code_Équipement','CODE_EQUIPEMENT','Equipement','Équipement') || ''
          };
        });
        STOCK_MAPPING = map;
        if (merge && STOCK_MAPPING_META) {
          STOCK_MAPPING_META.names.push(file.name);
          STOCK_MAPPING_META.count = Object.keys(map).length;
          STOCK_MAPPING_META.loadedAt = new Date();
        } else {
          STOCK_MAPPING_META = { names: [file.name], count: Object.keys(map).length, loadedAt: new Date() };
        }
        if (!silent) showToast(`✅ Correspondance Pièce→Système chargée — ${Object.keys(map).length} pièces`, 'success');
        if (document.getElementById('page-stock')?.classList.contains('active')) renderStockPage();
      } catch (err) { console.error(err); if (!silent) showToast(`❌ ${err.message}`, 'error'); }
      hideLoading();
      resolve();
    };
    reader.readAsBinaryString(file);
  });
}
function updateSlotUI(type, unit, filename) {
  const slot  = document.getElementById(`slot-${type}-${unit}`);
  const label = document.getElementById(`slot-${type}-file-${unit}`);
  if (slot)  slot.classList.add('loaded');
  if (label) label.textContent = filename.length > 18 ? filename.slice(0,16)+'…' : filename;
  const badge = document.getElementById(`unit-badge-${unit}`); if (badge) badge.style.display = '';
  const total = Object.keys(DB.loaded.corrective).length + Object.keys(DB.loaded.preventive).length;
  const status = document.getElementById('data-status');
  status.innerHTML = `<div class="dot"></div><span>${total}/14 fichiers charges${Object.keys(DB.loaded.stock).length ? ' · ' + Object.keys(DB.loaded.stock).length + '/7 fichiers Stock' : ''}</span>`;
  if (total > 0) status.classList.add('loaded');

  // ← NOUVEAU : basculer la vue dashboard si on est dessus
  if (document.getElementById('page-dashboard')?.classList.contains('active')) {
    renderDashboard();
  }
}
function updateBadges() {
  let tc = 0, tp = 0, ts = 0;
  UNITS.forEach(u => { tc += DB.corrective[u].length; tp += DB.preventive[u].length; ts += (DB.stock[u]||[]).length; });
  document.getElementById('badge-corr').textContent = formatK(tc);
  document.getElementById('badge-prev').textContent = formatK(tp);
  const bs = document.getElementById('badge-stock'); if (bs) bs.textContent = formatK(ts);
  const diag = document.getElementById('diag-panel'); if (!diag) return;
  let html = '<table style="width:100%;border-collapse:collapse;font-size:11px"><thead><tr style="color:var(--text3)"><th style="text-align:left;padding:4px 8px">Unite</th><th>Corr.</th><th>Prev.</th><th>Ex. DATE_DI</th><th>Ex. ETAT_DI</th><th>Ex. DATE_EVENEMENT</th><th>Ex. DATE_FIN_INTERVENTION</th><th>Ex. ETAT_BT</th></tr></thead><tbody>';
  UNITS.forEach(u => {
    const cr = DB.corrective[u] || [], pr = DB.preventive[u] || [];
    const ex = cr[0] || {};
    html += `<tr style="border-top:1px solid var(--border)"><td style="padding:4px 8px;font-weight:700">${u}</td>
      <td style="text-align:center;color:${cr.length>0?'#059669':'#dc2626'}">${cr.length}</td>
      <td style="text-align:center;color:${pr.length>0?'#059669':'#dc2626'}">${pr.length}</td>
      <td style="color:var(--text2)">${ex['DATE_DI']||'—'}</td>
      <td style="color:var(--text2)">${ex['ETAT_DI']||'—'}</td>
      <td style="color:${ex['DATE_EVENEMENT']?'#059669':'#dc2626'}">${ex['DATE_EVENEMENT']||'❌ MANQUANT'}</td>
      <td style="color:${ex['DATE_FIN_INTERVENTION']?'#059669':'#dc2626'}">${ex['DATE_FIN_INTERVENTION']||'❌ MANQUANT'}</td>
      <td style="color:var(--text2)">${pr[0]?pr[0]['ETAT_BT']||'—':'—'}</td>
    </tr>`;
  });
  html += '</tbody></table>'; diag.innerHTML = html;
}
function clearAll() {
  if (!confirm('Effacer toutes les donnees ?')) return;
  UNITS.forEach(u => { DB.corrective[u] = []; DB.preventive[u] = []; DB.stock[u] = []; delete DB.loaded.corrective[u]; delete DB.loaded.preventive[u]; delete DB.loaded.stock[u]; });
  EQ_CORR_STATS_CACHE = null;
  buildImportGrid(); updateBadges(); rebuildSystemFilter();
  const s = document.getElementById('data-status'); s.classList.remove('loaded');
  s.innerHTML = '<div class="dot"></div><span>Aucune donnee chargee</span>';
  showToast('🗑️ Efface', '');
}

// =====================================================================
// ██████████████████████████████████████████████████████████████████
// ██        GESTION DE STOCK — analyse des couts de maintenance     ██
// ██  (sorties de stock par piece), + prevision d'approvisionnement ██
// =====================================================================
function fmtDA(n) { return (Math.round(n || 0)).toLocaleString('fr-FR') + ' DA'; }
function allStockRows() { let out = []; UNITS.forEach(u => { out = out.concat(DB.stock[u] || []); }); return out; }
function stockHasData() { return allStockRows().length > 0; }

function populateStockFilterOptions() {
  const rows = allStockRows();
  const familles = [...new Set(rows.map(r => r.famille))].sort();
  const selF = document.getElementById('stk-sel-famille');
  const curF = selF.value;
  selF.innerHTML = '<option value="all">Toutes familles</option>' + familles.map(f => `<option value="${f.replace(/"/g,'&quot;')}">${f}</option>`).join('');
  if (familles.includes(curF)) selF.value = curF;

  const hasMapping = Object.keys(STOCK_MAPPING).length > 0;
  const selS = document.getElementById('stk-sel-systeme');
  const selE = document.getElementById('stk-sel-equip');
  if (hasMapping) {
    const systemes = [...new Set(rows.map(r => stockRowSysteme(r)).filter(Boolean))].sort();
    const curS = selS.value;
    selS.innerHTML = '<option value="all">Tous systèmes</option>' + systemes.map(s => `<option value="${s.replace(/"/g,'&quot;')}">${s}</option>`).join('');
    if (systemes.includes(curS)) selS.value = curS;
    const equips = [...new Set(rows.map(r => stockRowEquip(r)).filter(Boolean))].sort();
    const curE = selE.value;
    selE.innerHTML = '<option value="all">Tous équipements</option>' + equips.map(eq => `<option value="${eq.replace(/"/g,'&quot;')}">${eq}</option>`).join('');
    if (equips.includes(curE)) selE.value = curE;
    selS.disabled = false; selE.disabled = false;
  } else {
    selS.innerHTML = '<option value="all">Tous systèmes</option>'; selS.disabled = true;
    selE.innerHTML = '<option value="all">Tous équipements</option>'; selE.disabled = true;
  }

  const status = document.getElementById('stk-mapping-status');
  if (STOCK_MAPPING_META) {
    const fileLabel = STOCK_MAPPING_META.names.length > 1
      ? `${STOCK_MAPPING_META.names.length} fichiers (${STOCK_MAPPING_META.names.join(', ')})`
      : `<b>${STOCK_MAPPING_META.names[0]}</b>`;
    status.innerHTML = `✅ Correspondance chargée : ${fileLabel} — ${STOCK_MAPPING_META.count} pièces référencées.`;
    status.style.color = '#059669';
  } else {
    status.textContent = "Aucune correspondance Pièce→Système chargée — l'analyse par système/équipement sera limitée.";
    status.style.color = 'var(--text3)';
  }
}

/* ══ CARTES PLIABLES — Gestion de Stock ══ */
// Association carte pliable -> cle(s) du graphe Chart.js a redimensionner a l'ouverture
// (un canvas cache (display:none) a une taille nulle : Chart.js doit etre "resize()" une fois visible).
const STK_CARD_CHARTS = { 'month': ['stkMonth'], 'unit': ['stkUnit'] };
function toggleStkCard(id) {
  const body = document.getElementById('stkbody-' + id);
  const head = document.getElementById('stkhead-' + id);
  if (!body) return;
  const open = body.classList.toggle('open');
  if (head) head.classList.toggle('open', open);
  if (open) {
    setTimeout(() => {
      (STK_CARD_CHARTS[id] || []).forEach(k => { if (charts[k]) { try { charts[k].resize(); } catch(e) {} } });
    }, 60);
  }
}
function openAllStkCards() {
  document.querySelectorAll('#page-stock .stk-card-body').forEach(b => b.classList.add('open'));
  document.querySelectorAll('#page-stock .stk-card-head').forEach(h => h.classList.add('open'));
  setTimeout(() => { Object.values(STK_CARD_CHARTS).flat().forEach(k => { if (charts[k]) { try { charts[k].resize(); } catch(e) {} } }); }, 60);
}
function closeAllStkCards() {
  document.querySelectorAll('#page-stock .stk-card-body').forEach(b => b.classList.remove('open'));
  document.querySelectorAll('#page-stock .stk-card-head').forEach(h => h.classList.remove('open'));
}

function filterStockRows(applyDateRange) {

  const unit = document.getElementById('stk-sel-unit').value;
  const famille = document.getElementById('stk-sel-famille').value;
  const systeme = document.getElementById('stk-sel-systeme').value;
  const equip = document.getElementById('stk-sel-equip').value;
  const start = applyDateRange ? parseDate(document.getElementById('stk-date-start').value) : null;
  const end   = applyDateRange ? parseDate(document.getElementById('stk-date-end').value)   : null;
  if (end) end.setHours(23,59,59,999);
  let rows = allStockRows();
  if (unit !== 'all') rows = rows.filter(r => r.unit === unit);
  if (famille !== 'all') rows = rows.filter(r => r.famille === famille);
  if (systeme !== 'all') rows = rows.filter(r => stockRowSysteme(r) === systeme);
  if (equip !== 'all') rows = rows.filter(r => stockRowEquip(r) === equip);
  if (applyDateRange && (start || end)) {
    rows = rows.filter(r => r.date && (!start || r.date >= start) && (!end || r.date <= end));
  }
  return rows;
}

// Comme filterStockRows, mais l'unite est imposee (utilise par le clic sur le graphe "Coût par Unité",
// qui doit pouvoir isoler n'importe quelle unite meme si le filtre "Unité" en haut de page est sur "Toutes").
function filterStockRowsExceptUnit(applyDateRange, forcedUnit) {
  const famille = document.getElementById('stk-sel-famille').value;
  const systeme = document.getElementById('stk-sel-systeme').value;
  const equip = document.getElementById('stk-sel-equip').value;
  const start = applyDateRange ? parseDate(document.getElementById('stk-date-start').value) : null;
  const end   = applyDateRange ? parseDate(document.getElementById('stk-date-end').value)   : null;
  if (end) end.setHours(23,59,59,999);
  let rows = allStockRows();
  if (forcedUnit && forcedUnit !== 'all') rows = rows.filter(r => r.unit === forcedUnit);
  if (famille !== 'all') rows = rows.filter(r => r.famille === famille);
  if (systeme !== 'all') rows = rows.filter(r => stockRowSysteme(r) === systeme);
  if (equip !== 'all') rows = rows.filter(r => stockRowEquip(r) === equip);
  if (applyDateRange && (start || end)) {
    rows = rows.filter(r => r.date && (!start || r.date >= start) && (!end || r.date <= end));
  }
  return rows;
}

// Etat courant du detail par systeme affiche apres clic sur une barre du graphe "Coût par Unité"
// (memorise pour permettre l'export exact de ce qui est affiche).
let STK_UNIT_DRILLDOWN = null;

// Affiche, sous le graphe "Coût par Unité", la repartition par systeme des sorties de stock
// de l'unite cliquee (respecte les autres filtres actifs : periode, famille, systeme, equipement).
function renderStockUnitDrilldown(unit) {
  const wrap = document.getElementById('stk-unit-drilldown');
  const titleEl = document.getElementById('stk-unit-drilldown-title');
  const bodyEl = document.getElementById('stk-unit-drilldown-body');
  wrap.style.display = '';
  titleEl.textContent = `📦 Détail par Système / Équipement — Unité ${unit}`;

  const rows = filterStockRowsExceptUnit(true, unit);
  const totalUnit = rows.reduce((s, r) => s + r.valeur, 0);

  if (!rows.length) {
    bodyEl.innerHTML = `<div class="empty-hint" style="padding:10px">Aucune sortie de stock pour l'unité <b>${unit}</b> sur la période/filtre actif.</div>`;
    STK_UNIT_DRILLDOWN = null;
    return;
  }

  const hasMapping = Object.keys(STOCK_MAPPING).length > 0;
  if (!hasMapping) {
    bodyEl.innerHTML = `<div class="empty-state"><div class="es-icon">🔗</div><div class="es-title">Correspondance non chargée</div><div class="es-sub">Chargez le fichier « Correspondance Pièce → Système/Équipement » (bouton en haut de page) pour voir la répartition par système/équipement de l'unité <b>${unit}</b>. En attendant, voici le total consommé : <b>${fmtDA(totalUnit)}</b> sur ${rows.length} mouvement(s).</div></div>`;
    STK_UNIT_DRILLDOWN = null;
    return;
  }

  // Regroupement Système -> Équipement -> coût cumulé
  const bySys = {};
  rows.forEach(r => {
    const s = stockRowSysteme(r) || 'Non identifié';
    const eq = stockRowEquip(r) || '—';
    if (!bySys[s]) bySys[s] = { total: 0, equips: {} };
    bySys[s].total += r.valeur;
    bySys[s].equips[eq] = (bySys[s].equips[eq] || 0) + r.valeur;
  });
  const sysSorted = Object.entries(bySys).sort((a, b) => b[1].total - a[1].total);

  const body = sysSorted.map(([s, d], i) => {
    const eqSorted = Object.entries(d.equips).sort((a, b) => b[1] - a[1]);
    const eqRows = eqSorted.map(([eq, v]) =>
      `<tr style="border-top:1px solid var(--border)"><td style="padding:5px 10px 5px 28px;color:var(--text2)">↳ ${eq}</td><td style="text-align:right;padding:5px 10px;color:var(--text2)">${fmtDA(v)}</td><td style="text-align:right;padding:5px 10px;color:var(--text3)">${totalUnit > 0 ? (v / totalUnit * 100).toFixed(1) : '0.0'}%</td></tr>`
    ).join('');
    return `<tr style="border-top:1.5px solid var(--border2);cursor:pointer" onclick="const b=document.getElementById('stk-udd-eq-${i}'); b.style.display = b.style.display==='none'?'':'none';">
      <td style="padding:6px 10px;font-weight:700">▸ ${s}</td>
      <td style="text-align:right;padding:6px 10px;font-weight:700">${fmtDA(d.total)}</td>
      <td style="text-align:right;padding:6px 10px;color:var(--text3)">${totalUnit > 0 ? (d.total / totalUnit * 100).toFixed(1) : '0.0'}%</td></tr>
      <tr id="stk-udd-eq-${i}" style="display:none"><td colspan="3" style="padding:0"><table style="width:100%;border-collapse:collapse">${eqRows}</table></td></tr>`;
  }).join('');

  bodyEl.innerHTML = `<div class="section-sub" style="margin:0 0 10px">Total unité <b>${unit}</b> : <b>${fmtDA(totalUnit)}</b> sur ${rows.length} mouvement(s), ${sysSorted.length} système(s) identifié(s). <span style="color:var(--text3)">(cliquer sur un système pour voir le détail par équipement)</span></div>`
    + simpleTable(['Système', 'Coût', 'Part'], body);

  // Version a plat (systeme + equipement) memorisee pour l'export
  const flatRows = [];
  sysSorted.forEach(([s, d]) => {
    Object.entries(d.equips).sort((a, b) => b[1] - a[1]).forEach(([eq, v]) => {
      flatRows.push({ systeme: s, equipement: eq, valeur: v });
    });
  });

  STK_UNIT_DRILLDOWN = { unit, rows, sysSorted, flatRows, totalUnit };
}

// Exporte (XLSX, charte SETRAM) le detail par systeme actuellement affiche pour l'unite cliquee.
async function exportStockUnitDrilldown() {
  if (!STK_UNIT_DRILLDOWN || !STK_UNIT_DRILLDOWN.sysSorted || !STK_UNIT_DRILLDOWN.sysSorted.length) {
    alert('Aucun détail par système/équipement à exporter — cliquez d\'abord sur une barre du graphe « Coût par Unité » (correspondance Pièce→Système requise).');
    return;
  }
  const { unit, sysSorted, flatRows, totalUnit, rows } = STK_UNIT_DRILLDOWN;
  showLoading();
  try {
    const logoBuf = await setramLogoBuffer();
    const filtersLabel = buildStockFiltersLabel(true) + `   •   Unité sélectionnée (clic graphique) : ${unit}`;
    const kpis = stockKpisForExport(rows);
    const wb = new ExcelJS.Workbook();
    setSetramWorkbookProps(wb, {
      title: `Gestion de Stock — Détail par Système/Équipement (Unité ${unit})`,
      subject: 'Répartition des coûts de stock par système et équipement',
      keywords: 'stock, systeme, equipement, unite, drilldown, SETRAM'
    });
    writeStockCoverSheet(wb, {
      reportTitle: `Gestion de Stock — Détail par Système/Équipement — Unité ${unit}`,
      filtersLabel, kpis, nbLignes: rows.length, logoBuf, accentColor: SETRAM_XLSX.navy
    });
    const exportRowsSys = sysSorted.map(([s, d]) => ({
      'Système': s,
      'Coût (DA)': Math.round(d.total),
      'Part (%)': totalUnit > 0 ? Math.round((d.total / totalUnit) * 1000) / 10 : 0
    }));
    writeSetramSheet(wb, 'Par Systeme', exportRowsSys, {
      title: `Coût par Système — Unité ${unit}`,
      subtitle: filtersLabel,
      accentColor: SETRAM_XLSX.navy,
      logoBuf,
      footerNote: `SETRAM — Gestion de Stock — Détail par système — ${unit}`
    });
    const exportRowsEq = (flatRows || []).map(f => ({
      'Système': f.systeme,
      'Équipement': f.equipement,
      'Coût (DA)': Math.round(f.valeur),
      'Part (%)': totalUnit > 0 ? Math.round((f.valeur / totalUnit) * 1000) / 10 : 0
    }));
    writeSetramSheet(wb, 'Par Equipement', exportRowsEq, {
      title: `Coût par Équipement — Unité ${unit}`,
      subtitle: filtersLabel,
      accentColor: SETRAM_XLSX.cyan,
      logoBuf,
      footerNote: `SETRAM — Gestion de Stock — Détail par équipement — ${unit}`
    });
    await downloadSetramWorkbook(wb, `SETRAM_Stock_Systeme_Equipement_${unit}_${fmtDateInput(new Date())}.xlsx`);
  } catch (err) { console.error(err); showToast(`❌ ${err.message}`, 'error'); }
  hideLoading();
}

function simpleTable(headers, bodyRowsHtml, opts) {
  opts = opts || {};
  return `<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:11.5px">
    <thead><tr style="color:var(--text3)">${headers.map((h,i) => `<th style="text-align:${opts.align && opts.align[i] || (i===0?'left':'right')};padding:6px 10px;border-bottom:2px solid var(--border)">${h}</th>`).join('')}</tr></thead>
    <tbody>${bodyRowsHtml}</tbody></table></div>`;
}

function renderStockPage() {
  populateStockFilterOptions();
  if (!stockHasData()) {
    document.getElementById('stk-empty').style.display = '';
    document.getElementById('stk-content').style.display = 'none';
    return;
  }
  document.getElementById('stk-empty').style.display = 'none';
  document.getElementById('stk-content').style.display = '';

  const rows = filterStockRows(true);

  // ── KPIs ──
  const coutTotal = rows.reduce((s,r)=>s+r.valeur,0);
  const qteTotal  = rows.reduce((s,r)=>s+r.qte,0);
  const nbPieces  = new Set(rows.map(r=>r.codePiece)).size;
  const mois = new Set(rows.map(r=>r.monthKey).filter(Boolean));
  const coutMoyenMois = mois.size ? coutTotal / mois.size : 0;
  document.getElementById('stk-kpi-grid').innerHTML = `
    <div class="kpi-card c1"><div class="kpi-label">Coût Total (période)</div><div class="kpi-value" style="font-size:19px">${fmtDA(coutTotal)}</div><div class="kpi-sub">${rows.length} mouvement(s)</div></div>
    <div class="kpi-card c3"><div class="kpi-label">Qté sortie totale</div><div class="kpi-value">${Math.round(qteTotal).toLocaleString('fr-FR')}</div><div class="kpi-sub">unités toutes pièces</div></div>
    <div class="kpi-card c6"><div class="kpi-label">Pièces distinctes</div><div class="kpi-value">${nbPieces}</div><div class="kpi-sub">références consommées</div></div>
    <div class="kpi-card c9"><div class="kpi-label">Coût moyen / mois</div><div class="kpi-value" style="font-size:19px">${fmtDA(coutMoyenMois)}</div><div class="kpi-sub">sur ${mois.size} mois couverts</div></div>`;

  // ── Évolution mensuelle ──
  const byMonth = {};
  rows.forEach(r => { if (!r.monthKey) return; byMonth[r.monthKey] = (byMonth[r.monthKey]||0) + r.valeur; });
  const monthsSorted = Object.keys(byMonth).sort();
  if (charts.stkMonth) charts.stkMonth.destroy();
  const cMonth = document.getElementById('stk-chart-month');
  if (cMonth) charts.stkMonth = new Chart(cMonth, { type:'bar', data:{
    labels: monthsSorted, datasets:[{ label:'Coût (DA)', data: monthsSorted.map(m=>byMonth[m]), backgroundColor:'rgba(47,102,144,0.75)', borderRadius:4 }]
  }, options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{ y:{ ticks:{ callback:v=>formatK(v) } } } } });

  // ── Coût par unité ──
  const byUnit = {}; UNITS.forEach(u=>byUnit[u]=0);
  rows.forEach(r => { byUnit[r.unit] = (byUnit[r.unit]||0) + r.valeur; });
  if (charts.stkUnit) charts.stkUnit.destroy();
  const cUnit = document.getElementById('stk-chart-unit');
  if (cUnit) charts.stkUnit = new Chart(cUnit, { type:'bar', data:{
    labels: UNITS, datasets:[{ data: UNITS.map(u=>byUnit[u]), backgroundColor: UNITS.map(u=>UNIT_COLORS[u]), borderRadius:4 }]
  }, options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}},
    onClick: (evt, elements) => {
      if (!elements || !elements.length) return;
      const idx = elements[0].index;
      const unit = UNITS[idx];
      renderStockUnitDrilldown(unit);
      document.getElementById('stk-unit-drilldown').scrollIntoView({ behavior:'smooth', block:'nearest' });
    },
    onHover: (evt, elements) => { evt.native.target.style.cursor = elements && elements.length ? 'pointer' : 'default'; }
  } });

  // ── Répartition par type de sortie — uniquement Avec BT / Sans BT (toujours affichées, même à 0) ──
  const classifyTypeSortie = t => {
    const s = String(t || '').toLowerCase();
    if (s.includes('sans bt')) return 'Sortie sans BT';
    if (s.includes('avec bt')) return 'Sortie avec BT';
    return null;
  };
  const byType = { 'Sortie avec BT': 0, 'Sortie sans BT': 0 };
  rows.forEach(r => { const cat = classifyTypeSortie(r.typeSortie); if (cat) byType[cat] += r.valeur; });
  const typeBody = Object.entries(byType).sort((a,b)=>b[1]-a[1]).map(([t,v]) =>
    `<tr style="border-top:1px solid var(--border)"><td style="padding:5px 10px">${t}</td><td style="text-align:right;padding:5px 10px">${fmtDA(v)}</td><td style="text-align:right;padding:5px 10px;color:var(--text3)">${coutTotal>0?(v/coutTotal*100).toFixed(1):'0.0'}%</td></tr>`).join('');
  document.getElementById('stk-type-sortie').innerHTML = simpleTable(['Type de sortie','Coût','Part'], typeBody);

  // ── Top 20 pièces ──
  const byPiece = {};
  rows.forEach(r => {
    const k = r.codePiece || '—';
    if (!byPiece[k]) byPiece[k] = { designation:r.designation, famille:r.famille, qte:0, valeur:0 };
    byPiece[k].qte += r.qte; byPiece[k].valeur += r.valeur;
  });
  const topPieces = Object.entries(byPiece).sort((a,b)=>b[1].valeur-a[1].valeur).slice(0,20);
  const topBody = topPieces.map(([code,d]) =>
    `<tr style="border-top:1px solid var(--border)"><td style="padding:5px 10px">${code}</td><td style="padding:5px 10px;color:var(--text2)">${d.designation}</td><td style="padding:5px 10px;color:var(--text2)">${d.famille}</td><td style="text-align:right;padding:5px 10px">${Math.round(d.qte).toLocaleString('fr-FR')}</td><td style="text-align:right;padding:5px 10px;font-weight:700">${fmtDA(d.valeur)}</td></tr>`).join('');
  document.getElementById('stk-top-pieces').innerHTML = topBody
    ? simpleTable(['Code Pièce','Désignation','Famille','Qté','Coût cumulé'], topBody, {align:['left','left','left','right','right']})
    : '<div class="empty-hint" style="padding:10px">Aucune donnée sur la période filtrée.</div>';

  renderStockABC(rows);
  renderStockRotation();
  renderStockCriticite();
  renderStockUOComparaison(rows);
  renderStockCoutUnitaire();
  renderStockPointCommande();
  renderApprovisionnement();
}

// ── Classement ABC (Pareto valeur) — sur la période filtrée ──
function renderStockABC(rows) {
  const el = document.getElementById('stk-abc-content');
  const byPiece = {};
  rows.forEach(r => { const k=r.codePiece||'—'; if(!byPiece[k]) byPiece[k]={designation:r.designation,famille:r.famille,valeur:0}; byPiece[k].valeur += r.valeur; });
  const total = Object.values(byPiece).reduce((s,d)=>s+d.valeur,0);
  if (!total) { el.innerHTML = '<div class="empty-hint" style="padding:10px">Aucune donnée sur la période filtrée.</div>'; return; }
  const sorted = Object.entries(byPiece).sort((a,b)=>b[1].valeur-a[1].valeur);
  let cum = 0;
  const classed = sorted.map(([code,d]) => {
    cum += d.valeur;
    const pct = cum/total*100;
    const cls = pct <= 80 ? 'A' : (pct <= 95 ? 'B' : 'C');
    return { code, ...d, pctCum: pct, cls };
  });
  const summary = {A:{n:0,v:0},B:{n:0,v:0},C:{n:0,v:0}};
  classed.forEach(p => { summary[p.cls].n++; summary[p.cls].v += p.valeur; });
  const cardColor = {A:'#dc2626', B:'#d97706', C:'#16a34a'};
  const cards = ['A','B','C'].map(c => `<div class="kpi-card" style="cursor:pointer" onclick="const b=document.getElementById('stk-abc-list-${c}'); b.style.display = b.style.display==='none'?'':'none';">
    <div class="kpi-label">Classe ${c} <span style="color:var(--text3);font-weight:400">(cliquer pour la liste)</span></div>
    <div class="kpi-value" style="font-size:19px;color:${cardColor[c]}">${summary[c].n} réf.</div>
    <div class="kpi-sub">${fmtDA(summary[c].v)} — ${(summary[c].v/total*100).toFixed(1)}% de la valeur</div></div>`).join('');
  const lists = ['A','B','C'].map(c => {
    const body = classed.filter(p => p.cls === c).map(p => `<tr style="border-top:1px solid var(--border)">
      <td style="padding:5px 10px">${p.code}</td><td style="padding:5px 10px;color:var(--text2)">${p.designation}</td>
      <td style="padding:5px 10px;color:var(--text2)">${p.famille}</td>
      <td style="text-align:right;padding:5px 10px">${fmtDA(p.valeur)}</td>
      <td style="text-align:right;padding:5px 10px;color:var(--text3)">${p.pctCum.toFixed(1)}%</td></tr>`).join('');
    return `<div id="stk-abc-list-${c}" style="display:none;margin-top:12px">
      <div class="section-sub" style="margin:0 0 6px;font-weight:650;color:${cardColor[c]}">Classe ${c} — ${summary[c].n} référence(s)</div>
      ${simpleTable(['Code Pièce','Désignation','Famille','Valeur','% cumulé'], body, {align:['left','left','left','right','right']})}
    </div>`;
  }).join('');
  el.innerHTML = `<div class="kpi-grid" style="margin-bottom:0">${cards}</div>${lists}`;
}

// ── Rotation / Stock dormant — sur l'historique complet (hors filtre de dates) ──
function renderStockRotation() {
  const rows = filterStockRows(false);
  const el = document.getElementById('stk-rotation-content');
  const elDormant = document.getElementById('stk-dormant-content');
  if (!rows.length) {
    el.innerHTML = '<div class="empty-hint" style="padding:10px">Aucune donnée disponible.</div>';
    if (elDormant) elDormant.innerHTML = '<div class="empty-hint" style="padding:10px">Aucune donnée disponible.</div>';
    return;
  }
  const latest = stockLatestByPiece(rows);
  const hasStockCols = Object.values(latest).some(r => r.valeurStockApres > 0);
  const now = new Date();
  const cutoff12 = new Date(now); cutoff12.setFullYear(cutoff12.getFullYear()-1);
  const conso12 = {};
  rows.forEach(r => { if (r.date && r.date >= cutoff12) conso12[r.codePiece] = (conso12[r.codePiece]||0) + r.valeur; });

  const pieces = Object.keys(latest).map(code => {
    const l = latest[code];
    const daysSince = l.date ? Math.round((now - l.date)/86400000) : null;
    return { code, designation:l.designation, famille:l.famille, daysSince, valeurStock: l.valeurStockApres, conso12: conso12[code]||0 };
  });

  // ── Stock dormant : LISTE COMPLETE (aucune limite Top 20), triée par valeur immobilisée décroissante ──
  const dormant = pieces.filter(p => p.daysSince !== null && p.daysSince >= 365 && p.valeurStock > 0).sort((a,b)=>b.valeurStock-a.valeurStock);
  const dormantBody = dormant.map(p => `<tr style="border-top:1px solid var(--border)">
    <td style="padding:5px 10px">${p.code}</td><td style="padding:5px 10px;color:var(--text2)">${p.designation}</td>
    <td style="padding:5px 10px;color:var(--text2)">${p.famille}</td>
    <td style="text-align:right;padding:5px 10px">${p.daysSince} j</td>
    <td style="text-align:right;padding:5px 10px;font-weight:700;color:#dc2626">${fmtDA(p.valeurStock)}</td></tr>`).join('');
  const dormantValeurTotale = dormant.reduce((s,p)=>s+p.valeurStock,0);

  // ── Consommation moyenne mensuelle par pièce (valeur + quantité) — respecte le filtre de dates actif ──
  const rowsPeriode = filterStockRows(true);
  const startVal = document.getElementById('stk-date-start').value;
  const endVal = document.getElementById('stk-date-end').value;
  let nbMoisPeriode;
  if (startVal && endVal) {
    const sD = parseDate(startVal), eD = parseDate(endVal);
    nbMoisPeriode = (eD.getFullYear() - sD.getFullYear()) * 12 + (eD.getMonth() - sD.getMonth()) + 1;
  } else {
    nbMoisPeriode = new Set(rowsPeriode.map(r=>r.monthKey).filter(Boolean)).size;
  }
  nbMoisPeriode = Math.max(1, nbMoisPeriode);
  const byPieceConso = {};
  rowsPeriode.forEach(r => {
    const k = r.codePiece || '—';
    if (!byPieceConso[k]) byPieceConso[k] = { designation:r.designation, famille:r.famille, valeur:0, qte:0 };
    byPieceConso[k].valeur += r.valeur;
    byPieceConso[k].qte += r.qte;
  });
  const consoRows = Object.entries(byPieceConso).map(([code,d]) => ({ code, designation:d.designation, famille:d.famille, consoMoyMoisVal: d.valeur / nbMoisPeriode, consoMoyMoisQte: d.qte / nbMoisPeriode })).sort((a,b)=>b.consoMoyMoisVal-a.consoMoyMoisVal);
  const consoBody = consoRows.map(p => `<tr style="border-top:1px solid var(--border)">
    <td style="padding:5px 10px">${p.code}</td><td style="padding:5px 10px;color:var(--text2)">${p.designation}</td>
    <td style="padding:5px 10px;color:var(--text2)">${p.famille}</td>
    <td style="text-align:right;padding:5px 10px;font-weight:700">${fmtDA(p.consoMoyMoisVal)}</td>
    <td style="text-align:right;padding:5px 10px">${p.consoMoyMoisQte.toFixed(1)}</td></tr>`).join('');

  // ── Carte "Consommation moyenne par pièce" ──
  let html = '';
  html += `<div class="section-sub" style="margin:0 0 6px;font-weight:650;color:var(--text)">Consommation moyenne par mois et par pièce — ${consoRows.length} référence(s) (période filtrée : ${startVal||endVal ? `${startVal||'…'} → ${endVal||'…'}` : 'historique complet'}, ${nbMoisPeriode} mois)</div>`;
  html += `<div id="stk-conso-detail">${consoBody ? simpleTable(['Code Pièce','Désignation','Famille','Conso. moy./mois (Valeur)','Conso. moy./mois (Qté)'], consoBody, {align:['left','left','left','right','right']}) : '<div class="empty-hint" style="padding:10px">Aucune donnée sur la période filtrée.</div>'}</div>`;
  el.innerHTML = html;

  // ── Carte "Stock Dormant" (séparée, liste complète) ──
  if (elDormant) {
    let htmlDormant = '';
    if (!hasStockCols) {
      htmlDormant += `<div class="empty-hint" style="margin-bottom:10px">⚠️ Les colonnes Qte_Après_MVT / Valeur_Stock_Après_MVT sont absentes ou nulles dans les fichiers importés — le stock actuel par pièce ne peut pas être estimé pour le stock dormant ci-dessous.</div>`;
    }
    htmlDormant += `<div class="section-sub" style="margin:0 0 6px;font-weight:650;color:var(--text)">Stock dormant complet (aucun mouvement depuis ≥ 12 mois), triées par valeur immobilisée — ${dormant.length} référence(s), ${fmtDA(dormantValeurTotale)} immobilisés</div>`;
    htmlDormant += dormantBody ? simpleTable(['Code Pièce','Désignation','Famille','Sans mvt depuis','Valeur immobilisée'], dormantBody, {align:['left','left','left','right','right']}) : '<div class="empty-hint" style="padding:10px">Aucune pièce dormante détectée sur le périmètre filtré.</div>';
    elDormant.innerHTML = htmlDormant;
  }
}

// ── Croisement stock ↔ criticité équipement — nécessite STOCK_MAPPING + données correctives ──
function renderStockCriticite() {
  const el = document.getElementById('stk-critic-content');
  const hasMapping = Object.keys(STOCK_MAPPING).length > 0;
  if (!hasMapping) {
    el.innerHTML = `<div class="empty-state"><div class="es-icon">🔗</div><div class="es-title">Correspondance non chargée</div><div class="es-sub">Chargez le fichier « Correspondance Pièce → Système/Équipement » (bouton en haut) pour activer cette analyse.</div></div>`;
    return;
  }
  const corrStats = computeEquipementCorrStats();
  if (!Object.keys(corrStats).length) {
    el.innerHTML = `<div class="empty-hint" style="padding:10px">Aucune donnée corrective chargée — importez les fichiers Correctif des unités pour activer ce croisement.</div>`;
    return;
  }
  const rows = filterStockRows(false);
  const byEquip = {};
  rows.forEach(r => {
    const eq = stockRowEquip(r);
    if (!eq) return;
    if (!byEquip[eq]) byEquip[eq] = 0;
    byEquip[eq] += r.valeur;
  });
  const allEquips = new Set([...Object.keys(corrStats), ...Object.keys(byEquip)]);
  const combined = [...allEquips].map(eq => ({
    eq, pannes: (corrStats[eq]||{}).pannes || 0, dureeH: (corrStats[eq]||{}).dureeH || 0, valeurPieces: byEquip[eq] || 0
  }));

  const critiques = combined.filter(c => c.pannes > 0).sort((a,b)=>b.pannes-a.pannes).slice(0,15);
  const critBody = critiques.map(c => `<tr style="border-top:1px solid var(--border)">
    <td style="padding:5px 10px">${c.eq}</td>
    <td style="text-align:right;padding:5px 10px;font-weight:700">${c.pannes}</td>
    <td style="text-align:right;padding:5px 10px">${c.dureeH.toFixed(1)} h</td>
    <td style="text-align:right;padding:5px 10px;${c.valeurPieces===0?'color:#dc2626;font-weight:700':''}">${c.valeurPieces===0?'⚠️ Aucune sortie récente':fmtDA(c.valeurPieces)}</td></tr>`).join('');

  const nonCritiques = combined.filter(c => c.pannes <= 1 && c.valeurPieces > 0).sort((a,b)=>b.valeurPieces-a.valeurPieces).slice(0,15);
  const nonCritBody = nonCritiques.map(c => `<tr style="border-top:1px solid var(--border)">
    <td style="padding:5px 10px">${c.eq}</td>
    <td style="text-align:right;padding:5px 10px">${c.pannes}</td>
    <td style="text-align:right;padding:5px 10px;font-weight:700;color:#d97706">${fmtDA(c.valeurPieces)}</td></tr>`).join('');

  el.innerHTML = `
    <div class="section-sub" style="margin:0 0 6px;font-weight:650;color:var(--text)">Top 15 équipements les plus en panne — pièces consommées sur la période filtrée</div>
    <div class="empty-hint" style="margin-bottom:8px">⚠️ = équipement en tête des pannes correctives mais sans sortie de pièces récente sur le filtre actuel : risque de rupture à vérifier.</div>
    ${critBody ? simpleTable(['Équipement','Nb pannes','Durée interv.','Valeur pièces consommées'], critBody) : '<div class="empty-hint" style="padding:10px">Aucun équipement en panne trouvé.</div>'}
    <div class="section-sub" style="margin:16px 0 6px;font-weight:650;color:var(--text)">Équipements peu critiques (≤1 panne) mais forte valeur de pièces consommée — à questionner</div>
    ${nonCritBody ? simpleTable(['Équipement','Nb pannes','Valeur pièces consommées'], nonCritBody) : '<div class="empty-hint" style="padding:10px">Aucun cas détecté.</div>'}`;
}

// ── Comparaison entre unités (UO) — sur la période filtrée ──
function renderStockUOComparaison(rows) {
  const el = document.getElementById('stk-uo-content');
  if (!rows.length) { el.innerHTML = '<div class="empty-hint" style="padding:10px">Aucune donnée sur la période filtrée.</div>'; return; }

  // Pièces communes à plusieurs unités (candidates à mutualisation)
  const byPieceUnit = {};
  rows.forEach(r => {
    const k = r.codePiece || '—';
    if (!byPieceUnit[k]) byPieceUnit[k] = { designation:r.designation, famille:r.famille, units:new Set(), valeur:0 };
    byPieceUnit[k].units.add(r.unit); byPieceUnit[k].valeur += r.valeur;
  });
  const communes = Object.entries(byPieceUnit).filter(([k,d]) => d.units.size > 1).sort((a,b)=>b[1].valeur-a[1].valeur).slice(0,15);
  const commBody = communes.map(([code,d]) => `<tr style="border-top:1px solid var(--border)">
    <td style="padding:5px 10px">${code}</td><td style="padding:5px 10px;color:var(--text2)">${d.designation}</td>
    <td style="text-align:right;padding:5px 10px">${d.units.size}</td>
    <td style="padding:5px 10px;color:var(--text2)">${[...d.units].join(', ')}</td>
    <td style="text-align:right;padding:5px 10px;font-weight:700">${fmtDA(d.valeur)}</td></tr>`).join('');

  // Écart de consommation par famille et par UO vs la moyenne des UO actives sur cette famille
  const byFamUnit = {};
  rows.forEach(r => {
    if (!byFamUnit[r.famille]) byFamUnit[r.famille] = {};
    byFamUnit[r.famille][r.unit] = (byFamUnit[r.famille][r.unit]||0) + r.valeur;
  });
  const ecarts = [];
  Object.entries(byFamUnit).forEach(([fam,byU]) => {
    const vals = Object.values(byU);
    if (vals.length < 2) return;
    const avg = vals.reduce((a,b)=>a+b,0)/vals.length;
    Object.entries(byU).forEach(([u,v]) => { if (avg > 0 && v > avg*1.5) ecarts.push({ famille:fam, unit:u, valeur:v, avg, ecart:(v/avg-1)*100 }); });
  });
  ecarts.sort((a,b)=>b.ecart-a.ecart);
  const ecartBody = ecarts.slice(0,15).map(e => `<tr style="border-top:1px solid var(--border)">
    <td style="padding:5px 10px">${e.famille}</td><td style="padding:5px 10px;font-weight:700">${e.unit}</td>
    <td style="text-align:right;padding:5px 10px">${fmtDA(e.valeur)}</td>
    <td style="text-align:right;padding:5px 10px;color:var(--text3)">${fmtDA(e.avg)}</td>
    <td style="text-align:right;padding:5px 10px;font-weight:700;color:#dc2626">+${e.ecart.toFixed(0)}%</td></tr>`).join('');

  el.innerHTML = `
    <div class="section-sub" style="margin:0 0 6px;font-weight:650;color:var(--text)">Pièces communes à plusieurs unités (candidates à une gestion mutualisée)</div>
    ${commBody ? simpleTable(['Code Pièce','Désignation','Nb UO','Unités','Valeur cumulée'], commBody, {align:['left','left','right','left','right']}) : '<div class="empty-hint" style="padding:10px">Aucune pièce commune détectée sur la période filtrée.</div>'}
    <div class="section-sub" style="margin:16px 0 6px;font-weight:650;color:var(--text)">Unités en surconsommation (&gt;+50% vs la moyenne des UO, par famille de pièce)</div>
    ${ecartBody ? simpleTable(['Famille','Unité','Valeur','Moyenne UO','Écart'], ecartBody) : '<div class="empty-hint" style="padding:10px">Aucun écart significatif détecté.</div>'}`;
}

// ── Suivi des coûts unitaires — sur l'historique complet (hors filtre de dates) ──
function renderStockCoutUnitaire() {
  const rows = filterStockRows(false);
  const el = document.getElementById('stk-coutunit-content');
  if (!rows.length) { el.innerHTML = '<div class="empty-hint" style="padding:10px">Aucune donnée disponible.</div>'; return; }
  const byPieceYear = {};
  rows.forEach(r => {
    if (!r.year || !r.coutU) return;
    const k = r.codePiece || '—';
    if (!byPieceYear[k]) byPieceYear[k] = { designation:r.designation, famille:r.famille, years:{} };
    if (!byPieceYear[k].years[r.year]) byPieceYear[k].years[r.year] = { sum:0, n:0 };
    byPieceYear[k].years[r.year].sum += r.coutU; byPieceYear[k].years[r.year].n++;
  });
  const evolutions = [];
  Object.entries(byPieceYear).forEach(([code,d]) => {
    const yrs = Object.keys(d.years).map(Number).sort((a,b)=>a-b);
    if (yrs.length < 2) return;
    const firstAvg = d.years[yrs[0]].sum / d.years[yrs[0]].n;
    const lastAvg = d.years[yrs[yrs.length-1]].sum / d.years[yrs[yrs.length-1]].n;
    if (firstAvg <= 0) return;
    const evolPct = (lastAvg/firstAvg - 1) * 100;
    evolutions.push({ code, designation:d.designation, famille:d.famille, firstYear:yrs[0], lastYear:yrs[yrs.length-1], firstAvg, lastAvg, evolPct });
  });
  const hausses = evolutions.filter(e => e.evolPct >= 20).sort((a,b)=>b.evolPct-a.evolPct).slice(0,20);
  const body = hausses.map(e => `<tr style="border-top:1px solid var(--border)">
    <td style="padding:5px 10px">${e.code}</td><td style="padding:5px 10px;color:var(--text2)">${e.designation}</td>
    <td style="padding:5px 10px;color:var(--text2)">${e.famille}</td>
    <td style="text-align:right;padding:5px 10px">${fmtDA(e.firstAvg)} (${e.firstYear})</td>
    <td style="text-align:right;padding:5px 10px">${fmtDA(e.lastAvg)} (${e.lastYear})</td>
    <td style="text-align:right;padding:5px 10px;font-weight:700;color:#dc2626">+${e.evolPct.toFixed(0)}%</td></tr>`).join('');
  el.innerHTML = `
    <div class="section-sub" style="margin:0 0 6px;font-weight:650;color:var(--text)">Pièces avec une hausse de coût unitaire ≥ 20% entre leur première et dernière année d'historique</div>
    ${body ? simpleTable(['Code Pièce','Désignation','Famille','Coût initial','Coût récent','Évolution'], body, {align:['left','left','left','right','right','right']}) : '<div class="empty-hint" style="padding:10px">Aucune hausse significative détectée.</div>'}`;
}

// ── Stock de sécurité par pièce — Conso. moy./mois calculée sur la période filtrée, Stock sécurité = Conso. moy./mois × Délai fournisseur ──
function renderStockPointCommande() {
  const rowsFull = filterStockRows(false);
  const el = document.getElementById('stk-pointcommande-content');
  if (!rowsFull.length) { el.innerHTML = '<div class="empty-hint" style="padding:10px">Aucune donnée disponible.</div>'; return; }
  // Stock actuel (dernier mouvement connu) : calculé sur l'historique complet, indépendamment du filtre de dates.
  const latest = stockLatestByPiece(rowsFull);

  // Conso. moy./mois = consommation totale de la période filtrée ÷ nombre de mois de cette période
  // (ex : filtre du 01/12/2026 au 01/06/2026 → 6 mois → conso totale / 6).
  const rowsPeriode = filterStockRows(true);
  const startVal = document.getElementById('stk-date-start').value;
  const endVal = document.getElementById('stk-date-end').value;
  let nbMoisPeriode;
  if (startVal && endVal) {
    const sD = parseDate(startVal), eD = parseDate(endVal);
    nbMoisPeriode = (eD.getFullYear() - sD.getFullYear()) * 12 + (eD.getMonth() - sD.getMonth()) + 1;
  } else {
    nbMoisPeriode = new Set(rowsPeriode.map(r=>r.monthKey).filter(Boolean)).size;
  }
  nbMoisPeriode = Math.max(1, nbMoisPeriode);

  const byPiece = {};
  rowsPeriode.forEach(r => {
    const k = r.codePiece || '—';
    if (!byPiece[k]) byPiece[k] = { designation:r.designation, famille:r.famille, qte:0 };
    byPiece[k].qte += r.qte;
  });

  const delaiMois = Math.max(1, parseFloat(document.getElementById('stk-delai-mois')?.value) || 3);
  const list = Object.entries(byPiece).map(([code,d]) => {
    const avg = d.qte / nbMoisPeriode;
    const stockSecu = avg * delaiMois; // Stock sécurité = Conso. moy./mois × Délai fournisseur
    const stockActuel = (latest[code] && latest[code].qteApres) || 0;
    return { code, designation:d.designation, famille:d.famille, avgMonth:avg, stockSecu, stockActuel, sousSeuil: stockActuel < stockSecu };
  }).filter(p => p.avgMonth > 0);
  const sousSeuilList = list.filter(p => p.sousSeuil).sort((a,b)=>b.avgMonth-a.avgMonth).slice(0,25);
  const hasStockCols = Object.values(latest).some(r => r.qteApres > 0);
  const body = sousSeuilList.map(p => `<tr style="border-top:1px solid var(--border)">
    <td style="padding:5px 10px">${p.code}</td><td style="padding:5px 10px;color:var(--text2)">${p.designation}</td>
    <td style="padding:5px 10px;color:var(--text2)">${p.famille}</td>
    <td style="text-align:right;padding:5px 10px">${p.avgMonth.toFixed(1)}</td>
    <td style="text-align:right;padding:5px 10px;font-weight:700">${Math.round(p.stockSecu)}</td>
    <td style="text-align:right;padding:5px 10px;color:${hasStockCols?'#dc2626':'var(--text3)'};font-weight:700">${hasStockCols?Math.round(p.stockActuel):'N/A'}</td></tr>`).join('');
  el.innerHTML = (!hasStockCols ? `<div class="empty-hint" style="margin-bottom:10px">⚠️ Colonne Qte_Après_MVT absente ou nulle — le stock actuel par pièce n'est pas disponible ; seuls la conso. moyenne et le stock de sécurité théoriques sont calculés.</div>` : '') +
    `<div class="section-sub" style="margin:0 0 10px;font-weight:650;color:var(--text)">Consommation moyenne calculée sur la période filtrée (${startVal||endVal ? `${startVal||'…'} → ${endVal||'…'}` : 'historique complet'}, ${nbMoisPeriode} mois)</div>` +
    (body ? simpleTable(['Code Pièce','Désignation','Famille','Conso. moy./mois','Stock sécurité','Stock actuel'], body, {align:['left','left','left','right','right','right']})
          : '<div class="empty-hint" style="padding:10px">Aucune pièce sous son seuil détectée (ou stock actuel indisponible).</div>');
}


// IMPORTANT : la couverture calendaire (nb de mois "actifs" par année, pour savoir si une
// année est complète ou en cours) doit être calculée sur TOUT le stock (toutes pièces/systèmes
// confondus), jamais sur le sous-ensemble filtré par Système/Équipement. Sinon un équipement
// consommé seulement 1 ou 2 mois dans l'année (mais réellement rare, pas "sous-suivi") se voit
// artificiellement annualisé x6, x12... alors que l'année de suivi est bien complète.
