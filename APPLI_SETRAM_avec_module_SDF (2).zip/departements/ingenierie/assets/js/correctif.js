/* =========================================================
   CORRECTIF — Page "Correctif" (analyse des DI)
   Extrait de suivi-performances.html (refactor de maintenabilite,
   aucun changement de comportement). Ce fichier est charge en
   <script src="assets/js/correctif.js"> APRES le script principal
   de la page (il utilise des fonctions communes comme debounce,
   getFilters, pct... definies plus haut), donc ces fonctions
   restent globales et disponibles partout comme avant.
   ========================================================= */
function renderCorrectivePage() {
  const au = document.querySelector('#corr-unit-tabs .tab.active')?.dataset.unit || 'all';
  const { start, end, hoursTotal, systeme } = getFilters();
  let rows = [];
  if (au === 'all') UNITS.forEach(u => rows = rows.concat(DB.corrective[u]));
  else rows = DB.corrective[au] || [];
  rows = filterByDate(rows, 'DATE_DI', start, end); rows = filterBySystem(rows, systeme);
  const container = document.getElementById('corr-content');
  if (rows.length === 0) { container.innerHTML = `<div class="empty-state"><div class="es-icon">🔧</div><div class="es-title">Aucune donnee</div></div>`; return; }
  const kpi = calcKPIs(rows, [], hoursTotal, start, end);
  const tr2 = rows.filter(r => { const s = normState(r['ETAT_DI']); return isTraitee(s) || isRealisee(s); }).length;
  const tm  = rows.filter(r => isTransmis(normState(r['ETAT_DI']))).length;
  const at  = rows.filter(r => isTransmettre(normState(r['ETAT_DI']))).length;
  const dH  = sumField(rows, ['Durée Intervention_(Min)','Durée Intervention (Min)']) / 60;
  const lH  = sumField(rows, ['Temps Logistique_(Min)','Temps Logistique (Min)'])    / 60;
  const nbSansEvenement = rows.filter(r => !r['DATE_EVENEMENT'] || String(r['DATE_EVENEMENT']).trim() === '').length;
  const show = rows.slice(0, 300);
  let alertHtml = '';
  if (nbSansEvenement > 0) {
    alertHtml = `<div class="alert-panel warn" style="margin-bottom:12px"><div class="alert-panel-title">⚡ Donnees de dates incompletes</div>
      <div class="alert-item"><span class="ai-unit">DI</span><span class="ai-msg"><strong>${nbSansEvenement} DI sans DATE_EVENEMENT</strong></span><span class="ai-val">${nbSansEvenement} DI</span></div>
    </div>`;
  }
  container.innerHTML = `
    ${alertHtml}
    <div style="display:flex;gap:10px;margin-bottom:14px;flex-wrap:wrap">
      ${ms('Total DI',rows.length,'')}${ms('Traitée',tr2,'rgba(16,185,129,0.3)')}
      ${ms('Transmises',tm,'rgba(59,130,246,0.3)')}${ms('A transmettre',at,'rgba(239,68,68,0.3)')}
      ${ms("Durée d'intervention",dH.toFixed(1)+'h','rgba(249,115,22,0.3)')}${ms('Temps Logistique',lH.toFixed(1)+'h','rgba(139,92,246,0.3)')}
      ${ms('MTTR',kpi.mttr.toFixed(3)+'h','rgba(34,211,238,0.2)')}${ms('TMC',pct(kpi.tmc),'rgba(16,185,129,0.2)')}
      ${ms('λ',kpi.tauxPanne>0?fmtSciShort(kpi.tauxPanne):'0⚠️','rgba(239,68,68,0.2)')}${ms('μ',kpi.tauxRep>0?fmtSciShort(kpi.tauxRep):'—','rgba(16,185,129,0.2)')}
      ${nbSansEvenement>0?ms('Sans DATE_EVENEMENT',nbSansEvenement,'rgba(239,68,68,0.3)'):''}
    </div>
    <div style="font-size:11px;color:var(--text2);margin-bottom:10px">${rows.length} enregistrements (affichage: ${show.length})</div>
    <div class="table-wrap" style="max-height:480px;overflow-y:auto"><table><thead><tr>
      <th>Unite</th><th>SYSTEME</th><th>CODE_DI</th><th>ETAT_DI</th><th>TITRE_DI</th>
      <th>EQUIPEMENT</th><th>DATE_DI</th>
      <th >DATE_EVENEMENT ⚠️</th>
      <th >DATE_FIN_INTERV. ⚠️</th>
      <th>Durée d'intervention(h)</th><th>Temps Logistique(h)</th><th>Indispo(h)</th>
    </tr></thead><tbody>
      ${show.map(r => {
        const fin = parseDate(r['DATE_FIN_INTERVENTION']);
        const deb = parseDate(r['DATE_EVENEMENT']);
        let indH = '—'; let indStyle = '';
        if (!deb||!fin)       { indH = '⚠️ Dates manquantes'; indStyle = 'color:var(--red);font-size:10px'; }
        else if (fin <= deb)  { indH = '⚠️ FIN≤DEBUT';        indStyle = 'color:var(--red);font-size:10px'; }
        else { const h = (fin-deb)/3600000; indH = h.toFixed(2)+'h'; }
        const hasEv  = deb ? '' : 'style="background:rgba(239,68,68,0.08);color:#ef4444"';
        const hasFin = fin ? '' : 'style="background:rgba(239,68,68,0.08);color:#ef4444"';
        return `<tr>
          <td><span class="unit-tag bg-${(r.__UNIT__||'').toLowerCase()} u-${(r.__UNIT__||'').toLowerCase()}">${r.__UNIT__||'—'}</span></td>
          <td style="font-size:11px">${r['SYSTEME']||'—'}</td>
          <td style="font-size:11px;color:var(--text2)">${r['CODE_DI']||'—'}</td>
          <td>${stateBadge(r['ETAT_DI'])}</td>
          <td style="max-width:150px;white-space:normal;font-size:11px">${r['TITRE_DI']||'—'}</td>
          <td style="font-size:11px">${r['EQUIPEMENT']||r['CODE_EQUIPEMENT']||'—'}</td>
          <td style="font-size:11px">${r['DATE_DI']||'—'}</td>
          <td ${hasEv} style="font-size:11px">${r['DATE_EVENEMENT']||'❌ MANQUANT'}</td>
          <td ${hasFin} style="font-size:11px">${r['DATE_FIN_INTERVENTION']||'❌ MANQUANT'}</td>
          <td>${fmtMin(r['Durée Intervention_(Min)']||r['Durée Intervention (Min)'])}</td>
          <td>${fmtMin(r['Temps Logistique_(Min)']||r['Temps Logistique (Min)'])}</td>
          <td style="${indStyle}">${indH}</td>
        </tr>`;
      }).join('')}
    </tbody></table></div>`;
}
