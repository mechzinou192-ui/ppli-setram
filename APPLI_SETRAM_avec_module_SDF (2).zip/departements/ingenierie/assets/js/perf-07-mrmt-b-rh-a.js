// =============================================================================
// SUIVI DES PERFORMANCES — module 07/10 : perf-07-mrmt-b-rh-a.js
// Extrait mecaniquement (meme code, meme ordre) du script principal historique
// pour ameliorer la maintenabilite (le fichier faisait ~8300 lignes en un bloc).
// Contenu : Suite module MPU/TCU (MRMT) : import, filtres, correlations, rendu page et tableaux - debut Efficience RH : import en masse par unite
// IMPORTANT : ce fichier partage la portee globale avec les autres modules
// perf-XX-*.js et doit rester charge dans l'ORDRE (01 -> 10), car certaines
// fonctions utilisent des constantes/fonctions definies dans les modules precedents.
// =============================================================================
function setupMRMTImport() {
  const btnLoad  = document.getElementById('mrmt-btn-load');
  const btnClear = document.getElementById('mrmt-btn-clear');
  const input    = document.getElementById('mrmt-file-input');
  const dz       = document.getElementById('mrmt-drop-zone');
  if (!btnLoad || !input) return;
  btnLoad.addEventListener('click', () => input.click());
  input.addEventListener('change', e => mrmtHandleFiles(Array.from(e.target.files)));
  btnClear.addEventListener('click', () => {
    if (!confirm('Effacer toutes les données MPU / TCU ?')) return;
    MRMT_DB.rows = []; MRMT_DB.files = [];
    mrmtUpdateStatus(); renderMRMTPage();
    showToast('🗑️ Données MPU/TCU effacées', '');
  });
  dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('drag-over'); });
  dz.addEventListener('dragleave', () => dz.classList.remove('drag-over'));
  dz.addEventListener('drop', e => { e.preventDefault(); dz.classList.remove('drag-over'); mrmtHandleFiles(Array.from(e.dataTransfer.files)); });
  dz.addEventListener('click', () => input.click());
}

function mrmtHandleFiles(files) {
  if (!files.length) return;
  showLoading();
  let pending = files.length;
  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const text = e.target.result;
        const { idx, rows } = mrmtParseCSV(text);
        if (!rows.length) { showToast(`⚠️ ${file.name} vide ou illisible`, 'warn'); }
        else {
          const src = mrmtDetectSource(file.name, idx, rows);
          const cleaned = rows.map(fields => {
            const g = name => mrmtGet(idx, fields, name);
            const dateStr = g('OccurenceDate') || g('RecordDate');
            return {
              __SRC__: src,
              __FILE__: file.name,
              CodeName: g('CodeName') || '—',
              MaintenanceHelp: g('MaintenanceHelp') || '—',
              DeviceName: g('DeviceName') || '—',
              FunctionName: g('FunctionName') || '—',
              StackName: g('StackName') || '—',
              HintName: g('HintName') || '—',
              SeverityName: g('SeverityName') || '—',
              __DATE__: mrmtParseDate(dateStr),
              __DATESTR__: dateStr || ''
            };
          });
          MRMT_DB.rows = MRMT_DB.rows.concat(cleaned);
          MRMT_DB.files.push(file.name);
          showToast(`✅ ${file.name} — ${cleaned.length} événement(s) ${src !== 'INCONNU' ? src : ''}`, 'success');
        }
      } catch (err) { showToast(`❌ ${file.name} : ${err.message}`, 'error'); }
      pending--;
      if (pending === 0) { hideLoading(); mrmtUpdateStatus(); renderMRMTPage(); }
    };
    reader.readAsText(file, 'UTF-8');
  });
}

function mrmtUpdateStatus() {
  const el = document.getElementById('mrmt-import-status');
  if (el) el.textContent = MRMT_DB.files.length > 0
    ? `${MRMT_DB.files.length} fichier(s) — ${MRMT_DB.rows.length} événement(s) : ${MRMT_DB.files.join(', ')}`
    : '';
}

// =====================================================================
// FILTRES MPU / TCU
// =====================================================================
function mrmtGetFiltered() {
  const fromV  = document.getElementById('mrmt-date-start')?.value;
  const toV    = document.getElementById('mrmt-date-end')?.value;
  const srcF   = document.getElementById('mrmt-source-filter')?.value || 'ALL';
  const devF   = document.getElementById('mrmt-device-filter')?.value || 'ALL';
  const search = (document.getElementById('mrmt-search')?.value || '').trim().toLowerCase();
  return MRMT_DB.rows.filter(r => {
    if (srcF !== 'ALL' && r.__SRC__ !== srcF) return false;
    if (devF !== 'ALL' && r.DeviceName !== devF) return false;
    if (fromV || toV) {
      const dayKey = mrmtDateOnlyKey(r.__DATE__);
      if (!dayKey) return false;
      if (fromV && dayKey < fromV) return false;
      if (toV   && dayKey > toV)   return false;
    }
    if (search) {
      const hay = [r.CodeName, r.MaintenanceHelp, r.DeviceName, r.FunctionName, r.StackName, r.HintName, r.SeverityName].join(' ').toLowerCase();
      if (!hay.includes(search)) return false;
    }
    return true;
  });
}

// =====================================================================
// RENDU PAGE MPU / TCU
// =====================================================================
let mrmtChartFunction = null, mrmtChartTimeline = null, mrmtChartPie = null, mrmtChartDevice = null;
const MRMT_TABLE_PAGE = 25;
let mrmtShowAllMPU = false, mrmtShowAllTCU = false;

// Mots-clés de criticité : cherchés dans SeverityName (TCU) et
// MaintenanceHelp / StackName (MPU) faute de colonne de sévérité côté MPU.
const MRMT_CRIT_KEYWORDS = ['critique', 'grave', 'urgence', 'freinage', 'sécurité', 'securite', 'danger', 'majeur'];
function mrmtIsCritical(r) {
  const hay = [r.SeverityName, r.MaintenanceHelp, r.StackName].join(' ').toLowerCase();
  return MRMT_CRIT_KEYWORDS.some(k => hay.includes(k));
}

function mrmtCountBy(rows, keyFn) {
  const m = new Map();
  for (const r of rows) {
    const k = keyFn(r) || '—';
    m.set(k, (m.get(k) || 0) + 1);
  }
  return [...m.entries()].sort((a, b) => b[1] - a[1]);
}

function mrmtPopulateDeviceFilter() {
  const sel = document.getElementById('mrmt-device-filter');
  if (!sel) return;
  const current = sel.value || 'ALL';
  const devices = [...new Set(MRMT_DB.rows.map(r => r.DeviceName).filter(Boolean))].sort();
  sel.innerHTML = '<option value="ALL">Toutes les unités</option>' +
    devices.map(d => `<option value="${mrmtEsc(d)}">${mrmtEsc(d)}</option>`).join('');
  if (devices.includes(current)) sel.value = current;
}

// ── Corrélation temporelle MPU ↔ TCU (fenêtre ±5 min) ──
// Rapproche chaque événement critique MPU des événements TCU survenus
// dans la même fenêtre de temps (et inversement), piste de cause commune.
function mrmtComputeCorrelation(fdMPU, fdTCU, windowMinutes = 5) {
  const windowMs = windowMinutes * 60 * 1000;
  const critMPU = fdMPU.filter(r => r.__DATE__ && mrmtIsCritical(r));
  const matches = [];
  for (const a of critMPU) {
    for (const b of fdTCU) {
      if (!b.__DATE__) continue;
      const delta = b.__DATE__ - a.__DATE__;
      if (Math.abs(delta) <= windowMs) matches.push({ a, b, delta: delta / 1000 });
    }
  }
  matches.sort((x, y) => x.a.__DATE__ - y.a.__DATE__);
  return { critCount: critMPU.length, matches };
}

function mrmtUpdateDateLabel() {
  const s = document.getElementById('mrmt-date-start')?.value;
  const e = document.getElementById('mrmt-date-end')?.value;
  const el = document.getElementById('mrmt-date-range-label');
  if (!el) return;
  if (!s && !e) { el.textContent = 'Toute la période'; return; }
  const days = (s && e) ? Math.max(1, Math.round((new Date(e) - new Date(s)) / 86400000) + 1) : null;
  el.textContent = days ? `${days} jour(s)` : '—';
}

function renderMRMTPage() {
  const hasData = MRMT_DB.rows.length > 0;
  const importZone = document.getElementById('mrmt-import-zone');
  const filterBar   = document.getElementById('mrmt-filter-bar');
  const kpiRow      = document.getElementById('mrmt-kpi-row');
  if (importZone) importZone.style.display = hasData ? 'none' : '';
  if (filterBar)  filterBar.style.display  = hasData ? 'flex' : 'none';
  if (kpiRow)     kpiRow.style.display     = hasData ? '' : 'none';

  if (!hasData) {
    const content = document.getElementById('mrmt-content');
    if (content) content.innerHTML = '';
    return;
  }

  mrmtUpdateDateLabel();
  mrmtPopulateDeviceFilter();
  const fd = mrmtGetFiltered();
  const fdMPU = fd.filter(r => r.__SRC__ === 'MPU');
  const fdTCU = fd.filter(r => r.__SRC__ === 'TCU');

  // ── KPIs ──
  document.getElementById('mrmt-kpi-total').textContent = fd.length;
  document.getElementById('mrmt-kpi-mpu').textContent   = fdMPU.length;
  document.getElementById('mrmt-kpi-tcu').textContent   = fdTCU.length;
  document.getElementById('mrmt-kpi-mpu-sub').textContent = fd.length ? Math.round(fdMPU.length / fd.length * 100) + '% du total' : '—';
  document.getElementById('mrmt-kpi-tcu-sub').textContent = fd.length ? Math.round(fdTCU.length / fd.length * 100) + '% du total' : '—';
  const critCountKpi = fd.filter(mrmtIsCritical).length;
  document.getElementById('mrmt-kpi-crit').textContent = critCountKpi;

  // ── Comparaison par FunctionName (axe commun aux deux sources) ──
  // Normalisation (trim + majuscules) pour rapprocher "System" et "SYSTEM"
  // qui désignent la même fonction mais sont orthographiés différemment
  // selon le calculateur (MPU / TCU) source.
  const mrmtNormFn = s => String(s || '—').trim().toUpperCase();
  const fnMPU = {}, fnTCU = {}, fnLabel = {};
  fdMPU.forEach(r => { const k = mrmtNormFn(r.FunctionName); fnMPU[k] = (fnMPU[k] || 0) + 1; if (!fnLabel[k]) fnLabel[k] = r.FunctionName || '—'; });
  fdTCU.forEach(r => { const k = mrmtNormFn(r.FunctionName); fnTCU[k] = (fnTCU[k] || 0) + 1; if (!fnLabel[k]) fnLabel[k] = r.FunctionName || '—'; });
  const allFn = new Set([...Object.keys(fnMPU), ...Object.keys(fnTCU)]);
  const fnRows = [...allFn].map(k => ({
    fn: fnLabel[k], mpu: fnMPU[k] || 0, tcu: fnTCU[k] || 0, total: (fnMPU[k] || 0) + (fnTCU[k] || 0)
  })).sort((a, b) => b.total - a.total);
  const commonFn = fnRows.filter(r => r.mpu > 0 && r.tcu > 0);
  document.getElementById('mrmt-kpi-common').textContent = commonFn.length;

  // ── Code le plus fréquent (toutes sources confondues) ──
  const codeMap = {};
  fd.forEach(r => { const k = `${r.__SRC__} · ${r.CodeName}`; codeMap[k] = (codeMap[k] || 0) + 1; });
  const topCode = Object.entries(codeMap).sort((a, b) => b[1] - a[1])[0];
  document.getElementById('mrmt-kpi-top-code').textContent = topCode ? topCode[0] : '—';
  document.getElementById('mrmt-kpi-top-code-sub').textContent = topCode ? topCode[1] + ' occurrence(s)' : '—';

  // ── Timeline par jour ──
  const dayMPU = {}, dayTCU = {};
  fdMPU.forEach(r => { const k = mrmtDateOnlyKey(r.__DATE__); if (k) dayMPU[k] = (dayMPU[k] || 0) + 1; });
  fdTCU.forEach(r => { const k = mrmtDateOnlyKey(r.__DATE__); if (k) dayTCU[k] = (dayTCU[k] || 0) + 1; });
  const allDays = [...new Set([...Object.keys(dayMPU), ...Object.keys(dayTCU)])].sort();

  // ── Répartition par unité (DeviceName) ──
  const deviceStats = [
    ...mrmtCountBy(fdMPU, r => r.DeviceName).map(([name, count]) => ({ name, count, src: 'MPU' })),
    ...mrmtCountBy(fdTCU, r => r.DeviceName).map(([name, count]) => ({ name, count, src: 'TCU' }))
  ];

  // ── Top codes (CodeName) par source ──
  const topCodesMPU = mrmtCountBy(fdMPU, r => r.CodeName).slice(0, 10);
  const topCodesTCU = mrmtCountBy(fdTCU, r => r.CodeName).slice(0, 10);

  // ── Événements critiques ──
  const critItems = [];
  [{ rows: fdMPU, src: 'MPU' }, { rows: fdTCU, src: 'TCU' }].forEach(({ rows, src }) => {
    const crit = rows.filter(mrmtIsCritical);
    mrmtCountBy(crit, r => r.CodeName).forEach(([code, count]) => {
      const dates = crit.filter(r => r.CodeName === code).map(r => r.__DATE__).filter(Boolean);
      critItems.push({ src, code, count, last: dates.length ? new Date(Math.max(...dates)) : null });
    });
  });
  critItems.sort((a, b) => b.count - a.count);

  // ── Corrélation temporelle MPU ↔ TCU (±5 min) ──
  const correlation = mrmtComputeCorrelation(fdMPU, fdTCU);

  mrmtRenderCharts(fnRows, allDays, dayMPU, dayTCU, fdMPU.length, fdTCU.length, deviceStats);
  mrmtRenderContent(commonFn, fdMPU, fdTCU, topCodesMPU, topCodesTCU, critItems, correlation);
}

function mrmtRenderCharts(fnRows, allDays, dayMPU, dayTCU, totalMPU, totalTCU, deviceStats) {
  const top = fnRows.slice(0, 8);
  const ctxFn = document.getElementById('mrmt-chart-function');
  if (ctxFn) {
    if (mrmtChartFunction) mrmtChartFunction.destroy();
    mrmtChartFunction = new Chart(ctxFn, {
      type: 'bar',
      data: {
        labels: top.map(r => r.fn),
        datasets: [
          { label: 'MPU', data: top.map(r => r.mpu), backgroundColor: MRMT_SRC_COLORS.MPU },
          { label: 'TCU', data: top.map(r => r.tcu), backgroundColor: MRMT_SRC_COLORS.TCU }
        ]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom' } },
        scales: { x: { ticks: { autoSkip: false, maxRotation: 35, minRotation: 0 } }, y: { beginAtZero: true } }
      }
    });
  }

  const ctxTl = document.getElementById('mrmt-chart-timeline');
  if (ctxTl) {
    if (mrmtChartTimeline) mrmtChartTimeline.destroy();
    mrmtChartTimeline = new Chart(ctxTl, {
      type: 'line',
      data: {
        labels: allDays,
        datasets: [
          { label: 'MPU', data: allDays.map(d => dayMPU[d] || 0), borderColor: MRMT_SRC_COLORS.MPU, backgroundColor: MRMT_SRC_COLORS.MPU, tension: .25 },
          { label: 'TCU', data: allDays.map(d => dayTCU[d] || 0), borderColor: MRMT_SRC_COLORS.TCU, backgroundColor: MRMT_SRC_COLORS.TCU, tension: .25 }
        ]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } }, scales: { y: { beginAtZero: true } } }
    });
  }

  const ctxPie = document.getElementById('mrmt-chart-pie');
  if (ctxPie) {
    if (mrmtChartPie) mrmtChartPie.destroy();
    mrmtChartPie = new Chart(ctxPie, {
      type: 'doughnut',
      data: { labels: ['MPU', 'TCU'], datasets: [{ data: [totalMPU, totalTCU], backgroundColor: [MRMT_SRC_COLORS.MPU, MRMT_SRC_COLORS.TCU] }] },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
    });
  }

  const ctxDev = document.getElementById('mrmt-chart-device');
  if (ctxDev && deviceStats) {
    if (mrmtChartDevice) mrmtChartDevice.destroy();
    mrmtChartDevice = new Chart(ctxDev, {
      type: 'bar',
      data: {
        labels: deviceStats.map(d => d.name),
        datasets: [{
          data: deviceStats.map(d => d.count),
          backgroundColor: deviceStats.map(d => MRMT_SRC_COLORS[d.src]),
          borderRadius: 4, maxBarThickness: 40
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { x: { ticks: { autoSkip: false, maxRotation: 40, minRotation: 0 } }, y: { beginAtZero: true } }
      }
    });
  }
}

function mrmtEsc(s) {
  return String(s == null ? '' : s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
}
function mrmtFmtDate(d) {
  if (!d) return '—';
  const p = n => String(n).padStart(2, '0');
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

function mrmtBarList(topEntries, color) {
  if (!topEntries.length) return `<div style="text-align:center;padding:20px;color:#9aa5bb;font-size:12px">Aucune donnée</div>`;
  const max = topEntries[0][1] || 1;
  return topEntries.map(([name, count]) => `
    <div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;gap:8px;font-size:12px;margin-bottom:4px">
        <span style="font-weight:600;color:#1a2744;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${mrmtEsc(name)}">${mrmtEsc(name)}</span>
        <span style="font-family:'Montserrat',monospace;color:#6b7fa8">${count}</span>
      </div>
      <div style="height:6px;border-radius:4px;background:#eef2fb;overflow:hidden">
        <div style="height:100%;border-radius:4px;width:${(count / max * 100).toFixed(1)}%;background:${color}"></div>
      </div>
    </div>`).join('');
}

function mrmtRenderContent(commonFn, fdMPU, fdTCU, topCodesMPU, topCodesTCU, critItems, correlation) {
  const el = document.getElementById('mrmt-content');
  if (!el) return;

  const critRows = critItems.length
    ? critItems.map(it => `
      <div style="border:1px solid #fbd7d7;background:linear-gradient(90deg,#fdeeee,transparent 65%);border-radius:10px;padding:10px 14px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;gap:12px">
        <div>
          <div style="font-size:13px;font-weight:700;color:#1a2744">${mrmtEsc(it.code)}</div>
          <div style="font-family:'Montserrat',monospace;font-size:11px;color:#6b7fa8">${it.src}${it.last ? ' · dernier : ' + mrmtFmtDate(it.last) : ''}</div>
        </div>
        <div style="font-size:19px;font-weight:800;color:#dc2626">${it.count}</div>
      </div>`).join('')
    : `<div style="text-align:center;padding:20px;color:#9aa5bb;font-size:12px">Aucun événement critique détecté (SeverityName / mots-clés freinage, urgence, sécurité).</div>`;

  let corrHtml;
  if (!fdMPU.length || !fdTCU.length) {
    corrHtml = `<div style="text-align:center;padding:20px;color:#9aa5bb;font-size:12px">Chargez à la fois des événements MPU et TCU pour activer la corrélation.</div>`;
  } else if (!correlation.matches.length) {
    corrHtml = `<div style="text-align:center;padding:20px;color:#9aa5bb;font-size:12px">${correlation.critCount} événement(s) critique(s) MPU détecté(s), aucune correspondance TCU dans une fenêtre de ±5 min.</div>`;
  } else {
    const summary = mrmtCountBy(correlation.matches, m => m.b.CodeName).slice(0, 5);
    const rows = correlation.matches.slice(0, 200).map(m => `
      <tr>
        <td style="padding:7px 10px;font-size:12px">${mrmtFmtDate(m.a.__DATE__)}<br><span style="color:${MRMT_SRC_COLORS.MPU};font-weight:600">${mrmtEsc(m.a.CodeName)}</span></td>
        <td style="padding:7px 10px;font-size:12px;color:${MRMT_SRC_COLORS.TCU};font-weight:600">${mrmtEsc(m.b.CodeName)}</td>
        <td style="padding:7px 10px;font-size:12px">${mrmtEsc(m.b.DeviceName)}</td>
        <td style="padding:7px 10px;font-size:12px;color:${m.delta < 0 ? '#ea580c' : '#2f6690'}">${m.delta > 0 ? '+' : ''}${m.delta.toFixed(0)}s</td>
      </tr>`).join('');
    corrHtml = `
      <div style="font-size:12px;color:var(--text3);margin-bottom:12px">
        ${correlation.matches.length} correspondance(s) trouvée(s) autour de ${correlation.critCount} événement(s) critique(s) MPU.
        Codes TCU les plus fréquemment associés : ${summary.map(([n, c]) => `<b style="color:#1a2744">${mrmtEsc(n)}</b> (${c}×)`).join(', ')}.
      </div>
      <div style="overflow-x:auto;max-height:300px;overflow-y:auto">
        <table style="width:100%;border-collapse:collapse">
          <thead style="position:sticky;top:0;background:#fff"><tr>
            <th style="text-align:left;padding:8px 10px;font-size:11px;font-weight:700;color:#5a6e96;border-bottom:2px solid var(--border)">Critique MPU (Code)</th>
            <th style="text-align:left;padding:8px 10px;font-size:11px;font-weight:700;color:#5a6e96;border-bottom:2px solid var(--border)">Code TCU</th>
            <th style="text-align:left;padding:8px 10px;font-size:11px;font-weight:700;color:#5a6e96;border-bottom:2px solid var(--border)">Unité TCU</th>
            <th style="text-align:left;padding:8px 10px;font-size:11px;font-weight:700;color:#5a6e96;border-bottom:2px solid var(--border)">Écart</th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>`;
  }

  const commonRows = commonFn.length
    ? commonFn.map(r => `<tr>
        <td style="padding:7px 10px;font-size:12px;font-weight:600">${mrmtEsc(r.fn)}</td>
        <td style="text-align:center;padding:6px 8px"><span style="display:inline-block;min-width:26px;padding:2px 6px;border-radius:5px;background:#eaf2fb;color:${MRMT_SRC_COLORS.MPU};font-weight:700">${r.mpu}</span></td>
        <td style="text-align:center;padding:6px 8px"><span style="display:inline-block;min-width:26px;padding:2px 6px;border-radius:5px;background:#fde8e8;color:${MRMT_SRC_COLORS.TCU};font-weight:700">${r.tcu}</span></td>
        <td style="text-align:center;padding:6px 8px;font-weight:800;color:#1a2744">${r.total}</td>
      </tr>`).join('')
    : `<tr><td colspan="4" style="text-align:center;padding:14px;color:#9aa5bb;font-size:12px">Aucune fonction commune détectée sur la période / le filtre actuel</td></tr>`;

  el.innerHTML = `
    <div class="grid-2" style="margin-bottom:14px">
      <div class="card">
        <div class="card-title">📊 Comparaison par Fonction (FunctionName) — Top 8</div>
        <div class="chart-wrap tall"><canvas id="mrmt-chart-function"></canvas></div>
      </div>
      <div class="card">
        <div class="card-title">📈 Évolution quotidienne — MPU vs TCU</div>
        <div class="chart-wrap tall"><canvas id="mrmt-chart-timeline"></canvas></div>
      </div>
    </div>

    <div class="grid-2" style="margin-bottom:14px">
      <div class="card">
        <div class="card-title">🥧 Répartition globale MPU / TCU</div>
        <div class="chart-wrap"><canvas id="mrmt-chart-pie"></canvas></div>
      </div>
      <div class="card">
        <div class="card-title" style="color:#dc2626">🌐 Fonctions communes MPU &amp; TCU</div>
        <p style="font-size:11px;color:var(--text3);margin-bottom:10px">Fonctions (FunctionName) présentant des occurrences à la fois côté MPU et côté TCU — piste de défaut transverse</p>
        <div style="overflow-x:auto;max-height:280px;overflow-y:auto">
          <table style="width:100%;border-collapse:collapse;font-size:12px">
            <thead>
              <tr>
                <th style="text-align:left;padding:8px 10px;font-size:11px;font-weight:700;color:#5a6e96;border-bottom:2px solid var(--border)">Fonction</th>
                <th style="text-align:center;padding:8px 10px;font-size:10px;font-weight:700;color:${MRMT_SRC_COLORS.MPU};border-bottom:2px solid var(--border)">MPU</th>
                <th style="text-align:center;padding:8px 10px;font-size:10px;font-weight:700;color:${MRMT_SRC_COLORS.TCU};border-bottom:2px solid var(--border)">TCU</th>
                <th style="text-align:center;padding:8px 10px;font-size:10px;font-weight:700;color:#5a6e96;border-bottom:2px solid var(--border)">Total</th>
              </tr>
            </thead>
            <tbody>${commonRows}</tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="grid-2" style="margin-bottom:14px">
      <div class="card">
        <div class="card-title" style="color:${MRMT_SRC_COLORS.MPU}">🏆 Top codes événements — MPU</div>
        ${mrmtBarList(topCodesMPU, MRMT_SRC_COLORS.MPU)}
      </div>
      <div class="card">
        <div class="card-title" style="color:${MRMT_SRC_COLORS.TCU}">🏆 Top codes événements — TCU</div>
        ${mrmtBarList(topCodesTCU, MRMT_SRC_COLORS.TCU)}
      </div>
    </div>

    <div class="card" style="margin-bottom:14px">
      <div class="card-title">📍 Répartition par unité (DeviceName)</div>
      <div class="chart-wrap tall"><canvas id="mrmt-chart-device"></canvas></div>
    </div>

    <div class="card" style="margin-bottom:14px">
      <div class="card-title" style="color:#dc2626">🚨 Événements critiques (SeverityName / freinage / urgence / sécurité)</div>
      ${critRows}
    </div>

    <div class="card" style="margin-bottom:14px">
      <div class="card-title">🔗 Corrélation temporelle MPU ↔ TCU <span style="font-family:'Montserrat',monospace;font-size:11px;font-weight:400;color:#6b7fa8">(fenêtre ±5 min)</span></div>
      ${corrHtml}
    </div>

    <div class="card" style="margin-bottom:14px">
      <div class="card-title" style="color:${MRMT_SRC_COLORS.MPU}">🔧 Détail des événements MPU (${fdMPU.length})</div>
      <div id="mrmt-table-mpu"></div>
    </div>

    <div class="card">
      <div class="card-title" style="color:${MRMT_SRC_COLORS.TCU}">🔧 Détail des événements TCU (${fdTCU.length})</div>
      <div id="mrmt-table-tcu"></div>
    </div>
  `;

  mrmtRenderTable('mrmt-table-mpu', fdMPU, MRMT_COLUMNS.MPU, 'MPU');
  mrmtRenderTable('mrmt-table-tcu', fdTCU, MRMT_COLUMNS.TCU, 'TCU');
}

function mrmtRenderTable(containerId, rows, columns, src) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const showAll = src === 'MPU' ? mrmtShowAllMPU : mrmtShowAllTCU;
  const sorted = [...rows].sort((a, b) => (b.__DATE__ || 0) - (a.__DATE__ || 0));
  const display = showAll ? sorted : sorted.slice(0, MRMT_TABLE_PAGE);

  if (!rows.length) {
    el.innerHTML = `<div style="text-align:center;padding:14px;color:#9aa5bb;font-size:12px">Aucun événement ${src} sur la période / le filtre actuel</div>`;
    return;
  }

  const head = ['Date', ...columns].map(c => `<th style="text-align:left;padding:8px 10px;font-size:11px;font-weight:700;color:#5a6e96;border-bottom:2px solid var(--border);white-space:nowrap">${c === 'Date' ? 'Date' : c}</th>`).join('');
  const body = display.map(r => {
    const cells = columns.map(c => `<td style="padding:6px 10px;font-size:12px;max-width:260px;white-space:normal">${mrmtEsc(r[c])}</td>`).join('');
    return `<tr>
      <td style="padding:6px 10px;font-size:11.5px;white-space:nowrap;color:var(--text2)">${mrmtFmtDate(r.__DATE__)}</td>
      ${cells}
    </tr>`;
  }).join('');

  el.innerHTML = `
    <div style="overflow-x:auto;max-height:420px;overflow-y:auto">
      <table style="width:100%;border-collapse:collapse">
        <thead style="position:sticky;top:0;background:#fff;z-index:1"><tr>${head}</tr></thead>
        <tbody>${body}</tbody>
      </table>
    </div>
    ${rows.length > MRMT_TABLE_PAGE ? `
      <div style="text-align:center;margin-top:10px">
        <button class="btn btn-ghost btn-sm" onclick="mrmt${src === 'MPU' ? 'ShowAllMPU' : 'ShowAllTCU'} = !mrmt${src === 'MPU' ? 'ShowAllMPU' : 'ShowAllTCU'}; renderMRMTPage();">
          ${showAll ? '▲ Réduire' : `▼ Afficher les ${rows.length} événements`}
        </button>
      </div>` : ''}
  `;
}

// ── Recupere le sous-systeme depuis une ligne ──────────────────────────
function rhGetSousSysteme(row) {
  const explicit = (
    row['SYSTEME'] || row['Sous-systeme'] ||
    row['SOUS_SYSTEME'] || row['sous_systeme'] || ''
  ).trim();
  if (explicit) return explicit;
  const code = (
    row['CODE_EQUIPEMENT'] || row['EQUIPEMENT'] ||
    row['code_equipement'] || ''
  ).trim();
  if (code) return parseCodeEquipement(code).sousSysteme;
  return '— N/A —';
}

// ── Recupere le systeme (niveau 1) depuis une ligne ────────────────────
function rhGetSysteme(row) {
  const code = (
    row['CODE_EQUIPEMENT'] || row['EQUIPEMENT'] ||
    row['code_equipement'] || ''
  ).trim();
  if (code) return parseCodeEquipement(code).systeme;
  return '— N/A —';
}

// ══════════════════════════════════════════════════════════════════════
// MODIF 2 : rhFilterByDate + calcRHEfficienceUnit avec filtre systeme
// ══════════════════════════════════════════════════════════════════════


function rhFilterByDate(rows, start, end) {
  const DATE_CANDIDATES = [
    'DATE_CREATION','date_creation','Date_Creation',
    'DATE_DI','DATE_PREVUE','DATE_DEB_INTERVENTION',
    'DATE_EVENEMENT','DATE_CLOTURE','Date','DATE',
    'DATE_DEBUT_PREVU','DATE_DEBUT_PREVUE'
  ];
  // Si pas de filtre défini, tout retourner
  const noFilter = !start && !end;
  return rows.filter(row => {
    if (noFilter) return true;
    for (const f of DATE_CANDIDATES) {
      const v = row[f];
      if (v && String(v).trim() !== '') {
        const d = parseDate(v);
        if (d) {
          if (start && end) return d >= start && d <= end;
          if (start)        return d >= start;
          if (end)          return d <= end;
        }
      }
    }
    // Aucune date trouvée dans la ligne → exclure si filtre actif
    return false;
  });
  
}
const filterByDateRH = rhFilterByDate;

function getRHFilters() {
  const rhStart = document.getElementById('rh-date-start')?.value;
  const rhEnd   = document.getElementById('rh-date-end')?.value;
  const { systeme } = getFilters();

  let start, end;
  if (rhStart && rhStart.trim() !== '') {
    start = new Date(rhStart + 'T00:00:00');
  } else {
    // fallback : date min trouvée dans les données RH
    let minDate = null;
    UNITS.forEach(u => {
      [...(RH_DB.corrRows[u]||[]), ...(RH_DB.prevRows[u]||[])].forEach(row => {
        const DATE_CANDIDATES = ['DATE_CREATION','DATE_DI','DATE_PREVUE','DATE_DEB_INTERVENTION','DATE_EVENEMENT','DATE_CLOTURE','Date','DATE'];
        for (const f of DATE_CANDIDATES) {
          if (row[f] && String(row[f]).trim() !== '') {
            const d = parseDate(row[f]);
            if (d && (!minDate || d < minDate)) minDate = d;
            break;
          }
        }
      });
    });
    start = minDate || new Date(2000, 0, 1);
  }

  if (rhEnd && rhEnd.trim() !== '') {
    end = new Date(rhEnd + 'T23:59:59');
  } else {
    // fallback : date max trouvée dans les données RH
    let maxDate = null;
    UNITS.forEach(u => {
      [...(RH_DB.corrRows[u]||[]), ...(RH_DB.prevRows[u]||[])].forEach(row => {
        const DATE_CANDIDATES = ['DATE_CREATION','DATE_DI','DATE_PREVUE','DATE_DEB_INTERVENTION','DATE_EVENEMENT','DATE_CLOTURE','Date','DATE'];
        for (const f of DATE_CANDIDATES) {
          if (row[f] && String(row[f]).trim() !== '') {
            const d = parseDate(row[f]);
            if (d && (!maxDate || d > maxDate)) maxDate = d;
            break;
          }
        }
      });
    });
    end = maxDate || new Date(2099, 11, 31);
  }

  const selUnit = document.getElementById('rh-sel-unit')?.value || 'all';
  return { start, end, systeme, selUnit };
}

function calcRHEfficienceUnit(unit) {
  const { start, end, systeme } = getRHFilters();
  const normeSaisie = parseFloat(document.getElementById('rh-norme').value) || RH_NORME_DEFAULT;
  const norme = rhNormeProratee(normeSaisie, start, end);

  let corrRows = rhFilterByDate(RH_DB.corrRows[unit]||[], start, end);
  let prevRows = rhFilterByDate(RH_DB.prevRows[unit]||[], start, end);

  // Filtre systeme
  if (systeme && systeme !== 'all') {
    const sysFilter = r => {
      const parsed = parseCodeEquipement(r['CODE_EQUIPEMENT']||r['EQUIPEMENT']||'');
      return parsed.systeme === systeme || parsed.sousSysteme === systeme ||
             (r['SYSTEME']||'').trim() === systeme;
    };
    corrRows = corrRows.filter(sysFilter);
    prevRows = prevRows.filter(sysFilter);
  }

  const allRows = [...corrRows, ...prevRows];
  
  if (allRows.length === 0) return null;

  const techMap = {};
  allRows.forEach(row => {
    const tech   = rhGetTech(row);
    const heures = rhParseHours(row);
    if (!techMap[tech]) techMap[tech] = { technicien:tech, unite:unit, chargeReelle:0, nbInterventions:0 };
    techMap[tech].chargeReelle    += heures;
    techMap[tech].nbInterventions += 1;
  });

  const techList = Object.values(techMap).map(t => {
    const tauxOccupation = norme > 0 ? t.chargeReelle / norme : 0;
    const delta  = t.chargeReelle - norme;
    const statut = tauxOccupation > 1.05 ? 'surcharge' : tauxOccupation < 0.75 ? 'sous-charge' : 'equilibre';
    return { ...t, norme, tauxOccupation, tauxOccupationPct: tauxOccupation*100, delta, statut };
  });

  const chargeReelleTotale   = techList.reduce((s,t) => s + t.chargeReelle, 0);
  const nbTech               = techList.length;
  const besoinTheorique      = norme > 0 ? chargeReelleTotale / norme : 0;
  const besoinEssentiel      = norme > 0 ? Math.ceil(chargeReelleTotale / norme) : 0;
  const deltaUnite           = besoinEssentiel - nbTech;
  const tauxMoyenOccupation  = nbTech > 0 ? chargeReelleTotale / (nbTech * norme) : 0;

  return {
    unit, techList: techList.sort((a,b) => b.tauxOccupation - a.tauxOccupation),
    norme, chargeReelleTotale, nbTech, besoinTheorique, besoinEssentiel,
    deltaUnite, tauxMoyenOccupation,
    nbSurcharge:  techList.filter(t => t.statut==='surcharge').length,
    nbSousCharge: techList.filter(t => t.statut==='sous-charge').length,
    nbEquilibre:  techList.filter(t => t.statut==='equilibre').length,
    totalHeures: chargeReelleTotale
  };
}

// ── Build cartes unites RH ─────────────────────────────────────────────
function buildRHUnitCards() {
  const grid   = document.getElementById('rh-unit-cards');
  const hidden = document.getElementById('rh-hidden-inputs');
  if (!grid || !hidden) return;
  grid.innerHTML   = '';
  hidden.innerHTML = '';

  UNITS.forEach(u => {
    const uL   = u.toLowerCase();
    const card = document.createElement('div');
    card.className = 'rh-unit-import-card';
    card.id = `rh-card-${u}`;
    card.innerHTML = `
      <div class="rh-unit-name u-${uL}">${u}</div>
      <div style="font-size:10px;color:var(--text3);margin-bottom:6px">
        Corr: <span id="rh-cnt-corr-${u}">0</span> ·
        Prev: <span id="rh-cnt-prev-${u}">0</span>
      </div>
      <div class="rh-import-slot" id="rh-slot-${u}" style="cursor:default;pointer-events:none">
        <span class="slot-icon" id="rh-slot-icon-${u}">⏳</span>
        <span class="slot-label" id="rh-slot-lbl-${u}">En attente</span>
      </div>
      <div class="rh-card-actions">
        <button class="btn-analyse" id="rh-btn-analyse-${u}"
                onclick="renderRHUnitResult('${u}')" disabled>
          ⚡ Analyser
        </button>
        <button class="btn-ai" id="rh-btn-ai-${u}"
                onclick="launchRHAIUnit('${u}')" disabled>
          🤖 IA
        </button>
      </div>`;
    grid.appendChild(card);

    ['corr','prev'].forEach(t => {
      const inp = document.createElement('input');
      inp.type    = 'file'; inp.accept = '.xlsx,.xls,.csv,.xlsm';
      inp.id      = `rh-file-${t}-${u}`;
      inp.style.display = 'none';
      inp.addEventListener('change', e => { if (e.target.files[0]) handleRHFileUnit(e.target.files[0], t, u); });
      hidden.appendChild(inp);
    });
  });
}

function triggerRHBulkLoad() {
  document.getElementById('rh-file-bulk').click();
}

function handleRHBulkLoad(files) {
  if (!files || files.length === 0) return;
  showLoading();
  let pending = files.length;

  Array.from(files).forEach(file => {
    const name = file.name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    let detectedUnit = null;
    for (const u of UNITS) { if (name.includes(u.toLowerCase())) { detectedUnit = u; break; } }
    const isC = /corret|correctif|corrective/.test(name);
    const isP = /preventif|preventive|prev/.test(name);
    const detectedType = isC && !isP ? 'corr' : isP ? 'prev' : null;

    if (detectedUnit && detectedType) {
      readRHFile(file, detectedType, detectedUnit, () => { pending--; if (pending === 0) { hideLoading(); finalizeRHBulkLoad(); } });
    } else {
      pending--;
      showToast(`⚠️ ${file.name} non reconnu — import ignore`, 'warn');
      if (pending === 0) { hideLoading(); finalizeRHBulkLoad(); }
    }
  });
}

function readRHFile(file, type, unit, onDone) {
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const wb  = XLSX.read(e.target.result, { type:'binary', cellDates:false });
      const ws  = wb.Sheets[wb.SheetNames[0]];
      const raw = XLSX.utils.sheet_to_json(ws, { raw:false, defval:'', dateNF:'DD/MM/YYYY' });
      if (raw.length === 0) { onDone(); return; }
      const cleaned = raw.map(row => {
        const nr = {};
        Object.keys(row).forEach(k => {
          const ck = k.trim().replace(/\s+/g,' ').normalize('NFC');

          nr[ck] = typeof row[k] === 'string' ? row[k].trim() : row[k];
        });
        nr.__UNIT__ = unit; return nr;
      });
      if (type === 'corr') { RH_DB.corrRows[unit]  = (RH_DB.corrRows[unit]||[]).concat(cleaned); RH_DB.loadedCorr[unit] = file.name; }
      else                 { RH_DB.prevRows[unit]  = (RH_DB.prevRows[unit]||[]).concat(cleaned); RH_DB.loadedPrev[unit] = file.name; }
      updateRHCardStatus(unit);
    } catch (err) { console.error(err); showToast(`❌ ${file.name} : ${err.message}`, 'error'); }
    onDone();
  };
  reader.readAsBinaryString(file);
}

function updateRHCardStatus(unit) {
  const cntC  = (RH_DB.corrRows[unit] || []).length;
  const cntP  = (RH_DB.prevRows[unit] || []).length;
  const total = cntC + cntP;
  const elC   = document.getElementById(`rh-cnt-corr-${unit}`);
  const elP   = document.getElementById(`rh-cnt-prev-${unit}`);
  const slot  = document.getElementById(`rh-slot-${unit}`);
  const icon  = document.getElementById(`rh-slot-icon-${unit}`);
  const lbl   = document.getElementById(`rh-slot-lbl-${unit}`);
  const btnA  = document.getElementById(`rh-btn-analyse-${unit}`);
  const btnAI = document.getElementById(`rh-btn-ai-${unit}`);
  if (elC)  elC.textContent  = cntC;
  if (elP)  elP.textContent  = cntP;
  if (total > 0) {
    if (slot) slot.classList.add('loaded');
    if (icon) icon.textContent = '✅';
    if (lbl)  lbl.textContent  = `${total} lignes`;
    if (btnA)  btnA.disabled   = false;
    if (btnAI) btnAI.disabled  = false;
  }
}

function finalizeRHBulkLoad() {
  const loaded = UNITS.filter(u => (RH_DB.corrRows[u]||[]).length + (RH_DB.prevRows[u]||[]).length > 0);
  if (loaded.length === 0) { showToast('⚠️ Aucun fichier reconnu', 'warn'); return; }
  const btn = document.getElementById('rh-btn-analyse-all'); if (btn) btn.style.display = '';
  const badge = document.getElementById('badge-rh'); if (badge) badge.style.display = '';
  // Auto-remplir les dates RH depuis les données
  let minDate = null, maxDate = null;
  UNITS.forEach(u => {
    [...(RH_DB.corrRows[u]||[]), ...(RH_DB.prevRows[u]||[])].forEach(row => {
      const DATE_CANDIDATES = ['DATE_CREATION','DATE_DI','DATE_PREVUE','DATE_DEB_INTERVENTION','DATE_EVENEMENT','DATE_CLOTURE','Date','DATE'];
      for (const f of DATE_CANDIDATES) {
        if (row[f] && String(row[f]).trim() !== '') {
          const d = parseDate(row[f]);
          if (d) {
            if (!minDate || d < minDate) minDate = d;
            if (!maxDate || d > maxDate) maxDate = d;
          }
          break;
        }
      }
    });
  });
  const rhS = document.getElementById('rh-date-start');
  const rhE = document.getElementById('rh-date-end');
  if (minDate && rhS && !rhS.value) rhS.value = fmtDateInput(minDate);
  if (maxDate && rhE && !rhE.value) rhE.value = fmtDateInput(maxDate);

  showToast(
    `✅ ${loaded.length} unite(s) chargee(s) — ${UNITS.reduce((s,u)=>s+(RH_DB.corrRows[u]||[]).length+(RH_DB.prevRows[u]||[]).length,0)} lignes`,
    'success'
  );
  renderRHPage();
}

