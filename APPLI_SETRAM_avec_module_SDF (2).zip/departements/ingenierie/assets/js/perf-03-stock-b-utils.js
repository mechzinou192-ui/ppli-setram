// =============================================================================
// SUIVI DES PERFORMANCES — module 03/10 : perf-03-stock-b-utils.js
// Extrait mecaniquement (meme code, meme ordre) du script principal historique
// pour ameliorer la maintenabilite (le fichier faisait ~8300 lignes en un bloc).
// Contenu : Gestion de Stock (2/3) : approvisionnement + exports Excel - Utilitaires globaux transverses : parseDate, filterByDate/System/Equipement, normState/isTraitee/isRealisee..., calcKPIs, module export XLSX charte SETRAM
// IMPORTANT : ce fichier partage la portee globale avec les autres modules
// perf-XX-*.js et doit rester charge dans l'ORDRE (01 -> 10), car certaines
// fonctions utilisent des constantes/fonctions definies dans les modules precedents.
// =============================================================================
function computeCalendarCoverage() {
  const byYear = {};
  allStockRows().forEach(r => {
    if (!r.year || !r.monthKey) return;
    if (!byYear[r.year]) byYear[r.year] = new Set();
    byYear[r.year].add(r.monthKey);
  });
  const coverage = {};
  Object.keys(byYear).forEach(y => { coverage[y] = byYear[y].size || 12; });
  return coverage;
}
function computeYearlySeries(rows, calendarCoverage) {
  const byYear = {};
  rows.forEach(r => {
    if (!r.year) return;
    if (!byYear[r.year]) byYear[r.year] = { valeur:0, qte:0 };
    byYear[r.year].valeur += r.valeur; byYear[r.year].qte += r.qte;
  });
  return Object.keys(byYear).map(Number).sort((a,b)=>a-b).map(y => {
    const d = byYear[y];
    // nbMois = couverture calendaire GLOBALE de l'année (pas celle du sous-ensemble filtré)
    const nbMois = (calendarCoverage && calendarCoverage[y]) || 12;
    const factor = 12 / nbMois;
    return { year:y, valeur:d.valeur, qte:d.qte, nbMois, valeurAnn: d.valeur*factor, qteAnn: d.qte*factor, partial: nbMois < 12 };
  });
}
function avgGrowthRate(series, key) {
  if (series.length < 2) return 0;
  const rates = [];
  for (let i=1;i<series.length;i++) { const prev=series[i-1][key], cur=series[i][key]; if (prev>0) rates.push((cur-prev)/prev); }
  if (!rates.length) return 0;
  const avg = rates.reduce((a,b)=>a+b,0)/rates.length;
  return Math.max(-0.5, Math.min(1.5, avg));
}
function renderApprovisionnement() {
  // Prevision basee sur les filtres Unite/Famille/Systeme/Equipement, mais SANS le filtre de dates (besoin de tout l'historique)
  const rows = filterStockRows(false);
  const series = computeYearlySeries(rows, computeCalendarCoverage());
  const el = document.getElementById('stk-appro-content');
  if (series.length === 0) { el.innerHTML = '<div class="empty-hint" style="padding:10px">Pas assez de données datées pour établir une prévision.</div>'; return; }

  const lastFull = [...series].reverse().find(s => !s.partial) || series[series.length-1];
  const growthVal = avgGrowthRate(series, 'valeurAnn');
  const growthQte = avgGrowthRate(series, 'qteAnn');
  const marge = (parseFloat(document.getElementById('stk-marge').value) || 0) / 100;
  const budgetN1 = lastFull.valeurAnn * (1 + growthVal) * (1 + marge);
  const qteN1 = lastFull.qteAnn * (1 + growthQte) * (1 + marge);
  const nextYearLabel = lastFull.year + 1;

  // Delta = variation du coût annualisé vs l'année précédente (comparaison homogène même si année partielle)
  const yearlyBody = series.map((s, i) => {
    const delta = i > 0 ? (s.valeurAnn - series[i-1].valeurAnn) : null;
    const deltaTxt = delta === null
      ? '<span style="color:var(--text3)">—</span>'
      : `<span style="color:${delta>=0?'#dc2626':'#16a34a'}">${delta>=0?'+':''}${fmtDA(delta)}</span>`;
    return `<tr style="border-top:1px solid var(--border)">
      <td style="padding:5px 10px;font-weight:700">${s.year}${s.partial?' <span style="color:var(--text3);font-weight:400">(partielle, '+s.nbMois+' mois)</span>':''}</td>
      <td style="text-align:right;padding:5px 10px">${fmtDA(s.valeur)}</td>
      <td style="text-align:right;padding:5px 10px">${deltaTxt}</td>
      <td style="text-align:right;padding:5px 10px">${Math.round(s.qte).toLocaleString('fr-FR')}</td>
    </tr>`;
  }).join('');
  // Estimation N+1 = dernière année pleine (annualisée) + moyenne des deltas annuels observés
  const deltaList = series.slice(1).map((s,i) => s.valeurAnn - series[i].valeurAnn);
  const avgDelta = deltaList.length ? deltaList.reduce((a,b)=>a+b,0)/deltaList.length : 0;
  const estimN1Delta = lastFull.valeurAnn + avgDelta;

  // Top pieces a reapprovisionner (sur la derniere annee de reference, meme filtre)
  const rowsLastYear = rows.filter(r => r.year === lastFull.year);
  const byPiece = {};
  rowsLastYear.forEach(r => {
    const k = r.codePiece || '—';
    if (!byPiece[k]) byPiece[k] = { designation:r.designation, famille:r.famille, qte:0, valeur:0 };
    byPiece[k].qte += r.qte; byPiece[k].valeur += r.valeur;
  });
  const topAppro = Object.entries(byPiece).sort((a,b)=>b[1].valeur-a[1].valeur).slice(0,15);
  const apBody = topAppro.map(([code,d]) => {
    const qteRec = d.qte * (1+growthQte) * (1+marge) * (lastFull.partial ? 12/lastFull.nbMois : 1);
    const valRec = d.valeur * (1+growthVal) * (1+marge) * (lastFull.partial ? 12/lastFull.nbMois : 1);
    return `<tr style="border-top:1px solid var(--border)"><td style="padding:5px 10px">${code}</td><td style="padding:5px 10px;color:var(--text2)">${d.designation}</td><td style="padding:5px 10px;color:var(--text2)">${d.famille}</td><td style="text-align:right;padding:5px 10px;color:var(--text3)">${Math.round(d.qte).toLocaleString('fr-FR')}</td><td style="text-align:right;padding:5px 10px;font-weight:700;color:#d97706">${Math.round(qteRec).toLocaleString('fr-FR')}</td><td style="text-align:right;padding:5px 10px">${fmtDA(valRec)}</td></tr>`;
  }).join('');

  el.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-bottom:16px">
      <div class="kpi-card c6"><div class="kpi-label">Budget prévisionnel ${nextYearLabel}</div><div class="kpi-value" style="font-size:20px;color:#d97706">${fmtDA(budgetN1)}</div><div class="kpi-sub">croissance valeur moy. : ${(growthVal*100).toFixed(1)}%/an + marge ${(marge*100).toFixed(0)}%</div></div>
      <div class="kpi-card c9"><div class="kpi-label">Quantité prévisionnelle ${nextYearLabel}</div><div class="kpi-value" style="font-size:20px">${Math.round(qteN1).toLocaleString('fr-FR')}</div><div class="kpi-sub">croissance qté moy. : ${(growthQte*100).toFixed(1)}%/an + marge ${(marge*100).toFixed(0)}%</div></div>
      <div class="kpi-card c3"><div class="kpi-label">Référence</div><div class="kpi-value" style="font-size:20px">${lastFull.year}</div><div class="kpi-sub">${fmtDA(lastFull.valeurAnn)} (${lastFull.partial?'estimée année pleine':'année pleine'})</div></div>
    </div>
    <div class="section-sub" style="margin:0 0 6px;font-weight:650;color:var(--text)">Évolution annuelle</div>
    ${simpleTable(['Année','Coût réel','Delta vs N-1','Qté sortie'], yearlyBody)}
    <div class="empty-hint" style="margin-top:6px">Estimation ${nextYearLabel} (moyenne des deltas annuels) : delta moyen ${avgDelta>=0?'+':''}${fmtDA(avgDelta)}/an → <b style="color:#d97706">${fmtDA(estimN1Delta)}</b></div>
    <div class="section-sub" style="margin:16px 0 6px;font-weight:650;color:var(--text)">Top 15 pièces — quantité recommandée à provisionner pour ${nextYearLabel}</div>
    ${apBody ? simpleTable(['Code Pièce','Désignation','Famille',`Qté ${lastFull.year}`,`Qté reco. ${nextYearLabel}`,`Valeur reco.`], apBody, {align:['left','left','left','right','right','right']})
             : '<div class="empty-hint" style="padding:10px">Pas de données disponibles sur l\'année de référence.</div>'}
    <div class="empty-hint" style="margin-top:10px">Méthode : coût/quantité de l'année ${lastFull.year} (annualisée si incomplète), projetés avec le taux de croissance annuel moyen observé sur l'historique disponible, majorés de la marge de sécurité définie ci-dessus. À affiner avec le jugement métier (obsolescence, changements de parc, ruptures fournisseur...).</div>`;
}

// ── Exports XLSX ──
async function exportStockData() {
  const rows = filterStockRows(true);
  if (!rows.length) { alert('Aucune ligne à exporter pour la période/filtre sélectionné.'); return; }
  showLoading();
  try {
    const logoBuf = await setramLogoBuffer();
    const wb = new ExcelJS.Workbook(); wb.creator = 'SETRAM — Direction Ingenierie'; wb.created = new Date();
    const exportRows = rows.map(r => ({
      'Unité': r.unit, 'Code Pièce': r.codePiece, 'Désignation': r.designation, 'Famille': r.famille,
      'Système': stockRowSysteme(r) || '', 'Équipement': stockRowEquip(r) || '',
      'Magasin': r.magasin, 'Qté': r.qte, 'Coût Unitaire': r.coutU, 'Valeur': r.valeur,
      'Type Mouvement': r.typeMvt, 'Type Sortie': r.typeSortie, 'Date': r.date ? fmtDateInput(r.date) : '',
      'Responsable': r.responsable, 'Motif': r.motif
    }));
    writeSetramSheet(wb, 'Mouvements Stock', exportRows, { title: 'Gestion de Stock — Mouvements filtrés', subtitle: `${exportRows.length} ligne(s)`, accentColor: SETRAM_XLSX.navy, logoBuf });
    await downloadSetramWorkbook(wb, `stock_mouvements_${fmtDateInput(new Date())}.xlsx`);
  } catch(err) { console.error(err); showToast(`❌ ${err.message}`, 'error'); }
  hideLoading();
}
async function exportStockSynthese() {
  const rows = filterStockRows(true);
  if (!rows.length) { alert('Aucune donnée à exporter pour la période/filtre sélectionné.'); return; }
  showLoading();
  try {
    const logoBuf = await setramLogoBuffer();
    const wb = new ExcelJS.Workbook(); wb.creator = 'SETRAM — Direction Ingenierie'; wb.created = new Date();
    const dstr = fmtDateInput(new Date());

    // ── Feuille de garde / sommaire ──
    const unitLabel = document.getElementById('stk-sel-unit').value === 'all' ? 'Toutes les unités' : document.getElementById('stk-sel-unit').value;
    const startV = document.getElementById('stk-date-start').value, endV = document.getElementById('stk-date-end').value;
    writeSetramSheet(wb, 'Sommaire', [
      { 'Paramètre':'Périmètre', 'Valeur': unitLabel },
      { 'Paramètre':'Période', 'Valeur': (startV||endV) ? `${startV||'…'} → ${endV||'…'}` : 'Historique complet' },
      { 'Paramètre':'Nombre de mouvements (période)', 'Valeur': rows.length },
      { 'Paramètre':'Coût total (période)', 'Valeur': fmtDA(rows.reduce((s,r)=>s+r.valeur,0)) },
      { 'Paramètre':'Généré le', 'Valeur': new Date().toLocaleString('fr-FR') },
      { 'Paramètre':'Contenu du classeur', 'Valeur': 'Par Mois, Par Unité, Par Famille, Par Système, ABC (Pareto), Conso Moyenne Mensuelle, Stock Dormant, Comparaison UO, Coûts Unitaires, Anomalies' }
    ], { title: 'Gestion de Stock — Synthèse & Analyses', subtitle: 'Feuille de garde', accentColor: SETRAM_XLSX.navy, logoBuf, headers:['Paramètre','Valeur'] });

    // ── Répartitions de coûts (période filtrée) ──
    const byMonth = {}; rows.forEach(r => { if (r.monthKey) byMonth[r.monthKey] = (byMonth[r.monthKey]||0)+r.valeur; });
    writeSetramSheet(wb, 'Par Mois', Object.keys(byMonth).sort().map(m=>({'Mois':m,'Coût (DA)':Math.round(byMonth[m])})), { title:'Synthèse Coûts — Par Mois', accentColor: SETRAM_XLSX.navy, logoBuf });
    const byUnit = {}; UNITS.forEach(u=>byUnit[u]=0); rows.forEach(r => byUnit[r.unit]=(byUnit[r.unit]||0)+r.valeur);
    writeSetramSheet(wb, 'Par Unite', UNITS.map(u=>({'Unité':u,'Coût (DA)':Math.round(byUnit[u])})), { title:'Synthèse Coûts — Par Unité', accentColor: SETRAM_XLSX.cyan, logoBuf });
    const byFam = {}; rows.forEach(r => byFam[r.famille]=(byFam[r.famille]||0)+r.valeur);
    writeSetramSheet(wb, 'Par Famille', Object.entries(byFam).sort((a,b)=>b[1]-a[1]).map(([f,v])=>({'Famille':f,'Coût (DA)':Math.round(v)})), { title:'Synthèse Coûts — Par Famille de Pièce', accentColor: SETRAM_XLSX.orange, logoBuf });
    const hasMapping = Object.keys(STOCK_MAPPING).length > 0;
    if (hasMapping) {
      const bySys = {}; rows.forEach(r => { const s = stockRowSysteme(r)||'Non identifié'; bySys[s]=(bySys[s]||0)+r.valeur; });
      writeSetramSheet(wb, 'Par Systeme', Object.entries(bySys).sort((a,b)=>b[1]-a[1]).map(([s,v])=>({'Système':s,'Coût (DA)':Math.round(v)})), { title:'Synthèse Coûts — Par Système', accentColor: SETRAM_XLSX.green, logoBuf });
    }

    // ── Classement ABC (Pareto valeur) — période filtrée ──
    const byPieceAbc = {};
    rows.forEach(r => { const k=r.codePiece||'—'; if(!byPieceAbc[k]) byPieceAbc[k]={designation:r.designation,famille:r.famille,valeur:0}; byPieceAbc[k].valeur += r.valeur; });
    const totalAbc = Object.values(byPieceAbc).reduce((s,d)=>s+d.valeur,0);
    if (totalAbc > 0) {
      let cumAbc = 0;
      const abcRows = Object.entries(byPieceAbc).sort((a,b)=>b[1].valeur-a[1].valeur).map(([code,d]) => {
        cumAbc += d.valeur;
        const pct = cumAbc/totalAbc*100;
        const cls = pct <= 80 ? 'A' : (pct <= 95 ? 'B' : 'C');
        return { 'Code Pièce':code, 'Désignation':d.designation, 'Famille':d.famille, 'Valeur (DA)':Math.round(d.valeur), '% cumulé':pct.toFixed(1)+'%', 'Classe':cls };
      });
      writeSetramSheet(wb, 'ABC Pareto', abcRows, { title:'Classement ABC (Pareto valeur)', subtitle:'Priorisation du contrôle et du réappro — période filtrée', accentColor: SETRAM_XLSX.red, logoBuf });
    }

    // ── Consommation moyenne mensuelle par pièce — période filtrée ──
    const startValExp = document.getElementById('stk-date-start').value;
    const endValExp = document.getElementById('stk-date-end').value;
    let nbMoisPeriodeExp;
    if (startValExp && endValExp) {
      const sD = parseDate(startValExp), eD = parseDate(endValExp);
      nbMoisPeriodeExp = (eD.getFullYear() - sD.getFullYear()) * 12 + (eD.getMonth() - sD.getMonth()) + 1;
    } else {
      nbMoisPeriodeExp = new Set(rows.map(r=>r.monthKey).filter(Boolean)).size;
    }
    nbMoisPeriodeExp = Math.max(1, nbMoisPeriodeExp);
    const byPieceConsoExp = {};
    rows.forEach(r => {
      const k = r.codePiece || '—';
      if (!byPieceConsoExp[k]) byPieceConsoExp[k] = { designation:r.designation, famille:r.famille, valeur:0, qte:0 };
      byPieceConsoExp[k].valeur += r.valeur;
      byPieceConsoExp[k].qte += r.qte;
    });
    const consoRowsExp = Object.entries(byPieceConsoExp).map(([code,d]) => ({
      'Code Pièce':code, 'Désignation':d.designation, 'Famille':d.famille,
      'Conso. moy./mois (DA)':Math.round(d.valeur / nbMoisPeriodeExp), 'Conso. moy./mois (Qté)': +(d.qte / nbMoisPeriodeExp).toFixed(1)
    })).sort((a,b)=>b['Conso. moy./mois (DA)']-a['Conso. moy./mois (DA)']);
    if (consoRowsExp.length) writeSetramSheet(wb, 'Conso Moyenne Mensuelle', consoRowsExp, {
      title:'Consommation Moyenne Mensuelle par Pièce',
      subtitle:`Coût total de la période ÷ nombre de mois filtrés (${nbMoisPeriodeExp} mois)`,
      accentColor: SETRAM_XLSX.navy, logoBuf
    });

    // ── Stock dormant — historique complet ──
    const rowsFull = filterStockRows(false);
    if (rowsFull.length) {
      const latest = stockLatestByPiece(rowsFull);
      const now = new Date();
      const pieces = Object.keys(latest).map(code => {
        const l = latest[code];
        const daysSince = l.date ? Math.round((now - l.date)/86400000) : null;
        return { code, designation:l.designation, famille:l.famille, daysSince, valeurStock: l.valeurStockApres };
      });
      const dormantRows = pieces.filter(p => p.daysSince !== null && p.daysSince >= 365 && p.valeurStock > 0)
        .sort((a,b)=>b.valeurStock-a.valeurStock)
        .map(p => ({ 'Code Pièce':p.code, 'Désignation':p.designation, 'Famille':p.famille, 'Sans mouvement depuis (j)':p.daysSince, 'Valeur immobilisée (DA)':Math.round(p.valeurStock) }));
      if (dormantRows.length) writeSetramSheet(wb, 'Stock Dormant', dormantRows, { title:'Stock Dormant', subtitle:'Pièces sans mouvement depuis ≥ 12 mois, triées par valeur immobilisée — historique complet', accentColor: SETRAM_XLSX.red, logoBuf });
    }

    // ── Comparaison entre unités (UO) — période filtrée ──
    const byPieceUnit = {};
    rows.forEach(r => {
      const k = r.codePiece || '—';
      if (!byPieceUnit[k]) byPieceUnit[k] = { designation:r.designation, famille:r.famille, units:new Set(), valeur:0 };
      byPieceUnit[k].units.add(r.unit); byPieceUnit[k].valeur += r.valeur;
    });
    const communesRows = Object.entries(byPieceUnit).filter(([k,d]) => d.units.size > 1).sort((a,b)=>b[1].valeur-a[1].valeur)
      .map(([code,d]) => ({ 'Code Pièce':code, 'Désignation':d.designation, 'Nb UO':d.units.size, 'Unités':[...d.units].join(', '), 'Valeur cumulée (DA)':Math.round(d.valeur) }));
    if (communesRows.length) writeSetramSheet(wb, 'Pieces Communes UO', communesRows, { title:'Comparaison UO — Pièces Communes', subtitle:'Pièces consommées par plusieurs unités — candidates à une gestion mutualisée', accentColor: SETRAM_XLSX.cyan, logoBuf });

    const byFamUnit = {};
    rows.forEach(r => { if (!byFamUnit[r.famille]) byFamUnit[r.famille] = {}; byFamUnit[r.famille][r.unit] = (byFamUnit[r.famille][r.unit]||0) + r.valeur; });
    const ecartsRows = [];
    Object.entries(byFamUnit).forEach(([fam,byU]) => {
      const vals = Object.values(byU);
      if (vals.length < 2) return;
      const avg = vals.reduce((a,b)=>a+b,0)/vals.length;
      Object.entries(byU).forEach(([u,v]) => { if (avg > 0 && v > avg*1.5) ecartsRows.push({ 'Famille':fam, 'Unité':u, 'Valeur (DA)':Math.round(v), 'Moyenne UO (DA)':Math.round(avg), 'Écart':'+'+((v/avg-1)*100).toFixed(0)+'%' }); });
    });
    ecartsRows.sort((a,b)=>parseFloat(b['Écart'])-parseFloat(a['Écart']));
    if (ecartsRows.length) writeSetramSheet(wb, 'Ecarts Consommation UO', ecartsRows, { title:'Comparaison UO — Unités en Surconsommation', subtitle:'> +50% vs la moyenne des UO, par famille de pièce', accentColor: SETRAM_XLSX.orange, logoBuf });

    // ── Évolution des coûts unitaires — historique complet ──
    if (rowsFull.length) {
      const byPieceYear = {};
      rowsFull.forEach(r => {
        if (!r.year || !r.coutU) return;
        const k = r.codePiece || '—';
        if (!byPieceYear[k]) byPieceYear[k] = { designation:r.designation, famille:r.famille, years:{} };
        if (!byPieceYear[k].years[r.year]) byPieceYear[k].years[r.year] = { sum:0, n:0 };
        byPieceYear[k].years[r.year].sum += r.coutU; byPieceYear[k].years[r.year].n++;
      });
      const evolRows = [];
      Object.entries(byPieceYear).forEach(([code,d]) => {
        const yrs = Object.keys(d.years).map(Number).sort((a,b)=>a-b);
        if (yrs.length < 2) return;
        const firstAvg = d.years[yrs[0]].sum / d.years[yrs[0]].n;
        const lastAvg = d.years[yrs[yrs.length-1]].sum / d.years[yrs[yrs.length-1]].n;
        if (firstAvg <= 0) return;
        const evolPct = (lastAvg/firstAvg - 1) * 100;
        evolRows.push({ 'Code Pièce':code, 'Désignation':d.designation, 'Famille':d.famille, [`Coût ${yrs[0]}`]:Math.round(firstAvg), [`Coût ${yrs[yrs.length-1]}`]:Math.round(lastAvg), 'Évolution':(evolPct>=0?'+':'')+evolPct.toFixed(0)+'%' });
      });
      evolRows.sort((a,b)=>parseFloat(b['Évolution'])-parseFloat(a['Évolution']));
      if (evolRows.length) writeSetramSheet(wb, 'Couts Unitaires', evolRows, { title:'Évolution des Coûts Unitaires', subtitle:'Première vs dernière année d historique disponible, par pièce', accentColor: SETRAM_XLSX.navy, logoBuf });
    }

    // ── Croisement stock ↔ criticité équipement — nécessite mapping + correctif ──
    if (hasMapping) {
      const corrStats = computeEquipementCorrStats();
      if (Object.keys(corrStats).length) {
        const rowsCritic = filterStockRows(false);
        const byEquip = {};
        rowsCritic.forEach(r => { const eq = stockRowEquip(r); if (!eq) return; byEquip[eq] = (byEquip[eq]||0) + r.valeur; });
        const allEquips = new Set([...Object.keys(corrStats), ...Object.keys(byEquip)]);
        const combined = [...allEquips].map(eq => ({ eq, pannes: (corrStats[eq]||{}).pannes || 0, dureeH: (corrStats[eq]||{}).dureeH || 0, valeurPieces: byEquip[eq] || 0 }));
        const criticRows = combined.filter(c => c.pannes > 0).sort((a,b)=>b.pannes-a.pannes).map(c => ({
          'Équipement':c.eq, 'Nb pannes':c.pannes, 'Durée interv. (h)':c.dureeH.toFixed(1), 'Valeur pièces consommées (DA)':Math.round(c.valeurPieces), 'Statut': c.valeurPieces===0 ? '⚠️ Aucune sortie récente' : 'OK'
        }));
        if (criticRows.length) writeSetramSheet(wb, 'Criticite Equipements', criticRows, { title:'Croisement Stock ↔ Criticité Équipement', subtitle:'Équipements en panne — pièces consommées (période filtrée)', accentColor: SETRAM_XLSX.red, logoBuf });
      }
    }

    // ── Contrôle qualité des mouvements — historique complet ──
    if (rowsFull.length) {
      const anomRows = [];
      rowsFull.forEach(r => {
        if (!r.motif) anomRows.push({ 'Type':'Sans motif renseigné', 'Unité':r.unit, 'Code Pièce':r.codePiece, 'Désignation':r.designation, 'Date':r.date?fmtDateInput(r.date):'—' });
        if (!r.date) anomRows.push({ 'Type':'Sans date', 'Unité':r.unit, 'Code Pièce':r.codePiece, 'Désignation':r.designation, 'Date':'—' });
        if (r.qte > 0 && r.valeur === 0 && r.coutU === 0) anomRows.push({ 'Type':'Coût/valeur nuls', 'Unité':r.unit, 'Code Pièce':r.codePiece, 'Désignation':r.designation, 'Date':r.date?fmtDateInput(r.date):'—' });
        if (r.qteAvant && (Math.abs((r.qteAvant - r.qte) - r.qteApres) > 0.01)) anomRows.push({ 'Type':'Incohérence qté avant/après', 'Unité':r.unit, 'Code Pièce':r.codePiece, 'Désignation':r.designation, 'Date':r.date?fmtDateInput(r.date):'—' });
      });
      if (anomRows.length) writeSetramSheet(wb, 'Anomalies Qualite', anomRows, { title:'Contrôle Qualité des Mouvements', subtitle:'Anomalies de saisie détectées — historique complet, à faire remonter aux unités concernées', accentColor: SETRAM_XLSX.orange, logoBuf });
    }

    await downloadSetramWorkbook(wb, `stock_synthese_analyses_${dstr}.xlsx`);
  } catch(err) { console.error(err); showToast(`❌ ${err.message}`, 'error'); }
  hideLoading();
}
async function exportStockApprovisionnement() {
  const rows = filterStockRows(false);
  const series = computeYearlySeries(rows, computeCalendarCoverage());
  if (!series.length) { alert('Pas assez de données pour générer la prévision.'); return; }
  showLoading();
  try {
    const logoBuf = await setramLogoBuffer();
    const wb = new ExcelJS.Workbook(); wb.creator = 'SETRAM — Direction Ingenierie'; wb.created = new Date();
    const lastFull = [...series].reverse().find(s => !s.partial) || series[series.length-1];
    const growthVal = avgGrowthRate(series, 'valeurAnn');
    const growthQte = avgGrowthRate(series, 'qteAnn');
    const marge = (parseFloat(document.getElementById('stk-marge').value) || 0) / 100;
    const deltaListExport = series.slice(1).map((s,i) => s.valeurAnn - series[i].valeurAnn);
    const avgDeltaExport = deltaListExport.length ? deltaListExport.reduce((a,b)=>a+b,0)/deltaListExport.length : 0;
    writeSetramSheet(wb, 'Evolution Annuelle', series.map((s,i) => ({
      'Année': s.year, 'Coût réel (DA)': Math.round(s.valeur), 'Delta vs N-1 (DA)': i>0 ? Math.round(s.valeurAnn-series[i-1].valeurAnn) : '',
      'Qté réelle': Math.round(s.qte), 'Qté annualisée': Math.round(s.qteAnn), 'Année incomplète': s.partial ? 'Oui' : 'Non'
    })), { title: 'Approvisionnement — Évolution Annuelle', subtitle: `Delta moyen : ${avgDeltaExport>=0?'+':''}${Math.round(avgDeltaExport).toLocaleString('fr-FR')} DA/an`, accentColor: SETRAM_XLSX.orange, logoBuf });

    const rowsLastYear = rows.filter(r => r.year === lastFull.year);
    const byPiece = {};
    rowsLastYear.forEach(r => { const k=r.codePiece||'—'; if(!byPiece[k]) byPiece[k]={designation:r.designation,famille:r.famille,qte:0,valeur:0}; byPiece[k].qte+=r.qte; byPiece[k].valeur+=r.valeur; });
    const factor = lastFull.partial ? 12/lastFull.nbMois : 1;
    const apRows = Object.entries(byPiece).sort((a,b)=>b[1].valeur-a[1].valeur).map(([code,d]) => ({
      'Code Pièce': code, 'Désignation': d.designation, 'Famille': d.famille,
      [`Qté ${lastFull.year}`]: Math.round(d.qte),
      [`Qté recommandée ${lastFull.year+1}`]: Math.round(d.qte*(1+growthQte)*(1+marge)*factor),
      'Valeur recommandée (DA)': Math.round(d.valeur*(1+growthVal)*(1+marge)*factor)
    }));
    writeSetramSheet(wb, `Prevision ${lastFull.year+1}`, apRows, { title: `Approvisionnement Recommandé — ${lastFull.year+1}`, subtitle: `Marge de sécurité : ${(marge*100).toFixed(0)}%`, accentColor: SETRAM_XLSX.red, logoBuf });

    // ── Ruptures / Stock de sécurité — Conso. moy./mois calculée sur la période filtrée ──
    const delaiMoisExp = Math.max(1, parseFloat(document.getElementById('stk-delai-mois')?.value) || 3);
    const rowsPCFull = filterStockRows(false);
    const rowsPC = filterStockRows(true);
    if (rowsPC.length) {
      const latestPC = stockLatestByPiece(rowsPCFull);
      const startValExp = document.getElementById('stk-date-start').value;
      const endValExp = document.getElementById('stk-date-end').value;
      let nbMoisPeriodePC;
      if (startValExp && endValExp) {
        const sD = parseDate(startValExp), eD = parseDate(endValExp);
        nbMoisPeriodePC = (eD.getFullYear() - sD.getFullYear()) * 12 + (eD.getMonth() - sD.getMonth()) + 1;
      } else {
        nbMoisPeriodePC = new Set(rowsPC.map(r=>r.monthKey).filter(Boolean)).size;
      }
      nbMoisPeriodePC = Math.max(1, nbMoisPeriodePC);
      const byPiece = {};
      rowsPC.forEach(r => {
        const k = r.codePiece || '—';
        if (!byPiece[k]) byPiece[k] = { designation:r.designation, famille:r.famille, qte:0 };
        byPiece[k].qte += r.qte;
      });
      const pcList = Object.entries(byPiece).map(([code,d]) => {
        const avg = d.qte / nbMoisPeriodePC;
        const stockSecu = avg * delaiMoisExp; // Stock sécurité = Conso. moy./mois × Délai fournisseur
        const stockActuel = (latestPC[code] && latestPC[code].qteApres) || 0;
        return { code, designation:d.designation, famille:d.famille, avgMonth:avg, stockSecu, stockActuel, sousSeuil: stockActuel < stockSecu };
      }).filter(p => p.avgMonth > 0).sort((a,b) => (b.sousSeuil - a.sousSeuil) || (b.avgMonth - a.avgMonth));
      const pcRows = pcList.map(p => ({
        'Code Pièce':p.code, 'Désignation':p.designation, 'Famille':p.famille,
        'Conso. moy./mois':p.avgMonth.toFixed(1), 'Stock sécurité':Math.round(p.stockSecu),
        'Stock actuel':Math.round(p.stockActuel), 'Statut': p.sousSeuil ? '🔴 Sous seuil — à réapprovisionner' : 'OK'
      }));
      if (pcRows.length) writeSetramSheet(wb, 'Ruptures - Stock Securite', pcRows, {
        title: 'Ruptures — Stock de Sécurité par Pièce',
        subtitle: `Conso. moy./mois sur la période filtrée (${nbMoisPeriodePC} mois) — Stock sécurité = Conso. moy./mois × délai fournisseur (${delaiMoisExp} mois) — ${pcList.filter(p=>p.sousSeuil).length} référence(s) sous seuil`,
        accentColor: SETRAM_XLSX.red, logoBuf
      });
    }

    await downloadSetramWorkbook(wb, `stock_approvisionnement_${lastFull.year+1}.xlsx`);
  } catch(err) { console.error(err); showToast(`❌ ${err.message}`, 'error'); }
  hideLoading();
}

// =====================================================================
// DATE HELPERS
// =====================================================================
const FR_MONTHS = {
  'janv':0,'jan':0,'janvier':0,'févr':1,'fev':1,'fevr':1,'février':1,'mars':2,'avr':3,'avril':3,
  'mai':4,'juin':5,'juil':6,'juillet':6,'août':7,'aout':7,'sept':8,'sep':8,'septembre':8,
  'oct':9,'octobre':9,'nov':10,'novembre':10,'déc':11,'dec':11,'décembre':11
};
function parseDate(v) {
  if (!v) return null; if (v instanceof Date) return isNaN(v) ? null : v;
  const s = String(v).trim(); if (!s) return null;

  // DD/MM/YYYY HH:MM:SS
  let m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})/);
  if (m) return new Date(+m[3], +m[2]-1, +m[1], +m[4], +m[5], +m[6]);

  // Serial Excel
  if (/^\d{5}$/.test(s)) { const d = new Date((parseInt(s)-25569)*86400*1000); if (!isNaN(d)) return d; }

  // DD/MM/YYYY
  m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/);
  if (m) return new Date(+m[3], +m[2]-1, +m[1]);

  // YYYY-MM-DD
  m = s.match(/^(\d{4})[\/\-](\d{2})[\/\-](\d{2})/);
  if (m) return new Date(+m[1], +m[2]-1, +m[3]);

  // DD/MM/YYYY HH:MM
  m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})\s+(\d{1,2}):(\d{2})/);
  if (m) return new Date(+m[3], +m[2]-1, +m[1], +m[4], +m[5]);

  // YYYY-MM-DDTHH:MM
  m = s.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
  if (m) return new Date(+m[1], +m[2]-1, +m[3], +m[4], +m[5]);

  // "janv 2, 2025, 08:50" ou "janv 2, 2025" (format Excel FR affiché)
  m = s.match(/^([a-zéûôàâèêîïùäëöüç\.]+)\s+(\d{1,2}),?\s+(\d{4}),?\s*(\d{1,2}):(\d{2})/i);
  if (m) {
    const mo = FR_MONTHS[(m[1].replace('.','').toLowerCase())];
    if (mo !== undefined) return new Date(+m[3], mo, +m[2], +m[4], +m[5]);
  }
  m = s.match(/^([a-zéûôàâèêîïùäëöüç\.]+)\s+(\d{1,2}),?\s+(\d{4})/i);
  if (m) {
    const mo = FR_MONTHS[(m[1].replace('.','').toLowerCase())];
    if (mo !== undefined) return new Date(+m[3], mo, +m[2]);
  }

  // Fallback JS natif
  const d = new Date(s); return isNaN(d) ? null : d;
}

// =====================================================================
// FILTERING — MODIF 1 : inclus si date absente
// =====================================================================
function filterByDate(rows, field, start, end) {
  return rows.filter(r => {
    let v = r[field];
    
    // Fallback pour DATE_PREVUE
    if ((!v || String(v).trim() === '') && field === 'DATE_PREVUE') {
      v = r['DATE_DEB_INTERVENTION'] || r['DATE_CLOTURE'] || '';
    }
    
    // Inclure si date absente
    if (!v || String(v).trim() === '') {
      return true;
    }
    
    const d = parseDate(v);
    if (!d) return true;
    return d >= start && d <= end;
  });
}
function filterBySystem(rows, sys) { if (!sys || sys === 'all') return rows; return rows.filter(r => (r['SYSTEME'] || '').trim() === sys); }
function filterByEquipement(rows, eq) { if (!eq || eq === 'all') return rows; return rows.filter(r => (r['CODE_EQUIPEMENT'] || r['EQUIPEMENT'] || '').trim() === eq); }
function getFilteredData(unitOverride) {
  const { start, end, hoursTotal, unit, systeme } = getFilters();
  const u = unitOverride || unit;
  let cr = [], pr = [];
  if (u === 'all') { UNITS.forEach(un => { cr = cr.concat(DB.corrective[un]); pr = pr.concat(DB.preventive[un]); }); }
  else { cr = DB.corrective[u] || []; pr = DB.preventive[u] || []; }
  cr = filterByDate(cr, 'DATE_DI', start, end);
  pr = filterByDate(pr, 'DATE_PREVUE', start, end);
  cr = filterBySystem(cr, systeme); pr = filterBySystem(pr, systeme);
  return { corrRows: cr, prevRows: pr, hoursTotal, start, end };
}


// =====================================================================
// STATE HELPERS
// =====================================================================
function normState(s)    { return (s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim(); }
function isTraitee(s)    { return s.includes('trait'); }
function isRealisee(s)   { return s.includes('realis'); }
function isTransmis(s)   { return s.includes('transmis') && !s.includes('transmettre'); }
function isTransmettre(s){ return s.includes('transmettre') || s.includes('a transmettre'); }
function isAnnule(s)     { return s.includes('annul'); }

function sumField(rows, fields) {
  let s = 0;
  rows.forEach(r => { for (const f of fields) { const v = parseFloat(String(r[f]||'').replace(',','.')); if (!isNaN(v) && v >= 0) { s += v; break; } } });
  return s;
}

// =====================================================================
// ★ KPI CALCULATIONS ★
// =====================================================================
function calcKPIs(corrRows, prevRows, hoursTotal) {
  const hPI = sumField(prevRows, ['Durée Intervention (Min)','Durée Intervention_(Min)']) / 60;
  const hPL = sumField(prevRows, ['Temps Logistique (Min)','Temps Logistique_(Min)'])    / 60;
  const hCI = sumField(corrRows, ['Durée Intervention_(Min)','Durée Intervention (Min)']) / 60;
  const hCL = sumField(corrRows, ['Temps Logistique_(Min)','Temps Logistique (Min)'])    / 60;
  const hPrev = hPI + hPL, hCorr = hCI + hCL, hTotal = hPrev + hCorr;
  const tcp = hTotal > 0 ? hPrev / hTotal : 0;
  const tcc = hTotal > 0 ? hCorr / hTotal : 0;

  const btClosed = prevRows.filter(r => { const s = normState(r['ETAT_BT']); return s.includes('clos') || s.includes('fait'); }).length;
  const btDenom  = prevRows.filter(r => { const s = normState(r['ETAT_BT']); return s.includes('clos') || s.includes('fait') || s.includes('faire') || s.includes('attente') || s.includes('cours'); }).length;
  const tmp = btDenom > 0 ? btClosed / btDenom : 0;

    function isTravDivers(r) {

    const tv = normState(r['TYPE_TRAVAUX'] || '');

    return tv.includes('divers');

  }

  const corrRowsTMC = corrRows.filter(r => !isTravDivers(r));

  const diDone  = corrRowsTMC.filter(r => { const s = normState(r['ETAT_DI']); return isTraitee(s) || isRealisee(s); }).length;

  const diDenom = corrRowsTMC.filter(r => { const s = normState(r['ETAT_DI']); return isTraitee(s) || isRealisee(s) || isTransmis(s) || isTransmettre(s); }).length;

  const tmc = diDenom > 0 ? diDone / diDenom : 0;

  const pannesRep   = corrRows.filter(r => { const s = normState(r['ETAT_DI']); return isTraitee(s) || isRealisee(s); });
  const nbPannesRep = pannesRep.length;
  const pannesTot   = corrRows.filter(r => { const s = normState(r['ETAT_DI']); return isTraitee(s) || isRealisee(s) || isTransmis(s) || isTransmettre(s); });
  const nbPannesTot = pannesTot.length;

  const hIntervRep = sumField(pannesRep, ['Durée Intervention_(Min)','Durée Intervention (Min)']) / 60;
  const mttr = nbPannesRep > 0 ? hIntervRep / nbPannesRep : 0;

  const filterStart = arguments[3] || null;
  const filterEnd   = arguments[4] || null;

  let indispoH = 0;
  let nbAvecDates = 0, nbSansDebut = 0, nbNegatif = 0, nbAberrant = 0;
  const exSansDebut = [], exNegatif = [], exAberrant = [];

  // Noeuds pairs : DI/BT saisies sur un noeud parent (SITE.UNITE, ex: BO.OR1)
  // au lieu d'un equipement precis -- c'est l'anomalie a relever, pas la
  // DATE_FIN_INTERVENTION vide (qui n'est plus consideree comme anomalie).
  let nbNoeudsPaire = 0;
  const exNoeudsPaire = [];
  corrRows.forEach(r => {
    if (isPairedNodeCode(r['CODE_EQUIPEMENT'] || r['EQUIPEMENT'])) {
      nbNoeudsPaire++; if (exNoeudsPaire.length < 3) exNoeudsPaire.push(r['CODE_DI'] || '?');
    }
  });

  pannesTot.forEach(r => {
    let fin = parseDate(r['DATE_FIN_INTERVENTION']);
    let deb = parseDate(r['DATE_EVENEMENT']);

    // Valeur de secours pour le calcul (MTBF / Dispo) : Duree Intervention + Temps
    // Logistique (en heures), utilisee quand DATE_FIN_INTERVENTION est absente ou
    // quand l'ecart (fin - debut) est negatif. Ne change rien a l'affichage/export
    // des dates brutes, seulement au calcul de la duree d'indisponibilite.
    const durIntervMin = parseFloat(String(r['Durée Intervention_(Min)'] ?? r['Durée Intervention (Min)'] ?? '').replace(',', '.')) || 0;
    const tempsLogMin  = parseFloat(String(r['Temps Logistique_(Min)']  ?? r['Temps Logistique (Min)']  ?? '').replace(',', '.')) || 0;
    const dhSecours = (durIntervMin + tempsLogMin) / 60;

    let finManquante = false;
    if (!fin) {
      // DATE_FIN_INTERVENTION vide : on remplace la duree par Duree Intervention + Temps Logistique.
      finManquante = true;
    }
    if (!deb) {
      if (filterStart) {
        deb = new Date(filterStart.getTime()); deb.setHours(0,1,0,0);
        nbSansDebut++; if (exSansDebut.length < 3) exSansDebut.push(r['CODE_DI'] || '?');
      } else {
        nbSansDebut++; if (exSansDebut.length < 3) exSansDebut.push(r['CODE_DI'] || '?'); return;
      }
    }

    let dh;
    if (finManquante) {
      dh = dhSecours;
    } else {
      if (filterStart && deb < filterStart) { deb = new Date(filterStart.getTime()); deb.setHours(0,1,0,0); }
      if (filterEnd   && fin > filterEnd)   { fin = new Date(filterEnd.getTime());   fin.setHours(23,59,59,0); }
      dh = (fin - deb) / 3600000;
      if (dh <= 0) {
        // Ecart negatif (DATE_FIN_INTERVENTION < DATE_EVENEMENT) : on remplace
        // la duree par Duree Intervention + Temps Logistique pour le calcul.
        nbNegatif++; if (exNegatif.length < 3) exNegatif.push(`${r['CODE_DI']||'?'} (${dh.toFixed(1)}h)`);
        dh = dhSecours;
      }
    }

    if (dh > hoursTotal*1.5)  { nbAberrant++; if (exAberrant.length < 3) exAberrant.push(`${r['CODE_DI']||'?'} (${dh.toFixed(0)}h)`); return; }
    nbAvecDates++; indispoH += dh;
  });

  // Nombre d'equipements distincts (CODE_EQUIPEMENT / EQUIPEMENT) presents dans les
  // DI+BT importes pour ce perimetre (unite/systeme/filtre en cours). Chaque equipement
  // fonctionne en parallele sur la periode, donc le temps theorique total du parc =
  // heures de la periode x nombre d'equipements (ex: 31j x 24h = 744h x N equipements).
  const equipSet = new Set();
  [...corrRows, ...prevRows].forEach(r => {
    const code = (r['CODE_EQUIPEMENT'] || r['EQUIPEMENT'] || '').toString().trim();
    if (code) equipSet.add(code);
  });
  const nbEquipements = Math.max(equipSet.size, 1);
  const hoursFlotte    = hoursTotal * nbEquipements;

  const tbf      = Math.max(hoursFlotte - indispoH, 0);
  const mtbf     = nbPannesTot > 0 ? tbf / nbPannesTot : hoursFlotte;
  const dispo    = hoursFlotte > 0 ? tbf / hoursFlotte : 1;
  const tauxPanne = mtbf > 0 ? 1 / mtbf : 0;
  const tauxRep   = mttr > 0 ? 1 / mttr : 0;

  return {
    tcp, tcc, tmp, tmc, mttr, mtbf, dispo,
    nbPannesRep, nbPannesTot, hPrev, hCorr, hTotal,
    btClosed, btDenom, diDone, diDenom,
    indispoH, tbf, hoursTotal, nbEquipements, hoursFlotte, tauxPanne, tauxRep,
    nbAvecDates, nbSansDebut, nbNegatif, nbAberrant, nbNoeudsPaire,
    exSansDebut, exNegatif, exAberrant, exNoeudsPaire
  };
}

// =====================================================================
// ██████████████████████████████████████████████████████████████████
// ██        MODULE EXPORT XLSX "CHARTE SETRAM" (via ExcelJS)        ██
// ██  Habillage professionnel commun a tous les exports Excel :     ██
// ██  logo, bandeau titre, en-tetes colores, bordures, zebrage,     ██
// ██  filtre auto, volet fige, largeurs de colonnes auto.           ██
// =====================================================================
const SETRAM_XLSX = {
  navy:      'FF2B3593', // bleu fonce SETRAM (logo + theme PDC)
  navyDark:  'FF1F2570',
  cyan:      'FF2DC4EA', // cyan SETRAM (logo + theme PDC)
  cyanPale:  'FFEAF9FD',
  bandAlt:   'FFF4F8FC',
  white:     'FFFFFFFF',
  textDark:  'FF0A1930',
  textGray:  'FF5B6472',
  red:       'FFC00000',
  orange:    'FFE07B00',
  green:     'FF157347',
  borderCol: 'FFD7E1EE'
};

// Charge une fois le logo SETRAM (image PNG du projet) en ArrayBuffer, pour l'inserer dans les classeurs exportes
async function setramLogoBuffer() {
  if (window._setramLogoBuf !== undefined) return window._setramLogoBuf;
  try {
    const resp = await fetch('../../assets/setram-logo.png');
    window._setramLogoBuf = resp.ok ? await resp.arrayBuffer() : null;
  } catch (e) { window._setramLogoBuf = null; }
  return window._setramLogoBuf;
}

// Construit une feuille habillee "charte SETRAM" a partir d'un tableau d'objets (une ligne = un objet, cles = colonnes).
// opts: { title, subtitle, headers?(ordre des colonnes, sinon deduit de la 1ere ligne), accentColor?, logoBuf? }
function writeSetramSheet(wb, sheetName, rows, opts = {}) {
  const ws = wb.addWorksheet(sheetName.slice(0, 31), { views: [{ showGridLines: false }] });
  const headers = opts.headers && opts.headers.length ? opts.headers : (rows[0] ? Object.keys(rows[0]) : ['—']);
  const nbCols = Math.max(headers.length, 1);
  const accent = opts.accentColor || SETRAM_XLSX.navy;

  // ── Charte SETRAM officielle (logo + Référence / Date / Titre du document) ──
  // Le titre du document est rempli automatiquement (opts.title), comme sur
  // le modèle Charte.xlsx : aucun champ à compléter à la main.
  let top = 1;
  if (window.SETRAM_ADD_CHARTE) {
    top = window.SETRAM_ADD_CHARTE(ws, { titre: opts.title || sheetName, reference: opts.reference }, nbCols) + 1; // +1 = ligne d'espacement
  }

  // ── Bandeau titre (perimetre / couleur du module) ──
  ws.mergeCells(top, 1, top, nbCols);
  const titleCell = ws.getCell(top, 1);
  titleCell.value = '  ' + (opts.title || sheetName);
  titleCell.font = { name: 'Montserrat', size: 11, bold: true, color: { argb: SETRAM_XLSX.white } };
  titleCell.alignment = { vertical: 'middle', horizontal: 'left' };
  titleCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: accent } };
  ws.getRow(top).height = 32;

  // ── Sous-titre : perimetre / date de generation / nb de lignes ──
  const subRow = top + 1;
  ws.mergeCells(subRow, 1, subRow, nbCols);
  const subCell = ws.getCell(subRow, 1);
  const dstr = new Date().toLocaleString('fr-FR');
  subCell.value = '  ' + (opts.subtitle || '') + `   •   ${rows.length} ligne(s)   •   Genere le ${dstr}`;
  subCell.font = { name: 'Montserrat', size: 11, italic: true, color: { argb: SETRAM_XLSX.textGray } };
  subCell.alignment = { vertical: 'middle' };
  subCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: SETRAM_XLSX.cyanPale } };
  ws.getRow(subRow).height = 20;

  // ── Ligne d'espacement ──
  const gapRow = top + 2;
  ws.getRow(gapRow).height = 6;

  // ── En-tetes de tableau ──
  const headerRowIdx = top + 3;
  const headerRow = ws.getRow(headerRowIdx);
  headers.forEach((h, i) => {
    const c = headerRow.getCell(i + 1);
    c.value = h;
    c.font = { name: 'Montserrat', size: 11, bold: true, color: { argb: SETRAM_XLSX.white } };
    c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: accent } };
    c.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
    c.border = {
      top: { style: 'thin', color: { argb: SETRAM_XLSX.navyDark } },
      bottom: { style: 'medium', color: { argb: SETRAM_XLSX.navyDark } },
      left: { style: 'thin', color: { argb: SETRAM_XLSX.navyDark } },
      right: { style: 'thin', color: { argb: SETRAM_XLSX.navyDark } }
    };
  });
  headerRow.height = 22;

  // ── Lignes de donnees, zebrees, bordees ──
  rows.forEach((r, ri) => {
    const row = ws.getRow(headerRowIdx + 1 + ri);
    const bandFill = ri % 2 === 1 ? SETRAM_XLSX.bandAlt : SETRAM_XLSX.white;
    headers.forEach((h, ci) => {
      const cell = row.getCell(ci + 1);
      let v = r[h];
      if (v === undefined || v === null) v = '';
      cell.value = v;
      cell.font = { name: 'Montserrat', size: 11, color: { argb: SETRAM_XLSX.textDark } };
      cell.alignment = { vertical: 'middle', horizontal: typeof v === 'number' ? 'right' : 'left', wrapText: false };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: bandFill } };
      cell.border = {
        top: { style: 'hair', color: { argb: SETRAM_XLSX.borderCol } },
        bottom: { style: 'hair', color: { argb: SETRAM_XLSX.borderCol } },
        left: { style: 'hair', color: { argb: SETRAM_XLSX.borderCol } },
        right: { style: 'hair', color: { argb: SETRAM_XLSX.borderCol } }
      };
    });
    row.height = 17;
  });

  // ── Largeurs de colonnes (auto, bornees) ──
  headers.forEach((h, i) => {
    let maxLen = String(h || '').length;
    rows.forEach(r => { const l = String(r[h] ?? '').length; if (l > maxLen) maxLen = l; });
    ws.getColumn(i + 1).width = Math.min(Math.max(maxLen + 3, 11), 45);
  });
  // Les colonnes 1-2 doivent rester assez larges pour écrire la Référence de la charte (fusionnée)
  ws.getColumn(1).width = Math.max(ws.getColumn(1).width, 20);
  ws.getColumn(2).width = Math.max(ws.getColumn(2).width, 20);

  // ── Filtre auto + volet fige (en-tetes toujours visibles) ──
  if (rows.length > 0) {
    ws.autoFilter = { from: { row: headerRowIdx, column: 1 }, to: { row: headerRowIdx, column: nbCols } };
  }
  ws.views = [{ state: 'frozen', ySplit: headerRowIdx, showGridLines: false }];

  // ── Logo module (accent) en haut a droite du bandeau titre, sous le logo SETRAM de la charte ──
  if (opts.logoBuf) {
    try {
      const imgId = wb.addImage({ buffer: opts.logoBuf, extension: 'png' });
      const logoCol = Math.max(nbCols - 1.6, 0.2);
      ws.addImage(imgId, { tl: { col: logoCol, row: top - 1 + 0.05 }, ext: { width: 118, height: 34 } });
    } catch (e) { /* logo optionnel : on n'interrompt pas l'export si l'image echoue */ }
  }

  return ws;
}

// Ajoute une feuille "Synthese" recapitulative (tableau simple libelle/valeur ou multi-colonnes) en 1ere position
function writeSetramSummarySheet(wb, rows, opts = {}) {
  return writeSetramSheet(wb, opts.sheetName || 'Synthese', rows, { ...opts, accentColor: opts.accentColor || SETRAM_XLSX.navy });
}

// Genere le buffer XLSX et declenche le telechargement (equivalent de XLSX.writeFile, pour un classeur ExcelJS)
async function downloadSetramWorkbook(wb, filename) {
  const buf = await wb.xlsx.writeBuffer();
  const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

// -- Detecte les "noeuds pairs" GMAO : code au format SITE.UNITE exact
//    (ex: BO.OR1, BIL.OR1) -- ce sont des noeuds parents de l'arborescence,
//    pas des equipements reels, donc une DATE_FIN_INTERVENTION vide sur
//    ces lignes n'est pas une vraie anomalie.
function isPairedNodeCode(code) {
  if (!code) return false;
  const parts = String(code).trim().split('.').filter(Boolean);
  return parts.length === 2;
}

// \u2500\u2500 Collecte les lignes brutes d'anomalies (memes criteres que calcKPIs) pour export XLSX \u2500\u2500
function collectAnomalyRows(corrRows, hoursTotal, filterStart, filterEnd) {
  const isDiCompte = r => { const s = normState(r['ETAT_DI']); return isTraitee(s) || isRealisee(s) || isTransmis(s) || isTransmettre(s); };
  const pannesTot = corrRows.filter(isDiCompte);
  const out = { sansDebut: [], negatif: [], aberrant: [], noeudsPaire: [] };

  // Noeuds pairs : DI/BT saisies sur un noeud parent (SITE.UNITE, ex: BO.OR1)
  // au lieu d'un equipement precis -- c'est une anomalie de saisie en soi.
  corrRows.forEach(r => {
    if (isPairedNodeCode(r['CODE_EQUIPEMENT'] || r['EQUIPEMENT'])) out.noeudsPaire.push(r);
  });

  pannesTot.forEach(r => {
    let fin = parseDate(r['DATE_FIN_INTERVENTION']);
    let deb = parseDate(r['DATE_EVENEMENT']);

    if (!fin) {
      // DATE_FIN_INTERVENTION vide n'est plus consideree comme une anomalie :
      // on prolonge simplement jusqu'a la fin de periode si possible.
      if (filterEnd) { fin = new Date(filterEnd.getTime()); fin.setHours(23,59,59,0); }
      else return;
    }
    if (!deb) {
      out.sansDebut.push(r);
      if (filterStart) { deb = new Date(filterStart.getTime()); deb.setHours(0,1,0,0); }
      else return;
    }
    if (filterStart && deb < filterStart) { deb = new Date(filterStart.getTime()); deb.setHours(0,1,0,0); }
    if (filterEnd   && fin > filterEnd)   { fin = new Date(filterEnd.getTime());   fin.setHours(23,59,59,0); }

    const dh = (fin - deb) / 3600000;
    if (dh <= 0)             { out.negatif.push(r);  return; }
    if (dh > hoursTotal*1.5) { out.aberrant.push(r); return; }
  });

  return out;
}

// \u2500\u2500 Export XLSX des anomalies : par unite (scope = code unite) ou pour toutes les unites (scope = 'TOTAL') \u2500\u2500
// Habillage "charte SETRAM" : logo, bandeau titre, en-tetes colores, zebrage, filtre auto + feuille de synthese.
