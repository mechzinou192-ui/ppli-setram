/* =========================================================
   PREVENTIF — Page "Preventif" (analyse des BT)
   Extrait de suivi-performances.html (refactor de maintenabilite,
   aucun changement de comportement). Ce fichier est charge en
   <script src="assets/js/preventif.js"> APRES le script principal
   de la page (il utilise des fonctions communes comme debounce,
   getFilters, pct... definies plus haut), donc ces fonctions
   restent globales et disponibles partout comme avant.
   ========================================================= */
const debouncedRenderPreventivePage = debounce(() => renderPreventivePage(), 350);

let PREV_PAGE = 1;
const PREV_PAGE_SIZE = 300;
let PREV_LAST_FILTERED_ROWS = [];

async function exportPreventiveFiltered() {
  const rows = PREV_LAST_FILTERED_ROWS || [];
  if (rows.length === 0) {
    alert('Aucune donnée à exporter sur le périmètre filtré actuel.');
    return;
  }
  const logoBuf = await setramLogoBuffer();
  const wb = new ExcelJS.Workbook(); wb.creator = 'SETRAM — Direction Ingenierie'; wb.created = new Date();
  writeSetramSheet(wb, 'Preventif', rows, { title: 'Maintenance Préventive — Bons de travail filtrés', logoBuf });
  const dstr = new Date().toISOString().slice(0, 10);
  await downloadSetramWorkbook(wb, `Preventif_complet_${dstr}.xlsx`);
}

function renderPreventivePage() {
  const au = document.querySelector('#prev-unit-tabs .tab.active')?.dataset.unit || 'all';
  const { start, end, hoursTotal } = getFilters();

  let rows = [];
  if (au === 'all') UNITS.forEach(u => rows = rows.concat(DB.preventive[u] || []));
  else rows = DB.preventive[au] || [];
  rows = filterByDate(rows, 'DATE_PREVUE', start, end);

  const container = document.getElementById('prev-content');
  if (rows.length === 0) {
    container.innerHTML = `<div class="empty-state"><div class="es-icon">🛡️</div><div class="es-title">Aucune donnée</div></div>`;
    return;
  }

  // ── Collecter hiérarchie pour filtres ──
  const hier = collectEquipHierarchy(rows);
  const fSysteme     = document.getElementById('prev-fil-systeme')?.value     || 'all';
  const fUnite       = document.getElementById('prev-fil-unite')?.value       || 'all';
  const fSousSysteme = document.getElementById('prev-fil-sousSysteme')?.value || 'all';
  const fEquipement  = document.getElementById('prev-fil-equipement')?.value  || 'all';
  const fDuréeMin    = parseFloat(document.getElementById('prev-fil-duree-min')?.value || '0') || 0;
  const fDuréeMax    = parseFloat(document.getElementById('prev-fil-duree-max')?.value || '0') || 0;
  const fSearchCode  = document.getElementById('prev-search-code')?.value || '';
  const fDateStart   = document.getElementById('prev-fil-date-start')?.value || '';
  const fDateEnd     = document.getElementById('prev-fil-date-end')?.value   || '';

  // Appliquer filtres hiérarchiques
  rows = filterByEquipHierarchy(rows, { systeme: fSysteme, unite: fUnite, sousSysteme: fSousSysteme, equipement: fEquipement });

  // Appliquer filtre durée
  if (fDuréeMin > 0 || fDuréeMax > 0) {
    rows = rows.filter(r => {
      const d = parseFloat((r['Durée Intervention (Min)'] || r['Durée Intervention_(Min)'] || '').replace(',', '.'));
      if (isNaN(d)) return true;
      if (fDuréeMin > 0 && d < fDuréeMin) return false;
      if (fDuréeMax > 0 && d > fDuréeMax) return false;
      return true;
    });
  }

  // Appliquer filtre date spécifique (en plus du filtre date global)
  if (fDateStart) {
    const ds = new Date(fDateStart + 'T00:00:00');
    rows = rows.filter(r => { const d = parseDate(r['DATE_PREVUE']); return !d || d >= ds; });
  }
  if (fDateEnd) {
    const de = new Date(fDateEnd + 'T23:59:59');
    rows = rows.filter(r => { const d = parseDate(r['DATE_PREVUE']); return !d || d <= de; });
  }

  // Mémorise le jeu de données filtré complet (toutes lignes, non paginé) pour
  // permettre l'export Excel intégral depuis exportPreventiveFiltered().
  PREV_LAST_FILTERED_ROWS = rows;

  const kpi  = calcKPIs([], rows, hoursTotal, start, end);
  const clos = rows.filter(r => { const s = normState(r['ETAT_BT']); return s.includes('clos') || s.includes('fait'); }).length;
  const aF   = rows.filter(r => normState(r['ETAT_BT']).includes('faire')).length;
  const eC   = rows.filter(r => normState(r['ETAT_BT']).includes('cours')).length;
  const att  = rows.filter(r => normState(r['ETAT_BT']).includes('attente')).length;
  const dH   = sumField(rows, ['Durée Intervention (Min)', 'Durée Intervention_(Min)']) / 60;
  const lH   = sumField(rows, ['Temps Logistique (Min)',   'Temps Logistique_(Min)'])   / 60;

  // ── Calculer durée moyenne par équipement ──
  const equipGroupMap = {};
  rows.forEach(r => {
    const fullCode = (r['CODE_EQUIPEMENT'] || '').trim() || 'Inconnu';
    const parsed   = parseCodeEquipement(fullCode);
    const groupKey = fullCode.replace(/[^a-zA-Z0-9._-]/g, '_');

    // On calcule une seule fois les clés "durée" / "logistique" par ligne et on
    // les met en cache sur la ligne elle-même (__dk__/__lk__) pour éviter de
    // rescanner Object.keys(r) avec des regex une seconde fois plus bas lors
    // de la construction du tableau.
    const keys  = Object.keys(r);
    const dk    = keys.find(k => /dur.*interv|interv.*min/i.test(k));
    const lk    = keys.find(k => /temps.*log|log.*min/i.test(k));
    r.__dk__ = dk;
    r.__lk__ = lk;
    const duree = dk ? parseFloat(String(r[dk]).replace(',', '.')) : NaN;

    if (!equipGroupMap[groupKey]) {
      equipGroupMap[groupKey] = { groupKey, parsed, bts: [], dureeVals: [] };
    }
    equipGroupMap[groupKey].bts.push(r);
    if (!isNaN(duree) && duree > 0) equipGroupMap[groupKey].dureeVals.push(duree);
  });

  Object.keys(equipGroupMap).forEach(k => {
    const g = equipGroupMap[k];
    g.dureeMoy = g.dureeVals.length > 0
      ? g.dureeVals.reduce((s, v) => s + v, 0) / g.dureeVals.length
      : null;
  });

  // ── Options uniques pour selects ──
  const allSystemes     = [...new Set(rows.map(r => parseCodeEquipement(r['CODE_EQUIPEMENT']||'').systeme).filter(s=>s!=='— N/A —'))].sort();
  const allUnites       = hier.unites;
  const allSousSystemes = [...new Set(rows.map(r => parseCodeEquipement(r['CODE_EQUIPEMENT']||'').sousSysteme).filter(s=>s!=='— N/A —'))].sort();

  const mkOpt = (val, label, cur) => `<option value="${val}" ${cur===val?'selected':''}>${label}</option>`;

  // ── Barre de recherche CODE_EQUIPEMENT ──
  const searchBarHtml = `
    <div class="filter-card" style="margin:0 0 10px;width:auto;border-color:rgba(47, 102, 144,0.28);
         background:linear-gradient(135deg,rgba(239,246,255,0.92),rgba(238,242,255,0.88))">
      <div class="fc-icon">🔍</div>
      <div class="filter-group" style="flex:1;max-width:440px">
        <span class="filter-label">Recherche CODE_EQUIPEMENT exact</span>
        <input type="text" id="prev-search-code"
          value="${fSearchCode.replace(/"/g,'&quot;')}"
          placeholder="ex: CFA.STF.ELM.001.002.003"
          oninput="PREV_PAGE=1;debouncedRenderPreventivePage()"
          style="width:100%;background:#f0f6ff;border:1.5px solid #93c5fd;color:#0a1930;
                 padding:8px 13px;border-radius:9px;font-size:12.5px;
                 font-family:'Montserrat',sans-serif;outline:none;font-weight:500;"
          onfocus="this.style.borderColor='#2f6690';this.style.boxShadow='0 0 0 3px rgba(47, 102, 144,0.13)'"
          onblur="this.style.borderColor='#93c5fd';this.style.boxShadow=''">
      </div>
      <div id="prev-search-status"
           style="font-size:11px;color:#2f6690;font-weight:700;white-space:nowrap;
                  display:${fSearchCode?'flex':'none'};align-items:center;gap:6px">
        <span style="width:8px;height:8px;border-radius:50%;background:#2f6690;
                     animation:dot-pulse 2s infinite;display:inline-block"></span>
        <span id="prev-search-status-text">
          ${fSearchCode ? 'Recherche en cours...' : ''}
        </span>
      </div>
      ${fSearchCode ? `
        <button class="btn btn-ghost btn-sm"
          onclick="document.getElementById('prev-search-code').value='';PREV_PAGE=1;renderPreventivePage()">
          ✕ Effacer
        </button>` : ''}
    </div>`;

  // ── Barre de filtres hiérarchiques ──
  const filterBarHtml = `
    <div class="filter-card" style="margin:0 0 18px;width:auto" id="prev-filter-bar">
      <div class="fc-icon">🛡️</div>

      <div class="filter-group">
        <span class="filter-label">Système</span>
        <select id="prev-fil-systeme" onchange="PREV_PAGE=1;renderPreventivePage()"
          style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;
                 border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;
                 cursor:pointer;outline:none;font-weight:500;">
          ${mkOpt('all','Tous',fSysteme)}
          ${allSystemes.map(s=>mkOpt(s,s,fSysteme)).join('')}
        </select>
      </div>

      <div class="filter-group">
        <span class="filter-label">Unité CODE</span>
        <select id="prev-fil-unite" onchange="PREV_PAGE=1;renderPreventivePage()"
          style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;
                 border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;
                 cursor:pointer;outline:none;font-weight:500;">
          ${mkOpt('all','Toutes',fUnite)}
          ${allUnites.map(u=>mkOpt(u,u,fUnite)).join('')}
        </select>
      </div>

      <div class="filter-group">
        <span class="filter-label">Sous-système</span>
        <select id="prev-fil-sousSysteme" onchange="PREV_PAGE=1;renderPreventivePage()"
          style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;
                 border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;
                 cursor:pointer;outline:none;font-weight:500;">
          ${mkOpt('all','Tous',fSousSysteme)}
          ${allSousSystemes.map(s=>mkOpt(s,s,fSousSysteme)).join('')}
        </select>
      </div>

      <div class="filter-group">
        <span class="filter-label">Equipement</span>
        <select id="prev-fil-equipement" onchange="PREV_PAGE=1;renderPreventivePage()"
          style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;
                 border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;
                 cursor:pointer;outline:none;font-weight:500;">
          ${mkOpt('all','Tous',fEquipement)}
          ${hier.equipements.map(e=>mkOpt(e,e,fEquipement)).join('')}
        </select>
      </div>

      <div class="fc-divider"></div>

      <div class="filter-group">
        <span class="filter-label">Début</span>
        <input type="date" id="prev-fil-date-start" value="${fDateStart}"
          onchange="PREV_PAGE=1;renderPreventivePage()"
          style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;
                 border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;outline:none;">
      </div>

      <div class="filter-group">
        <span class="filter-label">Fin</span>
        <input type="date" id="prev-fil-date-end" value="${fDateEnd}"
          onchange="PREV_PAGE=1;renderPreventivePage()"
          style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;
                 border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;outline:none;">
      </div>

      <div class="filter-group">
        <span class="filter-label">Durée max (min)</span>
        <input type="number" id="prev-fil-duree-max" value="${fDuréeMax||''}" placeholder="∞" min="0"
          onchange="PREV_PAGE=1;renderPreventivePage()"
          style="width:70px;background:#f8faff;border:1.5px solid #dde6f5;padding:7px 10px;
                 border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;
                 color:#0a1930;outline:none;">
      </div>

      <div style="margin-left:auto;display:flex;gap:10px;align-items:center">
        <span style="font-size:11px;color:var(--text3);font-style:italic">${rows.length} BT</span>
        <button class="btn btn-ghost btn-sm" onclick="
          document.getElementById('prev-fil-systeme').value='all';
          document.getElementById('prev-fil-unite').value='all';
          document.getElementById('prev-fil-sousSysteme').value='all';
          document.getElementById('prev-fil-equipement').value='all';
          document.getElementById('prev-fil-duree-max').value='';
          document.getElementById('prev-fil-date-start').value='';
          document.getElementById('prev-fil-date-end').value='';
          PREV_PAGE=1;renderPreventivePage()">✕ Reset</button>
      </div>
    </div>`;

  // ── KPIs globaux ──
  const kpiHtml = `
    <div style="display:flex;gap:10px;margin-bottom:14px;flex-wrap:wrap">
      ${ms('Total BT',   rows.length, '')}
      ${ms('Cloturé',  clos,   'rgba(16,185,129,0.3)')}
      ${ms('A Faire',    aF,     'rgba(239,68,68,0.3)')}
      ${ms('En Cours',   eC,     'rgba(59,130,246,0.3)')}
      ${ms('Attente',    att,    'rgba(245,158,11,0.3)')}
      ${ms("Durée d'intervention", dH.toFixed(1)+'h', 'rgba(34,211,238,0.2)')}
      ${ms('Temps Logistique', lH.toFixed(1)+'h', 'rgba(139,92,246,0.3)')}
      ${ms('TMP',        pct(kpi.tmp),       'rgba(16,185,129,0.2)')}
    </div>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap">
      <div style="display:flex;align-items:center;gap:6px;font-size:10.5px;color:var(--text3)">
        <span style="width:12px;height:12px;border-radius:3px;
                     background:rgba(220,38,38,0.18);border:1px solid rgba(220,38,38,0.35);
                     display:inline-block"></span>
        Durée &gt; moy. + 10 min (équipement)
      </div>
      <div style="display:flex;align-items:center;gap:6px;font-size:10.5px;color:var(--text3)">
        <span style="width:12px;height:12px;border-radius:3px;
                     background:rgba(5,150,105,0.18);border:1px solid rgba(5,150,105,0.35);
                     display:inline-block"></span>
        Durée &lt; moy. − 10 min (équipement)
      </div>
      <div style="display:flex;align-items:center;gap:6px;font-size:10.5px;color:var(--text3)">
        <span style="width:12px;height:12px;border-radius:3px;
                     background:transparent;border:1px solid var(--border);
                     display:inline-block"></span>
        Dans la moyenne ± 10 min
      </div>
    </div>`;

  // ── Tableau groupé par équipement, PAGINÉ ──
  // Aucune ligne n'est cachée ou supprimée : la pagination ne fait que limiter
  // le nombre de lignes présentes dans le DOM à un instant T (c'est la seule
  // cause du gel navigateur), tout reste accessible via les boutons de page ou
  // l'export Excel intégral ci-dessous. Les stats/moyennes par équipement
  // restent calculées sur 100% des données filtrées.
  const equipGroups = Object.values(equipGroupMap)
    .sort((a, b) => a.groupKey.localeCompare(b.groupKey));

  // On "aplatit" l'ordre groupe -> BT pour pouvoir découper proprement par page
  const flatOrdered = [];
  equipGroups.forEach(group => {
    group.bts.forEach(r => flatOrdered.push({ r, group }));
  });

  const totalPages = Math.max(1, Math.ceil(flatOrdered.length / PREV_PAGE_SIZE));
  if (PREV_PAGE > totalPages) PREV_PAGE = totalPages;
  if (PREV_PAGE < 1) PREV_PAGE = 1;
  const pageStart = (PREV_PAGE - 1) * PREV_PAGE_SIZE;
  const pageSlice = flatOrdered.slice(pageStart, pageStart + PREV_PAGE_SIZE);

  // Regroupe la tranche de la page courante par équipement, en conservant
  // l'ordre, pour ré-afficher un en-tête de groupe à chaque changement.
  const pageGroupsOrder = [];
  const pageGroupsMap = {};
  pageSlice.forEach(({ r, group }) => {
    if (!pageGroupsMap[group.groupKey]) {
      pageGroupsMap[group.groupKey] = { group, bts: [] };
      pageGroupsOrder.push(group.groupKey);
    }
    pageGroupsMap[group.groupKey].bts.push(r);
  });

  const tableRows = pageGroupsOrder.map(gk => {
    const { group, bts } = pageGroupsMap[gk];
    const { groupKey, parsed, dureeMoy } = group;
    const safeKey = groupKey;
    const uL = (group.bts[0]?.__UNIT__ || '').toLowerCase();

    const totalDurée  = group.dureeVals.reduce((s, v) => s + v, 0);
    const nbBTs       = group.bts.length;
    const nbClos      = group.bts.filter(r => {
      const s = normState(r['ETAT_BT']||'');
      return s.includes('clos') || s.includes('fait');
    }).length;

    const headerRow = `
      <tr style="background:linear-gradient(90deg,rgba(47, 102, 144,0.09),rgba(36, 83, 122,0.05));
                 border-top:2px solid rgba(47, 102, 144,0.20);cursor:pointer"
          onclick="togglePrevGroup('${safeKey}')">
        <td colspan="11" style="padding:10px 14px">
          <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
            <span class="unit-tag bg-${uL} u-${uL}" style="font-size:10px">
              ${bts[0]?.__UNIT__||'—'}
            </span>
            <span style="font-weight:900;font-size:13px;color:#0a1930">${groupKey}</span>
            <span style="font-size:11px;background:linear-gradient(135deg,#ede9fe,#dbeafe);
                         color:#4c1d95;padding:2px 10px;border-radius:8px;font-weight:700">
              ${groupKey.replace(/_/g, '.')}
            </span>
            <span style="margin-left:auto;display:flex;gap:8px;align-items:center">
              <span class="badge badge-blue">${nbBTs} BT</span>
              <span class="badge badge-green">${nbClos} Clos</span>
              ${totalDurée > 0
                ? `<span style="font-size:11px;font-weight:800;color:#2f6690">
                     ${totalDurée.toFixed(0)} min total
                   </span>` : ''}
              ${dureeMoy !== null
                ? `<span style="font-size:10px;color:#6b7fa8">
                     moy: ${dureeMoy.toFixed(0)} min/BT
                   </span>` : ''}
              <!-- Bouton recherche croisée -->
              <button class="btn btn-ghost btn-sm"
                style="font-size:10px;padding:3px 9px;
                       border-color:rgba(47, 102, 144,0.35);color:#2f6690;
                       background:rgba(239,246,255,0.9)"
                onclick="event.stopPropagation();
                         document.getElementById('prev-search-code').value='${groupKey.replace(/_/g,'.')}';
                         renderPreventivePage();
                         document.getElementById('prev-search-results')?.scrollIntoView({behavior:'smooth',block:'start'})">
                🔍 Analyse croisée
              </button>
              <span style="font-size:11px;color:#24537a">▼</span>
            </span>
          </div>
        </td>
      </tr>`;

    const btRows = bts.map(r => {
      const dk       = r.__dk__;
      const lk       = r.__lk__;
      const dureeMin = dk ? parseFloat(String(r[dk]).replace(',', '.')) : NaN;
      const logMin   = lk ? parseFloat(String(r[lk]).replace(',', '.')) : NaN;
      const dureeH   = !isNaN(dureeMin) && dureeMin > 0 ? dureeMin / 60 : 0;
      const logH     = !isNaN(logMin)   && logMin   > 0 ? logMin   / 60 : 0;

      let rowBg    = '';
      let dureeCls = 'color:#0a1930';
      let diffLabel = '';
      if (!isNaN(dureeMin) && dureeMin > 0 && dureeMoy !== null) {
        const diff = dureeMin - dureeMoy;
        if (diff > 10) {
          rowBg     = 'background:rgba(220,38,38,0.07);';
          dureeCls  = 'color:#b91c1c;font-weight:800';
          diffLabel = `<span style="font-size:9px;color:#b91c1c;font-weight:700">
                         +${diff.toFixed(0)}min vs moy
                       </span>`;
        } else if (diff < -10) {
          rowBg     = 'background:rgba(5,150,105,0.07);';
          dureeCls  = 'color:#065f46;font-weight:800';
          diffLabel = `<span style="font-size:9px;color:#065f46;font-weight:700">
                         ${diff.toFixed(0)}min vs moy
                       </span>`;
        }
      }

      const ratio      = (!isNaN(dureeMin) && dureeMin > 0 && !isNaN(logMin) && logMin > 0)
        ? logMin / dureeMin : null;
      const ratioBadge = ratio !== null
        ? `<span class="badge ${ratio > 0.5 ? 'badge-yellow' : 'badge-green'}">
             ${(ratio*100).toFixed(0)}%
           </span>`
        : '<span style="color:var(--text3)">—</span>';

      return `
        <tr class="prev-group-rows-${safeKey}"
            style="${rowBg}transition:filter 0.15s"
            onmouseover="this.style.filter='brightness(0.97)'"
            onmouseout="this.style.filter=''">
          <td style="padding:7px 10px 7px 24px">
            <span style="font-size:10px;background:#dbeafe;color:#1e40af;
                         padding:2px 7px;border-radius:6px;font-weight:700">
              ${r['CODE_BT'] || '—'}
            </span>
          </td>
          <td style="padding:7px 10px;max-width:220px;white-space:normal;
                     font-size:11px;font-weight:500;color:#0f172a">
            ${r['TITRE_BT'] || '—'}
          </td>
          <td style="padding:7px 10px">${stateBadge(r['ETAT_BT'])}</td>
          <td style="padding:7px 10px;font-size:10px;color:#2f6690;font-weight:700">
            ${r['SYSTEME'] || parsed.systeme || '—'}
          </td>
          <td style="padding:7px 10px;font-size:10px">${r['DATE_DEB_INTERVENTION'] || '—'}</td>
          <td style="padding:7px 10px;font-size:10px">${r['DATE_FIN_INTERVENTION']  || '—'}</td>
          <td style="padding:7px 10px;text-align:right">
            <div style="${dureeCls}">
              ${!isNaN(dureeMin) && dureeMin > 0 ? dureeMin.toFixed(0) + ' min' : '—'}
            </div>
            ${dureeH > 0
              ? `<div style="font-size:9px;color:#94a3b8">${dureeH.toFixed(2)}h</div>` : ''}
            ${dureeMoy !== null && !isNaN(dureeMin) && dureeMin > 0
              ? `<div style="font-size:9px;color:#94a3b8;font-style:italic">
                   moy: ${dureeMoy.toFixed(0)}min
                 </div>` : ''}
            ${diffLabel}
          </td>
          <td style="padding:7px 10px;text-align:right">
            <div style="${!isNaN(logMin) && logMin > 480
              ? 'color:#d97706;font-weight:800' : 'color:#0a1930'}">
              ${!isNaN(logMin) && logMin > 0 ? logMin.toFixed(0) + ' min' : '—'}
            </div>
            ${logH > 0
              ? `<div style="font-size:9px;color:#94a3b8">${logH.toFixed(2)}h</div>` : ''}
          </td>
          <td style="padding:7px 10px;text-align:center">${ratioBadge}</td>
          <td style="padding:7px 10px;font-size:10px;color:#6b7fa8">
            ${r['DATE_PREVUE'] || '—'}
          </td>
          <td style="padding:7px 10px">
            <span class="unit-tag bg-${(r.__UNIT__||'').toLowerCase()} u-${(r.__UNIT__||'').toLowerCase()}"
                  style="font-size:10px">${r.__UNIT__||'—'}</span>
          </td>
        </tr>`;
    }).join('');

    const partial = bts.length < group.bts.length;
    const continuationRow = partial ? `
      <tr class="prev-group-rows-${safeKey}">
        <td colspan="11" style="padding:6px 10px 6px 24px;font-size:10.5px;color:var(--text3);font-style:italic">
          … cet équipement continue sur une autre page (${group.bts.length} BT au total pour cet équipement)
        </td>
      </tr>` : '';

    return headerRow + btRows + continuationRow;
  }).join('');

  // ── Barre de pagination (aucune ligne n'est perdue, tout est parcourable) ──
  const pageBtn = (p, label, disabled) => `
    <button class="btn btn-ghost btn-sm" ${disabled ? 'disabled style="opacity:.4;cursor:default"' : ''}
      onclick="PREV_PAGE=${p};renderPreventivePage();document.getElementById('prev-content')?.scrollIntoView({behavior:'smooth',block:'start'})">
      ${label}
    </button>`;
  let pageNumbers = '';
  const winStart = Math.max(1, PREV_PAGE - 2);
  const winEnd   = Math.min(totalPages, PREV_PAGE + 2);
  for (let p = winStart; p <= winEnd; p++) {
    pageNumbers += `<button class="btn btn-sm" style="${p===PREV_PAGE ? 'background:var(--accent);color:#fff;font-weight:800' : ''}"
      onclick="PREV_PAGE=${p};renderPreventivePage();document.getElementById('prev-content')?.scrollIntoView({behavior:'smooth',block:'start'})">${p}</button>`;
  }
  const paginationHtml = `
    <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-top:14px;padding-top:12px;border-top:1px solid var(--border)">
      ${pageBtn(1, '« Début', PREV_PAGE<=1)}
      ${pageBtn(PREV_PAGE-1, '‹ Préc.', PREV_PAGE<=1)}
      ${pageNumbers}
      ${pageBtn(PREV_PAGE+1, 'Suiv. ›', PREV_PAGE>=totalPages)}
      ${pageBtn(totalPages, 'Fin »', PREV_PAGE>=totalPages)}
      <span style="margin-left:8px;font-size:11px;color:var(--text3)">
        Page ${PREV_PAGE}/${totalPages} · ${pageSlice.length} BT affichés sur ${rows.length} au total (rien n'est masqué, tout est consultable ici ou via l'export)
      </span>
      <button class="btn btn-sm" style="margin-left:auto;background:var(--accent);color:#fff;font-weight:700"
        onclick="exportPreventiveFiltered()">⬇️ Exporter Excel — les ${rows.length} lignes</button>
    </div>`;

  const tableHtml = `
    <div style="font-size:11px;color:var(--text2);margin-bottom:10px">
      ${rows.length} BT · page ${PREV_PAGE}/${totalPages}
    </div>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th style="min-width:100px">CODE_BT</th>
            <th style="min-width:200px">TITRE_BT</th>
            <th>ETAT_BT</th>
            <th style="min-width:120px">Système</th>
            <th style="min-width:120px">DATE_DEBUT</th>
            <th style="min-width:120px">DATE_FIN</th>
            <th style="text-align:right;min-width:120px">⭐ Durée Intervention</th>
            <th style="text-align:right;min-width:110px">⭐ Temps Logistique</th>
            <th style="text-align:center;min-width:80px">Ratio Log/Dur</th>
            <th style="min-width:110px">DATE_PREVUE</th>
            <th style="min-width:60px">Unité</th>
          </tr>
        </thead>
        <tbody>${tableRows}</tbody>
      </table>
    </div>
    ${paginationHtml}`;

  // ══════════════════════════════════════════════════════
  // ANALYSE CROISÉE CODE_EQUIPEMENT
  // ══════════════════════════════════════════════════════
  let crossAnalysisHtml = '';

  if (fSearchCode && fSearchCode.trim() !== '') {
    const searchCode = fSearchCode.trim();

    // Chercher dans préventif (toutes unités, sans filtre date pour ne rien rater)
    let allPrevRows = [];
    UNITS.forEach(u => {
      if (au !== 'all' && au !== u) return;
      allPrevRows = allPrevRows.concat(
        filterByDate(DB.preventive[u]||[], 'DATE_PREVUE', start, end).filter(r =>
          (r['CODE_EQUIPEMENT']||'').trim().toLowerCase() === searchCode.toLowerCase()
        )
      );
    });

    // Chercher dans correctif (toutes unités)
    let corrSearchRows = [];
    UNITS.forEach(u => {
      if (au !== 'all' && au !== u) return;
      corrSearchRows = corrSearchRows.concat(
        filterByDate(DB.corrective[u]||[], 'DATE_DI', start, end).filter(r =>
          (r['CODE_EQUIPEMENT']||r['EQUIPEMENT']||'').trim().toLowerCase() === searchCode.toLowerCase()
        )
      );
    });

    const totalFound = allPrevRows.length + corrSearchRows.length;

    // Mettre à jour le compteur de la barre de recherche
    setTimeout(() => {
      const statusEl  = document.getElementById('prev-search-status-text');
      const statusDiv = document.getElementById('prev-search-status');
      if (statusEl)  statusEl.textContent =
        `${totalFound} résultat${totalFound>1?'s':''} — ${allPrevRows.length} BT prév. · ${corrSearchRows.length} DI corr.`;
      if (statusDiv) statusDiv.style.display = 'flex';
    }, 50);

    if (totalFound === 0) {
      crossAnalysisHtml = `
        <div id="prev-search-results"
             style="background:rgba(255,251,235,0.95);border:1.5px solid #fde68a;
                    border-radius:var(--radius);padding:18px 20px;margin-bottom:20px">
          <div style="font-size:13px;font-weight:800;color:#92400e;
                      margin-bottom:6px;display:flex;align-items:center;gap:8px">
            🔍 Aucun résultat pour
            <span style="background:#fef3c7;padding:2px 10px;border-radius:8px;
                         font-family:monospace;letter-spacing:0.5px">${searchCode}</span>
          </div>
          <div style="font-size:12px;color:#78350f">
            Aucune intervention trouvée ni en préventif ni en correctif pour ce code équipement.
          </div>
        </div>`;
    } else {
      // KPIs croisés pour cet équipement
      const crossKpi = calcKPIs(corrSearchRows, allPrevRows, hoursTotal, start, end);

      // ── Tableau Préventif ──
      const prevTableRows = allPrevRows.map(r => {
        const keys2     = Object.keys(r);
        const dk2       = keys2.find(k => /dur.*interv|interv.*min/i.test(k));
        const lk2       = keys2.find(k => /temps.*log|log.*min/i.test(k));
        const dureeMin2 = dk2 ? parseFloat(String(r[dk2]).replace(',', '.')) : NaN;
        const logMin2   = lk2 ? parseFloat(String(r[lk2]).replace(',', '.')) : NaN;
        const dureeH2   = !isNaN(dureeMin2) && dureeMin2 > 0
          ? (dureeMin2/60).toFixed(2)+'h' : '—';
        const logH2     = !isNaN(logMin2) && logMin2 > 0
          ? (logMin2/60).toFixed(2)+'h' : '—';
        const uLP = (r.__UNIT__||'').toLowerCase();
        return `<tr>
          <td>
            <span class="unit-tag bg-${uLP} u-${uLP}" style="font-size:10px">
              ${r.__UNIT__||'—'}
            </span>
          </td>
          <td style="font-size:11px;font-weight:700;color:#2f6690">${r['CODE_BT']||'—'}</td>
          <td style="font-size:11px;max-width:200px;white-space:normal">${r['TITRE_BT']||'—'}</td>
          <td>${stateBadge(r['ETAT_BT'])}</td>
          <td style="font-size:11px">${r['DATE_PREVUE']||'—'}</td>
          <td style="font-size:11px">${r['DATE_DEB_INTERVENTION']||'—'}</td>
          <td style="font-size:11px">${r['DATE_FIN_INTERVENTION']||'—'}</td>
          <td style="text-align:right;font-size:11px;font-weight:700">${dureeH2}</td>
          <td style="text-align:right;font-size:11px">${logH2}</td>
        </tr>`;
      }).join('');

      // ── Tableau Correctif ──
      const corrTableRows = corrSearchRows.map(r => {
        const fin2 = parseDate(r['DATE_FIN_INTERVENTION']);
        const deb2 = parseDate(r['DATE_EVENEMENT']);
        let indH2 = '—'; let indStyle2 = '';
        if (!deb2 || !fin2) {
          indH2 = '⚠️ Dates manquantes'; indStyle2 = 'color:#ef4444;font-size:10px';
        } else if (fin2 <= deb2) {
          indH2 = '⚠️ FIN≤DEB'; indStyle2 = 'color:#ef4444;font-size:10px';
        } else {
          indH2 = ((fin2-deb2)/3600000).toFixed(2)+'h';
        }
        const uLC = (r.__UNIT__||'').toLowerCase();
        return `<tr>
          <td>
            <span class="unit-tag bg-${uLC} u-${uLC}" style="font-size:10px">
              ${r.__UNIT__||'—'}
            </span>
          </td>
          <td style="font-size:11px;font-weight:700;color:#ea580c">${r['CODE_DI']||'—'}</td>
          <td style="font-size:11px;max-width:200px;white-space:normal">${r['TITRE_DI']||'—'}</td>
          <td>${stateBadge(r['ETAT_DI'])}</td>
          <td style="font-size:11px">${r['DATE_DI']||'—'}</td>
          <td style="font-size:11px;${!r['DATE_EVENEMENT']?'color:#ef4444':''}">
            ${r['DATE_EVENEMENT']||'❌ MANQUANT'}
          </td>
          <td style="font-size:11px;${!r['DATE_FIN_INTERVENTION']?'color:#ef4444':''}">
            ${r['DATE_FIN_INTERVENTION']||'❌ MANQUANT'}
          </td>
          <td style="text-align:right;font-size:11px;font-weight:700">
            ${fmtMin(r['Durée Intervention_(Min)']||r['Durée Intervention (Min)'])}
          </td>
          <td style="${indStyle2}">${indH2}</td>
        </tr>`;
      }).join('');

      // ── Badges objectifs ──
      const tauxPBadge = crossKpi.tauxPanne > 0
        ? `<span class="badge ${objClass('tauxPanne',crossKpi.tauxPanne)}" style="font-size:10px">
             ${fmtSciShort(crossKpi.tauxPanne)} ${trendArrow('tauxPanne',crossKpi.tauxPanne)}
           </span>`
        : '<span class="badge badge-gray" style="font-size:10px">0 ⚠️</span>';

      const tauxRBadge = crossKpi.tauxRep > 0
        ? `<span class="badge ${objClass('tauxRep',crossKpi.tauxRep)}" style="font-size:10px">
             ${fmtSciShort(crossKpi.tauxRep)} ${trendArrow('tauxRep',crossKpi.tauxRep)}
           </span>`
        : '<span class="badge badge-gray" style="font-size:10px">—</span>';

      crossAnalysisHtml = `
        <div id="prev-search-results"
             style="position:relative;overflow:hidden;
                    background:linear-gradient(135deg,rgba(47, 102, 144,0.05),rgba(36, 83, 122,0.03));
                    border:2px solid rgba(47, 102, 144,0.22);border-radius:var(--radius);
                    padding:22px;margin-bottom:22px">

          <!-- Barre décorative top -->
          <div style="position:absolute;top:0;left:0;right:0;height:3px;
                      background:linear-gradient(90deg,#2f6690,#24537a,#059669,#ea580c)">
          </div>

          <!-- En-tête -->
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:20px;flex-wrap:wrap">
            <div style="width:46px;height:46px;border-radius:13px;flex-shrink:0;
                        background:linear-gradient(135deg,#2f6690,#24537a);
                        display:flex;align-items:center;justify-content:center;
                        font-size:22px;box-shadow:0 4px 16px rgba(47, 102, 144,0.35)">🔬</div>
            <div>
              <div style="font-family:'Montserrat',sans-serif;font-size:17px;
                          font-weight:900;color:#0a1930;letter-spacing:-0.03em;
                          margin-bottom:5px">
                Analyse Croisée Préventif ↔ Correctif
              </div>
              <div style="display:inline-flex;align-items:center;gap:6px;
                          background:linear-gradient(135deg,#dbeafe,#ede9fe);
                          padding:4px 13px;border-radius:10px;
                          border:1px solid rgba(47, 102, 144,0.2)">
                <span style="font-size:11px;color:#5b21b6;font-weight:700">CODE_EQUIPEMENT</span>
                <span style="font-size:13px;font-weight:900;color:#1e40af;
                             font-family:monospace;letter-spacing:0.5px">${searchCode}</span>
              </div>
            </div>
            <div style="margin-left:auto;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
              <span class="badge badge-blue" style="font-size:11px;padding:4px 10px">
                🛡️ ${allPrevRows.length} BT Préventif
              </span>
              <span class="badge badge-yellow" style="font-size:11px;padding:4px 10px">
                🔧 ${corrSearchRows.length} DI Correctif
              </span>
              <span class="badge badge-gray" style="font-size:11px;padding:4px 10px">
                Σ ${totalFound} interventions
              </span>
            </div>
          </div>

          <!-- KPIs synthèse -->
          <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));
                      gap:10px;margin-bottom:18px">
            ${ms('MTTR',    crossKpi.mttr>0?crossKpi.mttr.toFixed(3)+'h':'—',          'rgba(234,88,12,0.2)')}
            ${ms('MTBF',    crossKpi.mtbf>0&&crossKpi.nbPannesTot>0?crossKpi.mtbf.toFixed(1)+'h':'—', 'rgba(36, 83, 122,0.2)')}
            ${ms('TCP',     pct(crossKpi.tcp),   'rgba(5,150,105,0.2)')}
            ${ms('TCC',     pct(crossKpi.tcc),   'rgba(220,38,38,0.2)')}
            ${ms('TMP',     pct(crossKpi.tmp),   'rgba(5,150,105,0.2)')}
            ${ms('TMC',     pct(crossKpi.tmc),   'rgba(8,145,178,0.2)')}
            ${ms('Dispo',   pct(crossKpi.dispo), 'rgba(217,119,6,0.2)')}
            ${ms('Indispo', crossKpi.indispoH.toFixed(1)+'h', 'rgba(220,38,38,0.15)')}
            ${ms('TBF',     crossKpi.tbf.toFixed(1)+'h',      'rgba(36, 83, 122,0.15)')}
            ${ms('Pannes',  crossKpi.nbPannesTot+' tot / '+crossKpi.nbPannesRep+' rép.', 'rgba(47, 102, 144,0.15)')}
          </div>

          <!-- Fiabilité -->
          <div style="display:flex;gap:14px;flex-wrap:wrap;margin-bottom:20px;
                      padding:13px 16px;background:rgba(255,255,255,0.75);
                      border-radius:12px;border:1px solid rgba(47, 102, 144,0.12)">
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:10px;text-transform:uppercase;letter-spacing:1px;
                           font-weight:700;color:#6b7fa8">λ Taux Défaillance</span>
              ${tauxPBadge}
            </div>
            <div style="width:1px;height:24px;background:var(--border)"></div>
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:10px;text-transform:uppercase;letter-spacing:1px;
                           font-weight:700;color:#6b7fa8">μ Taux Réparation</span>
              ${tauxRBadge}
            </div>
            <div style="width:1px;height:24px;background:var(--border)"></div>
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:10px;text-transform:uppercase;letter-spacing:1px;
                           font-weight:700;color:#6b7fa8">Disponibilité</span>
              <span class="badge ${objClass('dispo',crossKpi.dispo)}">${pct(crossKpi.dispo)}</span>
              ${trendArrow('dispo',crossKpi.dispo)}
            </div>
            <div style="width:1px;height:24px;background:var(--border)"></div>
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:10px;text-transform:uppercase;letter-spacing:1px;
                           font-weight:700;color:#6b7fa8">H Total</span>
              <span style="font-size:12px;font-weight:800;color:#0a1930">
                ${(crossKpi.hPrev + crossKpi.hCorr).toFixed(1)}h
              </span>
            </div>
          </div>

          <!-- Tableau BT Préventifs -->
          <div style="margin-bottom:18px">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
              <span style="width:4px;height:18px;background:#059669;
                           border-radius:2px;flex-shrink:0"></span>
              <span style="font-size:12px;font-weight:800;color:#059669;
                           text-transform:uppercase;letter-spacing:1px">
                🛡️ Bons de Travaux Préventifs (${allPrevRows.length})
              </span>
            </div>
            ${allPrevRows.length > 0 ? `
            <div class="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Unité</th>
                    <th>CODE_BT</th>
                    <th>TITRE_BT</th>
                    <th>ETAT_BT</th>
                    <th>DATE_PREVUE</th>
                    <th>DATE_DEBUT</th>
                    <th>DATE_FIN</th>
                    <th style="text-align:right">Durée Interv.</th>
                    <th style="text-align:right">Logistique</th>
                  </tr>
                </thead>
                <tbody>${prevTableRows}</tbody>
              </table>
            </div>` : `
            <div style="padding:12px 16px;background:rgba(5,150,105,0.06);
                        border-radius:10px;border:1px solid rgba(5,150,105,0.2);
                        font-size:12px;color:#059669;font-weight:600">
              Aucun BT préventif trouvé pour cet équipement dans la période sélectionnée.
            </div>`}
          </div>

          <!-- Tableau DI Correctifs -->
          <div>
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
              <span style="width:4px;height:18px;background:#ea580c;
                           border-radius:2px;flex-shrink:0"></span>
              <span style="font-size:12px;font-weight:800;color:#ea580c;
                           text-transform:uppercase;letter-spacing:1px">
                🔧 Demandes d'Intervention Correctives (${corrSearchRows.length})
              </span>
            </div>
            ${corrSearchRows.length > 0 ? `
            <div class="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Unité</th>
                    <th>CODE_DI</th>
                    <th>TITRE_DI</th>
                    <th>ETAT_DI</th>
                    <th>DATE_DI</th>
                    <th>DATE_EVENEMENT</th>
                    <th>DATE_FIN_INTERV.</th>
                    <th style="text-align:right">Durée</th>
                    <th style="text-align:right">Indispo</th>
                  </tr>
                </thead>
                <tbody>${corrTableRows}</tbody>
              </table>
            </div>` : `
            <div style="padding:12px 16px;background:rgba(234,88,12,0.06);
                        border-radius:10px;border:1px solid rgba(234,88,12,0.2);
                        font-size:12px;color:#ea580c;font-weight:600">
              Aucune DI corrective trouvée pour cet équipement dans la période sélectionnée.
            </div>`}
          </div>

        </div>`;
    }
  }

  container.innerHTML = searchBarHtml + crossAnalysisHtml + filterBarHtml + kpiHtml + tableHtml;
}

// ── Toggle dépliage des BT par équipement ──
function togglePrevGroup(safeKey) {
  const rows = document.querySelectorAll(`.prev-group-rows-${safeKey}`);
  if (!rows.length) return;
  const isVisible = rows[0].style.display !== 'none';
  rows.forEach(r => r.style.display = isVisible ? 'none' : '');
}
