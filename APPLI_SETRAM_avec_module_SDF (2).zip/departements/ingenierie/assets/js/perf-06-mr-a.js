// =============================================================================
// SUIVI DES PERFORMANCES — module 06/10 : perf-06-mr-a.js
// Extrait mecaniquement (meme code, meme ordre) du script principal historique
// pour ameliorer la maintenabilite (le fichier faisait ~8300 lignes en un bloc).
// Contenu : Materiel Roulant (MR) : import/parsing fichiers GMAO, rendu accordeon par unite, graphiques, export matrice - debut module MPU/TCU (MRMT)
// IMPORTANT : ce fichier partage la portee globale avec les autres modules
// perf-XX-*.js et doit rester charge dans l'ORDRE (01 -> 10), car certaines
// fonctions utilisent des constantes/fonctions definies dans les modules precedents.
// =============================================================================
function parseCodeEquipement(code) {
  if (!code || String(code).trim() === '') {
    return { systeme: '— N/A —', unite: '— N/A —', sousSysteme: '— N/A —', equipement: '— N/A —', raw: code };
  }
  const parts = String(code).trim().split('.');
  return {
    systeme:     parts[0] || '— N/A —',
    unite:       parts[1] || '— N/A —',
    sousSysteme: parts[2] || '— N/A —',
    equipement:  parts.slice(3).join('.') || '— N/A —',
    raw:         code
  };
}


// =====================================================================
// MR — RAMES : occurrences brutes + occurrences normalisees (fuzzy)
// =====================================================================

// =====================================================================
// MR — STOCKAGE PROPRE (fichiers independants, pas DB.corrective)
// =====================================================================
// =====================================================================
// MR — STOCKAGE & CONSTANTES
// =====================================================================
const MR_DB = { rows: [], files: [] };

const MR_UNIT_KEYWORDS = {
  ALG: ['ALG','ALGER'], ORN: ['ORN','ORAN'], SBA: ['SBA','SIDI'],
  CST: ['CST','CONSTANTINE'], STF: ['STF','SETIF','SÉTIF'],
  ORG: ['ORG','OUARGLA'], MGM: ['MGM','MOSTAGANEM']
};
const MR_UNIT_COLORS = {
  ALG:'#2f6690', ORN:'#d97706', SBA:'#24537a',
  CST:'#059669', STF:'#dc2626', ORG:'#0891b2', MGM:'#db2777'
};
const MR_UNITS_LIST = ['ALG','ORN','SBA','CST','STF','ORG','MGM'];

// Extraction rame depuis CODE_EQUIPEMENT (ex: MR.STF1.R121.M1 → R121).
// Si absent du code (ex: MR.ALG1), on cherche en secours dans TITRE_DI/COMMENTAIRE_DI
// (ex: "Rame150C/5 injecteurs de sable bouchés" → R150). Si introuvable dans les deux,
// retourne null : la DI est alors exclue des calculs par rame (pas de "rame INCONNUE").
function mrExtractRame(code, texteSecours) {
  const fromCode = code ? String(code).match(/\bR(\d+)\b/i) : null;
  if (fromCode) return 'R' + fromCode[1];
  if (texteSecours) {
    const fromTexte = String(texteSecours).match(/\bRame\s*n?°?\s*(\d+)/i);
    if (fromTexte) return 'R' + fromTexte[1];
  }
  return null;
}

// Détection unité depuis nom de fichier
function mrDetectUnit(filename) {
  const up = filename.toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  for (const [uid, kws] of Object.entries(MR_UNIT_KEYWORDS)) {
    if (kws.some(k => up.includes(k))) return uid;
  }
  return null;
}

// Extraction type de panne depuis TITRE_DI / COMMENTAIRE_DI
const MR_FAULT_KW = [
  [/communication.*(hs|hors service)|perte communication|d[ée]faut communication/i, 'Communication HS'],
  [/klaxon/i, 'Klaxon HS'],
  [/frein/i, 'Défaut freins'],
  [/afficheur/i, 'Défaut afficheur'],
  [/convertisseur statique|\bcvs\b/i, 'Défaut CVS'],
  [/tachym[èe]tre/i, 'Tachymètre'],
  [/feu de croisement|[ée]clairage|\blampe\b/i, 'Éclairage'],
  [/\bsae\b/i, 'SAE'],
  [/\bihm\b/i, 'IHM'],
  [/\bporte[s]?\b/i, 'Porte'],
  [/climatisation|\bclim\b/i, 'Climatisation'],
  [/pantograph/i, 'Pantographe'],
  [/bogie/i, 'Bogie'],
  [/bruit anormal/i, 'Bruit anormal'],
  [/vp\s*\d+k|visite pr[ée]ventive/i, 'Visite préventive'],
  [/tache|peinture|vitre|carrosserie/i, 'Esthétique'],
];
function mrExtractFaultType(titre, commentaire) {
  const text = String(titre || commentaire || '').trim();
  if (!text) return 'Non spécifié';
  const ios = text.match(/IOS\s*(?:FT\s*)?(\d+)/i);
  if (ios) return 'IOS ' + ios[1];
  for (const [re, label] of MR_FAULT_KW) { if (re.test(text)) return label; }
  return 'Autre';
}

// =====================================================================
// IMPORT MR
// =====================================================================
function setupMRImport() {
  const btnLoad  = document.getElementById('mr-btn-load');
  const btnClear = document.getElementById('mr-btn-clear');
  const input    = document.getElementById('mr-file-input');
  const dz       = document.getElementById('mr-drop-zone');
  if (!btnLoad || !input) return;
  btnLoad.addEventListener('click', () => input.click());
  input.addEventListener('change', e => mrHandleFiles(Array.from(e.target.files)));
  btnClear.addEventListener('click', () => {
    if (!confirm('Effacer toutes les données MR ?')) return;
    MR_DB.rows = []; MR_DB.files = [];
    mrUpdateStatus(); renderMRPage();
    showToast('🗑️ Données MR effacées', '');
  });
  dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('drag-over'); });
  dz.addEventListener('dragleave', () => dz.classList.remove('drag-over'));
  dz.addEventListener('drop', e => { e.preventDefault(); dz.classList.remove('drag-over'); mrHandleFiles(Array.from(e.dataTransfer.files)); });
  dz.addEventListener('click', () => input.click());
}

function mrHandleFiles(files) {
  if (!files.length) return;
  showLoading();
  let pending = files.length;
  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const data = new Uint8Array(e.target.result);
        // ✅ FIX TIMEZONE : cellDates:false + dateNF avec heure
        // Évite le décalage UTC+1 (Algérie) qui excluait les DI à minuit
        const wb = XLSX.read(data, { type:'array', cellDates:false });
        const sh   = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sh, {
          raw: false,
          defval: '',
          dateNF: 'dd/mm/yyyy hh:mm:ss'   // ← dates converties en STRING locale
        });
        if (!rows.length) { showToast(`⚠️ ${file.name} vide`, 'warn'); }
        else {
          const uid = mrDetectUnit(file.name);
          const cleaned = rows.map(r => {
            const nr = {}; Object.keys(r).forEach(k => { nr[k.trim()] = r[k]; });
            nr.__UNIT__      = uid || '—';
            nr.__RAME__      = mrExtractRame(nr.CODE_EQUIPEMENT || nr.EQUIPEMENT || '', nr.TITRE_DI || nr.TITRE || nr.COMMENTAIRE_DI || '');
            nr.__FAULT__     = mrExtractFaultType(nr.TITRE_DI || nr.TITRE, nr.COMMENTAIRE_DI);
            nr.__DATE__      = mrParseDate(nr.DATE_EVENEMENT || nr.DATE_DI || '');
            return nr;
          });
          MR_DB.rows = MR_DB.rows.concat(cleaned);
          MR_DB.files.push(file.name);
          showToast(`✅ ${file.name} — ${cleaned.length} DI${uid ? ' → ' + uid : ''}`, 'success');
        }
      } catch (err) { showToast(`❌ ${file.name} : ${err.message}`, 'error'); }
      pending--;
      if (pending === 0) { hideLoading(); mrUpdateStatus(); mrBuildRameSelect(); renderMRPage(); }
    };
    reader.readAsArrayBuffer(file);
  });
}

function mrParseDate(v) {
  if (v === null || v === undefined || v === '') return null;

  // Cas 1 : déjà un objet Date (cas normal avec cellDates:true)
  if (v instanceof Date) return isNaN(v) ? null : v;

  // Cas 2 : nombre de série Excel brut (ex: 46174 = date "ronde" sans heure,
  // parfois non converti en Date par SheetJS pour les valeurs entières)
  if (typeof v === 'number') {
    const d = new Date(Math.round((v - 25569) * 86400 * 1000));
    return isNaN(d) ? null : d;
  }

  // Cas 3 : chaîne de texte (formats DD/MM/YYYY, etc.)
  const d = parseDate(v);
  return d;
}

function mrUpdateStatus() {
  const el = document.getElementById('mr-import-status');
  if (el) el.textContent = MR_DB.files.length > 0
    ? `${MR_DB.files.length} fichier(s) — ${MR_DB.rows.length} DI : ${MR_DB.files.join(', ')}`
    : '';
}

function mrBuildRameSelect() {
  const sel = document.getElementById('mr-rame-filter');
  if (!sel) return;
  const cur = sel.value;
  sel.innerHTML = '<option value="ALL">Toutes les rames</option>';
  const rames = [...new Set(MR_DB.rows.map(r => r.__RAME__).filter(Boolean))].sort((a,b)=>{
    const na = parseInt(a.replace(/\D/g,''))||0, nb = parseInt(b.replace(/\D/g,''))||0;
    return na - nb;
  });
  rames.forEach(r => { const o = document.createElement('option'); o.value = r; o.text = r; sel.appendChild(o); });
  if (cur) sel.value = cur;
}

// =====================================================================
// FILTRES MR
// =====================================================================

function mrDateOnlyKey(d) {
  if (!d) return null;
  const y   = d.getFullYear();
  const m   = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
function mrGetFiltered() {
  const fromV = document.getElementById('mr-date-start')?.value;
  const toV   = document.getElementById('mr-date-end')?.value;
  const uoF   = document.getElementById('mr-uo-filter')?.value || 'ALL';
  const rameF = document.getElementById('mr-rame-filter')?.value || 'ALL';
  return MR_DB.rows.filter(r => {
    if (uoF !== 'ALL' && r.__UNIT__ !== uoF) return false;
    if (rameF !== 'ALL' && r.__RAME__ !== rameF) return false;
    if (fromV || toV) {
      const dayKey = mrDateOnlyKey(r.__DATE__);
      if (!dayKey) return false;
      if (fromV && dayKey < fromV) return false;
      if (toV   && dayKey > toV)   return false;
    }
    return true;
  });
}

// Même chose mais sans filtre UO (pour analyse communes)

function mrGetFilteredAllUnits() {
  const fromV = document.getElementById('mr-date-start')?.value;
  const toV   = document.getElementById('mr-date-end')?.value;
  const rameF = document.getElementById('mr-rame-filter')?.value || 'ALL';
  return MR_DB.rows.filter(r => {
    if (rameF !== 'ALL' && r.__RAME__ !== rameF) return false;
    if (fromV || toV) {
      const dayKey = mrDateOnlyKey(r.__DATE__);
      if (!dayKey) return false;
      if (fromV && dayKey < fromV) return false;
      if (toV   && dayKey > toV)   return false;
    }
    return true;
  });
}

// =====================================================================
// RENDER PAGE MR PRINCIPALE
// =====================================================================
let mrChartCommon = null, mrChartSpecific = null;

function renderMRPage() {
  const hasData = MR_DB.rows.length > 0;
  
  // ── Cacher/Afficher la zone import selon les données ──
  const importZone = document.getElementById('mr-import-zone');
  if (importZone) importZone.style.display = hasData ? 'none' : '';

  if (!hasData) {
    document.getElementById('mr-kpi-row').style.display = 'none';
    document.getElementById('mr-common-section').style.display = 'none';
    document.getElementById('mr-units-accordion').innerHTML = '';
    document.getElementById('mr-content').innerHTML = '';
    mrUpdateDateLabel();
    return;
  }

  mrUpdateDateLabel();
  mrBuildRameSelect();

  const fd      = mrGetFiltered();
  const fdAll   = mrGetFilteredAllUnits();

  // ── KPIs ──
  const rameMap = {};
  fd.forEach(r => {
    if (!r.__RAME__) return; // rame non identifiable (ni code équipement ni titre DI) : exclue du calcul
    const rame = r.__RAME__;
    if (!rameMap[rame]) rameMap[rame] = 0;
    rameMap[rame]++;
  });
  const sortedRames = Object.entries(rameMap).sort((a,b) => b[1]-a[1]);
  const topRame     = sortedRames[0];

  // Analyse pannes communes (toutes UO)
  const faultMatrix = {};
  fdAll.forEach(r => {
    const ft = r.__FAULT__ || 'Non spécifié';
    if (!faultMatrix[ft]) faultMatrix[ft] = {};
    const uid = r.__UNIT__ || '—';
    faultMatrix[ft][uid] = (faultMatrix[ft][uid] || 0) + 1;
  });
  const faultEnriched = Object.entries(faultMatrix).map(([ft, uMap]) => {
    const uids    = Object.keys(uMap).filter(u => MR_UNITS_LIST.includes(u));
    const total   = Object.values(uMap).reduce((s,v)=>s+v,0);
    return { ft, uMap, nbUnits: uids.length, total };
  }).sort((a,b) => b.total - a.total);

  const commonFaults   = faultEnriched.filter(e => e.nbUnits >= 2);
  const specificFaults = faultEnriched.filter(e => e.nbUnits === 1);

  document.getElementById('mr-kpi-row').style.display = '';
  document.getElementById('mr-kpi-total').textContent    = fd.length.toLocaleString('fr');
  document.getElementById('mr-kpi-rames').textContent    = Object.keys(rameMap).length;
  document.getElementById('mr-kpi-top-rame').textContent = topRame ? topRame[0] : '—';
  document.getElementById('mr-kpi-top-sub').textContent  = topRame ? topRame[1] + ' pannes' : '—';
  document.getElementById('mr-kpi-common').textContent   = commonFaults.length;
  document.getElementById('mr-kpi-specific').textContent = specificFaults.length;

  // ── Accordéon ──
  mrBuildAccordion(fd);

  // ── Section pannes communes ──
  if (fdAll.length > 0) {
    document.getElementById('mr-common-section').style.display = '';
    mrRenderCommonCharts(commonFaults, specificFaults);
    mrRenderMatrix(faultEnriched);
  } else {
    document.getElementById('mr-common-section').style.display = 'none';
  }
}

function mrUpdateDateLabel() {
  const fromV = document.getElementById('mr-date-start')?.value;
  const toV   = document.getElementById('mr-date-end')?.value;
  const lbl   = document.getElementById('mr-date-range-label');
  if (!lbl) return;
  if (!fromV || !toV) { lbl.textContent = '—'; return; }
  const from = new Date(fromV), to = new Date(toV);
  const days = Math.max(1, Math.round((to - from) / 86400000) + 1);
  lbl.textContent = `${from.toLocaleDateString('fr-FR',{day:'2-digit',month:'short',year:'numeric'})} → ${to.toLocaleDateString('fr-FR',{day:'2-digit',month:'short',year:'numeric'})} · ${days}j`;
}

// =====================================================================
// ACCORDÉON 7 UNITÉS
// =====================================================================
function mrBuildAccordion(fd) {
  const acc = document.getElementById('mr-units-accordion');
  acc.innerHTML = MR_UNITS_LIST.map(u => {
    const uRows = fd.filter(r => r.__UNIT__ === u);
    const uL    = u.toLowerCase();
    const color = MR_UNIT_COLORS[u] || '#888';
    return `
      <div class="kpi-section" id="mr-sec-${u}" style="--active-color:${color}">
        <div class="kpi-header" onclick="mrToggleUnit('${u}')">
          <div class="kpi-header-left">
            <span class="kpi-badge" style="background:${color};box-shadow:0 0 8px ${color}"></span>
            <div>
              <div class="kpi-name">
                <span class="unit-tag bg-${uL} u-${uL}" style="font-size:11px;margin-right:6px">${u}</span>
                MR ${u} — Matériel Roulant
              </div>
              <div class="kpi-desc">Pannes par rame · Classement · Types de pannes normalisés</div>
            </div>
          </div>
          <div class="kpi-peek">
            <div style="text-align:right">
              <div class="peek-val" style="color:${color}">${uRows.length}</div>
              <div class="peek-lbl">DI sur la période</div>
            </div>
          </div>
          <div class="toggle-sw" style="margin-left:12px">
            <input type="checkbox" id="mr-sw-${u}" onclick="event.stopPropagation();mrToggleUnit('${u}')">
            <div class="sw-track"></div><div class="sw-thumb"></div>
          </div>
        </div>
        <div class="kpi-body" id="mr-body-${u}">
          <div id="mr-unit-content-${u}"></div>
        </div>
      </div>`;
  }).join('');
}

function mrToggleUnit(unit) {
  const body = document.getElementById(`mr-body-${unit}`);
  const sw   = document.getElementById(`mr-sw-${unit}`);
  if (!body) return;
  const opening = !body.classList.contains('open');
  body.classList.toggle('open', opening);
  if (sw) sw.checked = opening;
  if (opening) mrRenderUnitDetail(unit);
}

// =====================================================================
// DÉTAIL D'UNE UNITÉ : rames + types de pannes
// =====================================================================
function mrRenderUnitDetail(unit) {
  const target = document.getElementById(`mr-unit-content-${unit}`);
  if (!target) return;
  const fd    = mrGetFiltered().filter(r => r.__UNIT__ === unit);
  const color = MR_UNIT_COLORS[unit] || '#888';
  const uL    = unit.toLowerCase();

  if (!fd.length) {
    target.innerHTML = `<div class="empty-state" style="padding:28px 10px">
      <div class="es-icon">🚆</div>
      <div class="es-title">Aucune DI pour MR ${unit} sur cette période</div>
    </div>`;
    return;
  }

  // ── Rames ──
  const rameMap = {};
  fd.forEach(r => {
    if (!r.__RAME__) return; // rame non identifiable (ni code équipement ni titre DI) : exclue du calcul
    const rame = r.__RAME__;
    if (!rameMap[rame]) rameMap[rame] = { count:0, code:r.CODE_EQUIPEMENT || r.EQUIPEMENT || '' };
    rameMap[rame].count++;
  });
  const rameList  = Object.entries(rameMap).sort((a,b) => b[1].count - a[1].count);
  const maxCount  = rameList[0]?.[1].count || 1;

  // ── Types de pannes ──
  const faultMap = {};
  fd.forEach(r => {
    const ft = r.__FAULT__ || 'Non spécifié';
    faultMap[ft] = (faultMap[ft] || 0) + 1;
  });
  const faultList = Object.entries(faultMap).sort((a,b) => b[1]-a[1]);
  const maxFault  = faultList[0]?.[1] || 1;

  target.innerHTML = `
    <div class="grid-2" style="margin-bottom:0">

      <!-- TABLEAU RAMES -->
      <div class="card">
        <div class="card-title" style="color:${color}">
          🚆 Classement des rames — MR ${unit}
          <span class="badge badge-blue" style="margin-left:8px">${fd.length} DI · ${rameList.length} rames</span>
        </div>
        <div class="table-wrap" style="max-height:400px">
          <table>
            <thead>
              <tr>
                <th>#</th><th>Rame</th><th>Code équipement</th>
                <th style="text-align:center">Nb pannes</th>
                <th style="min-width:120px">Répartition</th>
                <th style="text-align:center">%</th>
              </tr>
            </thead>
            <tbody>
              ${rameList.map(([rame, rv], i) => `
                <tr>
                  <td style="color:var(--text3);font-size:11px">${i+1}</td>
                  <td><span class="unit-tag bg-${uL} u-${uL}" style="font-size:12px;font-weight:800">${rame}</span></td>
                  <td style="font-size:10px;color:#6b7fa8;font-family:monospace">${rv.code}</td>
                  <td style="text-align:center;font-weight:800;font-size:14px;color:${color}">${rv.count}</td>
                  <td>
                    <div style="height:7px;background:var(--border);border-radius:4px;overflow:hidden">
                      <div style="height:100%;border-radius:4px;background:${color};width:${(rv.count/maxCount*100).toFixed(1)}%;transition:width .6s ease"></div>
                    </div>
                  </td>
                  <td style="text-align:center;font-size:11px;color:#6b7fa8">${(rv.count/fd.length*100).toFixed(1)}%</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- TABLEAU TYPES DE PANNES -->
      <div class="card">
        <div class="card-title" style="color:${color}">
          🔍 Types de pannes normalisés — MR ${unit}
          <span class="badge badge-gray" style="margin-left:8px">${faultList.length} types</span>
        </div>
        <div class="table-wrap" style="max-height:400px">
          <table>
            <thead>
              <tr>
                <th>#</th><th>Type de panne</th>
                <th style="text-align:center">Occurrences</th>
                <th style="min-width:100px">Fréquence</th>
              </tr>
            </thead>
            <tbody>
              ${faultList.map(([ft, cnt], i) => `
                <tr>
                  <td style="color:var(--text3);font-size:11px">${i+1}</td>
                  <td style="font-weight:600;font-size:12px;max-width:260px;white-space:normal">${ft}</td>
                  <td style="text-align:center;font-weight:800;color:${color}">${cnt}</td>
                  <td>
                    <div style="height:6px;background:var(--border);border-radius:3px;overflow:hidden">
                      <div style="height:100%;border-radius:3px;background:linear-gradient(90deg,${color},${color}88);width:${(cnt/maxFault*100).toFixed(1)}%"></div>
                    </div>
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>

    </div>`;
}

// =====================================================================
// GRAPHIQUES PANNES COMMUNES / SPÉCIFIQUES
// =====================================================================
function mrRenderCommonCharts(commonFaults, specificFaults) {
  // Chart pannes communes
  if (mrChartCommon) { mrChartCommon.destroy(); mrChartCommon = null; }
  const top10Common = commonFaults.slice(0, 10);
  const elC = document.getElementById('mr-chart-common');
  if (elC && top10Common.length) {
    mrChartCommon = new Chart(elC, {
      type: 'bar',
      data: {
        labels: top10Common.map(e => e.ft),
        datasets: MR_UNITS_LIST.map(u => ({
          label: 'MR ' + u,
          data: top10Common.map(e => e.uMap[u] || 0),
          backgroundColor: MR_UNIT_COLORS[u] + 'cc'
        }))
      },
      options: {
        indexAxis: 'y', responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position:'bottom', labels:{ font:{size:9}, boxWidth:9, padding:6 } } },
        scales: {
          x: { stacked:true, beginAtZero:true, ticks:{ precision:0, font:{size:10} } },
          y: { stacked:true, ticks:{ font:{size:10} } }
        }
      }
    });
  }

  // Chart pannes spécifiques
  if (mrChartSpecific) { mrChartSpecific.destroy(); mrChartSpecific = null; }
  const top10Spec = specificFaults.slice(0, 10);
  const elS = document.getElementById('mr-chart-specific');
  if (elS && top10Spec.length) {
    mrChartSpecific = new Chart(elS, {
      type: 'bar',
      data: {
        labels: top10Spec.map(e => e.ft + ' (' + Object.keys(e.uMap)[0] + ')'),
        datasets: [{
          label: 'Occurrences',
          data: top10Spec.map(e => e.total),
          backgroundColor: top10Spec.map(e => MR_UNIT_COLORS[Object.keys(e.uMap)[0]] + 'cc' || '#888cc'),
          borderRadius: 5
        }]
      },
      options: {
        indexAxis: 'y', responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display:false } },
        scales: {
          x: { beginAtZero:true, ticks:{ precision:0, font:{size:10} } },
          y: { ticks:{ font:{size:10} } }
        }
      }
    });
  }
}

// =====================================================================
// EXPORT COMPLET DE LA MATRICE PANNES × UNITÉS (toutes les lignes, XLSX)
// =====================================================================
async function mrExportMatrixXLSX(faultEnriched) {
  if (!faultEnriched || !faultEnriched.length) {
    alert("Aucune donnée à exporter.");
    return;
  }
  showLoading();
  try {
    const logoBuf = await setramLogoBuffer();
    const wb = new ExcelJS.Workbook();
    wb.creator = 'SETRAM — Direction Ingenierie';
    wb.created = new Date();

    const headers = ['Type de panne', ...MR_UNITS_LIST, 'Total', 'Nb unités'];
    const rows = faultEnriched.map(e => {
      const row = { 'Type de panne': e.ft };
      MR_UNITS_LIST.forEach(u => { row[u] = e.uMap[u] || 0; });
      row['Total'] = e.total;
      row['Nb unités'] = e.nbUnits;
      return row;
    });

    writeSetramSheet(wb, 'Matrice pannes', rows, {
      title: '🗺 Matrice Type de Panne × Unité',
      subtitle: `Export complet — ${faultEnriched.length} type(s) de panne`,
      headers,
      logoBuf
    });

    const dstr = new Date().toISOString().slice(0, 10);
    await downloadSetramWorkbook(wb, `Matrice_Type_Panne_Unite_${dstr}.xlsx`);
  } catch (e) {
    console.error(e);
    alert("Erreur lors de l'export : " + e.message);
  } finally {
    hideLoading();
  }
}

// =====================================================================
// MATRICE PANNES × UNITÉS
// =====================================================================
const MR_MATRIX_PAGE_SIZE = 50;
let mrMatrixCurrentPage = 1;

function mrRenderMatrix(faultEnriched) {
  const head = document.getElementById('mr-matrix-head');
  const body = document.getElementById('mr-matrix-body');
  if (!head || !body) return;

  window._mrMatrixFullData = faultEnriched;
  mrMatrixCurrentPage = 1;

  head.innerHTML = '<th style="text-align:left;padding:8px 10px;font-size:11px;font-weight:700;color:#5a6e96;border-bottom:2px solid var(--border)">Type de panne</th>' +
    MR_UNITS_LIST.map(u => `<th style="text-align:center;padding:8px 10px;font-size:10px;font-weight:700;color:${MR_UNIT_COLORS[u]};border-bottom:2px solid var(--border)">
      <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:${MR_UNIT_COLORS[u]};margin-right:4px"></span>${u}</th>`).join('') +
    '<th style="text-align:center;padding:8px 10px;font-size:10px;font-weight:700;color:#5a6e96;border-bottom:2px solid var(--border)">Total</th>';

  mrRenderMatrixPage(1);
}

function mrRenderMatrixPage(page) {
  const faultEnriched = window._mrMatrixFullData || [];
  const body = document.getElementById('mr-matrix-body');
  const pagerEl = document.getElementById('mr-matrix-pagination');
  if (!body) return;

  const totalPages = Math.max(1, Math.ceil(faultEnriched.length / MR_MATRIX_PAGE_SIZE));
  page = Math.min(Math.max(1, page), totalPages);
  mrMatrixCurrentPage = page;

  const start = (page - 1) * MR_MATRIX_PAGE_SIZE;
  const pageRows = faultEnriched.slice(start, start + MR_MATRIX_PAGE_SIZE);

  body.innerHTML = pageRows.map(e => {
    const isCommon = e.nbUnits >= 2;
    const rowStyle = isCommon
      ? 'background:rgba(255,243,224,0.7);border-left:3px solid #e85d26'
      : '';
    const cells = MR_UNITS_LIST.map(u => {
      const v = e.uMap[u] || 0;
      if (!v) return `<td style="text-align:center;color:#d0d5e0;padding:6px 8px">—</td>`;
      const intensity = v >= 5
        ? `background:#fde0d0;color:#b8420a;font-weight:800`
        : v >= 2
          ? `background:#fff3e0;color:#b85c00;font-weight:700`
          : `color:#1a1a1a`;
      return `<td style="text-align:center;padding:6px 8px">
        <span style="display:inline-block;min-width:22px;padding:2px 5px;border-radius:5px;${intensity}">${v}</span>
      </td>`;
    }).join('');
    return `<tr style="${rowStyle};transition:background .15s" onmouseover="this.style.filter='brightness(0.97)'" onmouseout="this.style.filter=''">
      <td style="padding:7px 10px;font-size:12px;font-weight:${isCommon?700:500};max-width:280px;white-space:normal">
        ${isCommon ? `<span style="display:inline-block;font-size:9px;font-weight:700;padding:1px 6px;border-radius:10px;background:#e85d26;color:#fff;margin-right:6px">${e.nbUnits} UO</span>` : ''}
        ${e.ft}
      </td>
      ${cells}
      <td style="text-align:center;padding:6px 8px;font-weight:800;color:#1a2744">${e.total}</td>
    </tr>`;
  }).join('');

  if (pagerEl) mrRenderMatrixPager(pagerEl, page, totalPages, faultEnriched.length);
}

// Construit la barre de pagination (Précédent / numéros de page / Suivant + bouton export global)
function mrRenderMatrixPager(pagerEl, page, totalPages, totalRows) {
  if (totalPages <= 1) { pagerEl.innerHTML = ''; return; }

  const btnStyle = (active) => `cursor:pointer;border:1px solid ${active ? '#2f6690' : '#d7e1ee'};padding:5px 11px;border-radius:6px;background:${active ? '#2f6690' : '#fff'};color:${active ? '#fff' : '#3a4a68'};font-size:11px;font-weight:700`;

  let pages = [];
  for (let p = 1; p <= totalPages; p++) pages.push(p);
  // Si trop de pages, on n'affiche qu'une fenêtre autour de la page courante
  if (totalPages > 9) {
    pages = [1];
    const lo = Math.max(2, page - 2), hi = Math.min(totalPages - 1, page + 2);
    if (lo > 2) pages.push('…');
    for (let p = lo; p <= hi; p++) pages.push(p);
    if (hi < totalPages - 1) pages.push('…');
    pages.push(totalPages);
  }

  pagerEl.innerHTML =
    `<button style="${btnStyle(false)}" ${page === 1 ? 'disabled' : ''} onclick="mrRenderMatrixPage(${page - 1})">‹ Précédent</button>` +
    pages.map(p => p === '…'
      ? `<span style="padding:5px 4px;color:#9aa5bb;font-size:11px">…</span>`
      : `<button style="${btnStyle(p === page)}" onclick="mrRenderMatrixPage(${p})">${p}</button>`
    ).join('') +
    `<button style="${btnStyle(false)}" ${page === totalPages ? 'disabled' : ''} onclick="mrRenderMatrixPage(${page + 1})">Suivant ›</button>` +
    `<span style="margin-left:10px;font-size:11px;color:#9aa5bb">${totalRows} types de pannes au total</span>` +
    `<button style="cursor:pointer;border:none;padding:6px 14px;border-radius:6px;background:#e85d26;color:#fff;font-size:11px;font-weight:700;margin-left:10px" onclick="mrExportMatrixXLSX(window._mrMatrixFullData)">⬇ Tout télécharger (XLSX)</button>`;
}

// Filtre une liste de lignes selon les critères CODE_EQUIPEMENT
// ── Collecte la hierarchie (systemes/unites/sous-systemes/equipements) ──
// presente dans un ensemble de lignes, a partir de CODE_EQUIPEMENT/EQUIPEMENT.
// Utilisee par les pages Preventive et Equipements pour construire les filtres.
function collectEquipHierarchy(rows) {
  const systemesSet     = new Set();
  const unitesSet       = new Set();
  const sousSystemesSet = new Set();
  const equipementsSet  = new Set();

  (rows || []).forEach(r => {
    const fullCode = (r['CODE_EQUIPEMENT'] || r['EQUIPEMENT'] || '').trim();
    if (!fullCode) return;
    const p = parseCodeEquipement(fullCode);
    if (p.systeme     !== '— N/A —') systemesSet.add(p.systeme);
    if (p.unite       !== '— N/A —') unitesSet.add(p.unite);
    if (p.sousSysteme !== '— N/A —') sousSystemesSet.add(p.sousSysteme);
    equipementsSet.add(fullCode);
  });

  return {
    systemes:     [...systemesSet].sort(),
    unites:       [...unitesSet].sort(),
    sousSystemes: [...sousSystemesSet].sort(),
    equipements:  [...equipementsSet].sort()
  };
}

function filterByEquipHierarchy(rows, { unite, systeme, sousSysteme, equipement }) {
  return rows.filter(r => {
    const fullCode = (r['CODE_EQUIPEMENT'] || r['EQUIPEMENT'] || '').trim();
    const p = parseCodeEquipement(fullCode);
    if (unite       && unite       !== 'all' && p.unite       !== unite)       return false;
    if (systeme     && systeme     !== 'all' && p.systeme     !== systeme)     return false;
    if (sousSysteme && sousSysteme !== 'all' && p.sousSysteme !== sousSysteme) return false;
    if (equipement  && equipement  !== 'all' && fullCode      !== equipement)  return false;
    return true;
  });
}

// =====================================================================
// ██████████████████████████████████████████████████████████████████
// ██        MR — SOUS-ONGLETS : ANALYSE GMAO  vs  ANALYSE MPU & TCU  ██
// ██████████████████████████████████████████████████████████████████
// =====================================================================

// ── Bascule entre les deux sous-onglets de la page MR ──────────────────
function switchMRSubTab(tab) {
  const isGmao = tab === 'gmao';
  document.getElementById('mr-subtab-btn-gmao')?.classList.toggle('active', isGmao);
  document.getElementById('mr-subtab-btn-mpu')?.classList.toggle('active', !isGmao);
  const pGmao = document.getElementById('mr-tabpanel-gmao');
  const pMpu  = document.getElementById('mr-tabpanel-mpu');
  if (pGmao) { pGmao.style.display = isGmao ? '' : 'none'; pGmao.classList.toggle('active', isGmao); }
  if (pMpu)  { pMpu.style.display  = isGmao ? 'none' : ''; pMpu.classList.toggle('active', !isGmao); }
}

// =====================================================================
// MR MPU/TCU — STOCKAGE
// =====================================================================
const MRMT_DB = { rows: [], files: [] };
const MRMT_SRC_COLORS = { MPU: '#2f6690', TCU: '#dc2626' };

// Colonnes utiles par source (telles que fournies par les exports "Events_...csv")
const MRMT_COLUMNS = {
  MPU: ['CodeName', 'MaintenanceHelp', 'DeviceName', 'FunctionName', 'StackName'],
  TCU: ['CodeName', 'DeviceName', 'HintName', 'SeverityName', 'FunctionName']
};

// ── Parseur CSV robuste (delimiteur ';', champs entre guillemets, guillemets doublés "" ) ──
function mrmtSplitLine(line) {
  const result = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') {
      if (inQuotes && line[i + 1] === '"') { cur += '"'; i++; }
      else inQuotes = !inQuotes;
    } else if (c === ';' && !inQuotes) {
      result.push(cur); cur = '';
    } else {
      cur += c;
    }
  }
  result.push(cur);
  return result;
}

// Les exports Events_*.csv contiennent, pour chaque evenement, une ligne principale
// (CodeName rempli) suivie de plusieurs lignes de "contexte/trace" (CodeName vide).
// On ne garde que les lignes principales.
function mrmtParseCSV(text) {
  text = text.replace(/^\uFEFF/, '');
  const lines = text.split(/\r\n|\n/);
  if (!lines.length) return { idx: {}, rows: [] };
  const header = mrmtSplitLine(lines[0]).map(h => h.trim().replace(/^"|"$/g, ''));
  const idx = {};
  header.forEach((h, i) => { idx[h] = i; });
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (!line || !line.trim()) continue;
    const fields = mrmtSplitLine(line).map(f => f.trim().replace(/^"|"$/g, ''));
    if (!fields[0]) continue; // ligne de contexte/trace : pas un evenement
    rows.push(fields);
  }
  return { idx, rows };
}

function mrmtGet(idx, fields, name) {
  const i = idx[name];
  if (i === undefined || i === null) return '';
  return (fields[i] || '').trim();
}

// Format des dates dans les exports : "2018-05-03 14:16:45:221"
function mrmtParseDate(s) {
  if (!s) return null;
  const m = String(s).match(/(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})(?::(\d+))?/);
  if (!m) return null;
  const d = new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6], m[7] ? +m[7] : 0);
  return isNaN(d) ? null : d;
}

// Détection de la source (MPU / TCU) : d'abord via le nom de fichier, sinon via DeviceName
function mrmtDetectSource(filename, idx, rows) {
  const up = String(filename || '').toUpperCase();
  if (/\bMPU\b/.test(up) || up.includes('MPU')) return 'MPU';
  if (/\bTCU\b/.test(up) || up.includes('TCU')) return 'TCU';
  for (const fields of rows) {
    const dn = mrmtGet(idx, fields, 'DeviceName').toUpperCase();
    if (dn.includes('MPU')) return 'MPU';
    if (dn.includes('TCU')) return 'TCU';
  }
  return 'INCONNU';
}

function mrmtDateOnlyKey(d) {
  if (!d) return null;
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

// =====================================================================
// IMPORT MPU / TCU
// =====================================================================
