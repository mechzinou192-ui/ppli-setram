// =============================================================================
// SUIVI DES PERFORMANCES — module 01/10 : perf-01-init-router-import.js
// Extrait mecaniquement (meme code, meme ordre) du script principal historique
// pour ameliorer la maintenabilite (le fichier faisait ~8300 lignes en un bloc).
// Contenu : Consommations mensuelles (page + logique) - constantes globales (UNITS, DB, charts, EQ_ROWS_MAP...) - Centre d'Import (autoload IndexedDB) - navigation/router (setupNav, navigateTo, renderCurrentPage) - filtres (setupFilters, getFilters)
// IMPORTANT : ce fichier partage la portee globale avec les autres modules
// perf-XX-*.js et doit rester charge dans l'ORDRE (01 -> 10), car certaines
// fonctions utilisent des constantes/fonctions definies dans les modules precedents.
// =============================================================================
// =====================================================================
// CONSTANTS
// =====================================================================
const UNITS = ['ALG', 'ORN', 'CST', 'SBA', 'STF', 'ORG', 'MGM'];

const UNIT_COLORS = {
  'ALG': '#2f6690',
  'ORN': '#d97706',
  'CST': '#059669',
  'SBA': '#24537a',
  'STF': '#dc2626',
  'ORG': '#0891b2',
  'MGM': '#db2777'
};

// =====================================================================
// CONSOMMATIONS MENSUELLES (saisie manuelle : Electricite, Eau, Gaz par UO)
// Donnees PARTAGEES entre tous les utilisateurs via assets/conso-mensuelle.js
// (meme mecanisme que comptes.js — voir admin.html)
// =====================================================================
var consoFileHandle = null; // handle vers assets/conso-mensuelle.js sur le serveur, une fois connecte

function consoLoadData() {
  if (!window.SETRAM_CONSO_MENSUELLE || typeof window.SETRAM_CONSO_MENSUELLE !== 'object') {
    window.SETRAM_CONSO_MENSUELLE = {};
  }
  return window.SETRAM_CONSO_MENSUELLE;
}
function consoMonthLabel(ym) {
  if (!ym) return '';
  const [y, m] = ym.split('-');
  const noms = ['Janv','Fevr','Mars','Avr','Mai','Juin','Juil','Aout','Sept','Oct','Nov','Dec'];
  const idx = parseInt(m, 10) - 1;
  return `${noms[idx] || m} ${y}`;
}
function consoCurrentMonth() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
}

function consoBuildFileContent() {
  return '/* =========================================================\n' +
    '   conso-mensuelle.js — Consommations mensuelles (Electricite, Eau, Gaz)\n' +
    '   Plateforme Maintenance SETRAM — genere automatiquement\n' +
    '   Derniere mise a jour le ' + new Date().toLocaleString('fr-FR') + '\n' +
    '   -----------------------------------------------------------\n' +
    "   ⚠️ A deposer dans assets/conso-mensuelle.js sur le serveur pour\n" +
    '   appliquer ces changements a TOUS les utilisateurs.\n' +
    '   ========================================================= */\n' +
    'window.SETRAM_CONSO_MENSUELLE = ' + JSON.stringify(consoLoadData(), null, 2) + ';\n';
}
function consoDownloadFile() {
  const content = consoBuildFileContent();
  const blob = new Blob([content], { type: 'text/javascript' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url; link.download = 'conso-mensuelle.js';
  document.body.appendChild(link); link.click(); document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
function consoSetHint(msg, kind) {
  const el = document.getElementById('conso-conn-hint');
  if (el) { el.textContent = msg; el.className = 'conso-conn-hint' + (kind ? ' ' + kind : ''); }
}

function consoGetPickerFn() {
  // suivi-performances.html s'affiche dans un <iframe> (voir index.html) ; or Chrome/Edge
  // interdisent showOpenFilePicker() depuis un iframe, meme de meme origine. On recupere
  // donc la fonction depuis la fenetre PARENTE (window.top), ce qui est autorise car
  // meme origine, et l'activation utilisateur (le clic) se propage bien jusqu'au parent.
  try {
    if (window.top && window.top !== window && typeof window.top.showOpenFilePicker === 'function') {
      return window.top.showOpenFilePicker.bind(window.top);
    }
  } catch (e) { /* cross-origin : impossible d'acceder a window.top, on retombe sur window */ }
  return (typeof window.showOpenFilePicker === 'function') ? window.showOpenFilePicker.bind(window) : null;
}

async function consoConnectFile(silent) {
  const pickerFn = consoGetPickerFn();
  if (!pickerFn) {
    if (!silent) alert("Ton navigateur ne permet pas la connexion directe a un fichier (ca marche sur Chrome ou Edge). Utilise « Telecharger conso-mensuelle.js » a la place, puis depose le fichier dans assets/ sur le serveur.");
    return;
  }
  try {
    var handle;
    if (!silent) {
      // Clic utilisateur direct : ouvrir le selecteur IMMEDIATEMENT, sans await avant,
      // sinon le navigateur perd la notion de "geste utilisateur" et refuse d'ouvrir la fenetre.
      var handles;
      try {
        handles = await pickerFn({
          types: [{ description: 'conso-mensuelle.js', accept: { 'text/javascript': ['.js'] } }],
          excludeAcceptAllOption: false
        });
      } catch (e) {
        if (e && e.name !== 'AbortError') alert("Le selecteur n'a pas pu s'ouvrir (" + (e && e.message ? e.message : e) + "). Utilise « Telecharger conso-mensuelle.js » a la place si le probleme persiste.");
        return; // selecteur ferme/annule/echec
      }
      var picked = handles[0];
      var grant;
      try { grant = await picked.requestPermission({ mode: 'readwrite' }); } catch (e) { grant = 'denied'; }
      if (grant !== 'granted') {
        alert("Permission d'ecriture refusee par le navigateur pour ce fichier.");
        return;
      }
      handle = picked;
    } else {
      // Tentative silencieuse (au chargement de page) : peut reutiliser un handle deja connu.
      const pick = await window.SetramFileHandleStore.getWritableHandle("conso-js", {
        types: [{ description: 'conso-mensuelle.js', accept: { 'text/javascript': ['.js'] } }],
        excludeAcceptAllOption: false
      });
      if (!pick.handle) return;
      handle = pick.handle;
    }

    consoFileHandle = handle;
    try { await window.SetramFileHandleStore.save('conso-js', handle); } catch (e) {}

    // Charger le contenu déjà présent dans le fichier connecté (les saisies des autres utilisateurs)
    try {
      const file = await consoFileHandle.getFile();
      const text = await file.text();
      const match = text.match(/window\.SETRAM_CONSO_MENSUELLE\s*=\s*(\{[\s\S]*\});?/);
      if (match) {
        const remote = JSON.parse(match[1]);
        window.SETRAM_CONSO_MENSUELLE = remote || {};
      }
    } catch (e) {}

    consoSetHint('✅ Connecte — vos saisies sont maintenant publiees directement dans le fichier partage, visibles par tous les utilisateurs.', 'ok');
    consoRenderTable(); consoRenderCharts(); consoFillFormFromStorage();
  } catch (e) { /* selecteur annule */ }
}

async function consoPublish() {
  const content = consoBuildFileContent();
  if (consoFileHandle) {
    try {
      const writable = await consoFileHandle.createWritable();
      await writable.write(content);
      await writable.close();
      return true;
    } catch (e) {
      consoFileHandle = null;
      try { await window.SetramFileHandleStore.clear('conso-js'); } catch (err) {}
      consoSetHint('⚠️ Connexion au fichier perdue (' + e.message + '). Cliquez sur « Connecter » pour la refaire.', 'err');
      consoDownloadFile();
      return false;
    }
  }
  return false;
}

function renderConsoPage() {
  const selUnit = document.getElementById('conso-sel-unit');
  const selChartUnit = document.getElementById('conso-sel-chart-unit');
  const selMonth = document.getElementById('conso-sel-month');
  if (!selUnit || !selChartUnit || !selMonth) return;

  // Peupler les listes déroulantes une seule fois
  if (!selUnit.dataset.built) {
    selUnit.innerHTML = UNITS.map(u => `<option value="${u}">${u}</option>`).join('');
    selUnit.dataset.built = '1';
  }
  if (!selChartUnit.dataset.built) {
    selChartUnit.innerHTML = `<option value="__ALL__">Toutes les UO</option>` +
      UNITS.map(u => `<option value="${u}">${u}</option>`).join('');
    selChartUnit.dataset.built = '1';
  }
  if (!selMonth.value) selMonth.value = consoCurrentMonth();

  consoFillFormFromStorage();
  consoRenderTable();
  consoRenderCharts();

  if (!renderConsoPage._wired) {
    renderConsoPage._wired = true;
    document.getElementById('conso-btn-save').addEventListener('click', consoSaveEntry);
    selUnit.addEventListener('change', consoFillFormFromStorage);
    selMonth.addEventListener('change', consoFillFormFromStorage);
    selChartUnit.addEventListener('change', consoRenderCharts);
    document.getElementById('conso-btn-connect').addEventListener('click', () => consoConnectFile(false));
    document.getElementById('conso-btn-download').addEventListener('click', consoDownloadFile);
    // Bouton de secours : si la page est dans un iframe, proposer de l'ouvrir a part
    // (garantit que le selecteur de fichier fonctionne, meme si l'astuce window.top echoue).
    if (window.top && window.top !== window) {
      const newTabBtn = document.getElementById('conso-btn-connect-newtab');
      newTabBtn.style.display = '';
      newTabBtn.addEventListener('click', () => window.open(location.href, '_blank'));
    }
    // Tentative de reconnexion silencieuse au fichier deja connecte precedemment sur ce poste
    (async () => {
      if (window.SetramFileHandleStore && window.showOpenFilePicker) {
        try {
          const pick = await window.SetramFileHandleStore.getWritableHandle('conso-js', null);
          if (pick && pick.handle) {
            consoFileHandle = pick.handle;
            try {
              const file = await consoFileHandle.getFile();
              const text = await file.text();
              const match = text.match(/window\.SETRAM_CONSO_MENSUELLE\s*=\s*(\{[\s\S]*\});?/);
              if (match) window.SETRAM_CONSO_MENSUELLE = JSON.parse(match[1]) || {};
            } catch (e) {}
            consoSetHint('✅ Connecte — vos saisies sont publiees directement dans le fichier partage pour tous les utilisateurs.', 'ok');
            consoRenderTable(); consoRenderCharts(); consoFillFormFromStorage();
          }
        } catch (e) {}
      }
    })();
  }
}

function consoFillFormFromStorage() {
  const unit = document.getElementById('conso-sel-unit').value;
  const month = document.getElementById('conso-sel-month').value;
  const data = consoLoadData();
  const entry = (data[unit] && data[unit][month]) || null;
  document.getElementById('conso-input-elec').value = entry ? entry.elec : '';
  document.getElementById('conso-input-eau').value  = entry ? entry.eau  : '';
  document.getElementById('conso-input-gaz').value  = entry ? entry.gaz  : '';
  const hint = document.getElementById('conso-form-hint');
  hint.textContent = entry ? `Une saisie existe deja pour ${unit} — ${consoMonthLabel(month)}. L'enregistrement la mettra a jour.` : '';
  hint.className = 'conso-form-hint';
}

async function consoSaveEntry() {
  const unit = document.getElementById('conso-sel-unit').value;
  const month = document.getElementById('conso-sel-month').value;
  const hint = document.getElementById('conso-form-hint');
  if (!month) { hint.textContent = 'Veuillez choisir un mois.'; hint.className = 'conso-form-hint err'; return; }

  const elec = parseFloat(document.getElementById('conso-input-elec').value);
  const eau  = parseFloat(document.getElementById('conso-input-eau').value);
  const gaz  = parseFloat(document.getElementById('conso-input-gaz').value);
  if (isNaN(elec) && isNaN(eau) && isNaN(gaz)) {
    hint.textContent = 'Veuillez saisir au moins une valeur.'; hint.className = 'conso-form-hint err'; return;
  }

  const data = consoLoadData();
  if (!data[unit]) data[unit] = {};
  data[unit][month] = {
    elec: isNaN(elec) ? 0 : elec,
    eau:  isNaN(eau)  ? 0 : eau,
    gaz:  isNaN(gaz)  ? 0 : gaz
  };

  if (consoFileHandle) {
    const ok = await consoPublish();
    hint.textContent = ok
      ? `Saisie enregistree et publiee pour tous les utilisateurs (${unit} — ${consoMonthLabel(month)}).`
      : `Saisie enregistree, mais la publication directe a echoue — un fichier a ete telecharge, deposez-le manuellement dans assets/.`;
    hint.className = 'conso-form-hint ' + (ok ? 'ok' : 'err');
  } else {
    consoDownloadFile();
    hint.textContent = `Saisie enregistree dans cette page. Fichier conso-mensuelle.js telecharge — deposez-le dans assets/ sur le serveur pour que tout le monde le voie, ou cliquez « Connecter » ci-dessus pour publier automatiquement la prochaine fois.`;
    hint.className = 'conso-form-hint err';
  }
  consoRenderTable();
  consoRenderCharts();
}

async function consoDeleteEntry(unit, month) {
  const data = consoLoadData();
  if (data[unit] && data[unit][month]) {
    delete data[unit][month];
    if (Object.keys(data[unit]).length === 0) delete data[unit];
    if (consoFileHandle) { await consoPublish(); }
    consoRenderTable();
    consoRenderCharts();
    consoFillFormFromStorage();
  }
}
window.consoDeleteEntry = consoDeleteEntry;

function consoRenderTable() {
  const data = consoLoadData();
  const rows = [];
  UNITS.forEach(u => {
    if (!data[u]) return;
    Object.keys(data[u]).sort().forEach(m => rows.push({ unit: u, month: m, ...data[u][m] }));
  });
  rows.sort((a, b) => b.month.localeCompare(a.month) || a.unit.localeCompare(b.unit));

  const tbody = document.getElementById('conso-table-body');
  const empty = document.getElementById('conso-empty');
  if (!rows.length) {
    tbody.innerHTML = '';
    empty.style.display = '';
    return;
  }
  empty.style.display = 'none';
  tbody.innerHTML = rows.map(r => `
    <tr>
      <td><span class="unit-dot" style="background:${UNIT_COLORS[r.unit] || '#888'}"></span> ${r.unit}</td>
      <td>${consoMonthLabel(r.month)}</td>
      <td>${r.elec.toLocaleString('fr-FR')}</td>
      <td>${r.eau.toLocaleString('fr-FR')}</td>
      <td>${r.gaz.toLocaleString('fr-FR')}</td>
      <td><button class="conso-row-del" onclick="consoDeleteEntry('${r.unit}','${r.month}')">Supprimer</button></td>
    </tr>
  `).join('');
}

function consoRenderCharts() {
  const data = consoLoadData();
  const filterUnit = document.getElementById('conso-sel-chart-unit')?.value || '__ALL__';
  const unitsToShow = filterUnit === '__ALL__' ? UNITS : [filterUnit];

  // Tous les mois présents, triés
  const monthSet = new Set();
  unitsToShow.forEach(u => { if (data[u]) Object.keys(data[u]).forEach(m => monthSet.add(m)); });
  const months = Array.from(monthSet).sort();
  const labels = months.map(consoMonthLabel);

  const buildDatasets = (key) => unitsToShow.map(u => ({
    label: u,
    data: months.map(m => (data[u] && data[u][m]) ? data[u][m][key] : null),
    borderColor: UNIT_COLORS[u] || '#888',
    backgroundColor: (UNIT_COLORS[u] || '#888') + '22',
    spanGaps: true,
    tension: 0.3,
    fill: false,
    pointRadius: 3
  }));

  const opts = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: true, labels: { boxWidth: 10, font: { size: 10.5 } } } },
    scales: { y: { beginAtZero: true } }
  };

  ['elec', 'eau', 'gaz'].forEach(key => {
    const id = `chart-conso-${key === 'elec' ? 'elec' : key}`;
    destroyChart(`conso-${key}`);
    const canvas = document.getElementById(id);
    if (!canvas) return;
    charts[`conso-${key}`] = new Chart(canvas, {
      type: 'line',
      data: { labels, datasets: buildDatasets(key) },
      options: opts
    });
  });
}

const KPI_COLORS = {
  tcp:       'rgba(5,150,105,0.85)',
  tcc:       'rgba(220,38,38,0.85)',
  tmp:       'rgba(5,150,105,0.85)',
  tmc:       'rgba(220,38,38,0.85)',
  dispo:     'rgba(47, 102, 144,0.85)',
  mttr:      'rgba(47, 102, 144,0.85)',
  mtbf:      'rgba(36, 83, 122,0.85)',
  tauxPanne: 'rgba(36, 83, 122,0.85)',
  tauxRep:   'rgba(47, 102, 144,0.85)'
};

const UNIT_SHORT = {
  'ALG': 'ALG', 'ORN': 'ORN', 'CST': 'CST',
  'SBA': 'SBA', 'STF': 'STF', 'ORG': 'ORG', 'MGM': 'MGM'
};

const OBJ = {
  tcp:      { val: 0.80, dir: 'up',   label: 'Obj: >80%' },
  tcc:      { val: 0.20, dir: 'down', label: 'Obj: <20%' },
  tmp:      { val: 1.00, dir: 'up',   label: 'Obj: 100%' },
  tmc:      { val: 0.90, dir: 'up',   label: 'Obj: >90%' },
  dispo:    { val: 0.97, dir: 'up',   label: 'Obj: >97%' },
  tauxPanne:{ val: 3e-3, dir: 'up',   label: 'Obj: >3×10⁻³' },
  tauxRep:  { val: 0.25, dir: 'up',   label: 'Obj: >2,5×10⁻¹' }
};

const ANCIEN_UNITS  = ['ALG','ORN','CST'];
const NOUVEAU_UNITS = ['SBA','STF','ORG','MGM'];

function debounce(fn, wait) {
  let t;
  return function(...args) {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
}

function getOBJ(unit) {
  const isNew = NOUVEAU_UNITS.includes(unit);
  return {
    tcp:      { val: isNew ? 0.80 : 0.70, dir: 'up',   label: isNew ? 'Obj: >80%' : 'Obj: >70%' },
    tcc:      { val: isNew ? 0.20 : 0.30, dir: 'down',  label: isNew ? 'Obj: <20%' : 'Obj: <30%' },
    tmp:      { val: 1.00,                dir: 'up',    label: 'Obj: 100%' },
    tmc:      { val: isNew ? 0.90 : 0.85, dir: 'up',    label: isNew ? 'Obj: >90%' : 'Obj: >85%' },
    dispo:    { val: isNew ? 0.97 : 0.95, dir: 'up',    label: isNew ? 'Obj: >97%' : 'Obj: >95%' },
    tauxPanne:{ val: isNew ? 5e-4 : 3e-4, dir: 'up',    label: isNew ? 'Obj: >5×10⁻⁴' : 'Obj: >3×10⁻⁴' },
    tauxRep:  { val: isNew ? 4e-1 : 0.25, dir: 'up',    label: isNew ? 'Obj: >4×10⁻¹' : 'Obj: >2,5×10⁻¹' }
  };
}

const DB = {
  corrective: { ALG:[], ORN:[], CST:[], SBA:[], STF:[], ORG:[], MGM:[] },
  preventive: { ALG:[], ORN:[], CST:[], SBA:[], STF:[], ORG:[], MGM:[] },
  stock:      { ALG:[], ORN:[], CST:[], SBA:[], STF:[], ORG:[], MGM:[] },
  loaded: { corrective:{}, preventive:{}, stock:{} },
  systems: new Set()
};
// Correspondance Code_Pièce -> { systeme, equipement }, chargee via le fichier de mapping (optionnel)
let STOCK_MAPPING = {};
let STOCK_MAPPING_META = null;
const charts = {};
let EQ_ROWS_MAP = {}; // { CODE_EQUIPEMENT: { corr: [rawRows...], prev: [rawRows...] } } — reconstruit a chaque rendu de la page Equipements
let CAT_ITEMS_MAP = {}; // { cat1: [items...], cat2: [...], cat3: [...] } — reconstruit a chaque rendu, pour export global par categorie
let KPI_ANOMALY_MAP = {}; // { UNITE: { sansDebut:[rows], negatif:[rows], aberrant:[rows], noeudsPaire:[rows] } } — reconstruit a chaque rendu de la page Performance

// =====================================================================
// CENTRE D'IMPORT — rechargement automatique des fichiers déjà importés
// une fois pour toute l'application (voir import-fichiers.html)
// =====================================================================
const IMPORT_DB_NAME = "setram-import-hub";
const IMPORT_STORE = "slots";
function importDbOpen(){
  return new Promise((res, rej)=>{
    const req = indexedDB.open(IMPORT_DB_NAME, 1);
    req.onupgradeneeded = ()=> req.result.createObjectStore(IMPORT_STORE);
    req.onsuccess = ()=> res(req.result);
    req.onerror = ()=> rej(req.error);
  });
}
async function importSlotGet(slotId){
  const db = await importDbOpen();
  return new Promise((res, rej)=>{
    const tx = db.transaction(IMPORT_STORE, "readonly");
    const r = tx.objectStore(IMPORT_STORE).get(slotId);
    r.onsuccess = ()=>res(r.result || null); r.onerror = ()=>rej(r.error);
  });
}
function autoDetectUnitFromName(filename){
  const name = filename.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  for (const u of UNITS) { if (name.includes(u.toLowerCase())) return u; }
  return null;
}
async function autoLoadSharedSlot(slotId, type){
  let packed;
  try { packed = await importSlotGet(slotId); } catch(e){ return 0; }
  if (!packed || !packed.files || !packed.files.length) return 0;
  const items = packed.files
    .map(p => new File([p.data], p.name, {type:p.type, lastModified:p.lastModified}))
    .map(f => ({ file:f, unit: autoDetectUnitFromName(f.name) }))
    .filter(x => x.unit);
  if (!items.length) return 0;
  // Alimente la base principale (Dashboard, Corrective/Preventive, Equipements…)
  await Promise.all(items.map(x => new Promise(resolve => handleSingleFile(x.file, type, x.unit, resolve))));
  return items.length;
}
async function autoLoadRHSlot(slotId, type){
  let packed;
  try { packed = await importSlotGet(slotId); } catch(e){ return 0; }
  if (!packed || !packed.files || !packed.files.length) return 0;
  const items = packed.files
    .map(p => new File([p.data], p.name, {type:p.type, lastModified:p.lastModified}))
    .map(f => ({ file:f, unit: autoDetectUnitFromName(f.name) }))
    .filter(x => x.unit);
  if (!items.length) return 0;
  // Alimente uniquement la base Efficience RH (fichiers dédiés, distincts de la Corrective/Préventif)
  await Promise.all(items.map(x => new Promise(resolve => readRHFile(x.file, type, x.unit, resolve))));
  return items.length;
}
async function autoLoadFromImportCenter(){
  const n1 = await autoLoadSharedSlot('corrective', 'corr');
  const n2 = await autoLoadSharedSlot('preventif', 'prev');
  if (n1 || n2){
    updateBadges(); rebuildSystemFilter();
    showToast(`✅ ${n1 + n2} fichier(s) chargé(s) automatiquement depuis le Centre d'Import`, 'success');
    if (document.getElementById('page-dashboard')?.classList.contains('active')) renderDashboard();
  }
  const n3 = await autoLoadRHSlot('rh-corretif', 'corr');
  const n4 = await autoLoadRHSlot('rh-preventif', 'prev');
  if (n3 || n4){
    finalizeRHBulkLoad();
    showToast(`✅ ${n3 + n4} fichier(s) Efficience RH chargé(s) automatiquement`, 'success');
  }
  const n5 = await autoLoadSharedSlot('stock', 'stock');
  if (n5) {
    updateBadges();
    showToast(`✅ ${n5} fichier(s) Stock chargé(s) automatiquement depuis le Centre d'Import`, 'success');
    if (document.getElementById('page-stock')?.classList.contains('active')) renderStockPage();
  }
  const mapPacked = await importSlotGet('stock-mapping').catch(()=>null);
  if (mapPacked && mapPacked.files && mapPacked.files.length) {
    STOCK_MAPPING = {}; STOCK_MAPPING_META = null;
    for (let i = 0; i < mapPacked.files.length; i++) {
      const mf = mapPacked.files[i];
      const mFile = new File([mf.data], mf.name, { type: mf.type, lastModified: mf.lastModified });
      await loadStockMappingFile(mFile, true, true);
    }
  }

  const mrPacked = await importSlotGet('materiel-roulant').catch(()=>null);
  if (mrPacked && mrPacked.files && mrPacked.files.length){
    const mrFiles = mrPacked.files.map(p => new File([p.data], p.name, {type:p.type, lastModified:p.lastModified}));
    mrHandleFiles(mrFiles);
  }
}

// =====================================================================
// INIT
// =====================================================================
document.addEventListener('DOMContentLoaded', () => {
  const now = new Date();
  const s = localStorage.getItem('gmao_start') || fmtDateInput(new Date(now.getFullYear(), now.getMonth(), 1));
  const e = localStorage.getItem('gmao_end')   || fmtDateInput(new Date(now.getFullYear(), now.getMonth()+1, 0));
  document.getElementById('sel-date-start').value = s;
  document.getElementById('sel-date-end').value   = e;
  updateDateRangeLabel();
  buildImportGrid(); buildUnitNav(); setupNav(); setupFilters(); setupImport(); setupTabs(); buildUnitOverviewGrid();
  setupMRImport();
  setupMRMTImport();
  document.getElementById('rh-file-bulk')
    ?.addEventListener('change', e => handleRHBulkLoad(e.target.files));
  autoLoadFromImportCenter();
});

function fmtDateInput(d) {
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function updateDateRangeLabel() {
  const s  = document.getElementById('sel-date-start').value;
  const e  = document.getElementById('sel-date-end').value;
  const el = document.getElementById('date-range-label');
  if (!s || !e) { el.textContent = '—'; return; }
  const days = Math.max(1, Math.round((new Date(e) - new Date(s)) / 86400000) + 1);
  const startFR = new Date(s).toLocaleDateString('fr-FR', { day:'2-digit', month:'long', year:'numeric' });
  const endFR   = new Date(e).toLocaleDateString('fr-FR', { day:'2-digit', month:'long', year:'numeric' });
  el.textContent = `${startFR} → ${endFR} · ${days} jour${days>1?'s':''} · ${days*24}h theoriques`;
}
function setQuickPeriod(p) {
  const now = new Date(); let s, e;
  if (p === 'week') {
    s = new Date(now); s.setDate(now.getDate()-6); e = now;
  } else if (p === 'month') {
    s = new Date(now.getFullYear(), now.getMonth(), 1);
    e = new Date(now.getFullYear(), now.getMonth()+1, 0);
  } else if (p === 'quarter') {
    const q = Math.floor(now.getMonth()/3);
    s = new Date(now.getFullYear(), q*3, 1);
    e = new Date(now.getFullYear(), q*3+3, 0);
  } else {
    s = new Date(now.getFullYear(), 0, 1);
    e = new Date(now.getFullYear(), 11, 31);
  }
  document.getElementById('sel-date-start').value = fmtDateInput(s);
  document.getElementById('sel-date-end').value   = fmtDateInput(e);
  updateDateRangeLabel();
  renderCurrentPage();
  if (document.getElementById('page-rh-import')?.classList.contains('active')) {
    renderRHPage();
  }
}

// =====================================================================
// NAV
// =====================================================================
function setupNav() {
  document.querySelectorAll('.nav-item[data-page]').forEach(el => {
    el.addEventListener('click', () => navigateTo(el.dataset.page, el.dataset.unit));
  });
  // ── Groupe dépliable "MR — Rames" : le clic sur l'en-tête ouvre/ferme le sous-menu ──
  const mrToggle = document.getElementById('mr-nav-toggle');
  const mrGroup  = document.getElementById('mr-nav-group');
  if (mrToggle && mrGroup) {
    mrToggle.addEventListener('click', (evt) => {
      evt.stopPropagation();
      mrGroup.classList.toggle('open');
    });
    document.addEventListener('click', (evt) => {
      if (!mrGroup.contains(evt.target)) mrGroup.classList.remove('open');
    });
    mrGroup.querySelectorAll('.nav-subitem').forEach(el => {
      el.addEventListener('click', () => mrGroup.classList.remove('open'));
    });
  }
}
function navigateTo(page, extra) {
  document.body.classList.remove('rh-page');
  document.body.classList.remove('import-page');

  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const pageEl = document.getElementById(`page-${page}`);
  if (pageEl) pageEl.classList.add('active');
  const navEl = document.querySelector(`.nav-item[data-page="${page}"]`);
  if (navEl) navEl.classList.add('active');
  const titles = {
    dashboard: 'Tableau de Bord', kpis: 'Performance ',
    corrective: 'Maintenance Corrective', preventive: 'Maintenance Preventive',
    equipements: 'Equipements', comparaison: 'Comparaison Sous-Systemes entre Unites',
    tendances: 'Evolution', import: 'Importer Donnees',
    mr: 'MR — Rames', stock: 'Gestion de Stock', conso: 'Consommations Mensuelles'
  };
  if (page === 'unit' && extra) {
    document.getElementById('page-title').textContent = `Unite ${extra}`;
    renderUnitPage(extra);
  } else {
    document.getElementById('page-title').textContent = titles[page] || page;
    renderCurrentPage(page);
  }

  // ── MR — Rames : ouvrir le groupe, activer le bon sous-item, basculer le sous-onglet GMAO/MPU ──
  if (page === 'mr') {
    const mrGroup = document.getElementById('mr-nav-group');
    if (mrGroup) mrGroup.classList.add('open');
    document.querySelectorAll('.nav-subitem[data-page="mr"]').forEach(n => n.classList.remove('active'));
    const tab = extra === 'mpu' ? 'mpu' : 'gmao';
    const subEl = document.querySelector(`.nav-subitem[data-page="mr"][data-unit="${tab}"]`);
    if (subEl) subEl.classList.add('active');
    if (typeof switchMRSubTab === 'function') switchMRSubTab(tab);
  }

  // ── Masquer/Afficher la barre de filtre globale EN DERNIER ──
const filterCard = document.getElementById('topbar').querySelector('.filter-card');
const hideFilterOn = ['mr', 'preventive', 'equipements', 'comparaison', 'rh-import', 'stock', 'conso'];
filterCard.classList.toggle('filter-card-hidden', hideFilterOn.includes(page));

// ── Cacher le filtre Unité sur la page Corrective (doublon avec les onglets) ──
const selUnitGroup = document.getElementById('sel-unit')?.closest('.filter-group');
if (selUnitGroup) selUnitGroup.style.display = page === 'corrective' ? 'none' : '';
}
function renderCurrentPage(page) {
  const p = page || (document.querySelector('.page.active')?.id || '').replace('page-', '');
  if (p === 'dashboard')   renderDashboard();
  if (p === 'kpis')        renderKPIsPage();
  if (p === 'corrective')  renderCorrectivePage();
  if (p === 'preventive')  renderPreventivePage();
  if (p === 'equipements') renderEquipementsPage();
  if (p === 'comparaison') renderComparaisonPage();
  if (p === 'tendances')   renderTendancesPage();
  if (p === 'mr')          renderMRPage();
  if (p === 'stock')       renderStockPage();
  if (p === 'conso')       renderConsoPage();
}
function buildUnitNav() {
  const c = document.getElementById('unit-nav-items'); c.innerHTML = '';
  UNITS.forEach(u => {
    if (window.SETRAM_HAS_SUB_ACCESS && !window.SETRAM_HAS_SUB_ACCESS('frame-3', 'unit', u)) return;
    const el = document.createElement('div');
    el.className = 'nav-item'; el.dataset.page = 'unit'; el.dataset.unit = u;
    el.innerHTML = `<span class="unit-dot" style="background:${UNIT_COLORS[u]}"></span>${u}<span class="nav-badge" id="unit-badge-${u}" style="display:none">✓</span>`;
    el.addEventListener('click', () => navigateTo('unit', u));
    c.appendChild(el);
  });
}

// =====================================================================
// FILTERS
// =====================================================================
function setupFilters() {
  ['sel-date-start','sel-date-end','sel-unit','sel-systeme','sel-equipement'].forEach(id => {
    document.getElementById(id).addEventListener('change', () => {
      if (id === 'sel-date-start' || id === 'sel-date-end') {
        localStorage.setItem('gmao_start', document.getElementById('sel-date-start').value);
        localStorage.setItem('gmao_end',   document.getElementById('sel-date-end').value);
        updateDateRangeLabel();
      }
      if (id === 'sel-systeme') rebuildEquipementFilter();
      renderCurrentPage();
      if (document.getElementById('page-rh-import')?.classList.contains('active')) {
        renderRHPage();
      }
    });
  });
  document.getElementById('btn-refresh').addEventListener('click', () => {
    showLoading(); setTimeout(() => { renderCurrentPage(); hideLoading(); }, 300);
  });
}
function getFilters() {
  const sV = document.getElementById('sel-date-start').value;
  const eV = document.getElementById('sel-date-end').value;
  const start = sV ? new Date(sV + 'T00:00:00') : new Date(2000, 0, 1);
  const end   = eV ? new Date(eV + 'T23:59:59') : new Date(2099, 11, 31);
  // Nombre de jours calendaires entre les deux dates (bornes incluses), calcule a minuit pour eviter
  // de compter un jour en trop (l'ancien calcul ajoutait +1 alors que "end" etait deja a 23:59:59).
  const startDay = sV ? new Date(sV + 'T00:00:00') : new Date(2000, 0, 1);
  const endDay   = eV ? new Date(eV + 'T00:00:00') : new Date(2099, 11, 31);
  const days  = Math.max(1, Math.round((endDay - startDay) / 86400000) + 1);
  return {
    start, end, hoursTotal: days * 24,
    unit:       document.getElementById('sel-unit').value,
    systeme:    document.getElementById('sel-systeme').value,
    equipement: document.getElementById('sel-equipement').value
  };
}

// =====================================================================
// SYSTEM FILTER
// =====================================================================
function rebuildSystemFilter() {
  const all = new Set();
  UNITS.forEach(u => [...DB.corrective[u], ...DB.preventive[u]].forEach(r => {
    const s = (r['SYSTEME'] || '').trim(); if (s) all.add(s);
  }));
  DB.systems = all;
  const sel = document.getElementById('sel-systeme'); const prev = sel.value;
  sel.innerHTML = '<option value="all">Tous</option>';
  [...all].sort().forEach(s => { const o = document.createElement('option'); o.value = s; o.textContent = s; sel.appendChild(o); });
  if (prev && [...all].includes(prev)) sel.value = prev;
  rebuildEquipementFilter();
}

// =====================================================================
// EQUIPEMENT FILTER (en cascade avec le filtre Systeme ci-dessus)
// =====================================================================
function rebuildEquipementFilter() {
  const sysVal = document.getElementById('sel-systeme')?.value || 'all';
  const codes = new Set();
  const nameMap = {};
  UNITS.forEach(u => [...DB.corrective[u], ...DB.preventive[u]].forEach(r => {
    if (sysVal !== 'all' && (r['SYSTEME'] || '').trim() !== sysVal) return;
    // Identifiant stable : CODE_EQUIPEMENT en priorité (present cote correctif ET preventif).
    // Le nom complet, lui, se trouve sous des colonnes differentes selon le type de fichier :
    // 'EQUIPEMENT' cote correctif, 'DESIGNATION_EQUIPEMENT' cote preventif.
    const code = (r['CODE_EQUIPEMENT'] || r['EQUIPEMENT'] || '').trim();
    if (!code) return;
    codes.add(code);
    if (!nameMap[code]) {
      const nom = (r['EQUIPEMENT'] || r['DESIGNATION_EQUIPEMENT'] || '').trim();
      if (nom && nom !== code) nameMap[code] = nom;
    }
  }));
  DB.equipements = codes;
  const sel = document.getElementById('sel-equipement'); if (!sel) return;
  const prev = sel.value;
  sel.innerHTML = '<option value="all">Tous</option>';
  [...codes].sort().forEach(c => {
    const o = document.createElement('option');
    o.value = c;
    o.textContent = nameMap[c] ? `${c} — ${nameMap[c]}` : c;
    sel.appendChild(o);
  });
  sel.value = (prev && [...codes].includes(prev)) ? prev : 'all';
}

// =====================================================================
// IMPORT
// =====================================================================
function buildImportGrid() {
  const grid = document.getElementById('import-grid'); grid.innerHTML = '';
  UNITS.forEach(u => {
    const card = document.createElement('div'); card.className = 'import-unit-card';
    card.innerHTML = `<div class="import-unit-name u-${u.toLowerCase()}">${u}</div>
      <div class="import-slot" id="slot-corr-${u}" onclick="triggerSlotFile('corr','${u}')"><span class="slot-icon">🔧</span><span class="slot-label">Correctif</span><span class="slot-file" id="slot-corr-file-${u}">Cliquer</span></div>
      <div class="import-slot" id="slot-prev-${u}" onclick="triggerSlotFile('prev','${u}')"><span class="slot-icon">🛡️</span><span class="slot-label">Preventif</span><span class="slot-file" id="slot-prev-file-${u}">Cliquer</span></div>
      <div class="import-slot" id="slot-stock-${u}" onclick="triggerSlotFile('stock','${u}')"><span class="slot-icon">📦</span><span class="slot-label">Stock</span><span class="slot-file" id="slot-stock-file-${u}">Cliquer</span></div>`;
    grid.appendChild(card);
  });
  const hid = document.getElementById('hidden-inputs'); hid.innerHTML = '';
  UNITS.forEach(u => ['corr','prev','stock'].forEach(t => {
    const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.xlsx,.xls,.csv';
    inp.id = `file-${t}-${u}`; inp.style.display = 'none';
    inp.addEventListener('change', e => { if (e.target.files[0]) handleSingleFile(e.target.files[0], t, u); });
    hid.appendChild(inp);
  }));
}
function triggerSlotFile(type, unit) { document.getElementById(`file-${type}-${unit}`).click(); }
function setupImport() {
  document.getElementById('btn-load-all').addEventListener('click', () => document.getElementById('file-input-multi').click());
  document.getElementById('file-input-multi').addEventListener('change', e => Array.from(e.target.files).forEach(f => handleAutoDetect(f)));
  document.getElementById('btn-clear-all').addEventListener('click', clearAll);
  const dz = document.getElementById('drop-zone');
  dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('drag-over'); });
  dz.addEventListener('dragleave', () => dz.classList.remove('drag-over'));
  dz.addEventListener('drop', e => { e.preventDefault(); dz.classList.remove('drag-over'); Array.from(e.dataTransfer.files).forEach(f => handleAutoDetect(f)); });
  dz.addEventListener('click', () => document.getElementById('file-input-multi').click());
}
function handleAutoDetect(file) {
  const name = file.name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  let dU = null, dT = null;
  for (const u of UNITS) { if (name.includes(u.toLowerCase())) { dU = u; break; } }
  const isC = name.includes('corretive') || name.includes('corrective') || name.includes('correctif');
  const isP = name.includes('preventive') || name.includes('preventif') || name.includes('prev');
  if (isC && !isP) dT = 'corr'; else if (isP) dT = 'prev';
  if (dU && dT) handleSingleFile(file, dT, dU); else showAssignModal(file);
}
function showAssignModal(file) {
  const unit = prompt(`Fichier: ${file.name}\nUnite (ALG/ORN/CST/SBA/STF/ORG/MGM):`);
  if (!unit || !UNITS.includes(unit.toUpperCase())) { showToast('❌ Unite invalide', 'error'); return; }
  const type = prompt('Type (corr / prev):');
  if (!type || !['corr','prev'].includes(type.toLowerCase())) { showToast('❌ Type invalide', 'error'); return; }
  handleSingleFile(file, type.toLowerCase(), unit.toUpperCase());
}
function handleSingleFile(file, type, unit, onDone) {
  showLoading();
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const wb   = XLSX.read(e.target.result, { type:'binary', cellDates:false });
      const ws   = wb.Sheets[wb.SheetNames[0]];
      const data    = XLSX.utils.sheet_to_json(ws, { raw:false, defval:'', dateNF:'DD/MM/YYYY' });
      // Lecture brute en parallele (raw:true) : pour les cellules numeriques, la version formatee (raw:false)
      // depend du format d'affichage Excel (espaces, separateurs, arrondis...) et peut deformer la valeur
      // (ex: coûts, quantites, valeurs de stock). On prefere systematiquement le nombre brut quand il existe.
      const dataRaw = XLSX.utils.sheet_to_json(ws, { raw:true, defval:'' });
      if (data.length === 0) { showToast(`⚠️ ${file.name} vide`, 'error'); hideLoading(); return; }
      const DATE_COLS = ['DATE_DI','DATE_EVENEMENT','DATE_CREATION','DATE_PREVUE','DATE_DEB_INTERVENTION','DATE_FIN_INTERVENTION','DATE_CLOTURE','Date_MVT'];
      const cleaned = data.map((row, ri) => {
        const rawRow = dataRaw[ri] || {};
        const nr = {};
        Object.keys(row).forEach(k => {
          const kk = k.trim(); let val = row[k];
          const rawVal = rawRow[k];
          if (DATE_COLS.includes(kk)) {
            // Colonne date : on privilegie le numero de serie Excel brut (plus fiable que le texte formate)
            if (typeof rawVal === 'number' && !isNaN(rawVal)) {
              const d = new Date(Math.round((rawVal - 25569) * 86400 * 1000));
              if (!isNaN(d)) val = `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
            } else if (val !== '' && /^\d{5}$/.test(String(val).trim())) {
              const d = new Date((parseInt(val)-25569)*86400*1000);
              if (!isNaN(d)) val = `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
            }
          } else if (typeof rawVal === 'number' && !isNaN(rawVal)) {
            // Colonne numerique (coûts, quantites, valeurs...) : on garde le nombre brut, jamais le texte formate
            val = rawVal;
          }
          nr[kk] = val;
        });
        nr.__UNIT__ = unit; return nr;
      });
      if (type === 'corr') { DB.corrective[unit] = cleaned; DB.loaded.corrective[unit] = file.name; EQ_CORR_STATS_CACHE = null; }
      else if (type === 'prev') { DB.preventive[unit] = cleaned; DB.loaded.preventive[unit] = file.name; }
      else if (type === 'stock') {
        DB.stock[unit] = cleaned.map(r => normalizeStockRow(r, unit)).filter(r => r.qte !== 0 || r.valeur !== 0);
        DB.loaded.stock[unit] = file.name;
      }
      updateSlotUI(type, unit, file.name);
      updateBadges(); rebuildSystemFilter();
      if (type !== 'stock') {
        const df = type === 'corr' ? 'DATE_DI' : 'DATE_PREVUE';
        const dates = cleaned.map(r => parseDate(r[df])).filter(Boolean);
        if (dates.length > 0) {
          const minD = new Date(Math.min(...dates.map(d => d.getTime())));
          const maxD = new Date(Math.max(...dates.map(d => d.getTime())));
          document.getElementById('sel-date-start').value = fmtDateInput(minD);
          document.getElementById('sel-date-end').value   = fmtDateInput(maxD);
          updateDateRangeLabel();
        }
      }
      const typeLabel = type === 'corr' ? 'Correctif' : (type === 'prev' ? 'Preventif' : 'Stock');
      showToast(`✅ ${unit} ${typeLabel} — ${cleaned.length} lignes`, 'success');
      if (type === 'stock') {
        if (document.getElementById('page-stock')?.classList.contains('active')) renderStockPage();
      } else {
        setTimeout(() => renderDashboard(), 200);
      }
    } catch(err) { console.error(err); showToast(`❌ ${err.message}`, 'error'); }
    hideLoading();
    if (onDone) onDone();
  };
  reader.readAsBinaryString(file);
}

// ── Normalisation d'une ligne de sortie de stock (fichier "liste_mvt_sortie") ──
