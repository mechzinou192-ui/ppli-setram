// =============================================================================
// SUIVI DES PERFORMANCES — module 04/10 : perf-04-dashboard-kpis-equip-a.js
// Extrait mecaniquement (meme code, meme ordre) du script principal historique
// pour ameliorer la maintenabilite (le fichier faisait ~8300 lignes en un bloc).
// Contenu : Dashboard, KPIs (Performance) et debut Equipements : export anomalies, zone d'alerte, formatters (pct, fmtSci...), helpers Chart.js, renderDashboard, renderKPIsPage, renderEquipementsPage
// IMPORTANT : ce fichier partage la portee globale avec les autres modules
// perf-XX-*.js et doit rester charge dans l'ORDRE (01 -> 10), car certaines
// fonctions utilisent des constantes/fonctions definies dans les modules precedents.
// =============================================================================
async function exportAnomalies(scope) {
  const units = scope === 'TOTAL' ? Object.keys(KPI_ANOMALY_MAP) : [scope];
  const cats = [
    { key: 'sansDebut',    label: 'Sans DATE_EVENEMENT',    accent: SETRAM_XLSX.orange },
    { key: 'negatif',      label: 'Duree negative',         accent: SETRAM_XLSX.red },
    { key: 'aberrant',     label: 'Duree aberrante',        accent: SETRAM_XLSX.red },
    { key: 'noeudsPaire',  label: 'Noeuds pairs (parent)',  accent: SETRAM_XLSX.navy }
  ];

  // Comptage par unite/categorie pour la synthese + le total global
  const counts = {}; // counts[unit][catKey] = n
  let total = 0;
  units.forEach(u => {
    counts[u] = {};
    cats.forEach(cat => {
      const n = ((KPI_ANOMALY_MAP[u] && KPI_ANOMALY_MAP[u][cat.key]) || []).length;
      counts[u][cat.key] = n;
      total += n;
    });
  });

  if (total === 0) {
    alert("Aucune anomalie a exporter pour " + (scope === 'TOTAL' ? "l'ensemble des unites" : scope) + " sur la periode filtree.");
    return;
  }

  showLoading();
  try {
    const logoBuf = await setramLogoBuffer();
    const wb = new ExcelJS.Workbook();
    wb.creator = 'SETRAM — Direction Ingenierie';
    wb.created = new Date();
    const scopeLabel = scope === 'TOTAL' ? "Toutes les unites" : scope;

    // ── Feuille de synthese : 1 ligne par unite, 1 colonne par type d'anomalie ──
    const summaryRows = units.map(u => ({
      'Unite': u,
      'Sans DATE_EVENEMENT': counts[u].sansDebut,
      'Duree negative':      counts[u].negatif,
      'Duree aberrante':     counts[u].aberrant,
      'Noeuds pairs (parent)': counts[u].noeudsPaire,
      'Total anomalies':     cats.reduce((s, c) => s + counts[u][c.key], 0)
    })).filter(r => r['Total anomalies'] > 0);
    if (scope === 'TOTAL' && summaryRows.length > 1) {
      summaryRows.push({
        'Unite': 'TOTAL',
        'Sans DATE_EVENEMENT': units.reduce((s, u) => s + counts[u].sansDebut, 0),
        'Duree negative':      units.reduce((s, u) => s + counts[u].negatif, 0),
        'Duree aberrante':     units.reduce((s, u) => s + counts[u].aberrant, 0),
        'Noeuds pairs (parent)': units.reduce((s, u) => s + counts[u].noeudsPaire, 0),
        'Total anomalies': total
      });
    }
    writeSetramSummarySheet(wb, summaryRows, {
      sheetName: 'Synthese',
      title: '⚠️ Problemes de donnees — Synthese',
      subtitle: `Perimetre : ${scopeLabel}`,
      logoBuf
    });

    // ── 1 feuille par type d'anomalie, avec toutes les lignes brutes concernees ──
    cats.forEach(cat => {
      let rowsAll = [];
      units.forEach(u => {
        const arr = (KPI_ANOMALY_MAP[u] && KPI_ANOMALY_MAP[u][cat.key]) || [];
        rowsAll = rowsAll.concat(arr);
      });
      if (!rowsAll.length) return;
      writeSetramSheet(wb, cat.label, rowsAll, {
        title: `⚠️ ${cat.label}`,
        subtitle: `Perimetre : ${scopeLabel}`,
        accentColor: cat.accent,
        logoBuf
      });
    });

    const label = scope === 'TOTAL' ? 'TOUTES_UNITES' : scope;
    const dstr  = new Date().toISOString().slice(0, 10);
    await downloadSetramWorkbook(wb, `Anomalies_${label}_${dstr}.xlsx`);
  } catch (e) {
    console.error(e);
    alert("Erreur lors de la generation du fichier Excel : " + e.message);
  } finally {
    hideLoading();
  }
}

// =====================================================================
// ALERT ZONE
// =====================================================================
function renderAlertZone(kpi, unit) {
  const zone = document.getElementById('alert-zone'); if (!zone) return;
  const alerts = [], warns = [];

  if (kpi.nbSansDebut > 0) {
    warns.push({ unit: unit==='all'?'Global':unit, msg:`<strong>${kpi.nbSansDebut} DI sans DATE_EVENEMENT</strong> — Remplacee par debut de periode (00:01)`, val:`${kpi.nbSansDebut} DI` });
  }
  if (kpi.nbNegatif > 0) {
    alerts.push({ unit: unit==='all'?'Global':unit, msg:`<strong>${kpi.nbNegatif} DI avec duree negative</strong> — DATE_FIN &lt; DATE_EVENEMENT`, val:`${kpi.nbNegatif} DI`, ex: kpi.exNegatif.join(', ') });
  }
  if (kpi.nbAberrant > 0) {
    alerts.push({ unit: unit==='all'?'Global':unit, msg:`<strong>${kpi.nbAberrant} DI avec duree aberrante</strong> — Durée &gt;150% du temps theorique, ignorees`, val:`${kpi.nbAberrant} DI`, ex: kpi.exAberrant.join(', ') });
  }
  if (kpi.mtbf === 0 || kpi.tauxPanne === 0) {
    if (kpi.nbPannesTot > 0) warns.push({ unit: unit==='all'?'Global':unit, msg:`<strong>MTBF = 0 / Taux Panne = 0</strong> — Aucune date valide trouvee`, val:'MTBF=0' });
  }
  if (alerts.length === 0 && warns.length === 0) { zone.innerHTML = ''; return; }

  let html = '';
  if (alerts.length > 0) {
    html += `<div class="alert-panel"><div class="alert-panel-title">⚠️ Problemes de donnees detectes (${alerts.length} alerte${alerts.length>1?'s':''})</div>
      ${alerts.map(a => `<div class="alert-item"><span class="ai-unit">${a.unit}</span><span class="ai-msg">${a.msg}${a.ex?`<br><span style="color:var(--text3);font-size:10px">Ex: ${a.ex}</span>`:''}</span><span class="ai-val">${a.val}</span></div>`).join('')}
    </div>`;
  }
  if (warns.length > 0) {
    html += `<div class="alert-panel warn"><div class="alert-panel-title">⚡ Indicateurs a zero — donnees insuffisantes</div>
      ${warns.map(a => `<div class="alert-item"><span class="ai-unit">${a.unit}</span><span class="ai-msg">${a.msg}</span><span class="ai-val">${a.val}</span></div>`).join('')}
    </div>`;
  }
  zone.innerHTML = html;
}

// =====================================================================
// FORMAT HELPERS
// =====================================================================
function pct(v, d=1)    { if (v===null||v===undefined||isNaN(v)) return '—'; return (v*100).toFixed(d)+'%'; }
function fmtSci(v)      { if (v===0||isNaN(v)) return '0'; const exp = Math.floor(Math.log10(Math.abs(v))); const mant = (v/Math.pow(10,exp)).toFixed(3); return `${mant}×10^${exp}`; }
function fmtSciShort(v) { if (v===0||isNaN(v)) return '0'; return v.toExponential(2); }
function fmtMin(v)      { const n = parseFloat(String(v||'').replace(',','.')); if (isNaN(n)||n===0) return '—'; return (n/60).toFixed(2)+'h'; }
function formatK(n)     { return n >= 1000 ? (n/1000).toFixed(1)+'k' : String(n); }

function objClass(key, val, unit) {
  const o = unit && unit !== 'all' ? getOBJ(unit)[key] : OBJ[key];
  if (!o || isNaN(val)) return 'obj-warn';
  if (o.dir === 'up')   return val >= o.val ? 'obj-ok' : val >= o.val * 0.8 ? 'obj-warn' : 'obj-bad';
  if (o.dir === 'down') return val <= o.val ? 'obj-ok' : val <= o.val * 1.2 ? 'obj-warn' : 'obj-bad';
  return 'obj-warn';
}
function trendArrow(key, val, unit) {
  const o = unit && unit !== 'all' ? getOBJ(unit)[key] : OBJ[key];
  if (!o || isNaN(val) || val === 0) return '';
  const ok = o.dir === 'up' ? val >= o.val : val <= o.val;
  return ok ? '<span class="trend-arrow up" title="Objectif atteint ✅">▲</span>'
            : '<span class="trend-arrow down" title="Objectif non atteint ❌">▼</span>';
}

// =====================================================================
// CHART HELPERS
// =====================================================================
function destroyChart(id) { if (charts[id]) { charts[id].destroy(); delete charts[id]; } }
function chartScaleX()   { return { ticks:{color:'#64748b',font:{size:11}}, grid:{color:'rgba(15,23,42,0.06)'} }; }
function chartScaleY(unit='') { return { ticks:{color:'#64748b',font:{size:11},callback:v=>v+(unit||'')}, grid:{color:'rgba(15,23,42,0.06)'} }; }
function chartOpts(unit='')  { return { responsive:true, maintainAspectRatio:false, plugins:{legend:{labels:{color:'#475569',font:{size:11}}}}, scales:{x:chartScaleX(),y:chartScaleY(unit)} }; }

// =====================================================================
// DASHBOARD
// =====================================================================
function renderDashboard() {
  // Vérifier si des données sont chargées
  const hasData = UNITS.some(u =>
    (DB.corrective[u]||[]).length + (DB.preventive[u]||[]).length > 0
  );
  const importZone = document.getElementById('dashboard-import-zone');
  const kpiZone    = document.getElementById('dashboard-kpi-zone');
  if (importZone) importZone.style.display = hasData ? 'none' : '';
  if (kpiZone)    kpiZone.style.display    = hasData ? ''     : 'none';
  if (!hasData) return;

  const { start, end, hoursTotal, unit, systeme } = getFilters();
  const { corrRows, prevRows } = getFilteredData();
  const kpi  = calcKPIs(corrRows, prevRows, hoursTotal, start, end);
  
  // reste identique
  const days = Math.round(hoursTotal / 24);
  const uL   = unit === 'all' ? 'Toutes unites' : `Unite ${unit}`;
  const sL   = systeme === 'all' ? '' : ` · Systeme: ${systeme}`;
  document.getElementById('dashboard-period-label').textContent =
    `${fmtDateFR(start)} → ${fmtDateFR(end)} · ${days}j · ${hoursTotal}h theoriques · ${uL}${sL} · ${corrRows.length+prevRows.length} enregistrements`;

  renderAlertZone(kpi, unit);

  setKpiCard('kpi-mttr', kpi.mttr > 0 ? kpi.mttr.toFixed(3)+'h' : '—', '', '');
  setElText('kpi-mttr-sub', `${kpi.nbPannesRep} pannes reparees · H_Interv=${kpi.hCI!==undefined?(kpi.hCI).toFixed(1):'?'}h`);

  const mtbfVal = kpi.mtbf > 0 && kpi.nbPannesTot > 0 ? kpi.mtbf.toFixed(1)+'h' : '—';
  setKpiCard('kpi-mtbf', mtbfVal, '', '');
  setElText('kpi-mtbf-sub', `TBF ${kpi.tbf.toFixed(1)}h · ${kpi.nbPannesTot} pannes · Indispo ${kpi.indispoH.toFixed(1)}h`);
  const mtbfAlert = document.getElementById('kpi-mtbf-alert');
  if (mtbfAlert) {
    if (kpi.mtbf === 0 && kpi.nbPannesTot > 0) {
      mtbfAlert.style.display = 'inline-block'; mtbfAlert.className = 'kpi-obj obj-bad';
      mtbfAlert.textContent = '⚠️ Dates manquantes → 0';
    } else mtbfAlert.style.display = 'none';
  }

  setKpiCard('kpi-taux-panne', kpi.tauxPanne > 0 ? fmtSci(kpi.tauxPanne) : '—', trendArrow('tauxPanne', kpi.tauxPanne), '');
  setElText('kpi-tp-sub', `1/MTBF = 1/${kpi.mtbf.toFixed(1)}h`);
  setObjBadge('kpi-tp-obj', kpi.tauxPanne, 'tauxPanne', getOBJ(unit).tauxPanne.label, unit);

  setKpiCard('kpi-taux-rep', kpi.tauxRep > 0 ? fmtSci(kpi.tauxRep) : '—', trendArrow('tauxRep', kpi.tauxRep), '');
  setElText('kpi-tr-sub', `1/MTTR = 1/${kpi.mttr.toFixed(3)}h`);
  setObjBadge('kpi-tr-obj', kpi.tauxRep, 'tauxRep', getOBJ(unit).tauxRep.label, unit);

  setKpiCard('kpi-tcp', pct(kpi.tcp), trendArrow('tcp', kpi.tcp), '');
  setElText('kpi-tcp-sub', `H_Prev ${kpi.hPrev.toFixed(1)}h / Total ${kpi.hTotal.toFixed(1)}h`);
  setObjBadge('kpi-tcp-obj', kpi.tcp, 'tcp', getOBJ(unit).tcp.label, unit);

  setKpiCard('kpi-tcc', pct(kpi.tcc), trendArrow('tcc', kpi.tcc), '');
  setElText('kpi-tcc-sub', `H_Corr ${kpi.hCorr.toFixed(1)}h / Total ${kpi.hTotal.toFixed(1)}h`);
  setObjBadge('kpi-tcc-obj', kpi.tcc, 'tcc', getOBJ(unit).tcc.label, unit);

  setKpiCard('kpi-tmp', pct(kpi.tmp), trendArrow('tmp', kpi.tmp), '');
  setElText('kpi-tmp-sub', `${kpi.btClosed} Clos+Fait / ${kpi.btDenom} BT`);
  setObjBadge('kpi-tmp-obj', kpi.tmp, 'tmp', 'Obj: 100%');

  setKpiCard('kpi-tmc', pct(kpi.tmc), trendArrow('tmc', kpi.tmc), '');
  setElText('kpi-tmc-sub', `${kpi.diDone} Trait+Real / ${kpi.diDenom} DI`);
  setObjBadge('kpi-tmc-obj', kpi.tmc, 'tmc', getOBJ(unit).tmc.label);

  setKpiCard('kpi-dispo', pct(kpi.dispo), trendArrow('dispo', kpi.dispo), '');
  setElText('kpi-dispo-sub', `Pratique ${kpi.tbf.toFixed(1)}h / Th ${kpi.hoursFlotte}h (${kpi.nbEquipements} eq.)`);
  setObjBadge('kpi-dispo-obj', kpi.dispo, 'dispo', getOBJ(unit).dispo.label, unit);

  setKpiCard('kpi-pannes', kpi.nbPannesTot, '', '');
  setElText('kpi-pannes-sub', 'Trait+Real+Trans+ATransm');

  renderUnitOverviewGrid();
  renderDashboardCharts();
    updatePeekValues(kpi, unit);
}

function setKpiCard(id, val, arrow, cls) {
  const el = document.getElementById(id); if (!el) return;
  el.innerHTML = `${val}${arrow ? ` ${arrow}` : ''}`;
}
function setElText(id, val)  { const el = document.getElementById(id); if (el) el.textContent = val; }
function setObjBadge(id, val, key, label, unit) {
  const el = document.getElementById(id); if (!el) return;
  el.className = `kpi-obj ${objClass(key, val, unit)}`; el.textContent = label;
}

function fmtDateFR(d) {
  return d.toLocaleDateString('fr-FR', { day:'2-digit', month:'short', year:'numeric' });
}

// =====================================================================
// UNIT OVERVIEW GRID
// =====================================================================
function buildUnitOverviewGrid() {
  const grid = document.getElementById('unit-overview-grid'); grid.innerHTML = '';
  UNITS.forEach(u => {
    const card = document.createElement('div'); card.className = 'unit-overview-card'; card.id = `uoc-${u}`;
    card.innerHTML = `<div class="uoc-name u-${u.toLowerCase()}">${u}</div>
      <div class="uoc-stats">
        <div class="uoc-stat"><span class="uoc-stat-label">TMP</span><span class="uoc-stat-val" id="uoc-tmp-${u}">—</span></div>
        <div class="uoc-stat"><span class="uoc-stat-label">TMC</span><span class="uoc-stat-val" id="uoc-tmc-${u}">—</span></div>
        <div class="uoc-stat"><span class="uoc-stat-label">Dispo</span><span class="uoc-stat-val" id="uoc-dispo-${u}">—</span></div>
        <div class="uoc-stat"><span class="uoc-stat-label">λ</span><span class="uoc-stat-val" id="uoc-tp-${u}" style="font-size:9px">—</span></div>
        <div class="uoc-stat"><span class="uoc-stat-label">μ</span><span class="uoc-stat-val" id="uoc-tr-${u}" style="font-size:9px">—</span></div>
      </div>`;
    card.addEventListener('click', () => {
      document.querySelectorAll('.unit-overview-card').forEach(c => c.classList.remove('active-unit'));
      card.classList.add('active-unit');
      document.getElementById('sel-unit').value = u;
      navigateTo('unit', u);
    });
    grid.appendChild(card);
  });
}
function renderUnitOverviewGrid() {
  const { hoursTotal, start, end } = getFilters();
  UNITS.forEach(u => {
    const { corrRows, prevRows } = getFilteredData(u);
    const k = calcKPIs(corrRows, prevRows, hoursTotal, start, end);
    const g = id => document.getElementById(`uoc-${id}-${u}`);
    if (g('tmp'))  g('tmp').innerHTML  = pct(k.tmp)  + ' ' + trendArrow('tmp',  k.tmp);
    if (g('tmc'))  g('tmc').innerHTML  = pct(k.tmc)  + ' ' + trendArrow('tmc',  k.tmc);
    if (g('dispo')) g('dispo').innerHTML = pct(k.dispo) + ' ' + trendArrow('dispo', k.dispo);
    if (g('tp'))   g('tp').innerHTML   = k.tauxPanne > 0 ? fmtSciShort(k.tauxPanne) + ' ' + trendArrow('tauxPanne', k.tauxPanne) : '⚠️0';
    if (g('tr'))   g('tr').innerHTML   = k.tauxRep   > 0 ? fmtSciShort(k.tauxRep)   + ' ' + trendArrow('tauxRep',   k.tauxRep)   : '—';
    const card = document.getElementById(`uoc-${u}`);
    if (card) {
      if      (k.dispo > 0.97) card.style.borderColor = 'rgba(16,185,129,0.3)';
      else if (k.dispo > 0.80) card.style.borderColor = 'rgba(245,158,11,0.3)';
      else if (k.dispo > 0)    card.style.borderColor = 'rgba(239,68,68,0.3)';
    }
  });
}

// =====================================================================
// DASHBOARD CHARTS
// =====================================================================
function renderDashboardCharts() {
  const { hoursTotal, start, end } = getFilters();
  const KS = UNITS.map(u => { const { corrRows, prevRows } = getFilteredData(u); return calcKPIs(corrRows, prevRows, hoursTotal, start, end); });
  const L  = UNITS;

  destroyChart('charge');
  const c1 = document.getElementById('chart-charge');
  if (c1) charts.charge = new Chart(c1, { type:'bar', data:{ labels:L, datasets:[
    { label:'TCP %', data:KS.map(k=>+(k.tcp*100).toFixed(1)), backgroundColor:KS.map((k,i)=>k.tcp>=getOBJ(L[i]).tcp.val?'rgba(5,150,105,0.85)':'rgba(220,38,38,0.85)'), borderRadius:6, order:1 },
    { label:'TCC %', data:KS.map(k=>+(k.tcc*100).toFixed(1)), backgroundColor:KS.map((k,i)=>k.tcc<=getOBJ(L[i]).tcc.val?'rgba(5,150,105,0.85)':'rgba(220,38,38,0.85)'), borderRadius:6, order:1 },
    { label:'Obj TCP', data:UNITS.map(u=>getOBJ(u).tcp.val*100), type:'line', borderColor:'rgba(34,211,238,0.5)', borderDash:[5,5], borderWidth:2, pointRadius:0, fill:false, order:0 },
    { label:'Obj TCC', data:UNITS.map(u=>getOBJ(u).tcc.val*100), type:'line', borderColor:'rgba(249,115,22,0.5)',  borderDash:[5,5], borderWidth:2, pointRadius:0, fill:false, order:0 }
  ]}, options:chartOpts('%') });

  destroyChart('tmt');
  const c2 = document.getElementById('chart-tmt');
  if (c2) charts.tmt = new Chart(c2, { type:'bar', data:{ labels:L, datasets:[
    { label:'TMP %', data:KS.map(k=>+(k.tmp*100).toFixed(1)), backgroundColor:KS.map((k,i)=>k.tmp>=getOBJ(L[i]).tmp.val?'rgba(5,150,105,0.85)':'rgba(220,38,38,0.85)'), borderRadius:6, order:1 },
    { label:'TMC %', data:KS.map(k=>+(k.tmc*100).toFixed(1)), backgroundColor:KS.map((k,i)=>k.tmc>=getOBJ(L[i]).tmc.val?'rgba(5,150,105,0.85)':'rgba(220,38,38,0.85)'), borderRadius:6, order:1 },
    { label:'Obj 100%', data:Array(L.length).fill(100), type:'line', borderColor:'rgba(16,185,129,0.6)', borderDash:[5,5], borderWidth:2, pointRadius:0, fill:false, order:0 },
    { label:'Obj TMC',  data:UNITS.map(u=>getOBJ(u).tmc.val*100), type:'line', borderColor:'rgba(245,158,11,0.6)', borderDash:[5,5], borderWidth:2, pointRadius:0, fill:false, order:0 }
  ]}, options:chartOpts('%') });

  destroyChart('dispo');
  const c3 = document.getElementById('chart-dispo');
  if (c3) charts.dispo = new Chart(c3, { type:'bar', data:{ labels:L, datasets:[
    { label:'Disponibilite %', data:KS.map(k=>+(k.dispo*100).toFixed(1)), backgroundColor:KS.map((k,i)=>k.dispo>=getOBJ(L[i]).dispo.val?'rgba(5,150,105,0.85)':'rgba(220,38,38,0.85)'), borderRadius:6, order:1 },
    { label:'Obj Dispo', data:UNITS.map(u=>getOBJ(u).dispo.val*100), type:'line', borderColor:'rgba(16,185,129,0.6)', borderDash:[5,5], borderWidth:2, pointRadius:0, fill:false, order:0 }
  ]}, options:chartOpts('%') });

  destroyChart('mttr');
  const c4a = document.getElementById('chart-mttr');
  if (c4a) charts['mttr'] = new Chart(c4a, { type:'bar', data:{ labels:L, datasets:[
    { label:'MTTR (h)', data:KS.map(k=>+k.mttr.toFixed(3)), backgroundColor:L.map(()=>'rgba(220,38,38,0.85)'), borderRadius:6 }
  ]}, options:chartOpts('h') });

  destroyChart('mtbf');
  const c4b = document.getElementById('chart-mtbf');
  if (c4b) charts['mtbf'] = new Chart(c4b, { type:'bar', data:{ labels:L, datasets:[
    { label:'MTBF (h)', data:KS.map(k=>+k.mtbf.toFixed(1)), backgroundColor:L.map(()=>'rgba(36, 83, 122,0.85)'), borderRadius:6 }
  ]}, options:chartOpts('h') });

  destroyChart('taux-panne');
  const c5 = document.getElementById('chart-taux-panne');
  if (c5) {
    const tpD = KS.map(k => k.tauxPanne);
    charts['taux-panne'] = new Chart(c5, { type:'bar', data:{ labels:L, datasets:[
      { label:'λ=1/MTBF', data:tpD, backgroundColor:tpD.map((v,i)=>v>=getOBJ(L[i]).tauxPanne.val?'rgba(5,150,105,0.85)':v>0?'rgba(220,38,38,0.85)':'rgba(148,163,184,0.5)'), borderRadius:8, order:1 },
      { label:'Obj λ-Def', data:UNITS.map(u=>getOBJ(u).tauxPanne.val), type:'line', borderColor:'rgba(217,119,6,0.9)', borderDash:[6,4], borderWidth:2, pointRadius:0, fill:false }
    ]}, options:{ responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{labels:{color:'#475569',font:{size:11}}}, tooltip:{callbacks:{label:c=>c.raw===0?` λ = 0 ⚠️ Donnees manquantes`:[` λ = ${fmtSciShort(c.raw)}`,` = ${fmtSci(c.raw)}`]}} },
      scales:{ x:chartScaleX(), y:{ ticks:{color:'#64748b',font:{size:10},callback:v=>v===0?'0⚠️':v.toExponential(1)}, grid:{color:'rgba(15,23,42,0.06)'}, title:{display:true,text:'λ=1/MTBF',color:'#64748b',font:{size:11}} } } } });
  }

  destroyChart('taux-rep');
  const c6 = document.getElementById('chart-taux-rep');
  if (c6) {
    const trD = KS.map(k => k.tauxRep);
    charts['taux-rep'] = new Chart(c6, { type:'bar', data:{ labels:L, datasets:[
      { label:'μ=1/MTTR', data:trD, backgroundColor:trD.map((v,i)=>v>=getOBJ(L[i]).tauxRep.val?'rgba(5,150,105,0.85)':v>0?'rgba(220,38,38,0.85)':'rgba(148,163,184,0.5)'), borderRadius:8, order:1 },
      { label:'Obj μ-Rep', data:UNITS.map(u=>getOBJ(u).tauxRep.val), type:'line', borderColor:'rgba(5,150,105,0.9)', borderDash:[6,4], borderWidth:2, pointRadius:0, fill:false }
    ]}, options:{ responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{labels:{color:'#475569',font:{size:11}}}, tooltip:{callbacks:{label:c=>c.raw===0?` μ = 0 ⚠️ Durées d'intervention manquantes`:[` μ = ${c.raw.toFixed(4)}`,` = ${fmtSci(c.raw)}`]}} },
      scales:{ x:chartScaleX(), y:{ ticks:{color:'#64748b',font:{size:10},callback:v=>v.toFixed(3)}, grid:{color:'rgba(15,23,42,0.06)'}, title:{display:true,text:'μ=1/MTTR',color:'#64748b',font:{size:11}} } } } });
  }

}


// =====================================================================
// KPIs PAGE
// =====================================================================
function renderKPIsPage() {
  const container = document.getElementById('kpis-detail-content');
  const { hoursTotal, start, end } = getFilters();
  const rows  = UNITS.map(u => { const { corrRows, prevRows } = getFilteredData(u); return { u, k: calcKPIs(corrRows, prevRows, hoursTotal, start, end), corrRows, prevRows }; });
  const total = rows.reduce((a, r) => a + r.corrRows.length + r.prevRows.length, 0);
  if (total === 0) { container.innerHTML = `<div class="empty-state"><div class="es-icon">📈</div><div class="es-title">Aucune donnee</div></div>`; return; }

  // ── BOUTON RAPPORT GENERAL IA ──
  // ── BOUTON RAPPORT GENERAL IA (telechargeable) ──
  const aiTriggerHtml = `
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:18px;padding:14px 18px;
                background:linear-gradient(135deg,rgba(36, 83, 122,0.07),rgba(47, 102, 144,0.05));
                border:1.5px solid rgba(36, 83, 122,0.2);border-radius:var(--radius)">
      <div style="width:42px;height:42px;border-radius:12px;background:var(--grad1);
                  display:flex;align-items:center;justify-content:center;font-size:20px;
                  box-shadow:0 4px 14px rgba(36, 83, 122,0.35);flex-shrink:0">🤖</div>
      <div style="flex:1">
        <div style="font-family:'Montserrat',sans-serif;font-size:14.5px;font-weight:800;color:#0a1930">
          Rapport General de Performance — IA
        </div>
        <div style="font-size:11.5px;color:#6b7fa8;font-style:italic">
          Analyse complete et detaillee de tous les indicateurs (hors MR et Efficience RH) — telechargement HTML
        </div>
      </div>
      <button class="btn btn-primary" id="btn-gen-ai-report" onclick="generateGeneralAIReport()">
        📥 Generer & Telecharger
      </button>
    </div>
    <div id="ai-general-report-status" style="display:none;margin-bottom:18px"></div>`;

  // ── Anomalies par unite (pour export XLSX — par unite ou Total) ──
  KPI_ANOMALY_MAP = {};
  rows.forEach(({ u, corrRows }) => { KPI_ANOMALY_MAP[u] = collectAnomalyRows(corrRows, hoursTotal, start, end); });

  let alertHtml = '';
  rows.forEach(({ u, k }) => {
    const items = [];
    if (k.nbSansDebut > 0) items.push(`${k.nbSansDebut} DI sans DATE_EVENEMENT`);
    if (k.nbNegatif  > 0) items.push(`${k.nbNegatif} DI duree negative`);
    if (k.nbAberrant > 0) items.push(`${k.nbAberrant} DI duree aberrante`);
    if (k.nbNoeudsPaire > 0) items.push(`${k.nbNoeudsPaire} DI sur noeud pair (${k.exNoeudsPaire.join(', ')})`);
    if (items.length > 0) alertHtml += `<div class="alert-item"><span class="ai-unit">${u}</span><span class="ai-msg">${items.join(' · ')}</span><span class="ai-val">MTBF affecte</span>
      <button class="btn btn-ghost btn-sm" style="padding:3px 9px;font-size:10px;white-space:nowrap" onclick="exportAnomalies('${u}')">⬇️ Exporter</button>
    </div>`;
  });

  container.innerHTML = `
    ${aiTriggerHtml}
    ${alertHtml ? `<div class="alert-panel" style="margin-bottom:16px">
      <div class="alert-panel-title" style="justify-content:space-between">
        <span>⚠️ Problemes de donnees par unite</span>
        <button class="btn btn-ghost btn-sm" style="font-size:10px;padding:4px 10px;white-space:nowrap" onclick="exportAnomalies('TOTAL')">📥 Exporter toutes les anomalies (Total)</button>
      </div>
      ${alertHtml}
    </div>` : ''}
    <div class="kpi-section-header engineering" style="margin-top:0">
      <span class="ksh-icon">🔬</span>
      <div><div class="ksh-title" style="color:#24537a">Indicateurs d'Ingenierie</div><div class="ksh-sub">MTTR · MTBF · λ · μ · TCP · TCC</div></div>
    </div>
    <div class="table-wrap" style="margin-bottom:16px">
      <table><thead><tr>
        <th>Unite</th><th>MTTR(h)</th><th>MTBF(h)</th>
        <th>λ=1/MTBF<br><small style="color:var(--green)">&gt;3e-3</small></th>
        <th>μ=1/MTTR<br><small style="color:var(--green)">&gt;0.25</small></th>
        <th>TCP<br><small style="color:var(--green)">&gt;80%</small></th>
        <th>TCC<br><small style="color:var(--red)">&lt;20%</small></th>
        <th>H_Prev</th><th>H_Corr</th><th>Rep.</th><th>Tot.</th><th>Indispo(h)</th><th>TBF(h)</th>
        <th style="text-align:center">Détail</th>
      </tr></thead><tbody>
        ${rows.map(({u,k}) => `<tr>
  <td><span class="unit-tag bg-${u.toLowerCase()} u-${u.toLowerCase()}">${u}</span></td>
  <td style="color:var(--corr)">${k.mttr.toFixed(3)}</td>
  <td style="color:var(--prev)">${k.mtbf>0&&k.nbPannesTot>0?k.mtbf.toFixed(1):'<span style="color:#ef4444">0 ⚠️</span>'}</td>
  <td><span class="badge ${objClass('tauxPanne',k.tauxPanne)}" style="font-size:9px">${k.tauxPanne>0?fmtSciShort(k.tauxPanne):'0 ⚠️'}</span> ${trendArrow('tauxPanne',k.tauxPanne)}</td>
  <td><span class="badge ${objClass('tauxRep',k.tauxRep)}" style="font-size:9px">${k.tauxRep>0?fmtSciShort(k.tauxRep):'0'}</span> ${trendArrow('tauxRep',k.tauxRep)}</td>
  <td><span class="badge ${objClass('tcp',k.tcp)}">${pct(k.tcp)}</span> ${trendArrow('tcp',k.tcp)}</td>
  <td><span class="badge ${objClass('tcc',k.tcc)}">${pct(k.tcc)}</span> ${trendArrow('tcc',k.tcc)}</td>
  <td style="font-size:11px">${k.hPrev.toFixed(1)}h</td><td style="font-size:11px">${k.hCorr.toFixed(1)}h</td>
  <td>${k.nbPannesRep}</td><td>${k.nbPannesTot}</td>
  <td style="color:var(--corr);font-size:11px">${k.indispoH.toFixed(1)}</td>
  <td style="font-size:11px">${k.tbf.toFixed(1)}</td>
  <td style="text-align:center">
    <button class="btn btn-ghost btn-sm" style="font-size:10px;padding:4px 10px;white-space:nowrap"
      onclick="toggleKpiEngDetail('${u}', this)">
      + Info
    </button>
  </td>
</tr>
<tr id="kpi-eng-detail-${u}" style="display:none">
  <td colspan="15" style="padding:0;background:rgba(248,250,255,0.9)">
    <div style="padding:12px 16px" id="kpi-eng-detail-content-${u}"></div>
  </td>
</tr>`).join('')}
      </tbody></table>
    </div>
    <div class="kpi-section-header realisation">
      <span class="ksh-icon">✅</span>
      <div><div class="ksh-title" style="color:#059669">Indicateurs de Realisation</div><div class="ksh-sub">TMP · TMC · Disponibilite · Nb Pannes</div></div>
    </div>
    <div class="table-wrap" style="margin-bottom:16px">
      <table><thead><tr>
        <th>Unite</th>
        <th>TMP<br><small style="color:var(--green)">100%</small></th>
        <th>TMC<br><small style="color:var(--green)">&gt;90%</small></th>
        <th>Dispo<br><small style="color:var(--green)">&gt;97%</small></th>
        <th>Nb Pannes Rep.</th><th>Nb Pannes Tot.</th>
        <th>BT Clos+Fait</th><th>BT Total</th><th>DI Trait+Real</th><th>DI Total</th>
        <th style="text-align:center">Détail</th>
      </tr></thead><tbody>
        ${rows.map(({u,k}) => `<tr>
          <td><span class="unit-tag bg-${u.toLowerCase()} u-${u.toLowerCase()}">${u}</span></td>
          <td><span class="badge ${objClass('tmp',k.tmp)}">${pct(k.tmp)}</span> ${trendArrow('tmp',k.tmp)}</td>
          <td><span class="badge ${objClass('tmc',k.tmc)}">${pct(k.tmc)}</span> ${trendArrow('tmc',k.tmc)}</td>
          <td><span class="badge ${objClass('dispo',k.dispo)}">${pct(k.dispo)}</span> ${trendArrow('dispo',k.dispo)}</td>
          <td>${k.nbPannesRep}</td><td>${k.nbPannesTot}</td>
          <td>${k.btClosed}</td><td>${k.btDenom}</td><td>${k.diDone}</td><td>${k.diDenom}</td>
          <td style="text-align:center">
            <button class="btn btn-ghost btn-sm" style="font-size:10px;padding:4px 10px;white-space:nowrap"
              onclick="toggleKpiRealDetail('${u}', this)">
              + Info
            </button>
          </td>
        </tr>
        <tr id="kpi-real-detail-${u}" style="display:none">
          <td colspan="11" style="padding:0;background:rgba(248,250,255,0.9)">
            <div style="padding:12px 16px" id="kpi-real-detail-content-${u}"></div>
          </td>
        </tr>`).join('')}
      </tbody></table>
    </div>
    `;

  
}

// =====================================================================
// CORRECTIVE PAGE
// =====================================================================
function setupTabs() {
  ['corr','prev'].forEach(t => {
    document.querySelectorAll(`#${t}-unit-tabs .tab`).forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll(`#${t}-unit-tabs .tab`).forEach(x => x.classList.remove('active'));
        tab.classList.add('active');
        if (t === 'corr') renderCorrectivePage(); else { PREV_PAGE = 1; renderPreventivePage(); }
      });
    });
  });
}
/* -> extrait dans assets/js/correctif.js (charge en fin de page, voir avant </body>) */

/* -> extrait dans assets/js/preventif.js (charge en fin de page, voir avant </body>) */





function ms(label, val, bc) {
  return `<div class="card" style="padding:10px 14px;flex:1;min-width:90px;${bc?'border-color:'+bc:''}"><div style="font-size:9px;color:var(--text3);text-transform:uppercase;letter-spacing:1px">${label}</div><div style="font-size:16px;font-weight:800;font-family:'Montserrat',sans-serif">${val}</div></div>`;
}

// =====================================================================
// EQUIPEMENTS PAGE
// =====================================================================
function renderEquipementsPage() {
  const { start, end, hoursTotal, unit } = getFilters();
  const container = document.getElementById('equip-content');

  // ── Collecte toutes les lignes selon filtre unite globale ──
  let allCorr = [], allPrev = [];
  UNITS.forEach(u => {
    if (unit !== 'all' && unit !== u) return;
    allCorr = allCorr.concat(filterByDate(DB.corrective[u] || [], 'DATE_DI',    start, end));
    allPrev = allPrev.concat(filterByDate(DB.preventive[u] || [], 'DATE_PREVUE', start, end));
  });

  if (allCorr.length + allPrev.length === 0) {
    container.innerHTML = `<div class="empty-state"><div class="es-icon">⚙️</div><div class="es-title">Aucune donnée</div></div>`;
    return;
  }

  // ── Construire l'interface de filtres hiérarchiques ──
  const hierCorr = collectEquipHierarchy(allCorr);
  const hierPrev = collectEquipHierarchy(allPrev);
  const allSystemes     = [...new Set([...hierCorr.systemes,     ...hierPrev.systemes])].sort();
  const allUnites       = [...new Set([...hierCorr.unites,       ...hierPrev.unites])].sort();
  const allSousSystemes = [...new Set([...hierCorr.sousSystemes, ...hierPrev.sousSystemes])].sort();

  // ── Lire les filtres courants depuis les selects dédiés ──
  const fUnite       = document.getElementById('eq-fil-unite')?.value       || 'all';
  const fSysteme     = document.getElementById('eq-fil-systeme')?.value     || 'all';
  const fSousSysteme = document.getElementById('eq-fil-sousSysteme')?.value || 'all';
  const fEquipement  = document.getElementById('eq-fil-equipement')?.value  || 'all';

  // ── Appliquer les filtres hiérarchiques ──
  const corrF = filterByEquipHierarchy(allCorr, { unite: fUnite, systeme: fSysteme, sousSysteme: fSousSysteme, equipement: fEquipement });
  const prevF = filterByEquipHierarchy(allPrev, { unite: fUnite, systeme: fSysteme, sousSysteme: fSousSysteme, equipement: fEquipement });

  // ── Liste des équipements disponibles (selon Unité/Système/Sous-système, indépendamment du filtre Équipement lui-même) ──
  const corrFnoEq = filterByEquipHierarchy(allCorr, { unite: fUnite, systeme: fSysteme, sousSysteme: fSousSysteme });
  const prevFnoEq = filterByEquipHierarchy(allPrev, { unite: fUnite, systeme: fSysteme, sousSysteme: fSousSysteme });
  const allEquipementsFiltres = [...new Set(
    [...corrFnoEq, ...prevFnoEq].map(r => (r['CODE_EQUIPEMENT'] || r['EQUIPEMENT'] || '').trim()).filter(Boolean)
  )].sort();

  // ── Nom réel de l'équipement par code (EQUIPEMENT en correctif, DESIGNATION_EQUIPEMENT en préventif) ──
  const eqNameMap = {};
  [...corrFnoEq, ...prevFnoEq].forEach(r => {
    const code = (r['CODE_EQUIPEMENT'] || r['EQUIPEMENT'] || '').trim();
    if (!code || eqNameMap[code]) return;
    const nom = (r['EQUIPEMENT'] || r['DESIGNATION_EQUIPEMENT'] || '').trim();
    if (nom && nom !== code) eqNameMap[code] = nom;
  });

  // ── Filtres date (lus tôt car ils doivent s'appliquer AVANT l'indexation par équipement) ──
  const fDateStart  = document.getElementById('eq-fil-date-start')?.value  || '';
  const fDateEnd    = document.getElementById('eq-fil-date-end')?.value    || '';
  let corrFinal = corrF, prevFinal = prevF;
  if (fDateStart) {
    const ds = new Date(fDateStart + 'T00:00:00');
    corrFinal = corrFinal.filter(r => { const d = parseDate(r['DATE_DI']); return !d || d >= ds; });
    prevFinal = prevFinal.filter(r => { const d = parseDate(r['DATE_PREVUE']); return !d || d >= ds; });
  }
  if (fDateEnd) {
    const de = new Date(fDateEnd + 'T23:59:59');
    corrFinal = corrFinal.filter(r => { const d = parseDate(r['DATE_DI']); return !d || d <= de; });
    prevFinal = prevFinal.filter(r => { const d = parseDate(r['DATE_PREVUE']); return !d || d <= de; });
  }

  // ── Indexer par CODE_EQUIPEMENT (sur les données filtrées par date) ──
  const corrMap = {}, prevMap = {};
  EQ_ROWS_MAP = {}; // reconstruit a chaque rendu, sur le meme perimetre filtre (date/unite/systeme/equipement)
  const eqRows = (code) => (EQ_ROWS_MAP[code] || (EQ_ROWS_MAP[code] = { corr: [], prev: [] }));

  corrFinal.forEach(r => {
    const code = (r['CODE_EQUIPEMENT'] || r['EQUIPEMENT'] || 'Inconnu').trim();
    if (!isAnnule(normState(r['ETAT_DI']))) eqRows(code).corr.push(r); // ligne brute complete (toutes colonnes import, jusqu'a CHEMIN_PJ) pour export — DI Annulé exclues
    if (!corrMap[code]) {
      const p = parseCodeEquipement(code);
      corrMap[code] = { code, systeme: p.systeme, unite: p.unite, sousSysteme: p.sousSysteme,
        pannesTot: 0, pannesRep: 0, dureeH: 0, logistiqueH: 0, indispoH: 0, nbSansDate: 0, unit: r.__UNIT__ || '—' };
    }
    const s = normState(r['ETAT_DI']);
    if (isTraitee(s) || isRealisee(s) || isTransmis(s) || isTransmettre(s)) corrMap[code].pannesTot++;
    if (isTraitee(s) || isRealisee(s)) corrMap[code].pannesRep++;
    const keys_c = Object.keys(r);
    const dk_c = keys_c.find(k => /dur.{0,3}e.*interv|interv.*min/i.test(k.normalize('NFD').replace(/[\u0300-\u036f]/g,'')));
    const lk_c = keys_c.find(k => /temps.*log|log.*min/i.test(k.normalize('NFD').replace(/[\u0300-\u036f]/g,'')));
    const d_c = dk_c ? parseFloat(String(r[dk_c]).replace(',','.')) : NaN;
    const l_c = lk_c ? parseFloat(String(r[lk_c]).replace(',','.')) : NaN;
    if (!isNaN(d_c) && d_c > 0) corrMap[code].dureeH      += d_c / 60;
    if (!isNaN(l_c) && l_c > 0) corrMap[code].logistiqueH += l_c / 60;
    const fin = parseDate(r['DATE_FIN_INTERVENTION']), deb = parseDate(r['DATE_EVENEMENT']);
    if (fin && deb && fin > deb) corrMap[code].indispoH += (fin - deb) / 3600000;
    else if (!fin || !deb) corrMap[code].nbSansDate++;
  });

  prevFinal.forEach(r => {
    const code = (r['CODE_EQUIPEMENT'] || '').trim() || 'Inconnu';
    eqRows(code).prev.push(r); // ligne brute complete (toutes colonnes import) pour export
    if (!prevMap[code]) {
      const p = parseCodeEquipement(code);
      prevMap[code] = { code, systeme: p.systeme, unite: p.unite, sousSysteme: p.sousSysteme,
        nbBT: 0, btClos: 0, dureeH: 0, logistiqueH: 0, nbPassages: 0, unit: r.__UNIT__ || '—' };
    }
    prevMap[code].nbBT++;
    prevMap[code].nbPassages++;
    const s = normState(r['ETAT_BT']);
    if (s.includes('clos') || s.includes('fait')) prevMap[code].btClos++;
    const keys_p = Object.keys(r);
    const dk_p = keys_p.find(k => /dur.{0,3}e.*interv|interv.*min/i.test(k.normalize('NFD').replace(/[\u0300-\u036f]/g,'')));
    const lk_p = keys_p.find(k => /temps.*log|log.*min/i.test(k.normalize('NFD').replace(/[\u0300-\u036f]/g,'')));
    const d_p = dk_p ? parseFloat(String(r[dk_p]).replace(',','.')) : NaN;
    const l_p = lk_p ? parseFloat(String(r[lk_p]).replace(',','.')) : NaN;
    if (!isNaN(d_p) && d_p > 0) prevMap[code].dureeH      += d_p / 60;
    if (!isNaN(l_p) && l_p > 0) prevMap[code].logistiqueH += l_p / 60;
  });

  // ── Classification des 3 catégories ──
  const allCodes = new Set([...Object.keys(corrMap), ...Object.keys(prevMap)]);

if (allCodes.size === 0) {
    container.innerHTML = `<div class="empty-state"><div class="es-icon">⚙️</div><div class="es-title">Aucun équipement trouvé</div><div class="es-sub">Vérifiez que vos fichiers contiennent une colonne CODE_EQUIPEMENT ou EQUIPEMENT</div></div>`;
    return;
}

const cat1 = [], cat2 = [], cat3 = [];

  allCodes.forEach(code => {
    const hasCorr = !!corrMap[code];
    const hasPrev = !!prevMap[code];
    const p    = parseCodeEquipement(code);
    const base = {
      code,
      systeme:     p.systeme,
      unite:       p.unite,
      sousSysteme: p.sousSysteme,
      unitOp:      (corrMap[code] || prevMap[code])?.unit || '—',
      corrData:    corrMap[code] || null,
      prevData:    prevMap[code] || null
    };
    if (hasCorr && hasPrev) cat1.push(base);
    else if (hasPrev)       cat2.push(base);
    else                    cat3.push(base);
  });

  // Tri par nombre d'interventions décroissant
  const sortCat = (arr) => arr.sort((a, b) => {
    const aScore = (a.corrData?.pannesTot || 0) + (a.prevData?.nbBT || 0);
    const bScore = (b.corrData?.pannesTot || 0) + (b.prevData?.nbBT || 0);
    return bScore - aScore;
  });
  sortCat(cat1); sortCat(cat2); sortCat(cat3);

  // ── HTML ──
  const mkOption = (val, label, cur) =>
    `<option value="${val}" ${cur === val ? 'selected' : ''}>${label}</option>`;

 // ── Lire aussi les seuils équipements (dates déjà lues plus haut) ──
  const fMinCorr  = parseInt(document.getElementById('eq-fil-min-corr')?.value  || '0') || 0;
const fMaxCorr  = parseInt(document.getElementById('eq-fil-max-corr')?.value  || '0') || 0;
const fMinPrev  = parseInt(document.getElementById('eq-fil-min-prev')?.value  || '0') || 0;
const fMaxPrev  = parseInt(document.getElementById('eq-fil-max-prev')?.value  || '0') || 0;
const fBtSeuil  = parseInt(document.getElementById('eq-fil-bt-seuil')?.value  || '0') || 0;

// Guard : si aucune donnée
if (allCorr.length + allPrev.length === 0) {
    container.innerHTML = `<div class="empty-state"><div class="es-icon">⚙️</div><div class="es-title">Aucune donnée</div></div>`;
    return;
}

  // (filtrage date déjà appliqué plus haut, avant l'indexation par équipement)

  // ── Sous-systèmes filtrés selon système choisi ──
  const allSousSystemesFiltres = fSysteme !== 'all'
    ? [...new Set(
        [...corrFinal, ...prevFinal].map(r => parseCodeEquipement(r['CODE_EQUIPEMENT']||r['EQUIPEMENT']||'').sousSysteme).filter(s=>s!=='— N/A —')
      )].sort()
    : allSousSystemes;

  const filterBarHtml = `
    <div class="filter-card" style="margin:0 0 18px;width:auto;flex-wrap:wrap;gap:10px"
         id="eq-filter-bar">
      <div class="fc-icon">🔧</div>

      <div class="filter-group">
        <span class="filter-label">Unité CODE</span>
        <select id="eq-fil-unite" onchange="renderEquipementsPage()" style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;cursor:pointer;outline:none;font-weight:500;">
          ${mkOption('all','Toutes',fUnite)}
          ${allUnites.map(u => mkOption(u, u, fUnite)).join('')}
        </select>
      </div>

      <div class="filter-group">
        <span class="filter-label">Système</span>
        <select id="eq-fil-systeme" onchange="renderEquipementsPage()" style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;cursor:pointer;outline:none;font-weight:500;">
          ${mkOption('all','Tous',fSysteme)}
          ${allSystemes.map(s => mkOption(s, s, fSysteme)).join('')}
        </select>
      </div>

      <div class="filter-group">
        <span class="filter-label">Sous-système</span>
        <select id="eq-fil-sousSysteme" onchange="renderEquipementsPage()" style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;cursor:pointer;outline:none;font-weight:500;">
          ${mkOption('all','Tous',fSousSysteme)}
          ${allSousSystemesFiltres.map(s => mkOption(s, s, fSousSysteme)).join('')}
        </select>
      </div>

      <div class="filter-group">
        <span class="filter-label">Équipement</span>
        <select id="eq-fil-equipement" onchange="renderEquipementsPage()" style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;cursor:pointer;outline:none;font-weight:500;max-width:220px">
          ${mkOption('all','Tous',fEquipement)}
          ${allEquipementsFiltres.map(e => mkOption(e, eqNameMap[e] ? `${e} — ${eqNameMap[e]}` : e, fEquipement)).join('')}
        </select>
      </div>

      <div class="fc-divider"></div>

      <div class="filter-group">
        <span class="filter-label">Début</span>
        <input type="date" id="eq-fil-date-start" value="${fDateStart}"
          onchange="renderEquipementsPage()"
          style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;outline:none;">
      </div>
      <div class="filter-group">
        <span class="filter-label">Fin</span>
        <input type="date" id="eq-fil-date-end" value="${fDateEnd}"
          onchange="renderEquipementsPage()"
          style="background:#f8faff;border:1.5px solid #dde6f5;color:#0a1930;padding:7px 11px;border-radius:9px;font-size:12.5px;font-family:'Montserrat',sans-serif;outline:none;">
      </div>

      <div class="fc-divider"></div>

      

      <div class="filter-group" style="flex-direction:column;gap:4px">
  <span class="filter-label">🔴 Seuil BT Total</span>
  <input type="number" id="eq-fil-bt-seuil" value="${fBtSeuil||''}" placeholder="ex: 10" min="0"
    onchange="renderEquipementsPage()"
    style="width:70px;background:#f8faff;border:1.5px solid #dde6f5;padding:6px 8px;border-radius:9px;font-size:12px;font-family:'Montserrat',sans-serif;color:#0a1930;outline:none;">
  <span style="font-size:9px;color:var(--text3)">Colorie si BT ≥ seuil</span>
</div>

<div style="margin-left:auto;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
  <span style="font-size:11px;color:var(--text3);font-style:italic">
    ${corrFinal.length} corr. · ${prevFinal.length} prév. · ${allCodes.size} équipements
  </span>
  <button class="btn btn-ghost btn-sm" onclick="
    ['eq-fil-unite','eq-fil-systeme','eq-fil-sousSysteme','eq-fil-equipement'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='all';});
    ['eq-fil-date-start','eq-fil-date-end'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
    const bs=document.getElementById('eq-fil-bt-seuil');if(bs)bs.value='';
    renderEquipementsPage()">✕ Reset</button>
</div>
    </div>`;

  // ── Indicateur Taux de Panne (λ = Durée d'intervention / Temps de Fonctionnement Théorique) ──
  // Calculé sur le périmètre filtré (Unité / Système / Sous-système / Équipement / dates)
  // Temps de fonctionnement théorique = Nb équipements du périmètre × heures réelles de la période
  // (ex: janvier = 31j × 24h = 744h). Aucune soustraction d'indisponibilité — c'est un temps THÉORIQUE.
  const tpDs = fDateStart ? new Date(fDateStart + 'T00:00:00') : start;
  const tpDe = fDateEnd   ? new Date(fDateEnd   + 'T23:59:59') : end;
  const tpDays = Math.max(1, Math.round((tpDe - tpDs) / 86400000));
  const tpHoursPerEquip = tpDays * 24;
  const tpNbEquip = fEquipement !== 'all' ? 1 : Math.max(1, allEquipementsFiltres.length);
  const tpHoursTotal = tpHoursPerEquip * tpNbEquip;
  const tpKpi = calcKPIs(corrFinal, prevFinal, tpHoursTotal, tpDs, tpDe);

  // λ théorique = Durée d'intervention (Durée Corr. + Logist. Corr., en h) / Temps de fonctionnement théorique
  const tpTauxTheorique = tpHoursTotal > 0 ? tpKpi.hCorr / tpHoursTotal : 0;
  const tpMtbfTheorique = tpTauxTheorique > 0 ? 1 / tpTauxTheorique : tpHoursTotal;

  const tpScopeLabel = [
    fSysteme    !== 'all' ? `Système: ${fSysteme}`       : null,
    fEquipement !== 'all' ? `Équipement: ${fEquipement}` : null,
    fUnite      !== 'all' ? `Unité: ${fUnite}`           : null
  ].filter(Boolean).join(' · ') || 'Tous systèmes / équipements';

  // ── Échelle qualitative — seuils dépendants de la durée de la période filtrée ──
  const tpNbMois = tpDays / 30.44;
  let tpPeriodeType;
  if (tpNbMois <= 1.5)      { tpPeriodeType = 'Mensuel (≈1 mois)';       }
  else if (tpNbMois <= 4.5) { tpPeriodeType = 'Trimestriel (≈3 mois)';   }
  else if (tpNbMois <= 9)   { tpPeriodeType = 'Semestriel (≈6 mois)';    }
  else                      { tpPeriodeType = 'Annuel (≈12 mois)';       }
  const tpSeuilBon = 0.5, tpSeuilAlerte = 1;

  const tpPct = tpTauxTheorique * 100;
  function rateTauxPanne(pct, seuilBon, seuilAlerte) {
    if (pct <= 0)          return { label: '—',              color: '#94a3b8', bg: 'rgba(148,163,184,0.15)' };
    if (pct < seuilBon)    return { label: 'Bon',             color: '#059669', bg: 'rgba(5,150,105,0.15)'  };
    if (pct < seuilAlerte) return { label: "Seuil d'alerte",  color: '#d97706', bg: 'rgba(217,119,6,0.15)'  };
    return                      { label: 'Seuil critique',   color: '#dc2626', bg: 'rgba(220,38,38,0.15)'  };
  }
  const tpRating = rateTauxPanne(tpPct, tpSeuilBon, tpSeuilAlerte);

  const tauxPanneHtml = `
    <div class="card" style="margin-bottom:18px;border-left:4px solid #dc2626">
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:6px">
        <div class="card-title" style="margin-bottom:0">📉 Taux de Panne</div>
        <span style="font-size:11px;color:var(--text3);font-style:italic">${tpScopeLabel} · ${tpPeriodeType}</span>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;margin-top:10px">
        <div class="kpi-card" style="border-top:3px solid #dc2626">
          <div class="kpi-label">Taux de Panne (λ)</div>
          <div class="kpi-value" style="font-size:22px;color:#dc2626">${tpTauxTheorique > 0 ? tpPct.toFixed(3) + '%' : '—'}</div>
          <div class="kpi-sub">${tpTauxTheorique > 0 ? 'h interv. / h théoriques' : 'durée intervention / durée théorique'}</div>
          <div style="margin-top:8px;display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;color:${tpRating.color};background:${tpRating.bg}">${tpRating.label}</div>
        </div>
        <div class="kpi-card" style="border-top:3px solid #24537a">
          <div class="kpi-label">Durée d'Intervention</div>
          <div class="kpi-value" style="font-size:22px;color:#24537a">${tpKpi.hCorr.toFixed(1)}h</div>
          <div class="kpi-sub">sur la période filtrée</div>
        </div>
        <div class="kpi-card" style="border-top:3px solid #d97706">
          <div class="kpi-label">Nb Équipements</div>
          <div class="kpi-value" style="font-size:22px;color:#d97706">${tpNbEquip}</div>
          <div class="kpi-sub">× ${tpHoursPerEquip.toFixed(0)}h/équip.</div>
        </div>
        <div class="kpi-card" style="border-top:3px solid #059669">
          <div class="kpi-label">Temps Fonct. Théorique</div>
          <div class="kpi-value" style="font-size:22px;color:#059669">${tpHoursTotal.toFixed(0)}h</div>
          <div class="kpi-sub">${tpNbEquip} équip. × ${tpHoursPerEquip.toFixed(0)}h</div>
        </div>
      </div>
      <div style="margin-top:12px;display:flex;flex-wrap:wrap;gap:8px;font-size:10.5px;align-items:center">
        <span style="color:var(--text3);font-weight:600">Seuils :</span>
        <span style="padding:3px 9px;border-radius:20px;background:rgba(5,150,105,0.12);color:#059669;font-weight:600">&lt; ${tpSeuilBon}% Bon</span>
        <span style="padding:3px 9px;border-radius:20px;background:rgba(217,119,6,0.12);color:#d97706;font-weight:600">${tpSeuilBon}–${tpSeuilAlerte}% Seuil d'alerte</span>
        <span style="padding:3px 9px;border-radius:20px;background:rgba(220,38,38,0.12);color:#dc2626;font-weight:600">≥ ${tpSeuilAlerte}% Seuil critique</span>
      </div>
    </div>`;

  // ── Indicateur Taux d'arrêt (τ = Temps d'Indisponibilité / Temps de Fonctionnement Théorique) ──
  // Meme perimetre filtre et meme Temps de Fonctionnement Theorique (tpHoursTotal) que le Taux de Panne ci-dessus.
  // Temps d'indisponibilite = tpKpi.indispoH, calcule par calcKPIs() exactement comme dans le Tableau de bord / Performance
  // (ecart DATE_FIN_INTERVENTION - DATE_EVENEMENT, avec la valeur de secours Duree Intervention + Temps Logistique en absence/anomalie de dates).
  const tpTauxIntervention = tpHoursTotal > 0 ? tpKpi.indispoH / tpHoursTotal : 0;
  const tpPctInterv = tpTauxIntervention * 100;
  const tiSeuilBon = 1, tiSeuilAlerte = 5;
  const tiRating = rateTauxPanne(tpPctInterv, tiSeuilBon, tiSeuilAlerte);

  const tauxInterventionHtml = `
    <div class="card" style="margin-bottom:18px;border-left:4px solid #7c3aed">
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:6px">
        <div class="card-title" style="margin-bottom:0">🛠️ Taux d'arrêt</div>
        <span style="font-size:11px;color:var(--text3);font-style:italic">${tpScopeLabel} · ${tpPeriodeType}</span>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;margin-top:10px">
        <div class="kpi-card" style="border-top:3px solid #7c3aed">
          <div class="kpi-label">Taux d'arrêt (τ)</div>
          <div class="kpi-value" style="font-size:22px;color:#7c3aed">${tpTauxIntervention > 0 ? tpPctInterv.toFixed(3) + '%' : '—'}</div>
          <div class="kpi-sub">${tpTauxIntervention > 0 ? 'h indispo / h théoriques' : 'temps indisponibilité / temps théorique'}</div>
          <div style="margin-top:8px;display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;color:${tiRating.color};background:${tiRating.bg}">${tiRating.label}</div>
        </div>
        <div class="kpi-card" style="border-top:3px solid #24537a">
          <div class="kpi-label">Temps d'Indisponibilité</div>
          <div class="kpi-value" style="font-size:22px;color:#24537a">${tpKpi.indispoH.toFixed(1)}h</div>
          <div class="kpi-sub">sur la période filtrée</div>
        </div>
        <div class="kpi-card" style="border-top:3px solid #d97706">
          <div class="kpi-label">Nb Équipements</div>
          <div class="kpi-value" style="font-size:22px;color:#d97706">${tpNbEquip}</div>
          <div class="kpi-sub">× ${tpHoursPerEquip.toFixed(0)}h/équip.</div>
        </div>
        <div class="kpi-card" style="border-top:3px solid #059669">
          <div class="kpi-label">Temps Fonct. Théorique</div>
          <div class="kpi-value" style="font-size:22px;color:#059669">${tpHoursTotal.toFixed(0)}h</div>
          <div class="kpi-sub">${tpNbEquip} équip. × ${tpHoursPerEquip.toFixed(0)}h</div>
        </div>
      </div>
      <div style="margin-top:12px;display:flex;flex-wrap:wrap;gap:8px;font-size:10.5px;align-items:center">
        <span style="color:var(--text3);font-weight:600">Seuils :</span>
        <span style="padding:3px 9px;border-radius:20px;background:rgba(5,150,105,0.12);color:#059669;font-weight:600">&lt; ${tiSeuilBon}% Bon</span>
        <span style="padding:3px 9px;border-radius:20px;background:rgba(217,119,6,0.12);color:#d97706;font-weight:600">${tiSeuilBon}–${tiSeuilAlerte}% Seuil d'alerte</span>
        <span style="padding:3px 9px;border-radius:20px;background:rgba(220,38,38,0.12);color:#dc2626;font-weight:600">≥ ${tiSeuilAlerte}% Seuil critique</span>
      </div>
    </div>`;

  // ── Indicateur Taux de pannes récurrentes (τr = Nb pannes récurrentes / Nb pannes totales) ──
  // Même périmètre filtré (Unité / Système / Sous-système / Équipement / dates) que les 2 indicateurs ci-dessus.
  // Définition : une panne est "récurrente" quand elle partage le même MOTIF DE PANNE (texte normalisé
  // à partir de TITRE_DI + C_R, en secours COMMENTAIRE_DI) qu'au moins une autre panne du MEME équipement
  // (CODE_EQUIPEMENT) sur la période filtrée. On ne compare que les pannes abouties (Traitée / Réalisée /
  // Transmis / À transmettre — même filtre que "Pannes Totales" / tpKpi.nbPannesTot) pour rester cohérent
  // avec le dénominateur.
  //
  // Normalisation du motif : accents supprimés, minuscule, ponctuation/chiffres retirés, mots < 3 lettres et
  // mots vides ("de","le","du"...) filtrés, puis mots triés/dédupliqués → "empreinte" insensible à l'ordre
  // des mots et aux petites variations de rédaction entre deux DI portant sur la même cause.
  const MOTIF_STOPWORDS = new Set(['de','du','des','le','la','les','un','une','et','ou','sur','avec','pour','dans',
    'ce','cette','ces','au','aux','en','par','plus','non','pas','the','and','est','sont','suite','apres','après',
    'avant','lors','the','a','à','via','vers','tres','très','nouveau','nouvelle','concernant']);
  function normalizeMotifText(str) {
    if (!str) return '';
    const words = String(str)
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z\s]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length >= 3 && !MOTIF_STOPWORDS.has(w));
    return [...new Set(words)].sort().join(' ');
  }
  function getMotifKey(r) {
    const titre = r['TITRE_DI'] || r['TITRE'] || '';
    const cr = r['C_R'] || r['CR'] || r['COMMENTAIRE_DI'] || '';
    return normalizeMotifText(titre + ' ' + cr);
  }

  const motifGroups = {};
  let __mIdx = 0;
  corrFinal.forEach(r => {
    const s = normState(r['ETAT_DI']);
    if (!(isTraitee(s) || isRealisee(s) || isTransmis(s) || isTransmettre(s))) return;
    const code = (r['CODE_EQUIPEMENT'] || r['EQUIPEMENT'] || 'Inconnu').trim();
    const motif = getMotifKey(r);
    __mIdx++;
    const key = motif ? (code + '§' + motif) : (code + '§__vide__' + __mIdx); // motif vide = jamais regroupé
    if (!motifGroups[key]) motifGroups[key] = { count: 0, code, motif, titles: {} };
    motifGroups[key].count++;
    const origTitle = (r['TITRE_DI'] || r['TITRE'] || '').toString().trim() || '(sans titre)';
    motifGroups[key].titles[origTitle] = (motifGroups[key].titles[origTitle] || 0) + 1;
  });

  let tpNbPannesRecurrentes = 0;
  let tpNbMotifsRecurrents = 0;
  const equipRecurrentsSet = new Set();
  const topMotifsList = [];
  Object.values(motifGroups).forEach(g => {
    if (g.count >= 2 && g.motif) {
      tpNbPannesRecurrentes += g.count;
      tpNbMotifsRecurrents++;
      equipRecurrentsSet.add(g.code);
      const bestTitle = Object.entries(g.titles).sort((a, b) => b[1] - a[1])[0][0];
      topMotifsList.push({ code: g.code, label: bestTitle, count: g.count });
    }
  });
  topMotifsList.sort((a, b) => b.count - a.count);
  const tpNbEquipRecurrents = equipRecurrentsSet.size;

  const tpNbPannesTotales = tpKpi.nbPannesTot;
  const tpTauxRecurrence = tpNbPannesTotales > 0 ? tpNbPannesRecurrentes / tpNbPannesTotales : 0;
  const tpPctRecurrence = tpTauxRecurrence * 100;
  const trSeuilBon = 15, trSeuilAlerte = 30;
  const trRating = rateTauxPanne(tpPctRecurrence, trSeuilBon, trSeuilAlerte);

  const topMotifsRowsHtml = topMotifsList.slice(0, 8).map(m => `
    <tr>
      <td style="padding:6px 10px;font-size:11.5px;color:#0a1930">${m.code}</td>
      <td style="padding:6px 10px;font-size:11.5px;color:var(--text2)">${(m.label || '').slice(0, 90)}</td>
      <td style="padding:6px 10px;font-size:11.5px;text-align:center"><span class="badge" style="background:rgba(234,88,12,0.12);color:#ea580c;font-weight:700">${m.count}×</span></td>
    </tr>`).join('');

  const tauxRecurrenceHtml = `
    <div class="card" style="margin-bottom:18px;border-left:4px solid #ea580c">
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:6px">
        <div class="card-title" style="margin-bottom:0">🔁 Taux de Pannes Récurrentes</div>
        <span style="font-size:11px;color:var(--text3);font-style:italic">${tpScopeLabel} · ${tpPeriodeType}</span>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;margin-top:10px">
        <div class="kpi-card" style="border-top:3px solid #ea580c">
          <div class="kpi-label">Taux de Récurrence</div>
          <div class="kpi-value" style="font-size:22px;color:#ea580c">${tpNbPannesTotales > 0 ? tpPctRecurrence.toFixed(1) + '%' : '—'}</div>
          <div class="kpi-sub">${tpNbPannesTotales > 0 ? 'pannes récurr. / pannes totales' : 'nb pannes récurrentes / nb pannes totales'}</div>
          <div style="margin-top:8px;display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;color:${trRating.color};background:${trRating.bg}">${trRating.label}</div>
        </div>
        <div class="kpi-card" style="border-top:3px solid #24537a">
          <div class="kpi-label">Pannes Récurrentes</div>
          <div class="kpi-value" style="font-size:22px;color:#24537a">${tpNbPannesRecurrentes}</div>
          <div class="kpi-sub">${tpNbMotifsRecurrents} motif(s) répété(s)</div>
        </div>
        <div class="kpi-card" style="border-top:3px solid #d97706">
          <div class="kpi-label">Pannes Totales</div>
          <div class="kpi-value" style="font-size:22px;color:#d97706">${tpNbPannesTotales}</div>
          <div class="kpi-sub">sur la période filtrée</div>
        </div>
        <div class="kpi-card" style="border-top:3px solid #059669">
          <div class="kpi-label">Équipements Concernés</div>
          <div class="kpi-value" style="font-size:22px;color:#059669">${tpNbEquipRecurrents}</div>
          <div class="kpi-sub">avec ≥ 1 motif répété</div>
        </div>
      </div>
      <div style="margin-top:12px;display:flex;flex-wrap:wrap;gap:8px;font-size:10.5px;align-items:center">
        <span style="color:var(--text3);font-weight:600">Seuils :</span>
        <span style="padding:3px 9px;border-radius:20px;background:rgba(5,150,105,0.12);color:#059669;font-weight:600">&lt; ${trSeuilBon}% Bon</span>
        <span style="padding:3px 9px;border-radius:20px;background:rgba(217,119,6,0.12);color:#d97706;font-weight:600">${trSeuilBon}–${trSeuilAlerte}% Seuil d'alerte</span>
        <span style="padding:3px 9px;border-radius:20px;background:rgba(220,38,38,0.12);color:#dc2626;font-weight:600">≥ ${trSeuilAlerte}% Seuil critique</span>
      </div>
      <div style="margin-top:6px;font-size:10px;color:var(--text3);font-style:italic">Une panne est "récurrente" quand son motif (TITRE_DI + C_R normalisés) se répète au moins 2 fois sur le même équipement, sur la période filtrée.</div>
      ${topMotifsList.length ? `
      <div style="margin-top:14px;border-top:1px solid var(--border,#e5e9f2);padding-top:12px">
        <div style="font-size:11.5px;font-weight:700;color:#0a1930;margin-bottom:6px">Top motifs de pannes récurrentes</div>
        <div style="overflow-x:auto">
          <table style="width:100%;border-collapse:collapse">
            <thead><tr style="text-align:left;border-bottom:1px solid var(--border,#e5e9f2)">
              <th style="padding:4px 10px;font-size:10.5px;color:var(--text3)">Équipement</th>
              <th style="padding:4px 10px;font-size:10.5px;color:var(--text3)">Motif (TITRE_DI)</th>
              <th style="padding:4px 10px;font-size:10.5px;color:var(--text3);text-align:center">Occurrences</th>
            </tr></thead>
            <tbody>${topMotifsRowsHtml}</tbody>
          </table>
        </div>
      </div>` : ''}
    </div>`;

  // ── Résumé visuel 3 catégories ──
  const summaryHtml = `
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:20px">
      ${eqCatCard('🔄','Préventif + Correctif',cat1.length,
        'Équipements couverts sur les deux plans','rgba(36, 83, 122,0.15)','#24537a')}
      ${eqCatCard('🛡️','Préventif seulement',cat2.length,
        'Aucune panne correctve enregistrée','rgba(5,150,105,0.15)','#059669')}
      ${eqCatCard('🔴','Correctif seulement',cat3.length,
        'Aucune maintenance préventive planifiée','rgba(220,38,38,0.15)','#dc2626')}
    </div>`;

  // ── Tableaux par catégorie ──
  const cat1Html = buildEqCatTable(cat1, 'cat1', '🔄 Catégorie 1 — Préventif ET Correctif', '#24537a', hoursTotal, fBtSeuil);
  const cat2Html = buildEqCatTable(cat2, 'cat2', '🛡️ Catégorie 2 — Préventif seulement',   '#059669', hoursTotal, fBtSeuil);
  const cat3Html = buildEqCatTable(cat3, 'cat3', '🔴 Catégorie 3 — Correctif seulement',   '#dc2626', hoursTotal, fBtSeuil);

  // ── Graphiques Top 10 ──
  const chartsHtml = `
    <div class="grid-2" style="margin-bottom:18px">
      <div class="card">
        <div class="card-title">🔴 Top 10 — Pannes Correctives</div>
        <div class="chart-wrap tall"><canvas id="eq-top"></canvas></div>
      </div>
      <div class="card">
        <div class="card-title">⏱️ Top 10 — Durée Intervention (Corr.)</div>
        <div class="chart-wrap tall"><canvas id="eq-dur"></canvas></div>
      </div>
    </div>`;

  container.innerHTML = filterBarHtml + tauxPanneHtml + tauxInterventionHtml + tauxRecurrenceHtml + summaryHtml + chartsHtml + cat1Html + cat2Html + cat3Html;

  // ── Boutons Export par équipement (tableaux Catégorie 1/2/3) ──
  container.querySelectorAll('.btn-export-eq').forEach(btn => {
    btn.addEventListener('click', () => showEquipementDetail(btn.dataset.code));
  });

  // ── Graphiques ──
  setTimeout(() => {
    const top10 = Object.values(corrMap)
      .sort((a, b) => b.pannesTot - a.pannesTot).slice(0, 10);

    // Clic sur une barre => affiche le detail de l'équipement (l'export se decide ensuite dans la modale)
    const onBarClickExport = (evt, elements, chart) => {
      if (!elements.length) return;
      const eq = top10[elements[0].index];
      if (eq) showEquipementDetail(eq.code);
    };
    const onBarHoverCursor = (evt, elements) => {
      evt.native.target.style.cursor = elements.length ? 'pointer' : 'default';
    };

    destroyChart('eq-top');
    charts['eq-top'] = new Chart(document.getElementById('eq-top'), {
      type: 'bar',
      data: {
        labels: top10.map(e => e.code.slice(0, 16)),
        datasets: [{ label: 'Pannes',
          data: top10.map(e => e.pannesTot),
          backgroundColor: top10.map(e => UNIT_COLORS[e.unit] + 'bb' || '#2f6690bb'),
          borderRadius: 6 }]
      },
      options: { ...chartOpts(''), indexAxis: 'y', scales: { x: chartScaleY(''), y: chartScaleX() },
        onClick: onBarClickExport, onHover: onBarHoverCursor }
    });

    destroyChart('eq-dur');
    charts['eq-dur'] = new Chart(document.getElementById('eq-dur'), {
      type: 'bar',
      data: {
        labels: top10.map(e => e.code.slice(0, 16)),
        datasets: [{ label: 'Durée(h)',
          data: top10.map(e => +e.dureeH.toFixed(2)),
          backgroundColor: top10.map(e => UNIT_COLORS[e.unit] + 'bb' || '#2f6690bb'),
          borderRadius: 6 }]
      },
      options: { ...chartOpts('h'), indexAxis: 'y', scales: { x: chartScaleY('h'), y: chartScaleX() },
        onClick: onBarClickExport, onHover: onBarHoverCursor }
    });
  }, 100);
}

// ── Carte résumé catégorie ──
// ── Modale de detail : affiche les pannes/interventions d'un equipement, l'utilisateur decide ensuite d'exporter ──
