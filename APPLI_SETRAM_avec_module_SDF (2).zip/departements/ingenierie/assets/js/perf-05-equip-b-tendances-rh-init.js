// =============================================================================
// SUIVI DES PERFORMANCES — module 05/10 : perf-05-equip-b-tendances-rh-init.js
// Extrait mecaniquement (meme code, meme ordre) du script principal historique
// pour ameliorer la maintenabilite (le fichier faisait ~8300 lignes en un bloc).
// Contenu : Suite Equipements (modale detail, exports par categorie) - Evolutions (Tendances) - Page par Unite - initialisation module Efficience RH (RH_DB)
// IMPORTANT : ce fichier partage la portee globale avec les autres modules
// perf-XX-*.js et doit rester charge dans l'ORDRE (01 -> 10), car certaines
// fonctions utilisent des constantes/fonctions definies dans les modules precedents.
// =============================================================================
function closeEqModal() {
  const ov = document.getElementById('eqp-modal-overlay');
  if (ov) ov.remove();
}

function showEquipementDetail(code) {
  const data = EQ_ROWS_MAP[code] || { corr: [], prev: [] };
  const nbCorr = data.corr.length, nbPrev = data.prev.length;
  if (nbCorr + nbPrev === 0) {
    alert("Aucune donnee pour l'equipement " + code + " sur le perimetre filtre actuel.");
    return;
  }

  const buildPreview = (rows, max = 200) => {
    if (!rows.length) return '';
    const shown = rows.slice(0, max);
    const cols = Object.keys(shown[0]);
    const thead = `<tr>${cols.map(c => `<th>${c}</th>`).join('')}</tr>`;
    const tbody = shown.map(r => `<tr>${cols.map(c => `<td>${String(r[c] ?? '').slice(0, 50)}</td>`).join('')}</tr>`).join('');
    const more = rows.length > max ? `<div class="eqp-more-note">... et ${rows.length - max} ligne(s) supplementaire(s) (incluses dans l'export)</div>` : '';
    return `<table class="eqp-preview-table"><thead>${thead}</thead><tbody>${tbody}</tbody></table>${more}`;
  };

  const html = `
    <div id="eqp-modal-overlay" class="eqp-modal-overlay">
      <div class="eqp-modal">
        <div class="eqp-modal-header">
          <div>
            <div class="eqp-modal-title">${code}</div>
            <div class="eqp-modal-sub">${nbCorr} panne(s) corrective(s) · ${nbPrev} intervention(s) preventive(s) — perimetre filtre actuel</div>
          </div>
          <button type="button" class="btn btn-ghost btn-sm eqp-close">✕</button>
        </div>
        <div class="eqp-modal-body">
          ${nbCorr ? `<div class="eqp-section-title">🔴 Correctif (${nbCorr})</div>${buildPreview(data.corr)}` : ''}
          ${nbPrev ? `<div class="eqp-section-title" style="margin-top:16px">🛡️ Preventif (${nbPrev})</div>${buildPreview(data.prev)}` : ''}
        </div>
        <div class="eqp-modal-footer">
          <button type="button" class="btn btn-ghost btn-sm eqp-close">Fermer</button>
          <button type="button" class="btn btn-sm eqp-do-export" data-code="${code.replace(/"/g, '&quot;')}"
            style="background:var(--accent);color:#fff;font-weight:700">⬇️ Exporter en XLSX</button>
        </div>
      </div>
    </div>`;

  closeEqModal();
  document.body.insertAdjacentHTML('beforeend', html);
  const overlay = document.getElementById('eqp-modal-overlay');
  overlay.addEventListener('click', (e) => { if (e.target === overlay) closeEqModal(); });
  overlay.querySelectorAll('.eqp-close').forEach(b => b.addEventListener('click', closeEqModal));
  overlay.querySelector('.eqp-do-export').addEventListener('click', (e) => exportEquipementPannes(e.currentTarget.dataset.code));
}

// ── Export XLSX de toutes les pannes/interventions d'un equipement (toutes colonnes brutes de l'import, y compris CHEMIN_PJ) ──
async function exportEquipementPannes(code) {
  const data = EQ_ROWS_MAP[code];
  const nbCorr = data ? data.corr.length : 0;
  const nbPrev = data ? data.prev.length : 0;
  if (!data || (nbCorr + nbPrev === 0)) {
    alert("Aucune donnee a exporter pour l'equipement " + code + " sur le perimetre filtre actuel.");
    return;
  }
  const logoBuf = await setramLogoBuffer();
  const wb = new ExcelJS.Workbook(); wb.creator = 'SETRAM — Direction Ingenierie'; wb.created = new Date();
  const titre = 'Pannes & Interventions — Équipement ' + code;
  if (nbCorr) writeSetramSheet(wb, 'Correctif', data.corr, { title: titre, subtitle: 'Correctif', logoBuf });
  if (nbPrev) writeSetramSheet(wb, 'Preventif', data.prev, { title: titre, subtitle: 'Préventif', logoBuf });
  const safeCode = String(code).replace(/[\\/:*?"<>|]/g, '_').slice(0, 50);
  const dstr = new Date().toISOString().slice(0, 10);
  await downloadSetramWorkbook(wb, `Pannes_${safeCode}_${dstr}.xlsx`);
}

// ── Export XLSX groupé pour toute une catégorie : préventif seul, ou préventif + correctif ──
async function exportCategoryPannes(catId, mode) {
  const items = catId === 'all'
    ? [].concat(CAT_ITEMS_MAP.cat1 || [], CAT_ITEMS_MAP.cat2 || [], CAT_ITEMS_MAP.cat3 || [])
    : (CAT_ITEMS_MAP[catId] || []);
  if (items.length === 0) {
    alert("Aucun équipement dans cette catégorie sur le périmètre filtré actuel.");
    return;
  }
  let corrRows = [], prevRows = [];
  items.forEach(item => {
    const d = EQ_ROWS_MAP[item.code];
    if (!d) return;
    if (mode === 'corr' || mode === 'both') corrRows = corrRows.concat(d.corr);
    if (mode === 'prev' || mode === 'both') prevRows = prevRows.concat(d.prev);
  });
  if (corrRows.length === 0 && prevRows.length === 0) {
    alert("Aucune donnée à exporter pour cette catégorie sur le périmètre filtré actuel.");
    return;
  }
  const catLabel = { cat1: 'Categorie1', cat2: 'Categorie2', cat3: 'Categorie3', all: 'ToutesCategories' }[catId] || catId;
  const modeLabel = { prev: 'Preventif', corr: 'Correctif', both: 'Preventif_Correctif' }[mode] || mode;
  const logoBuf = await setramLogoBuffer();
  const wb = new ExcelJS.Workbook(); wb.creator = 'SETRAM — Direction Ingenierie'; wb.created = new Date();
  const titre = 'Pannes & Interventions — ' + catLabel.replace(/([a-z])([A-Z])/g, '$1 $2');
  if (corrRows.length) writeSetramSheet(wb, 'Correctif', corrRows, { title: titre, subtitle: 'Correctif', logoBuf });
  if (prevRows.length) writeSetramSheet(wb, 'Preventif', prevRows, { title: titre, subtitle: 'Préventif', logoBuf });
  const dstr = new Date().toISOString().slice(0, 10);
  await downloadSetramWorkbook(wb, `${catLabel}_${modeLabel}_${dstr}.xlsx`);
}

function eqCatCard(icon, title, count, sub, bg, color) {
  return `<div class="kpi-card" style="border-top:3px solid ${color}">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
      <span style="font-size:24px">${icon}</span>
      <div>
        <div class="kpi-label">${title}</div>
        <div class="kpi-value" style="font-size:32px;color:${color}">${count}</div>
      </div>
    </div>
    <div class="kpi-sub">${sub}</div>
  </div>`;
}

// ── Tableau par catégorie ──
function buildEqCatTable(items, catId, title, color, hoursTotal, btSeuil = 0) {
  CAT_ITEMS_MAP[catId] = items;
  if (items.length === 0) return '';

  const rows = items.slice(0, 200).map(item => {
    const c  = item.corrData;
    const p  = item.prevData;
    const uL = (item.unitOp || '').toLowerCase();

    // ── KPIs correctif ──
    const mttr  = (c && c.nbPannesRep > 0) ? c.dureeH / c.nbPannesRep : 0;
    const mtbf  = (c && c.pannesTot > 0)   ? Math.max(hoursTotal - c.indispoH, 0) / c.pannesTot : 0;
    const dp    = hoursTotal > 0 ? Math.max(hoursTotal - (c ? c.indispoH : 0), 0) / hoursTotal : 1;
    const tp    = mtbf > 0 ? 1 / mtbf : 0;
    const tr2   = mttr > 0 ? 1 / mttr : 0;

    // ── Taux logistique / Taux d'intervention (corr. et prév.) ──
    // Taux Corr = Durée Corr. / (Durée Corr. + Logist. Corr.) ; Taux logistique Corr = Logist. Corr. / (Durée Corr. + Logist. Corr.)
    const totCorr = (c && (c.dureeH + c.logistiqueH) > 0) ? c.dureeH + c.logistiqueH : 0;
    const totPrev = (p && (p.dureeH + p.logistiqueH) > 0) ? p.dureeH + p.logistiqueH : 0;
    const tauxCorrRaw     = totCorr > 0 ? c.dureeH / totCorr : null;
    const tauxLogCorrRaw  = totCorr > 0 ? c.logistiqueH / totCorr : null;
    const tauxPrevRaw     = totPrev > 0 ? p.dureeH / totPrev : null;
    const tauxLogPrevRaw  = totPrev > 0 ? p.logistiqueH / totPrev : null;
    const tauxCorr    = tauxCorrRaw    !== null ? (tauxCorrRaw    * 100).toFixed(1) + '%' : '—';
    const tauxLogCorr = tauxLogCorrRaw !== null ? (tauxLogCorrRaw * 100).toFixed(1) + '%' : '—';
    const tauxPrev    = tauxPrevRaw    !== null ? (tauxPrevRaw    * 100).toFixed(1) + '%' : '—';
    const tauxLogPrev = tauxLogPrevRaw !== null ? (tauxLogPrevRaw * 100).toFixed(1) + '%' : '—';
    // Badge coloré sur le taux logistique (plus il est élevé, plus c'est défavorable)
    const tauxLogCorrCls = tauxLogCorrRaw !== null ? (tauxLogCorrRaw > 0.5 ? 'badge-red' : tauxLogCorrRaw > 0.25 ? 'badge-yellow' : 'badge-green') : 'badge-gray';
    const tauxLogPrevCls = tauxLogPrevRaw !== null ? (tauxLogPrevRaw > 0.5 ? 'badge-red' : tauxLogPrevRaw > 0.25 ? 'badge-yellow' : 'badge-green') : 'badge-gray';
    const tauxCorrCls    = tauxCorrRaw    !== null ? (tauxCorrRaw    < 0.5 ? 'badge-red' : tauxCorrRaw    < 0.75 ? 'badge-yellow' : 'badge-green') : 'badge-gray';
    const tauxPrevCls    = tauxPrevRaw    !== null ? (tauxPrevRaw    < 0.5 ? 'badge-red' : tauxPrevRaw    < 0.75 ? 'badge-yellow' : 'badge-green') : 'badge-gray';

    // ── Alertes seuil ──
    const pannesTotAlert = btSeuil > 0 && c && c.pannesTot > btSeuil;
    const btAlert        = btSeuil > 0 && p && p.nbBT      > btSeuil;
    const rowBg = pannesTotAlert ? 'background:rgba(220,38,38,0.07);border-left:3px solid #dc2626;' : '';

    // ── Colonnes correctif ──
    const corrCols = c ? `
      <td style="text-align:center">
        <span class="badge ${pannesTotAlert ? 'badge-red' : 'badge-gray'}">
          ${pannesTotAlert ? '⚠️ ' : ''}${c.pannesTot}
        </span>
      </td>
      <td style="text-align:center">${c.pannesRep}</td>
      <td style="text-align:center;font-size:11px">${c.dureeH.toFixed(2)}h</td>
      <td style="text-align:center;font-size:11px">${c.logistiqueH.toFixed(2)}h</td>
      <td style="text-align:center"><span class="badge ${tauxLogCorrCls}">${tauxLogCorr}</span></td>
      <td style="text-align:center"><span class="badge ${tauxCorrCls}">${tauxCorr}</span></td>
    ` : `<td colspan="6" style="text-align:center;color:var(--text3);font-style:italic">— Pas de correctif —</td>`;

    // ── Colonnes préventif ──
    const prevCols = p ? `
      <td style="text-align:center;background:${btAlert ? 'rgba(220,38,38,0.08)' : ''}">
        <span class="badge ${btAlert ? 'badge-red' : 'badge-blue'}">
          ${btAlert ? '⚠️ ' : ''}${p.nbBT}
        </span>
      </td>
      <td style="text-align:center;background:${btAlert ? 'rgba(220,38,38,0.08)' : ''}">${p.btClos}</td>
      <td style="text-align:center;background:${btAlert ? 'rgba(220,38,38,0.08)' : ''}">
        <span style="font-size:11px;font-weight:700">${p.nbPassages}</span>
        <div style="font-size:9px;color:var(--text3)">${p.nbPassages > 1 ? 'passages' : 'passage'}</div>
      </td>
      <td style="text-align:center;font-size:11px">${p.dureeH.toFixed(2)}h</td>
      <td style="text-align:center;font-size:11px">${p.logistiqueH.toFixed(2)}h</td>
      <td style="text-align:center"><span class="badge ${tauxLogPrevCls}">${tauxLogPrev}</span></td>
      <td style="text-align:center"><span class="badge ${tauxPrevCls}">${tauxPrev}</span></td>
    ` : `<td colspan="7" style="text-align:center;color:var(--text3);font-style:italic">— Pas de préventif —</td>`;

    // ── KPIs fiabilité ──
    const kpiCols = c ? `
      <td style="text-align:center;color:#ef4444;font-size:11px">${c.indispoH.toFixed(1)}h</td>
      <td><span class="badge ${objClass('dispo', dp)}">${pct(dp)}</span></td>
      <td style="font-size:10px">${mttr > 0 ? mttr.toFixed(3) + 'h' : '—'}</td>
      <td style="font-size:10px">${mtbf > 0 ? mtbf.toFixed(1) + 'h' : '—'}</td>
      <td style="font-size:9px">${tp > 0 ? fmtSciShort(tp) : '—'}</td>
      <td style="font-size:9px">${tr2 > 0 ? fmtSciShort(tr2) : '—'}</td>
    ` : `<td colspan="6" style="text-align:center;color:var(--text3)">—</td>`;

    return `<tr style="${rowBg}">
      <td><span class="unit-tag bg-${uL} u-${uL}" style="font-size:10px">${item.unitOp || '—'}</span></td>
      <td style="font-size:11px;font-weight:700">${item.code}</td>
      <td style="font-size:11px;color:#2f6690">${item.systeme}</td>
      <td style="font-size:11px">${item.unite}</td>
      <td style="font-size:11px">${item.sousSysteme}</td>
      ${corrCols}
      ${prevCols}
      ${kpiCols}
      <td style="text-align:center">
        <button type="button" class="btn btn-ghost btn-sm btn-export-eq" data-code="${item.code.replace(/"/g,'&quot;')}"
          title="Voir le detail des pannes/interventions de cet équipement (puis exporter si besoin)">👁️</button>
      </td>
    </tr>`;
  }).join('');

  // Boutons d'export directs, adaptés au contenu de la catégorie
  let exportBtnsHtml = '';
  if (catId === 'cat1') {
    exportBtnsHtml = `
      <button type="button" class="btn btn-ghost btn-sm" style="font-size:10.5px;padding:5px 11px;white-space:nowrap" onclick="exportCategoryPannes('cat1','prev')">🛡️ Export Préventif</button>
      <button type="button" class="btn btn-ghost btn-sm" style="font-size:10.5px;padding:5px 11px;white-space:nowrap" onclick="exportCategoryPannes('cat1','corr')">🔴 Export Correctif</button>
      <button type="button" class="btn btn-ghost btn-sm" style="font-size:10.5px;padding:5px 11px;white-space:nowrap" onclick="exportCategoryPannes('cat1','both')">📥 Export les deux</button>`;
  } else if (catId === 'cat2') {
    exportBtnsHtml = `
      <button type="button" class="btn btn-ghost btn-sm" style="font-size:10.5px;padding:5px 11px;white-space:nowrap" onclick="exportCategoryPannes('cat2','prev')">🛡️ Export Préventif</button>`;
  } else if (catId === 'cat3') {
    exportBtnsHtml = `
      <button type="button" class="btn btn-ghost btn-sm" style="font-size:10.5px;padding:5px 11px;white-space:nowrap" onclick="exportCategoryPannes('cat3','corr')">🔴 Export Correctif</button>`;
  }

  return `
    <div class="card" style="margin-bottom:18px;border-top:3px solid ${color}">
      <div class="card-title" style="color:${color};display:flex;align-items:center;flex-wrap:wrap;gap:8px">
        <span>${title}</span>
        <span class="badge badge-gray">${items.length} équipements</span>
        <span style="margin-left:auto;display:flex;gap:6px;flex-wrap:wrap">${exportBtnsHtml}</span>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Unité</th>
              <th>CODE_EQUIPEMENT</th>
              <th>Système</th>
              <th>Unité EQ</th>
              <th>Sous-sys.</th>
              <th>Pannes Tot.</th>
              <th>Pannes Rep.</th>
              <th>Durée Corr.(h)</th>
              <th>Logist. Corr.(h)</th>
              <th>Taux logistique Corr</th>
              <th>Taux d'intervention Corr</th>
              <th>BT Total</th>
              <th>BT Clos</th>
              <th>Nb Passages</th>
              <th>Durée Prév.(h)</th>
              <th>Logist. Prév.(h)</th>
              <th>Taux logistique Prév</th>
              <th>Taux d'intervention Prév</th>
              <th>Indispo(h)</th>
              <th>Dispo</th>
              <th>MTTR</th>
              <th>MTBF</th>
              <th>λ</th>
              <th>μ</th>
              <th>Détail</th>
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>`;
}

// =====================================================================
// TENDANCES PAGE
// =====================================================================
function renderTendancesPage() {
  const { start, end, unit, systeme, equipement } = getFilters();
  let aC = [], aP = [];
  UNITS.forEach(u => { if (unit === 'all' || unit === u) { aC.push(...(DB.corrective[u]||[])); aP.push(...(DB.preventive[u]||[])); } });
  aC = filterBySystem(aC, systeme); aP = filterBySystem(aP, systeme);
  aC = filterByEquipement(aC, equipement); aP = filterByEquipement(aP, equipement);
  const container = document.getElementById('tendances-content');
  if (aC.length + aP.length === 0) { container.innerHTML = `<div class="empty-state"><div class="es-icon">📉</div><div class="es-title">Aucune donnee</div></div>`; return; }

  // ── NOUVEAU : calcul des intervalles dynamiques ──────────────────
  const totalDays = Math.round((end - start) / 86400000);

  // Choisir la granularité : jour (≤14j), semaine (≤90j), mois sinon
  let granularity, intervals, periodLabel;

  if (totalDays <= 14) {
    // Granularité JOUR
    granularity = 'day';
    intervals = [];
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const dayStart = new Date(d); dayStart.setHours(0, 0, 0, 0);
      const dayEnd   = new Date(d); dayEnd.setHours(23, 59, 59, 999);
      intervals.push({
        label: dayStart.toLocaleDateString('fr-FR', { day:'2-digit', month:'2-digit' }),
        start: new Date(dayStart), end: new Date(dayEnd), hours: 24
      });
    }
    periodLabel = `Détail journalier — ${fmtDateFR(start)} → ${fmtDateFR(end)}`;

  } else if (totalDays <= 90) {
    // Granularité SEMAINE
    granularity = 'week';
    intervals = [];
    let cursor = new Date(start); cursor.setHours(0, 0, 0, 0);
    let weekNum = 1;
    while (cursor <= end) {
      const wStart = new Date(cursor);
      const wEnd   = new Date(cursor);
      wEnd.setDate(wEnd.getDate() + 6); wEnd.setHours(23, 59, 59, 999);
      if (wEnd > end) { wEnd.setTime(end.getTime()); wEnd.setHours(23, 59, 59, 999); }
      const wDays = Math.round((wEnd - wStart) / 86400000);
      intervals.push({
        label: `S${weekNum} (${wStart.toLocaleDateString('fr-FR', { day:'2-digit', month:'2-digit' })})`,
        start: new Date(wStart), end: new Date(wEnd), hours: wDays * 24
      });
      cursor.setDate(cursor.getDate() + 7);
      weekNum++;
    }
    periodLabel = `Détail hebdomadaire — ${fmtDateFR(start)} → ${fmtDateFR(end)}`;

  } else {
    // Granularité MOIS (comportement étendu : peut couvrir plusieurs années)
    granularity = 'month';
    intervals = [];
    let cursor = new Date(start.getFullYear(), start.getMonth(), 1);
    const endMonth = new Date(end.getFullYear(), end.getMonth() + 1, 0, 23, 59, 59);
    while (cursor <= endMonth) {
      const mStart = new Date(cursor);
      const mEnd   = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0, 23, 59, 59);
      const clampStart = mStart < start ? new Date(start) : mStart;
      const clampEnd   = mEnd   > end   ? new Date(end)   : mEnd;
      const mDays = daysInMonth(cursor.getFullYear(), cursor.getMonth() + 1);
      const label = cursor.toLocaleDateString('fr-FR', { month:'short', year: start.getFullYear() !== end.getFullYear() ? '2-digit' : undefined });
      intervals.push({
        label, start: clampStart, end: clampEnd, hours: mDays * 24
      });
      cursor.setMonth(cursor.getMonth() + 1);
    }
    periodLabel = `Détail mensuel — ${fmtDateFR(start)} → ${fmtDateFR(end)}`;
  }

  const mL = intervals.map(i => i.label);
  const mD = intervals.map(iv => {
    const cr = aC.filter(r => { const d = parseDate(r['DATE_DI']);    return d && d >= iv.start && d <= iv.end; });
    const pr = aP.filter(r => { const d = parseDate(r['DATE_PREVUE']); return d && d >= iv.start && d <= iv.end; });
    return calcKPIs(cr, pr, iv.hours, iv.start, iv.end);
  });
  // ────────────────────────────────────────────────────────────────

  container.innerHTML = `
    <div class="grid-2">
      <div class="card"><div class="card-title">✅ TMP & TMC — ${periodLabel}</div><div class="chart-wrap tall"><canvas id="t-tmp"></canvas></div></div>
      <div class="card"><div class="card-title">🔵 TCP & TCC — ${periodLabel}</div><div class="chart-wrap tall"><canvas id="t-tcp"></canvas></div></div>
      <div class="card"><div class="card-title">🟢 Disponibilite — ${periodLabel}</div><div class="chart-wrap tall"><canvas id="t-dispo"></canvas></div></div>
      <div class="card"><div class="card-title">⏱️ MTTR — ${periodLabel}</div><div class="chart-wrap tall"><canvas id="t-mttr"></canvas></div></div>
    </div>
    <div class="grid-2">
      <div class="card"><div class="card-title">📉 Taux de Panne λ — ${periodLabel}</div><div class="chart-wrap tall"><canvas id="t-tp"></canvas></div></div>
      <div class="card"><div class="card-title">🔧 Taux de Reparation μ — ${periodLabel}</div><div class="chart-wrap tall"><canvas id="t-tr"></canvas></div></div>
    </div>
    <div class="card"><div class="card-title">🔢 Volumes Pannes — ${periodLabel}</div><div class="chart-wrap"><canvas id="t-vol"></canvas></div></div>`;

  // Le reste du code des graphes (setTimeout) reste IDENTIQUE — aucun changement
  setTimeout(() => {
    const lO = (u) => ({ responsive:true, maintainAspectRatio:false, plugins:{legend:{labels:{color:'#475569',font:{size:11}}}}, scales:{x:chartScaleX(),y:{...chartScaleY(u),beginAtZero:true}} });
    const mkL = (id, ds, u) => { destroyChart(id); const el = document.getElementById(id); if (el) charts[id] = new Chart(el, { type:'line', data:{ labels:mL, datasets:ds }, options:lO(u) }); };
    mkL('t-tmp', [
      { label:'TMP %', data:mD.map(k=>+(k.tmp*100).toFixed(1)), borderColor:'#22d3ee', backgroundColor:'rgba(34,211,238,0.1)', tension:0.4, fill:true },
      { label:'TMC %', data:mD.map(k=>+(k.tmc*100).toFixed(1)), borderColor:'#f97316', backgroundColor:'rgba(249,115,22,0.1)', tension:0.4, fill:true },
      { label:'Obj 100%', data:Array(mL.length).fill(100), borderColor:'rgba(34,211,238,0.3)', borderDash:[5,5], borderWidth:1, pointRadius:0 },
      { label:'Obj 90%',  data:Array(mL.length).fill(90),  borderColor:'rgba(249,115,22,0.3)', borderDash:[5,5], borderWidth:1, pointRadius:0 }
    ], '%');
    mkL('t-tcp', [
      { label:'TCP %', data:mD.map(k=>+(k.tcp*100).toFixed(1)), borderColor:'#22d3ee', tension:0.4 },
      { label:'TCC %', data:mD.map(k=>+(k.tcc*100).toFixed(1)), borderColor:'#f97316', tension:0.4 },
      { label:'Obj 80%', data:Array(mL.length).fill(80), borderColor:'rgba(34,211,238,0.3)', borderDash:[5,5], borderWidth:1, pointRadius:0 },
      { label:'Obj 20%', data:Array(mL.length).fill(20), borderColor:'rgba(249,115,22,0.3)', borderDash:[5,5], borderWidth:1, pointRadius:0 }
    ], '%');
    mkL('t-dispo', [
      { label:'Dispo %', data:mD.map(k=>+(k.dispo*100).toFixed(1)), borderColor:'#059669', backgroundColor:'rgba(16,185,129,0.1)', tension:0.4, fill:true },
      { label:'Obj 97%', data:Array(mL.length).fill(97), borderColor:'rgba(16,185,129,0.3)', borderDash:[5,5], borderWidth:1, pointRadius:0 }
    ], '%');
    mkL('t-mttr', [{ label:'MTTR(h)', data:mD.map(k=>+k.mttr.toFixed(3)), borderColor:'#f59e0b', backgroundColor:'rgba(245,158,11,0.1)', tension:0.4, fill:true }], 'h');
    destroyChart('t-tp');
    const elTP = document.getElementById('t-tp');
    if (elTP) charts['t-tp'] = new Chart(elTP, { type:'line', data:{ labels:mL, datasets:[
      { label:'λ(1/h)', data:mD.map(k=>k.tauxPanne), borderColor:'#dc2626', backgroundColor:'rgba(239,68,68,0.1)', tension:0.4, fill:true, pointBackgroundColor:mD.map(k=>k.tauxPanne===0?'#f59e0b':'#dc2626'), pointRadius:mD.map(k=>k.tauxPanne===0?6:3) },
      { label:'Obj 3e-3', data:Array(mL.length).fill(3e-3), borderColor:'rgba(245,158,11,0.6)', borderDash:[5,5], borderWidth:2, pointRadius:0 }
    ]}, options:{ responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{labels:{color:'#475569',font:{size:11}}}, tooltip:{callbacks:{label:c=>c.raw===0?` λ=0 ⚠️ Dates manquantes`:[` λ=${fmtSciShort(c.raw)}`]}} },
      scales:{ x:chartScaleX(), y:{ ticks:{color:'#64748b',font:{size:10},callback:v=>v===0?'0⚠️':v.toExponential(1)}, grid:{color:'rgba(15,23,42,0.06)'} } } } });
    destroyChart('t-tr');
    const elTR = document.getElementById('t-tr');
    if (elTR) charts['t-tr'] = new Chart(elTR, { type:'line', data:{ labels:mL, datasets:[
      { label:'μ(1/h)', data:mD.map(k=>k.tauxRep), borderColor:'#059669', backgroundColor:'rgba(16,185,129,0.1)', tension:0.4, fill:true },
      { label:'Obj 0.25', data:Array(mL.length).fill(0.25), borderColor:'rgba(16,185,129,0.6)', borderDash:[5,5], borderWidth:2, pointRadius:0 }
    ]}, options:{ responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{labels:{color:'#475569',font:{size:11}}}, tooltip:{callbacks:{label:c=>` μ=${c.raw.toFixed(4)}`}} },
      scales:{ x:chartScaleX(), y:{ ticks:{color:'#64748b',font:{size:10},callback:v=>v.toFixed(3)}, grid:{color:'rgba(15,23,42,0.06)'} } } } });
    destroyChart('t-vol');
    charts['t-vol'] = new Chart(document.getElementById('t-vol'), { type:'bar', data:{ labels:mL, datasets:[
      { label:'Pannes Tot.', data:mD.map(k=>k.nbPannesTot), backgroundColor:'rgba(249,115,22,0.7)', borderRadius:4 },
      { label:'Pannes Rep.', data:mD.map(k=>k.nbPannesRep), backgroundColor:'rgba(16,185,129,0.7)', borderRadius:4 }
    ]}, options:chartOpts('') });
  }, 100);
}

function daysInMonth(year, month) {
  return new Date(year, month, 0).getDate();
}

// =====================================================================
// UNIT PAGE
// =====================================================================
function renderUnitPage(unit) {
  document.getElementById('unit-page-title').textContent = `Unite ${unit}`;
  document.getElementById('unit-page-sub').textContent   = `Analyse detaillee — ${unit}`;
  const { hoursTotal, start, end } = getFilters();
  const { corrRows, prevRows } = getFilteredData(unit);
  const k = calcKPIs(corrRows, prevRows, hoursTotal, start, end);
  const container = document.getElementById('unit-page-content');
  if (corrRows.length + prevRows.length === 0) { container.innerHTML = `<div class="empty-state"><div class="es-icon">📂</div><div class="es-title">Aucune donnee pour ${unit}</div></div>`; return; }

  let alertHtml = '';
  if (k.nbSansDebut > 0 || k.nbNegatif > 0 || k.nbAberrant > 0 || k.nbNoeudsPaire > 0) {
    const items = [];
    if (k.nbSansDebut > 0) items.push(`${k.nbSansDebut} DI sans DATE_EVENEMENT (Ex: ${k.exSansDebut.join(', ')})`);
    if (k.nbNegatif  > 0) items.push(`${k.nbNegatif} DI duree negative (Ex: ${k.exNegatif.join(', ')})`);
    if (k.nbAberrant > 0) items.push(`${k.nbAberrant} DI duree aberrante (Ex: ${k.exAberrant.join(', ')})`);
    if (k.nbNoeudsPaire > 0) items.push(`${k.nbNoeudsPaire} DI sur noeud pair (Ex: ${k.exNoeudsPaire.join(', ')})`);
    alertHtml = `<div class="alert-panel" style="margin-bottom:16px"><div class="alert-panel-title">⚠️ Problemes de donnees</div>
      ${items.map(i => `<div class="alert-item"><span class="ai-unit">${unit}</span><span class="ai-msg">${i}</span><span class="ai-val">Impact λ</span></div>`).join('')}
    </div>`;
  }

  container.innerHTML = `
    ${alertHtml}
    <div class="kpi-section-header engineering" style="margin-top:0">
      <span class="ksh-icon">🔬</span>
      <div><div class="ksh-title" style="color:#24537a">Indicateurs d'Ingenierie — ${unit}</div></div>
    </div>
    <div class="kpi-grid">
      
      <div class="kpi-card c1"><div class="kpi-label">TCP</div><div class="kpi-value">${pct(k.tcp)} ${trendArrow('tcp',k.tcp)}</div><div class="kpi-obj ${objClass('tcp',k.tcp)}">Obj: &gt;80%</div></div>
      <div class="kpi-card c6"><div class="kpi-label">TCC</div><div class="kpi-value">${pct(k.tcc)} ${trendArrow('tcc',k.tcc)}</div><div class="kpi-obj ${objClass('tcc',k.tcc)}">Obj: &lt;20%</div></div>
    </div>
    <div class="kpi-section-header realisation">
      <span class="ksh-icon">✅</span>
      <div><div class="ksh-title" style="color:#059669">Indicateurs de Realisation — ${unit}</div></div>
    </div>
    <div class="kpi-grid">
      <div class="kpi-card c5"><div class="kpi-label">MTTR</div><div class="kpi-value">${k.mttr.toFixed(3)}h</div><div class="kpi-sub">${k.nbPannesRep} pannes rep.</div></div>
      <div class="kpi-card c7"><div class="kpi-label">MTBF</div><div class="kpi-value">${k.mtbf>0&&k.nbPannesTot>0?k.mtbf.toFixed(1)+'h':'<span style="color:#ef4444">0⚠️</span>'}</div><div class="kpi-sub">TBF ${k.tbf.toFixed(1)}h · Indispo ${k.indispoH.toFixed(1)}h</div></div>
      <div class="kpi-card c9"><div class="kpi-label">λ Taux Panne</div><div class="kpi-value small">${k.tauxPanne>0?fmtSci(k.tauxPanne):'0 ⚠️'} ${trendArrow('tauxPanne',k.tauxPanne)}</div><div class="kpi-obj ${objClass('tauxPanne',k.tauxPanne)}">Obj: &gt;3×10⁻³</div></div>
      <div class="kpi-card c10"><div class="kpi-label">μ Taux Repar.</div><div class="kpi-value small">${k.tauxRep>0?fmtSci(k.tauxRep):'—'} ${trendArrow('tauxRep',k.tauxRep)}</div><div class="kpi-obj ${objClass('tauxRep',k.tauxRep)}">Obj: &gt;0.25</div></div>
      <div class="kpi-card c2"><div class="kpi-label">TMP</div><div class="kpi-value">${pct(k.tmp)} ${trendArrow('tmp',k.tmp)}</div><div class="kpi-obj ${objClass('tmp',k.tmp)}">Obj: 100%</div></div>
      <div class="kpi-card c3"><div class="kpi-label">TMC</div><div class="kpi-value">${pct(k.tmc)} ${trendArrow('tmc',k.tmc)}</div><div class="kpi-obj ${objClass('tmc',k.tmc)}">Obj: &gt;90%</div></div>
      <div class="kpi-card c4"><div class="kpi-label">Disponibilite</div><div class="kpi-value">${pct(k.dispo)} ${trendArrow('dispo',k.dispo)}</div><div class="kpi-obj ${objClass('dispo',k.dispo)}">Obj: &gt;97%</div></div>
      <div class="kpi-card c8"><div class="kpi-label">Pannes Totales</div><div class="kpi-value">${k.nbPannesTot}</div><div class="kpi-sub">${k.nbPannesRep} reparees</div></div>
    </div>
    <div class="grid-2" style="margin-bottom:16px">
      <div class="card"><div class="card-title">📉 λ & μ — ${unit}</div><div class="chart-wrap tall"><canvas id="up-taux"></canvas></div></div>
      <div class="card"><div class="card-title">📊 Etats DI</div>${stateDistribution(corrRows,'ETAT_DI')}</div>
    </div>
    <div class="grid-2">
      <div class="card"><div class="card-title">🔧 Correctives (${corrRows.length})</div>
        <div class="table-wrap" style="max-height:260px;overflow-y:auto">
          <table><thead><tr><th>CODE_DI</th><th>ETAT_DI</th><th>DATE_EVENEMENT</th><th>DATE_FIN</th></tr></thead>
          <tbody>${corrRows.slice(0,50).map(r => {
            const hasDeb = r['DATE_EVENEMENT'] && String(r['DATE_EVENEMENT']).trim() !== '';
            const hasFin = r['DATE_FIN_INTERVENTION'] && String(r['DATE_FIN_INTERVENTION']).trim() !== '';
            return `<tr><td>${r['CODE_DI']||'—'}</td><td>${stateBadge(r['ETAT_DI'])}</td>
              <td style="${hasDeb?'':'color:#ef4444'}">${r['DATE_EVENEMENT']||'❌'}</td>
              <td style="${hasFin?'':'color:#ef4444'}">${r['DATE_FIN_INTERVENTION']||'❌'}</td></tr>`;
          }).join('')}</tbody></table>
        </div>
      </div>
      <div class="card"><div class="card-title">🛡️ Preventives (${prevRows.length})</div>
        <div class="table-wrap" style="max-height:260px;overflow-y:auto">
          <table><thead><tr><th>CODE_BT</th><th>ETAT_BT</th><th>SYSTEME</th><th>DATE_PREVUE</th></tr></thead>
          <tbody>${prevRows.slice(0,50).map(r => `<tr><td>${r['CODE_BT']||'—'}</td><td>${stateBadge(r['ETAT_BT'])}</td><td style="font-size:11px">${r['SYSTEME']||'—'}</td><td style="font-size:11px">${r['DATE_PREVUE']||'—'}</td></tr>`).join('')}</tbody>
          </table>
        </div>
      </div>
    </div>`;

  setTimeout(() => {
    destroyChart('up-taux');
    const el = document.getElementById('up-taux');
    if (el) {
      const tpV = k.tauxPanne, trV = k.tauxRep;
      charts['up-taux'] = new Chart(el, { type:'bar',
        data:{ labels:['λ = 1/MTBF','μ = 1/MTTR'], datasets:[{ label:unit, data:[tpV, trV],
          backgroundColor:[tpV===0?'rgba(148,163,184,0.5)':'rgba(220,38,38,0.85)', trV===0?'rgba(148,163,184,0.5)':'rgba(5,150,105,0.85)'],
          borderColor:[tpV===0?'#94a3b8':'#dc2626', trV===0?'#94a3b8':'#059669'], borderWidth:2, borderRadius:10
        }] },
        options:{ responsive:true, maintainAspectRatio:false,
          plugins:{ legend:{display:false}, tooltip:{callbacks:{label:c=>c.dataIndex===0?(tpV===0?` λ=0 ⚠️ Dates manquantes`:[` λ=${fmtSci(tpV)}`]):(trV===0?` μ=0 ⚠️`:[` μ=${fmtSci(trV)}`])}} },
          scales:{ x:chartScaleX(), y:{ ticks:{color:'#64748b',font:{size:10},callback:v=>v===0?'0⚠️':v.toExponential(2)}, grid:{color:'rgba(15,23,42,0.06)'} } } } });
    }
  }, 100);
}

function stateDistribution(rows, field) {
  const counts = {}; rows.forEach(r => { const s = r[field]||'N/A'; counts[s]=(counts[s]||0)+1; });
  const sorted = Object.entries(counts).sort((a,b) => b[1]-a[1]); const total = rows.length;
  return `<div class="unit-list" style="margin-top:8px">${sorted.map(([s,n]) => `
    <div class="unit-row">
      <span style="font-size:11px;min-width:130px;color:var(--text2)">${s}</span>
      <div class="unit-bar-track"><div class="unit-bar-fill" style="width:${total?n/total*100:0}%;background:${stateColor(s)}"></div></div>
      <span class="unit-val" style="font-size:11px">${n}</span>
    </div>`).join('')}</div>`;
}
function stateBadge(state) {
  if (!state) return '<span class="badge badge-gray">—</span>';
  const s = normState(state); let cls = 'badge-gray';
  if (isTraitee(s)||isRealisee(s)||s.includes('clos')||s.includes('fait')) cls = 'badge-green';
  else if (isTransmis(s)||s.includes('cours'))  cls = 'badge-blue';
  else if (s.includes('attente'))               cls = 'badge-yellow';
  else if (isTransmettre(s)||s.includes('faire')) cls = 'badge-red';
  return `<span class="badge ${cls}">${state}</span>`;
}
function stateColor(s) {
  const sl = normState(s);
  if (isTraitee(sl)||isRealisee(sl)||sl.includes('clos')||sl.includes('fait')) return '#059669';
  if (isTransmis(sl)||sl.includes('cours')) return '#2f6690';
  if (sl.includes('attente')) return '#d97706';
  return '#94a3b8';
}

function showToast(msg, type='') { const el = document.getElementById('toast'); el.textContent = msg; el.className = `show ${type}`; clearTimeout(el._t); el._t = setTimeout(() => el.classList.remove('show'), 4000); }
function showLoading() { document.getElementById('loading').style.display = 'flex'; }
function hideLoading() { document.getElementById('loading').style.display = 'none'; }

// =====================================================================
// ██████████████████████████████████████████████████████████████████
// ██        COMPARAISON SOUS-SYSTEMES ENTRE UNITES                 ██
// =====================================================================
/* -> extrait dans assets/js/comparaison.js (charge en fin de page, voir avant </body>) */


// =====================================================================
// ██████████████████████████████████████████████████████████████████
// ██                   EFFICIENCE RH MODULE                        ██
// ██████████████████████████████████████████████████████████████████
// =====================================================================

const RH_DB = {
  corrRows: {},
  prevRows: {},
  loadedCorr: {},
  loadedPrev: {}
};

const RH_NORME_DEFAULT = 108;

// La norme (ex: 108h) est definie "par mois" (mois de reference = 30 jours).
// Si la periode filtree est plus courte/longue qu'un mois, on ajuste la norme
// proportionnellement au nombre de jours reellement filtres (ex: filtre de
// 25 jours => norme = 108 * 25/30 ; filtre de 3 mois/~90j => norme = 108 * 3).
function rhNormeProratee(normeBase, start, end) {
  if (!start || !end || !(start instanceof Date) || !(end instanceof Date)) return normeBase;
  // start est a 00:00:00 et end a 23:59:59 (voir getRHFilters) : leur difference brute
  // donne deja le bon nombre de jours inclusif (ex: 01/01 00:00:00 -> 31/01 23:59:59 = 31 jours).
  const jours = Math.max(1, Math.round((end - start) / 86400000));
  return normeBase * (jours / 30);
}

// ── Parser CODE_EQUIPEMENT → { systeme, unite, sousSysteme } ────────
