// =============================================================================
// SUIVI DES PERFORMANCES — module 10/10 : perf-10-rh-d-kpis-rapport.js
// Extrait mecaniquement (meme code, meme ordre) du script principal historique
// pour ameliorer la maintenabilite (le fichier faisait ~8300 lignes en un bloc).
// Contenu : Efficience RH (fin) : telechargement rapport, tableaux KPI Reel/Engagement par systeme, sections repliables, rapport de performance general (export)
// IMPORTANT : ce fichier partage la portee globale avec les autres modules
// perf-XX-*.js et doit rester charge dans l'ORDRE (01 -> 10), car certaines
// fonctions utilisent des constantes/fonctions definies dans les modules precedents.
// =============================================================================
function downloadRHGeneralReport(r, data) {
  const dateGenere = new Date().toLocaleString('fr-FR', { day:'2-digit', month:'long', year:'numeric', hour:'2-digit', minute:'2-digit' });
  const periodeLabel = `${fmtDateFR(data.start)} → ${fmtDateFR(data.end)}`;

  const scoreColor = (s) => s >= 4 ? '#059669' : s >= 3 ? '#d97706' : '#dc2626';
  const badgeObj = (ok) => ok
    ? `<span style="display:inline-block;padding:4px 12px;border-radius:20px;background:#dcfce7;color:#15803d;font-weight:700;font-size:12px">✅ Equilibre atteint</span>`
    : `<span style="display:inline-block;padding:4px 12px;border-radius:20px;background:#fee2e2;color:#b91c1c;font-weight:700;font-size:12px">⚠️ Desequilibre detecte</span>`;
  const listHtml = (arr) => `<ul style="margin:0;padding-left:20px;line-height:1.9">${(arr||[]).map(i=>`<li style="margin-bottom:4px">${i}</li>`).join('')}</ul>`;

  const unitsHtml = (r.rapports_unites||[]).map(u => `
    <div style="border:1.5px solid #e2e8f4;border-radius:14px;padding:18px 20px;margin-bottom:14px;background:#fafbff">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;flex-wrap:wrap">
        <span style="background:${UNIT_COLORS[u.unite]||'#2f6690'};color:#fff;padding:4px 14px;border-radius:8px;font-weight:800;font-size:14px">${u.unite}</span>
        <span style="font-weight:700;font-size:13px;color:${scoreColor(u.score_sur_5)}">Score : ${u.score_sur_5}/5</span>
        ${badgeObj(u.equilibre_atteint)}
      </div>
      <div style="font-weight:700;font-size:13px;color:#0a1930;margin-bottom:6px">${u.resume||''}</div>
      <div style="font-size:12.5px;color:#44537a;line-height:1.7;margin-bottom:10px">${u.analyse_detaillee||''}</div>
      ${u.mobilite_recommandee ? `<div style="background:#ede9fe;border-radius:10px;padding:10px 14px;font-size:12px;color:#5b21b6;font-weight:600;margin-bottom:10px">🔄 ${u.mobilite_recommandee}</div>` : ''}
      ${u.actions_prioritaires && u.actions_prioritaires.length ? `
      <div style="font-size:11px;font-weight:700;color:#24537a;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px">Actions prioritaires</div>
      ${listHtml(u.actions_prioritaires)}` : ''}
    </div>`).join('');

  const html = `<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8">
<title>${r.titre || 'Rapport General Efficience RH'}</title>
<style>
  body{font-family:'Montserrat',Arial,sans-serif;background:#f0f4ff;color:#0a1930;margin:0;padding:40px;line-height:1.6}
  .report{max-width:920px;margin:0 auto;background:#fff;border-radius:18px;box-shadow:0 12px 48px rgba(13,27,62,0.10);overflow:hidden}
  .header{background:linear-gradient(135deg,#24537a,#db2777);color:#fff;padding:36px 40px}
  .header h1{margin:0 0 8px;font-size:26px;font-weight:800}
  .header .meta{font-size:12.5px;opacity:0.9}
  .body{padding:32px 40px}
  h2{font-size:16px;font-weight:800;color:#0a1930;margin:28px 0 12px;padding-bottom:8px;border-bottom:2px solid #ede9fe}
  .score-banner{display:flex;align-items:center;gap:16px;background:#f4f7ff;border:1.5px solid #e2e8f4;border-radius:14px;padding:18px 20px;margin-bottom:20px}
  .score-circle{width:64px;height:64px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:900;color:#fff;flex-shrink:0}
  p{font-size:13px;color:#44537a;margin:6px 0}
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin:14px 0}
  .box{background:#fafbff;border:1.5px solid #e2e8f4;border-radius:12px;padding:16px 18px}
  .footer{padding:20px 40px;font-size:11px;color:#8896b3;text-align:center;border-top:1px solid #e2e8f4}
  @media print{ body{background:#fff;padding:0} .report{box-shadow:none;border-radius:0} }
</style></head>
<body>
<div class="report">
  <div class="header">
    <h1>👥 ${r.titre || 'Rapport General d\'Efficience RH'}</h1>
    <div class="meta">Periode analysee : ${periodeLabel} · Norme ${data.norme}h/mois/technicien · Genere le ${dateGenere}</div>
  </div>
  <div class="body">

    <div class="score-banner">
      <div class="score-circle" style="background:${scoreColor(r.score_global_sur_5)}">${r.score_global_sur_5}/5</div>
      <div>
        <div style="font-weight:800;font-size:14px;margin-bottom:4px">${badgeObj(r.equilibre_global_atteint)}</div>
        <div style="font-size:12.5px;color:#44537a">Score global base sur la repartition surcharge / sous-charge / equilibre</div>
      </div>
    </div>

    <h2>Synthese Executive</h2>
    <p>${r.synthese_executive || ''}</p>

    <h2>Analyses Detaillees</h2>
    <div class="grid2">
      <div class="box"><strong>⚖️ Charge Globale</strong><p>${r.analyse_charge_globale||''}</p></div>
      <div class="box"><strong>🔴 Surcharges</strong><p>${r.analyse_surcharges||''}</p></div>
      <div class="box"><strong>🟡 Sous-charges</strong><p>${r.analyse_sous_charges||''}</p></div>
      <div class="box"><strong>🔧 Repartition par Systeme</strong><p>${r.analyse_repartition_systemes||''}</p></div>
    </div>

    <h2>✅ Points Forts</h2>
    ${listHtml(r.points_forts)}

    <h2>⚠️ Points d'Attention</h2>
    ${listHtml(r.points_attention)}

    <h2>🔴 Risques RH</h2>
    ${listHtml(r.risques_rh)}

    <h2>🏭 Rapports par Unite</h2>
    ${unitsHtml || '<p>Aucune unite analysee.</p>'}

    <h2>💡 Recommandations Strategiques</h2>
    ${listHtml(r.recommandations_strategiques)}

    <h2>Conclusion</h2>
    <p>${r.conclusion || ''}</p>

  </div>
  <div class="footer">Rapport genere automatiquement par le module IA de la plateforme GMAO — A usage interne</div>
</div>
</body></html>`;

  const blob = new Blob([html], { type:'text/html;charset=utf-8' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  const dstr = new Date().toISOString().slice(0,10);
  a.href = url;
  a.download = `Rapport_Efficience_RH_${dstr}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

// =====================================================================
// KPI ENG DETAIL — Par Systeme puis Sous-Systeme
// =====================================================================
function toggleKpiEngDetail(unit, btn) {
  const row = document.getElementById(`kpi-eng-detail-${unit}`);
  if (!row) return;
  if (row.style.display !== 'none') {
    row.style.display = 'none';
    btn.textContent = '+ Info';
    return;
  }
  row.style.display = '';
  btn.textContent = '− Fermer';
  renderKpiEngBySysteme(unit);
}

function toggleKpiRealDetail(unit, btn) {
  const row = document.getElementById(`kpi-real-detail-${unit}`);
  if (!row) return;
  if (row.style.display !== 'none') {
    row.style.display = 'none';
    btn.textContent = '+ Info';
    return;
  }
  row.style.display = '';
  btn.textContent = '− Fermer';
  renderKpiRealBySysteme(unit);
}

function buildKpiRealTableHTML(kpiList, keyCol) {
  return `<div class="table-wrap" style="margin-bottom:8px">
    <table>
      <thead><tr>
        <th>${keyCol}</th>
        <th>TMP<br><small style="color:var(--green)">100%</small></th>
        <th>TMC<br><small style="color:var(--green)">&gt;90%</small></th>
        <th>Dispo<br><small style="color:var(--green)">&gt;97%</small></th>
        <th>Nb Pannes Rep.</th><th>Nb Pannes Tot.</th>
        <th>BT Clos+Fait</th><th>BT Total</th><th>DI Trait+Real</th><th>DI Total</th>
      </tr></thead>
      <tbody>
        ${kpiList.map(item => `
          <tr style="background:rgba(248,250,255,0.7)">
            <td style="font-weight:700;font-size:12px;color:#1e40af">${item.key}</td>
            <td><span class="badge ${objClass('tmp',item.k.tmp)}">${pct(item.k.tmp)}</span> ${trendArrow('tmp',item.k.tmp)}</td>
            <td><span class="badge ${objClass('tmc',item.k.tmc)}">${pct(item.k.tmc)}</span> ${trendArrow('tmc',item.k.tmc)}</td>
            <td><span class="badge ${objClass('dispo',item.k.dispo)}">${pct(item.k.dispo)}</span> ${trendArrow('dispo',item.k.dispo)}</td>
            <td>${item.k.nbPannesRep}</td>
            <td>${item.k.nbPannesTot}</td>
            <td>${item.k.btClosed}</td>
            <td>${item.k.btDenom}</td>
            <td>${item.k.diDone}</td>
            <td>${item.k.diDenom}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  </div>`;
}

function renderKpiRealBySysteme(unit) {
  const container = document.getElementById(`kpi-real-detail-content-${unit}`);
  if (!container) return;

  const { start, end, hoursTotal } = getFilters();
  const corrAll = filterByDate(DB.corrective[unit]||[], 'DATE_DI', start, end);
  const prevAll = filterByDate(DB.preventive[unit]||[], 'DATE_PREVUE', start, end);

  // Collecter tous les systèmes depuis SYSTEME + EQUIPEMENT(col1) + CODE_EQUIPEMENT(col1)
  const systemes = new Set();
  corrAll.forEach(r => {
    const s = (r['SYSTEME']||'').trim();
    if (s) systemes.add(s);
    const e = (r['EQUIPEMENT']||'').trim().split('.')[0];
    if (e && e !== s) systemes.add(e);
  });
  prevAll.forEach(r => {
    const s = (r['SYSTEME']||'').trim();
    if (s) systemes.add(s);
    const c = (r['CODE_EQUIPEMENT']||'').trim().split('.')[0];
    if (c && c !== s) systemes.add(c);
  });
  systemes.delete(''); systemes.delete('— N/A —');

  if (systemes.size === 0) {
    container.innerHTML = `<div style="color:var(--text3);font-size:12px;padding:8px">
      Aucun système identifié dans les données de l'unité ${unit}.
    </div>`;
    return;
  }

  const kpiList = [...systemes].sort().map(sys => {
    const corrFiltered = corrAll.filter(r => {
      const s = (r['SYSTEME']||'').trim();
      const e = (r['EQUIPEMENT']||'').trim().split('.')[0];
      return s === sys || e === sys;
    });
    const prevFiltered = prevAll.filter(r => {
      const s = (r['SYSTEME']||'').trim();
      const c = (r['CODE_EQUIPEMENT']||'').trim().split('.')[0];
      return s === sys || c === sys;
    });
    const k = calcKPIs(corrFiltered, prevFiltered, hoursTotal, start, end);
    return { key: sys, k };
  });

  container.innerHTML = `
    <div style="font-size:11px;font-weight:800;color:#059669;text-transform:uppercase;
                letter-spacing:1px;margin-bottom:8px;display:flex;align-items:center;gap:8px">
      <span style="width:4px;height:16px;background:linear-gradient(180deg,#059669,#0891b2);
                   border-radius:2px;display:inline-block"></span>
      Indicateurs de Realisation par Système — ${unit}
    </div>
    ${buildKpiRealTableHTML(kpiList, 'Système')}`;
}

function buildKpiEngTableHTML(kpiList, keyCol, showSousSystemeBtn, unit) {
  return `<div class="table-wrap" style="margin-bottom:8px">
    <table>
      <thead><tr>
        <th>${keyCol}</th>
        <th>MTTR(h)</th>
        <th>MTBF(h)</th>
        <th>λ=1/MTBF<br><small style="color:var(--green)">&gt;3e-3</small></th>
        <th>μ=1/MTTR<br><small style="color:var(--green)">&gt;0.25</small></th>
        <th>TCP<br><small style="color:var(--green)">&gt;80%</small></th>
        <th>TCC<br><small style="color:var(--red)">&lt;20%</small></th>
        <th>H_Prev</th><th>H_Corr</th>
        <th>Rep.</th><th>Tot.</th>
        <th>Indispo(h)</th><th>TBF(h)</th>
        ${showSousSystemeBtn ? '<th></th>' : ''}
      </tr></thead>
      <tbody>
        ${kpiList.map(item => {
          const safeKey = item.key.replace(/[^a-zA-Z0-9]/g,'_');
          return `
          <tr style="background:rgba(248,250,255,0.7)" id="kpi-sys-row-${unit}-${safeKey}">
            <td style="font-weight:700;font-size:12px;color:#1e40af">${item.key}</td>
            <td style="color:var(--corr)">${item.k.mttr.toFixed(3)}</td>
            <td style="color:var(--prev)">${item.k.mtbf>0&&item.k.nbPannesTot>0?item.k.mtbf.toFixed(1):'<span style="color:#ef4444">0 ⚠️</span>'}</td>
            <td><span class="badge ${objClass('tauxPanne',item.k.tauxPanne)}" style="font-size:9px">${item.k.tauxPanne>0?fmtSciShort(item.k.tauxPanne):'0 ⚠️'}</span> ${trendArrow('tauxPanne',item.k.tauxPanne)}</td>
            <td><span class="badge ${objClass('tauxRep',item.k.tauxRep)}" style="font-size:9px">${item.k.tauxRep>0?fmtSciShort(item.k.tauxRep):'—'}</span> ${trendArrow('tauxRep',item.k.tauxRep)}</td>
            <td><span class="badge ${objClass('tcp',item.k.tcp)}">${pct(item.k.tcp)}</span> ${trendArrow('tcp',item.k.tcp)}</td>
            <td><span class="badge ${objClass('tcc',item.k.tcc)}">${pct(item.k.tcc)}</span> ${trendArrow('tcc',item.k.tcc)}</td>
            <td style="font-size:11px">${item.k.hPrev.toFixed(1)}h</td>
            <td style="font-size:11px">${item.k.hCorr.toFixed(1)}h</td>
            <td>${item.k.nbPannesRep}</td>
            <td>${item.k.nbPannesTot}</td>
            <td style="color:var(--corr);font-size:11px">${item.k.indispoH.toFixed(1)}</td>
            <td style="font-size:11px">${item.k.tbf.toFixed(1)}</td>
            ${showSousSystemeBtn ? `
            <td style="text-align:center;min-width:110px">
              <button class="btn btn-ghost btn-sm" style="font-size:10px;padding:3px 8px;white-space:nowrap"
                onclick="toggleKpiEngSousSysteme('${unit}','${item.key.replace(/'/g,"\\'")}',this)">
                🔍 Sous-sys.
              </button>
            </td>` : ''}
          </tr>
          ${showSousSystemeBtn ? `
          <tr id="kpi-syssub-row-${unit}-${safeKey}" style="display:none">
            <td colspan="14" style="padding:0;border:none">
              <div id="kpi-syssub-${unit}-${safeKey}"
                style="margin:0 0 4px 32px;
                       border-left:4px solid #059669;
                       border-radius:0 0 12px 12px;
                       background:linear-gradient(135deg,rgba(5,150,105,0.06),rgba(8,145,178,0.04));
                       padding:14px 16px">
              </div>
            </td>
          </tr>` : ''}
        `}).join('')}
      </tbody>
    </table>
  </div>`;
}

function renderKpiEngBySysteme(unit) {
  const container = document.getElementById(`kpi-eng-detail-content-${unit}`);
  if (!container) return;

  const { start, end, hoursTotal } = getFilters();
  const corrAll = filterByDate(DB.corrective[unit]||[], 'DATE_DI', start, end);
  const prevAll = filterByDate(DB.preventive[unit]||[], 'DATE_PREVUE', start, end);

  // Collecter tous les systèmes depuis SYSTEME + EQUIPEMENT(col1) + CODE_EQUIPEMENT(col1)
  const systemes = new Set();
  corrAll.forEach(r => {
    const s = (r['SYSTEME']||'').trim();
    if (s) systemes.add(s);
    const e = (r['EQUIPEMENT']||'').trim().split('.')[0];
    if (e && e !== s) systemes.add(e);
  });
  prevAll.forEach(r => {
    const s = (r['SYSTEME']||'').trim();
    if (s) systemes.add(s);
    const c = (r['CODE_EQUIPEMENT']||'').trim().split('.')[0];
    if (c && c !== s) systemes.add(c);
  });
  systemes.delete(''); systemes.delete('— N/A —');

  if (systemes.size === 0) {
    container.innerHTML = `<div style="color:var(--text3);font-size:12px;padding:8px">
      Aucun système identifié dans les données de l'unité ${unit}.
    </div>`;
    return;
  }

  const kpiList = [...systemes].sort().map(sys => {
    // Filtrer correctives : colonne SYSTEME OU première partie de EQUIPEMENT
    const corrFiltered = corrAll.filter(r => {
      const s = (r['SYSTEME']||'').trim();
      const e = (r['EQUIPEMENT']||'').trim().split('.')[0];
      return s === sys || e === sys;
    });
    // Filtrer preventives : colonne SYSTEME OU première partie de CODE_EQUIPEMENT
    const prevFiltered = prevAll.filter(r => {
      const s = (r['SYSTEME']||'').trim();
      const c = (r['CODE_EQUIPEMENT']||'').trim().split('.')[0];
      return s === sys || c === sys;
    });
    const k = calcKPIs(corrFiltered, prevFiltered, hoursTotal, start, end);
    return { key: sys, k };
  });

  container.innerHTML = `
    <div style="font-size:11px;font-weight:800;color:#24537a;text-transform:uppercase;
                letter-spacing:1px;margin-bottom:8px;display:flex;align-items:center;gap:8px">
      <span style="width:4px;height:16px;background:linear-gradient(180deg,#24537a,#2f6690);
                   border-radius:2px;display:inline-block"></span>
      KPIs par Système — ${unit}
    </div>
    ${buildKpiEngTableHTML(kpiList, 'Système', true, unit)}`;
}

function toggleKpiEngSousSysteme(unit, systeme, btn) {
  const safeKey   = systeme.replace(/[^a-zA-Z0-9]/g,'_');
  const wrapRow   = document.getElementById(`kpi-syssub-row-${unit}-${safeKey}`);
  const container = document.getElementById(`kpi-syssub-${unit}-${safeKey}`);
  if (!wrapRow || !container) return;

  if (wrapRow.style.display !== 'none') {
    wrapRow.style.display = 'none';
    btn.textContent = '🔍 Sous-sys.';
    return;
  }

  wrapRow.style.display = '';
  btn.textContent = '− Fermer';

  // Si déjà rendu, ne pas recalculer
  if (container.dataset.rendered === '1') return;
  container.dataset.rendered = '1';

  const { start, end, hoursTotal } = getFilters();

  const corrAll = filterByDate(DB.corrective[unit]||[], 'DATE_DI', start, end).filter(r => {
    const s = (r['SYSTEME']||'').trim();
    const e = (r['EQUIPEMENT']||'').trim().split('.')[0];
    return s === systeme || e === systeme;
  });
  const prevAll = filterByDate(DB.preventive[unit]||[], 'DATE_PREVUE', start, end).filter(r => {
    const s = (r['SYSTEME']||'').trim();
    const c = (r['CODE_EQUIPEMENT']||'').trim().split('.')[0];
    return s === systeme || c === systeme;
  });

  const sousSys = new Set();
  corrAll.forEach(r => {
    const p = (r['EQUIPEMENT']||'').trim().split('.');
    if (p[2] && p[2].trim()) sousSys.add(p[2].trim());
  });
  prevAll.forEach(r => {
    const p = (r['CODE_EQUIPEMENT']||'').trim().split('.');
    if (p[2] && p[2].trim()) sousSys.add(p[2].trim());
  });
  sousSys.delete(''); sousSys.delete('— N/A —');

  if (sousSys.size === 0) {
    container.innerHTML = `
      <div style="color:#059669;font-size:11px;font-style:italic;padding:4px 0">
        Aucun sous-système identifié pour « ${systeme} ».
      </div>`;
    return;
  }

  const kpiList = [...sousSys].sort().map(ss => {
    const corrFiltered = corrAll.filter(r =>
      (r['EQUIPEMENT']||'').trim().split('.')[2] === ss
    );
    const prevFiltered = prevAll.filter(r =>
      (r['CODE_EQUIPEMENT']||'').trim().split('.')[2] === ss
    );
    const k = calcKPIs(corrFiltered, prevFiltered, hoursTotal, start, end);
    return { key: ss, k };
  });

  container.innerHTML = `
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
      <span style="width:4px;height:16px;background:linear-gradient(180deg,#059669,#0891b2);
                   border-radius:2px;flex-shrink:0"></span>
      <span style="font-size:11px;font-weight:800;color:#059669;
                   text-transform:uppercase;letter-spacing:1px">
        Sous-systèmes de « ${systeme} »
      </span>
      <span style="font-size:10px;background:#d1fae5;color:#065f46;
                   padding:2px 8px;border-radius:12px;font-weight:700">
        ${kpiList.length} sous-système${kpiList.length>1?'s':''}
      </span>
    </div>
    <div class="table-wrap">
      <table>
        <thead>
          <tr style="background:linear-gradient(135deg,rgba(5,150,105,0.12),rgba(8,145,178,0.08))">
            <th style="color:#065f46">Sous-Système</th>
            <th>MTTR(h)</th>
            <th>MTBF(h)</th>
            <th>λ=1/MTBF<br><small style="color:var(--green)">&gt;3e-3</small></th>
            <th>μ=1/MTTR<br><small style="color:var(--green)">&gt;0.25</small></th>
            <th>TCP<br><small style="color:var(--green)">&gt;80%</small></th>
            <th>TCC<br><small style="color:var(--red)">&lt;20%</small></th>
            <th>H_Prev</th><th>H_Corr</th>
            <th>Rep.</th><th>Tot.</th>
            <th>Indispo(h)</th><th>TBF(h)</th>
          </tr>
        </thead>
        <tbody>
          ${kpiList.map((item, idx) => `
            <tr style="background:${idx%2===0?'rgba(209,250,229,0.25)':'rgba(207,250,254,0.20)'}">
              <td style="font-weight:700;font-size:12px;color:#065f46">
                <span style="display:inline-flex;align-items:center;gap:6px">
                  <span style="width:6px;height:6px;border-radius:50%;
                               background:#059669;flex-shrink:0;
                               box-shadow:0 0 5px rgba(5,150,105,0.5)"></span>
                  ${item.key}
                </span>
              </td>
              <td style="color:var(--corr)">${item.k.mttr.toFixed(3)}</td>
              <td style="color:var(--prev)">${item.k.mtbf>0&&item.k.nbPannesTot>0?item.k.mtbf.toFixed(1):'<span style="color:#ef4444">0 ⚠️</span>'}</td>
              <td><span class="badge ${objClass('tauxPanne',item.k.tauxPanne)}" style="font-size:9px">${item.k.tauxPanne>0?fmtSciShort(item.k.tauxPanne):'0 ⚠️'}</span> ${trendArrow('tauxPanne',item.k.tauxPanne)}</td>
              <td><span class="badge ${objClass('tauxRep',item.k.tauxRep)}" style="font-size:9px">${item.k.tauxRep>0?fmtSciShort(item.k.tauxRep):'—'}</span> ${trendArrow('tauxRep',item.k.tauxRep)}</td>
              <td><span class="badge ${objClass('tcp',item.k.tcp)}">${pct(item.k.tcp)}</span> ${trendArrow('tcp',item.k.tcp)}</td>
              <td><span class="badge ${objClass('tcc',item.k.tcc)}">${pct(item.k.tcc)}</span> ${trendArrow('tcc',item.k.tcc)}</td>
              <td style="font-size:11px">${item.k.hPrev.toFixed(1)}h</td>
              <td style="font-size:11px">${item.k.hCorr.toFixed(1)}h</td>
              <td>${item.k.nbPannesRep}</td>
              <td>${item.k.nbPannesTot}</td>
              <td style="color:var(--corr);font-size:11px">${item.k.indispoH.toFixed(1)}</td>
              <td style="font-size:11px">${item.k.tbf.toFixed(1)}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>`;
}


function toggleChartGroup(checkbox) {
  const groupId = checkbox.dataset.chart;
  const group   = document.getElementById(groupId);
  if (!group) return;
  const label = checkbox.closest('label');
  if (checkbox.checked) {
    group.style.display = '';
    if (label) label.style.opacity = '1';
  } else {
    group.style.display = 'none';
    if (label) label.style.opacity = '0.45';
  }
  // Re-render charts si le groupe vient d'être affiché
  if (checkbox.checked) {
    setTimeout(() => { Object.values(charts).forEach(c => { try { c.resize(); } catch(e){} }); }, 50);
  }
}

function toggleAllCharts(show) {
  document.querySelectorAll('#chart-selector input[type="checkbox"]').forEach(cb => {
    cb.checked = show;
    toggleChartGroup(cb);
  });
}

/* ══ TOGGLE SECTIONS ══ */
const KPI_SECTIONS=['tcp','mttr','mtbf','tmp','dispo','taux'];
const CHART_MAP={tcp:['chart-charge'],mttr:['chart-mttr'],mtbf:['chart-mtbf'],tmp:['chart-tmt'],dispo:['chart-dispo'],taux:['chart-taux-panne','chart-taux-rep']};

function toggleSection(id){
  const sw=document.getElementById('sw-'+id);if(!sw)return;
  sw.checked=!sw.checked;onSwitch(id,sw.checked);
}
function onSwitch(id,on){
  const body=document.getElementById('body-'+id);if(!body)return;
  body.classList.toggle('open',on);
  if(on)setTimeout(()=>{(CHART_MAP[id]||[]).forEach(cid=>{if(charts[cid])try{charts[cid].resize()}catch(e){}});},60);
}
function openAllSections(){KPI_SECTIONS.forEach(id=>{const sw=document.getElementById('sw-'+id);if(sw){sw.checked=true;onSwitch(id,true);}});}
function closeAllSections(){KPI_SECTIONS.forEach(id=>{const sw=document.getElementById('sw-'+id);if(sw){sw.checked=false;onSwitch(id,false);}});}
function quickOpen(id){
  closeAllSections();
  const sw=document.getElementById('sw-'+id);if(sw){sw.checked=true;onSwitch(id,true);}
  const sec=document.getElementById('sec-'+id);
  if(sec)setTimeout(()=>sec.scrollIntoView({behavior:'smooth',block:'start'}),80);
}

/* ══ MISE À JOUR PEEK VALUES ══ */
function updatePeekValues(kpi,unit){
  const s=(el,v)=>{const e=document.getElementById(el);if(e)e.textContent=v;};
  s('peek-tcp-val', pct(kpi.tcp)+' / '+pct(kpi.tcc));
  s('peek-mttr-val',kpi.mttr>0?kpi.mttr.toFixed(3)+'h':'—');
  s('peek-mtbf-val',kpi.mtbf>0&&kpi.nbPannesTot>0?kpi.mtbf.toFixed(1)+'h':'—');
  s('peek-tmp-val', pct(kpi.tmp)+' / '+pct(kpi.tmc));
  s('peek-dispo-val',pct(kpi.dispo));
  s('peek-taux-val',kpi.tauxPanne>0?fmtSciShort(kpi.tauxPanne):'—');
  s('kpi-indispo',  kpi.indispoH.toFixed(1)+'h');
  s('kpi-indispo-sub','Sur '+kpi.hoursFlotte+'h theoriques ('+kpi.nbEquipements+' eq.)');
  s('kpi-tbf',      kpi.tbf.toFixed(1)+'h');
  s('kpi-tbf-sub',  kpi.hoursFlotte+'h - '+kpi.indispoH.toFixed(1)+'h');
}

// =====================================================================
// RAPPORT GENERAL DE PERFORMANCE — IA (toutes pages, hors MR et RH)
// Genere un rapport detaille et le telecharge en fichier HTML
// =====================================================================
function collectGlobalPerformanceData() {
  const { hoursTotal, start, end } = getFilters();

  // ── Synthese globale ──
  const { corrRows: allCorr, prevRows: allPrev } = getFilteredData();
  const globalK = calcKPIs(allCorr, allPrev, hoursTotal, start, end);

  // ── Par unite, avec details complets ──
  const unitData = UNITS.map(u => {
    const { corrRows, prevRows } = getFilteredData(u);
    if (corrRows.length + prevRows.length === 0) return null;
    const k = calcKPIs(corrRows, prevRows, hoursTotal, start, end);
    const obj = getOBJ(u);
    const checks = {
      tcp:   { ok: k.tcp   >= obj.tcp.val,   label:'TCP',   val:pct(k.tcp),   objLabel:obj.tcp.label   },
      tcc:   { ok: k.tcc   <= obj.tcc.val,   label:'TCC',   val:pct(k.tcc),   objLabel:obj.tcc.label   },
      tmp:   { ok: k.tmp   >= obj.tmp.val,   label:'TMP',   val:pct(k.tmp),   objLabel:obj.tmp.label   },
      tmc:   { ok: k.tmc   >= obj.tmc.val,   label:'TMC',   val:pct(k.tmc),   objLabel:obj.tmc.label   },
      dispo: { ok: k.dispo >= obj.dispo.val, label:'Dispo', val:pct(k.dispo), objLabel:obj.dispo.label }
    };
    const nbAtteints = Object.values(checks).filter(c=>c.ok).length;

    // Top 5 etats DI / BT
    const etatsDI = {}; corrRows.forEach(r => { const e = r['ETAT_DI']||'N/A'; etatsDI[e]=(etatsDI[e]||0)+1; });
    const etatsBT = {}; prevRows.forEach(r => { const e = r['ETAT_BT']||'N/A'; etatsBT[e]=(etatsBT[e]||0)+1; });

    return {
      unit: u, k, checks, nbAtteints, nbTotal: 5,
      nbCorr: corrRows.length, nbPrev: prevRows.length,
      nbSansDebut: k.nbSansDebut, nbNegatif: k.nbNegatif, nbAberrant: k.nbAberrant,
      etatsDI: Object.entries(etatsDI).sort((a,b)=>b[1]-a[1]).slice(0,5),
      etatsBT: Object.entries(etatsBT).sort((a,b)=>b[1]-a[1]).slice(0,5)
    };
  }).filter(Boolean);

  // ── Equipements : repartition 3 categories ──
  let nbEqBoth = 0, nbEqPrevOnly = 0, nbEqCorrOnly = 0;
  const corrCodes = new Set(), prevCodes = new Set();
  UNITS.forEach(u => {
    filterByDate(DB.corrective[u]||[], 'DATE_DI', start, end).forEach(r => {
      const c = (r['CODE_EQUIPEMENT']||r['EQUIPEMENT']||'').trim(); if (c) corrCodes.add(c);
    });
    filterByDate(DB.preventive[u]||[], 'DATE_PREVUE', start, end).forEach(r => {
      const c = (r['CODE_EQUIPEMENT']||'').trim(); if (c) prevCodes.add(c);
    });
  });
  corrCodes.forEach(c => { if (prevCodes.has(c)) nbEqBoth++; else nbEqCorrOnly++; });
  prevCodes.forEach(c => { if (!corrCodes.has(c)) nbEqPrevOnly++; });

  // ── Top 5 equipements les plus en panne (toutes unites) ──
  const eqPannes = {};
  UNITS.forEach(u => {
    filterByDate(DB.corrective[u]||[], 'DATE_DI', start, end).forEach(r => {
      const c = (r['CODE_EQUIPEMENT']||r['EQUIPEMENT']||'Inconnu').trim();
      const s = normState(r['ETAT_DI']);
      if (isTraitee(s)||isRealisee(s)||isTransmis(s)||isTransmettre(s)) eqPannes[c] = (eqPannes[c]||0)+1;
    });
  });
  const topEquip = Object.entries(eqPannes).sort((a,b)=>b[1]-a[1]).slice(0,5);

  // ── Tendance globale (comparaison 1ere vs 2eme moitie periode) ──
  const midDate = new Date((start.getTime()+end.getTime())/2);
  const corrFirstHalf = allCorr.filter(r => { const d=parseDate(r['DATE_DI']); return d && d<=midDate; });
  const corrSecondHalf = allCorr.filter(r => { const d=parseDate(r['DATE_DI']); return d && d>midDate; });
  const trendDirection = corrSecondHalf.length > corrFirstHalf.length ? 'hausse' :
                          corrSecondHalf.length < corrFirstHalf.length ? 'baisse' : 'stable';

  return { globalK, unitData, hoursTotal, start, end,
    equip: { nbEqBoth, nbEqPrevOnly, nbEqCorrOnly, topEquip },
    trend: { firstHalf: corrFirstHalf.length, secondHalf: corrSecondHalf.length, direction: trendDirection } };
}

async function generateGeneralAIReport() {
  const statusEl = document.getElementById('ai-general-report-status');
  const btn      = document.getElementById('btn-gen-ai-report');
  if (statusEl) {
    statusEl.style.display = 'flex';
    statusEl.style.alignItems = 'center';
    statusEl.style.gap = '10px';
    statusEl.innerHTML = `<div class="loader" style="width:22px;height:22px;border-width:2px"></div>
      <span style="font-size:12.5px;color:var(--text2);font-weight:600">Analyse de toutes les pages en cours…</span>`;
  }
  if (btn) btn.disabled = true;

  const data = collectGlobalPerformanceData();

  const unitsSummary = data.unitData.map(d =>
    `${d.unit} : TCP ${pct(d.k.tcp)} (obj ${getOBJ(d.unit).tcp.label}), TCC ${pct(d.k.tcc)} (obj ${getOBJ(d.unit).tcc.label}), ` +
    `TMP ${pct(d.k.tmp)}, TMC ${pct(d.k.tmc)}, Dispo ${pct(d.k.dispo)} (obj ${getOBJ(d.unit).dispo.label}), ` +
    `MTTR ${d.k.mttr.toFixed(2)}h, MTBF ${d.k.mtbf.toFixed(1)}h, Indispo ${d.k.indispoH.toFixed(1)}h, ` +
    `Pannes ${d.k.nbPannesTot} (${d.k.nbPannesRep} reparees), BT preventifs ${d.nbPrev}, ` +
    `Objectifs atteints : ${d.nbAtteints}/${d.nbTotal}` +
    (d.nbSansDebut+d.nbNegatif+d.nbAberrant > 0 ? ` [Qualite donnees: ${d.nbSansDebut} dates manquantes, ${d.nbNegatif} durees negatives, ${d.nbAberrant} durees aberrantes]` : '')
  ).join('\n');

  const prompt = 'Tu es un expert senior en maintenance industrielle ferroviaire (GMAO), charge de produire un rapport de direction.\n\n' +
    'DONNEES — periode de ' + data.hoursTotal + 'h theoriques (' + fmtDateFR(data.start) + ' au ' + fmtDateFR(data.end) + ') :\n\n' +
    'GLOBAL TOUTES UNITES :\n' +
    '- TCP ' + pct(data.globalK.tcp) + ' / TCC ' + pct(data.globalK.tcc) + '\n' +
    '- TMP ' + pct(data.globalK.tmp) + ' / TMC ' + pct(data.globalK.tmc) + '\n' +
    '- Disponibilite ' + pct(data.globalK.dispo) + '\n' +
    '- MTTR ' + data.globalK.mttr.toFixed(2) + 'h / MTBF ' + data.globalK.mtbf.toFixed(1) + 'h\n' +
    '- Indisponibilite totale ' + data.globalK.indispoH.toFixed(1) + 'h\n' +
    '- Pannes totales ' + data.globalK.nbPannesTot + ' dont ' + data.globalK.nbPannesRep + ' reparees\n\n' +
    'DETAIL PAR UNITE :\n' + unitsSummary + '\n\n' +
    'EQUIPEMENTS : ' + data.equip.nbEqBoth + ' couverts preventif+correctif, ' +
    data.equip.nbEqPrevOnly + ' preventif seul, ' + data.equip.nbEqCorrOnly + ' correctif seul.\n' +
    'Top 5 equipements les plus en panne : ' + data.equip.topEquip.map(([c,n])=>`${c} (${n})`).join(', ') + '\n\n' +
    'TENDANCE : pannes 1ere moitie de periode = ' + data.trend.firstHalf + ', 2eme moitie = ' + data.trend.secondHalf +
    ' → tendance ' + data.trend.direction + '\n\n' +
    'Produis un rapport JSON STRICT (sans markdown, sans backticks), riche et exploitable par un directeur de maintenance, format exact :\n' +
    '{\n' +
    '  "titre": "...",\n' +
    '  "synthese_executive": "2-4 phrases, vue d\'ensemble strategique",\n' +
    '  "objectifs_globaux_atteints": true|false,\n' +
    '  "score_global_sur_5": 0-5,\n' +
    '  "analyse_disponibilite": "...",\n' +
    '  "analyse_charge_preventive_corrective": "...",\n' +
    '  "analyse_fiabilite": "analyse MTTR/MTBF et qualite des donnees...",\n' +
    '  "analyse_equipements": "...",\n' +
    '  "analyse_tendance": "...",\n' +
    '  "points_forts": ["...","...","..."],\n' +
    '  "points_attention": ["...","...","..."],\n' +
    '  "risques": ["...","..."],\n' +
    '  "rapports_unites": [{ "unite":"...", "score_sur_5":0-5, "resume":"...", "objectifs_atteints":true|false, "analyse_detaillee":"3-4 phrases", "actions_prioritaires":["...","..."] }],\n' +
    '  "recommandations_strategiques": ["...","...","...","..."],\n' +
    '  "conclusion": "..."\n' +
    '}';

  let report;
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model:'claude-sonnet-4-20250514', max_tokens:3000, messages:[{ role:'user', content:prompt }] })
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const apiData   = await response.json();
    const rawText   = (apiData.content||[]).filter(b=>b.type==='text').map(b=>b.text).join('');
    const cleanJson = rawText.replace(/```json|```/g,'').trim();
    report = JSON.parse(cleanJson);
  } catch (err) {
    console.warn('Fallback local :', err.message);
    report = generateLocalGeneralReport(data);
  }

  downloadGeneralReport(report, data);

  if (statusEl) {
    statusEl.innerHTML = `<span style="font-size:12.5px;color:#059669;font-weight:700">✅ Rapport telecharge avec succes</span>`;
    setTimeout(() => { statusEl.style.display = 'none'; }, 4000);
  }
  if (btn) btn.disabled = false;
}

function generateLocalGeneralReport(data) {
  const g = data.globalK;
  const objGlobal = { tcp: g.tcp>=0.80, tcc: g.tcc<=0.20, tmp: g.tmp>=1.0, tmc: g.tmc>=0.90, dispo: g.dispo>=0.97 };
  const nbOk = Object.values(objGlobal).filter(Boolean).length;
  const pointsForts = [], pointsAttention = [], risques = [];

  if (objGlobal.dispo) pointsForts.push(`Disponibilite globale conforme a l'objectif (${pct(g.dispo)} ≥ 97%)`);
  else { pointsAttention.push(`Disponibilite globale insuffisante (${pct(g.dispo)} vs objectif 97%)`); risques.push('Risque d\'interruption de service accru'); }

  if (objGlobal.tcp) pointsForts.push(`Bon equilibre preventif/correctif (TCP ${pct(g.tcp)})`);
  else { pointsAttention.push(`Charge corrective excessive (TCC ${pct(g.tcc)} vs objectif <20%)`); risques.push('Derive vers une maintenance subie plutot qu\'anticipee'); }

  if (g.mtbf > 0) pointsForts.push(`MTBF mesurable et exploitable : ${g.mtbf.toFixed(1)}h`);
  else { pointsAttention.push('MTBF a 0 — dates d\'intervention (DATE_EVENEMENT / DATE_FIN_INTERVENTION) manquantes en masse'); risques.push('Incapacite a fiabiliser les previsions de panne sans correction des donnees sources'); }

  if (g.mttr > 0) pointsForts.push(`Temps de reparation moyen mesure : ${g.mttr.toFixed(2)}h`);

  const rapportsUnites = data.unitData.map(d => ({
    unite: d.unit,
    score_sur_5: d.nbAtteints,
    resume: `TCP ${pct(d.k.tcp)} / TCC ${pct(d.k.tcc)} / Dispo ${pct(d.k.dispo)} / ${d.k.nbPannesTot} pannes`,
    objectifs_atteints: d.nbAtteints >= Math.ceil(d.nbTotal*0.8),
    analyse_detaillee: `${d.nbAtteints}/${d.nbTotal} objectifs atteints. MTTR ${d.k.mttr.toFixed(2)}h, MTBF ${d.k.mtbf.toFixed(1)}h, indisponibilite ${d.k.indispoH.toFixed(1)}h.` +
      (d.nbSansDebut+d.nbNegatif+d.nbAberrant>0 ? ` Qualite des donnees a ameliorer : ${d.nbSansDebut} dates manquantes, ${d.nbNegatif} durees negatives, ${d.nbAberrant} durees aberrantes.` : ' Qualite des donnees correcte.'),
    actions_prioritaires: d.nbAtteints < 3
      ? ['Auditer les causes racines des pannes recurrentes', 'Renforcer la planification preventive', 'Fiabiliser la saisie des dates d\'intervention']
      : ['Maintenir le niveau de performance actuel', 'Capitaliser les bonnes pratiques vers les autres unites']
  }));

  return {
    titre: 'Rapport General de Performance Maintenance',
    synthese_executive: `Sur la periode analysee (${data.hoursTotal}h theoriques), ${nbOk}/5 objectifs cles sont atteints au niveau global. ` +
      `${g.nbPannesTot} pannes ont ete traitees avec une disponibilite de ${pct(g.dispo)}. La tendance des pannes est en ${data.trend.direction} entre les deux moities de la periode.`,
    objectifs_globaux_atteints: nbOk >= 4,
    score_global_sur_5: nbOk,
    analyse_disponibilite: `La disponibilite operationnelle s'etablit a ${pct(g.dispo)} pour un objectif de 97%, representant ${g.indispoH.toFixed(1)}h d'indisponibilite cumulee sur ${g.hoursFlotte}h theoriques (${g.nbEquipements} equipements).`,
    analyse_charge_preventive_corrective: `Le taux de charge preventive (TCP) est de ${pct(g.tcp)} contre ${pct(g.tcc)} de charge corrective. ${objGlobal.tcp ? 'L\'equilibre est sain.' : 'La part corrective reste trop importante, signe d\'une maintenance plus reactive que planifiee.'}`,
    analyse_fiabilite: `MTTR moyen de ${g.mttr.toFixed(2)}h et MTBF de ${g.mtbf.toFixed(1)}h. ${g.mtbf===0 ? 'L\'absence de MTBF exploitable revele un probleme de qualite de saisie des dates d\'evenement et de fin d\'intervention qui doit etre corrige en priorite.' : 'Ces valeurs permettent un suivi fiable de la fiabilite des equipements.'}`,
    analyse_equipements: `${data.equip.nbEqBoth} equipements beneficient d'un suivi preventif et correctif combine, ${data.equip.nbEqPrevOnly} sont suivis uniquement en preventif, et ${data.equip.nbEqCorrOnly} n'ont aucune couverture preventive malgre des pannes constatees — ces derniers constituent un risque prioritaire.`,
    analyse_tendance: `Le volume de pannes correctives est passe de ${data.trend.firstHalf} sur la premiere moitie de periode a ${data.trend.secondHalf} sur la seconde, soit une tendance a la ${data.trend.direction}.`,
    points_forts: pointsForts.length ? pointsForts : ['Aucun point fort significatif identifie sur la periode'],
    points_attention: pointsAttention.length ? pointsAttention : ['Aucun point d\'attention majeur detecte'],
    risques: risques.length ? risques : ['Aucun risque majeur identifie'],
    rapports_unites: rapportsUnites,
    recommandations_strategiques: [
      'Fiabiliser systematiquement la saisie de DATE_EVENEMENT et DATE_FIN_INTERVENTION pour reactiver le calcul du MTBF',
      'Prioriser le passage en preventif des equipements actuellement en correctif seul, en commencant par les plus recurrents',
      'Concentrer les actions correctives sur les unites ayant le moins d\'objectifs atteints',
      'Mettre en place un suivi mensuel de la tendance des pannes pour anticiper les derives'
    ],
    conclusion: `${nbOk >= 4 ? 'La performance globale est globalement satisfaisante, avec des marges de progression cibles.' : 'La performance globale necessite un plan d\'action correctif prioritaire sur la disponibilite et la fiabilite des donnees.'} Un suivi rapproche des unites les plus en difficulte est recommande.`
  };
}

// ── Construction et telechargement du rapport HTML ──
function downloadGeneralReport(r, data) {
  const dateGenere = new Date().toLocaleString('fr-FR', { day:'2-digit', month:'long', year:'numeric', hour:'2-digit', minute:'2-digit' });
  const periodeLabel = `${fmtDateFR(data.start)} → ${fmtDateFR(data.end)}`;

  const scoreColor = (s) => s >= 4 ? '#059669' : s >= 3 ? '#d97706' : '#dc2626';
  const badgeObj = (ok) => ok
    ? `<span style="display:inline-block;padding:4px 12px;border-radius:20px;background:#dcfce7;color:#15803d;font-weight:700;font-size:12px">✅ Objectifs atteints</span>`
    : `<span style="display:inline-block;padding:4px 12px;border-radius:20px;background:#fee2e2;color:#b91c1c;font-weight:700;font-size:12px">⚠️ Objectifs non atteints</span>`;

  const listHtml = (arr, color) => `<ul style="margin:0;padding-left:20px;line-height:1.9">${(arr||[]).map(i=>`<li style="margin-bottom:4px">${i}</li>`).join('')}</ul>`;

  const unitsHtml = (r.rapports_unites||[]).map(u => `
    <div style="border:1.5px solid #e2e8f4;border-radius:14px;padding:18px 20px;margin-bottom:14px;background:#fafbff">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;flex-wrap:wrap">
        <span style="background:${UNIT_COLORS[u.unite]||'#2f6690'};color:#fff;padding:4px 14px;border-radius:8px;font-weight:800;font-size:14px">${u.unite}</span>
        <span style="font-weight:700;font-size:13px;color:${scoreColor(u.score_sur_5)}">Score : ${u.score_sur_5}/5</span>
        ${badgeObj(u.objectifs_atteints)}
      </div>
      <div style="font-weight:700;font-size:13px;color:#0a1930;margin-bottom:6px">${u.resume||''}</div>
      <div style="font-size:12.5px;color:#44537a;line-height:1.7;margin-bottom:10px">${u.analyse_detaillee||''}</div>
      ${u.actions_prioritaires && u.actions_prioritaires.length ? `
      <div style="font-size:11px;font-weight:700;color:#24537a;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px">Actions prioritaires</div>
      ${listHtml(u.actions_prioritaires)}` : ''}
    </div>`).join('');

  const html = `<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8">
<title>${r.titre || 'Rapport General de Performance'}</title>
<style>
  body{font-family:'Montserrat',Arial,sans-serif;background:#f0f4ff;color:#0a1930;margin:0;padding:40px;line-height:1.6}
  .report{max-width:920px;margin:0 auto;background:#fff;border-radius:18px;box-shadow:0 12px 48px rgba(13,27,62,0.10);overflow:hidden}
  .header{background:linear-gradient(135deg,#2f6690,#24537a);color:#fff;padding:36px 40px}
  .header h1{margin:0 0 8px;font-size:26px;font-weight:800}
  .header .meta{font-size:12.5px;opacity:0.9}
  .body{padding:32px 40px}
  h2{font-size:16px;font-weight:800;color:#0a1930;margin:28px 0 12px;padding-bottom:8px;border-bottom:2px solid #ede9fe}
  .score-banner{display:flex;align-items:center;gap:16px;background:#f4f7ff;border:1.5px solid #e2e8f4;border-radius:14px;padding:18px 20px;margin-bottom:20px}
  .score-circle{width:64px;height:64px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:900;color:#fff;flex-shrink:0}
  p{font-size:13px;color:#44537a;margin:6px 0}
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin:14px 0}
  .box{background:#fafbff;border:1.5px solid #e2e8f4;border-radius:12px;padding:16px 18px}
  .footer{padding:20px 40px;font-size:11px;color:#8896b3;text-align:center;border-top:1px solid #e2e8f4}
  @media print{ body{background:#fff;padding:0} .report{box-shadow:none;border-radius:0} }
</style></head>
<body>
<div class="report">
  <div class="header">
    <h1>📋 ${r.titre || 'Rapport General de Performance Maintenance'}</h1>
    <div class="meta">Periode analysee : ${periodeLabel} · ${data.hoursTotal}h theoriques · Genere le ${dateGenere}</div>
  </div>
  <div class="body">

    <div class="score-banner">
      <div class="score-circle" style="background:${scoreColor(r.score_global_sur_5)}">${r.score_global_sur_5}/5</div>
      <div>
        <div style="font-weight:800;font-size:14px;margin-bottom:4px">${badgeObj(r.objectifs_globaux_atteints)}</div>
        <div style="font-size:12.5px;color:#44537a">Score global base sur TCP, TCC, TMP, TMC et Disponibilite</div>
      </div>
    </div>

    <h2>Synthese Executive</h2>
    <p>${r.synthese_executive || ''}</p>

    <h2>Analyses Detaillees</h2>
    <div class="grid2">
      <div class="box"><strong>🟢 Disponibilite</strong><p>${r.analyse_disponibilite||''}</p></div>
      <div class="box"><strong>🔵 Charge Preventive / Corrective</strong><p>${r.analyse_charge_preventive_corrective||''}</p></div>
      <div class="box"><strong>🟣 Fiabilite (MTTR/MTBF)</strong><p>${r.analyse_fiabilite||''}</p></div>
      <div class="box"><strong>🟠 Equipements</strong><p>${r.analyse_equipements||''}</p></div>
    </div>
    <div class="box" style="margin-top:14px"><strong>📈 Tendance</strong><p>${r.analyse_tendance||''}</p></div>

    <h2>✅ Points Forts</h2>
    ${listHtml(r.points_forts, '#059669')}

    <h2>⚠️ Points d'Attention</h2>
    ${listHtml(r.points_attention, '#d97706')}

    <h2>🔴 Risques Identifies</h2>
    ${listHtml(r.risques, '#dc2626')}

    <h2>🏭 Rapports par Unite</h2>
    ${unitsHtml || '<p>Aucune unite analysee.</p>'}

    <h2>💡 Recommandations Strategiques</h2>
    ${listHtml(r.recommandations_strategiques)}

    <h2>Conclusion</h2>
    <p>${r.conclusion || ''}</p>

  </div>
  <div class="footer">Rapport genere automatiquement par le module IA de la plateforme GMAO — A usage interne</div>
</div>
</body></html>`;

  const blob = new Blob([html], { type:'text/html;charset=utf-8' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  const dstr = new Date().toISOString().slice(0,10);
  a.href = url;
  a.download = `Rapport_Performance_${dstr}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}


