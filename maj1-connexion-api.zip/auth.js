/* =========================================================
   auth.js — Authentification · Plateforme Maintenance SETRAM
   -----------------------------------------------------------
   Module partagé inclus dans TOUTES les pages de l'application.
   Vérifie l'email + mot de passe contre window.SETRAM_COMPTES
   (défini dans assets/comptes.js, chargé AVANT ce fichier).

   Le "mot de passe oublié" écrit directement le nouveau hash dans
   comptes.js, via l'API native du navigateur (File System Access —
   Chrome/Edge uniquement). Aucun serveur, aucun compte tiers.

   ⚠️ Portée de la protection : contrôle d'accès côté navigateur
   pour un usage interne (dossier partagé / réseau d'entreprise),
   pas une sécurité de niveau serveur.
   ========================================================= */
(function () {
  "use strict";

  var SESSION_KEY = "setram_auth_session";
  var SESSION_DURATION_MS = 12 * 60 * 60 * 1000; // 12h
  var REMEMBER_KEY = "setram_remembered_accounts"; // persiste sur cet ordinateur (localStorage)

  // ---------------------------------------------------------------
  // Historique des connexions — persisté en localStorage (donc propre
  // à CE poste/navigateur). Chaque connexion ouvre une entrée ; elle
  // est "fermée" (logoutAt) à la déconnexion, à l'expiration de la
  // session, ou remplacée par une nouvelle connexion. Un "heartbeat"
  // périodique met à jour lastSeenAt pour estimer la durée même sans
  // déconnexion explicite (fermeture d'onglet, etc.).
  // ---------------------------------------------------------------
  var HISTORY_KEY = "setram_login_history";
  var HISTORY_MAX = 300;

  function getHistory() {
    try {
      var raw = localStorage.getItem(HISTORY_KEY);
      var list = raw ? JSON.parse(raw) : [];
      return Array.isArray(list) ? list : [];
    } catch (e) { return []; }
  }

  function saveHistory(list) {
    try {
      if (list.length > HISTORY_MAX) list = list.slice(list.length - HISTORY_MAX);
      localStorage.setItem(HISTORY_KEY, JSON.stringify(list));
    } catch (e) {}
  }

  function genHistoryId() {
    return "h_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8);
  }

  function openHistoryEntry(username, role, nom) {
    var list = getHistory();
    var id = genHistoryId();
    var entry = {
      id: id,
      username: username,
      nom: nom || username,
      role: role || "user",
      loginAt: Date.now(),
      lastSeenAt: Date.now(),
      logoutAt: null,
      logoutReason: null
    };
    list.push(entry);
    saveHistory(list);
    return entry;
  }

  function closeHistoryEntry(historyId, reason, atTime) {
    if (!historyId) return null;
    var list = getHistory();
    var entry = list.find(function (h) { return h.id === historyId && !h.logoutAt; });
    if (entry) {
      entry.logoutAt = atTime || Date.now();
      entry.logoutReason = reason || "deconnexion";
      saveHistory(list);
    }
    return entry;
  }

  function touchHistoryEntry(historyId) {
    if (!historyId) return null;
    var list = getHistory();
    var entry = list.find(function (h) { return h.id === historyId && !h.logoutAt; });
    if (entry) {
      entry.lastSeenAt = Date.now();
      saveHistory(list);
    }
    return entry;
  }

  // Lecture de l'historique pour affichage (ex: admin.html), le plus récent d'abord.
  window.SETRAM_GET_LOGIN_HISTORY = function () {
    return getHistory().slice().sort(function (a, b) { return b.loginAt - a.loginAt; });
  };

  window.SETRAM_CLEAR_LOGIN_HISTORY = function () {
    try { localStorage.removeItem(HISTORY_KEY); } catch (e) {}
  };

  // ---------------------------------------------------------------
  // Synchronisation vers le fichier PARTAGÉ (assets/historique-connexions.js)
  // pour obtenir un historique centralisé, tous postes confondus.
  // Utilise le même mécanisme que comptes.js (File System Access API +
  // SetramFileHandleStore). Écriture "best effort" : ne bloque JAMAIS la
  // connexion/déconnexion de l'utilisateur en cas d'échec.
  // ---------------------------------------------------------------
  var SHARED_HISTORY_KEY = "historique-js";
  var SHARED_HISTORY_ASK_KEY = "setram_shared_history_asked";
  var SHARED_HISTORY_MAX = 500;

  function buildSharedHistoryContent(list) {
    var lines = list.map(function (h) {
      return "  { id: " + JSON.stringify(h.id) +
        ", username: " + JSON.stringify(h.username) +
        ", nom: " + JSON.stringify(h.nom || h.username) +
        ", role: " + JSON.stringify(h.role || "user") +
        ", loginAt: " + h.loginAt +
        ", lastSeenAt: " + h.lastSeenAt +
        ", logoutAt: " + (h.logoutAt === null || h.logoutAt === undefined ? "null" : h.logoutAt) +
        ", logoutReason: " + JSON.stringify(h.logoutReason || null) + " }";
    }).join(",\n");
    return "/* =========================================================\n" +
      "   historique-connexions.js — Historique des connexions\n" +
      "   Plateforme Maintenance SETRAM\n" +
      "   Dernière écriture : " + new Date().toLocaleString("fr-FR") + "\n" +
      "   -----------------------------------------------------------\n" +
      "   Alimenté automatiquement par assets/auth.js à chaque connexion,\n" +
      "   depuis n'importe quel poste connecté à ce fichier partagé.\n" +
      "   Ne pas éditer à la main.\n" +
      "   ========================================================= */\n" +
      "window.SETRAM_HISTORIQUE = [\n" + lines + "\n];\n";
  }

  async function readSharedHistory(handle) {
    try {
      var file = await handle.getFile();
      var text = await file.text();
      var m = text.match(/window\.SETRAM_HISTORIQUE\s*=\s*(\[[\s\S]*?\]);/);
      if (!m) return [];
      var arr = (0, eval)(m[1]);
      return Array.isArray(arr) ? arr : [];
    } catch (e) { return []; }
  }

  async function writeEntryToHandle(handle, entry) {
    var list = await readSharedHistory(handle);
    var idx = list.findIndex(function (h) { return h.id === entry.id; });
    if (idx >= 0) list[idx] = entry; else list.push(entry);
    if (list.length > SHARED_HISTORY_MAX) list = list.slice(list.length - SHARED_HISTORY_MAX);
    var writable = await handle.createWritable();
    await writable.write(buildSharedHistoryContent(list));
    await writable.close();
  }

  // Sync silencieuse (jamais de fenêtre) : utilisée pour le heartbeat, la
  // déconnexion et l'expiration — uniquement si ce poste est déjà connecté.
  function syncEntrySilently(entry) {
    if (!entry || !window.SetramFileHandleStore || !window.showOpenFilePicker) return;
    window.SetramFileHandleStore.tryGetHandleSilently(SHARED_HISTORY_KEY)
      .then(function (handle) { if (handle) return writeEntryToHandle(handle, entry); })
      .catch(function () {});
  }

  // Appelée à la connexion : si ce poste n'est pas encore connecté au fichier
  // partagé ET n'a jamais refusé, propose UNE SEULE FOIS (par navigateur) de
  // choisir le fichier assets/historique-connexions.js. N'interrompt jamais
  // la connexion en cas d'échec/annulation.
  function syncLoginToSharedHistory(entry) {
    if (!window.SetramFileHandleStore || !window.showOpenFilePicker) return;
    window.SetramFileHandleStore.tryGetHandleSilently(SHARED_HISTORY_KEY).then(function (handle) {
      if (handle) return writeEntryToHandle(handle, entry);
      var alreadyAsked = false;
      try { alreadyAsked = localStorage.getItem(SHARED_HISTORY_ASK_KEY) === "1"; } catch (e) {}
      if (alreadyAsked) return;
      try { localStorage.setItem(SHARED_HISTORY_ASK_KEY, "1"); } catch (e) {}
      var ok = confirm(
        "Activer le suivi des connexions sur ce poste ?\n\n" +
        "Cela permet à l'administrateur de voir qui se connecte à l'application, depuis tous les ordinateurs.\n" +
        "Vous devrez choisir UNE FOIS le fichier partagé « historique-connexions.js » (dossier assets/ de l'application)."
      );
      if (!ok) return;
      return window.SetramFileHandleStore.getWritableHandle(SHARED_HISTORY_KEY, {
        types: [{ description: "historique-connexions.js", accept: { "text/javascript": [".js"] } }],
        excludeAcceptAllOption: false
      }).then(function (pick) {
        if (pick.handle) return writeEntryToHandle(pick.handle, entry);
      });
    }).catch(function () {});
  }

  function getRememberedAccounts() {
    try {
      var raw = localStorage.getItem(REMEMBER_KEY);
      var list = raw ? JSON.parse(raw) : [];
      return Array.isArray(list) ? list : [];
    } catch (e) { return []; }
  }

  function saveRememberedAccounts(list) {
    try { localStorage.setItem(REMEMBER_KEY, JSON.stringify(list)); } catch (e) {}
  }

  // Enregistre/actualise ce compte dans la liste mémorisée sur cet appareil.
  function rememberAccount(acc, hash) {
    var list = getRememberedAccounts().filter(function (r) {
      return r.username.toLowerCase() !== acc.username.toLowerCase();
    });
    list.unshift({
      username: acc.username,
      nom: acc.nom || acc.username,
      role: acc.role || "user",
      hash: hash
    });
    if (list.length > 8) list = list.slice(0, 8);
    saveRememberedAccounts(list);
  }

  function forgetAccount(username) {
    var list = getRememberedAccounts().filter(function (r) {
      return r.username.toLowerCase() !== username.toLowerCase();
    });
    saveRememberedAccounts(list);
  }

  document.documentElement.style.visibility = "hidden";

  function getSession() {
    try {
      var raw = sessionStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      var s = JSON.parse(raw);
      if (!s || !s.username || !s.exp) return null;
      if (Date.now() > s.exp) {
        var closed = closeHistoryEntry(s.hid, "expiration", s.exp);
        syncEntrySilently(closed);
        try { sessionStorage.removeItem(SESSION_KEY); } catch (e) {}
        return null;
      }
      return s;
    } catch (e) { return null; }
  }

  function setSession(username, role, nom, permissions, email) {
    var entry = openHistoryEntry(username, role, nom);
    syncLoginToSharedHistory(entry);
    var s = { username: username, email: email || "", role: role || "user", nom: nom || "", permissions: permissions || [], exp: Date.now() + SESSION_DURATION_MS, hid: entry.id };
    try { sessionStorage.setItem(SESSION_KEY, JSON.stringify(s)); } catch (e) {}
    return s;
  }

  window.SETRAM_LOGOUT = function () {
    try {
      var raw = sessionStorage.getItem(SESSION_KEY);
      var s = raw ? JSON.parse(raw) : null;
      if (s && s.hid) {
        var closed = closeHistoryEntry(s.hid, "deconnexion");
        syncEntrySilently(closed);
      }
    } catch (e) {}
    try { sessionStorage.removeItem(SESSION_KEY); } catch (e) {}
    location.reload();
  };

  async function sha256Hex(str) {
    if (window.crypto && window.crypto.subtle) {
      var enc = new TextEncoder().encode(str);
      var buf = await window.crypto.subtle.digest("SHA-256", enc);
      return Array.from(new Uint8Array(buf)).map(function (b) { return b.toString(16).padStart(2, "0"); }).join("");
    }
    var hash = 0, i, chr;
    for (i = 0; i < str.length; i++) {
      chr = str.charCodeAt(i);
      hash = (hash << 5) - hash + chr;
      hash |= 0;
    }
    return "fallback_" + hash;
  }

  function accounts() {
    return window.SETRAM_COMPTES || [];
  }

  // ---------------------------------------------------------------
  // Écriture directe de comptes.js (File System Access API).
  // Ne fonctionne que sur Chrome/Edge, avec le fichier accessible
  // (partage réseau monté, ou copie locale). Reconstruit le fichier
  // à l'identique, en ne changeant que le hash du compte concerné.
  // ---------------------------------------------------------------
  function buildComptesFileContent(list, notifications) {
    var lines = list.map(function (a) {
      return "  {\n" +
        "    username: " + JSON.stringify(a.username || "") + ",\n" +
        "    email: " + JSON.stringify(a.email || "") + ",\n" +
        "    nom: " + JSON.stringify(a.nom || "") + ",\n" +
        "    telephone: " + JSON.stringify(a.telephone || "") + ",\n" +
        "    role: " + JSON.stringify(a.role || "user") + ",\n" +
        "    hash: " + JSON.stringify(a.hash) + ",\n" +
        "    actif: " + (a.actif !== false) + ",\n" +
        "    permissions: " + JSON.stringify(a.permissions || []) + "\n" +
        "  }";
    }).join(",\n");
    var notifLines = (notifications || []).map(function (n) {
      return "  { username: " + JSON.stringify(n.username) + ", date: " + JSON.stringify(n.date) +
        ", message: " + JSON.stringify(n.message) + " }";
    }).join(",\n");
    return "/* =========================================================\n" +
      "   comptes.js — Comptes autorisés · Plateforme Maintenance SETRAM\n" +
      "   Mis à jour automatiquement (réinitialisation de mot de passe) le " + new Date().toLocaleString("fr-FR") + "\n" +
      "   ========================================================= */\n" +
      "window.SETRAM_COMPTES = [\n" + lines + "\n];\n\n" +
      "/* Journal des réinitialisations de mot de passe, affiché dans\n" +
      "   admin.html (Gestion des comptes). Alimenté automatiquement. */\n" +
      "window.SETRAM_NOTIFICATIONS = [\n" + notifLines + "\n];\n";
  }

  async function writeNewPasswordToFile(username, newHash) {
    if (!window.showOpenFilePicker) {
      return { ok: false, reason: "unsupported" };
    }
    var pick = await window.SetramFileHandleStore.getWritableHandle("comptes-js", {
      types: [{ description: "comptes.js", accept: { "text/javascript": [".js"] } }],
      excludeAcceptAllOption: false
    });
    if (pick.reason === "user_cancelled") return { ok: false, reason: "cancelled" };
    if (pick.reason === "permission_denied") return { ok: false, reason: "permission_denied" };
    if (pick.reason === "unsupported" || !pick.handle) return { ok: false, reason: "unsupported" };
    var handle = pick.handle;
    try {
      var file = await handle.getFile();
      var text = await file.text();
      if (text.indexOf("SETRAM_COMPTES") === -1) {
        return { ok: false, reason: "wrong_file" };
      }

      var list = JSON.parse(JSON.stringify(accounts()));
      var acc = list.find(function (a) { return a.username && a.username.toLowerCase() === username.toLowerCase(); });
      if (!acc) return { ok: false, reason: "not_found" };
      acc.hash = newHash;

      var notifications = JSON.parse(JSON.stringify(window.SETRAM_NOTIFICATIONS || []));
      notifications.push({
        username: acc.username,
        date: new Date().toISOString(),
        message: (acc.nom || acc.username) + " a réinitialisé son mot de passe."
      });

      var content = buildComptesFileContent(list, notifications);
      var writable = await handle.createWritable();
      await writable.write(content);
      await writable.close();
      return { ok: true };
    } catch (e) {
      await window.SetramFileHandleStore.clear("comptes-js");
      return { ok: false, reason: "write_error", error: e };
    }
  }

  window.SETRAM_HAS_ACCESS = function (permId) {
    var u = window.SETRAM_USER;
    if (!u) return false;
    if (u.role === "admin") return true;
    return Array.isArray(u.permissions) && (u.permissions.indexOf(permId) !== -1 || u.permissions.indexOf("all") !== -1);
  };

  window.SETRAM_HAS_SUB_ACCESS = function (toolId, group, itemId) {
    var u = window.SETRAM_USER;
    if (!u) return false;
    if (u.role === "admin") return true;
    if (!window.SETRAM_HAS_ACCESS(toolId)) return false;
    var perms = u.permissions || [];
    if (perms.indexOf("all") !== -1) return true;
    var prefix = toolId + ":" + group + ":";
    var subEntries = perms.filter(function (p) { return p.indexOf(prefix) === 0; });
    if (subEntries.length === 0) return true;
    return subEntries.indexOf(prefix + itemId) !== -1;
  };

  function injectDenied() {
    var overlay = document.createElement("div");
    overlay.id = "setram-denied-overlay";
    overlay.innerHTML =
      '<style>' +
      '#setram-denied-overlay{position:fixed;inset:0;z-index:9999999;display:flex;align-items:center;justify-content:center;' +
      'background:linear-gradient(135deg,#0a1930 20%,#2f6690 100%);font-family:"Montserrat","Segoe UI",Arial,sans-serif;text-align:center;}' +
      '#setram-denied-overlay .box{background:#fff;border-radius:14px;padding:36px 34px;width:340px;max-width:88vw;box-shadow:0 24px 60px rgba(0,0,0,.45);}' +
      '#setram-denied-overlay h1{margin:0 0 8px;font-size:16px;color:#0a1930;font-weight:800;}' +
      '#setram-denied-overlay p{margin:0 0 20px;font-size:12.5px;color:#44537a;line-height:1.6;}' +
      '#setram-denied-overlay button{border:none;border-radius:8px;background:#2f6690;color:#fff;font-weight:700;' +
      'font-size:13px;padding:10px 18px;cursor:pointer;font-family:inherit;}' +
      '</style>' +
      '<div class="box">' +
      '<h1>Accès refusé</h1>' +
      '<p>Votre compte n\'a pas accès à cet outil. Contactez un administrateur si vous pensez que c\'est une erreur.</p>' +
      '<button onclick="window.SETRAM_LOGOUT()">Se déconnecter</button>' +
      '</div>';
    document.body.appendChild(overlay);
  }

  function finalize(user) {
    window.SETRAM_USER = user;
    document.documentElement.style.visibility = "visible";
    var req = window.SETRAM_REQUIRE_PERM;
    var allowed = !req || window.SETRAM_HAS_ACCESS(req);
    if (!allowed) {
      injectDenied();
      return;
    }
    document.dispatchEvent(new CustomEvent("setram-auth-ready", { detail: user }));
  }

  function injectOverlay() {
    var overlay = document.createElement("div");
    overlay.id = "setram-auth-overlay";
    overlay.innerHTML =
      '<style>' +
      '#setram-auth-overlay{position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;' +
      'background:linear-gradient(135deg,#0a1930 20%,#2f6690 100%);font-family:"Montserrat","Segoe UI",Arial,sans-serif;}' +
      '#setram-auth-overlay .box{background:#ffffff;border-radius:14px;padding:36px 34px 30px;width:340px;max-width:88vw;' +
      'box-shadow:0 24px 60px rgba(0,0,0,.45);}' +
      '#setram-auth-overlay h1{margin:0 0 4px;font-size:17px;color:#0a1930;font-weight:800;line-height:1.3;}' +
      '#setram-auth-overlay p.sub{margin:0 0 22px;font-size:12.5px;color:#44537a;}' +
      '#setram-auth-overlay label{display:block;font-size:11px;font-weight:700;color:#44537a;margin:0 0 6px;text-transform:uppercase;letter-spacing:.4px;}' +
      '#setram-auth-overlay input{width:100%;padding:10px 12px;margin-bottom:16px;border:1px solid #e2e8f4;border-radius:8px;' +
      'font-size:14px;font-family:inherit;box-sizing:border-box;color:#0a1930;}' +
      '#setram-auth-overlay input:focus{outline:none;border-color:#2f6690;}' +
      '#setram-auth-overlay button{width:100%;padding:11px;border:none;border-radius:8px;background:#2f6690;color:#fff;' +
      'font-weight:700;font-size:13.5px;cursor:pointer;font-family:inherit;}' +
      '#setram-auth-overlay button:hover{background:#24537a;}' +
      '#setram-auth-overlay button:disabled{opacity:.6;cursor:default;}' +
      '#setram-auth-overlay .err{color:#c0392b;font-size:12px;margin:-10px 0 14px;min-height:14px;}' +
      '#setram-auth-overlay .forgot{display:block;text-align:center;margin-top:14px;font-size:11.5px;' +
      'color:#2f6690;text-decoration:none;cursor:pointer;background:none;border:none;font-family:inherit;width:100%;}' +
      '#setram-auth-overlay .forgot:hover{text-decoration:underline;}' +
      '#setram-reset-view{display:none;}' +
      '#setram-reset-view .info{font-size:12px;color:#44537a;line-height:1.6;margin:0 0 16px;}' +
      '#setram-reset-view .ok{font-size:12.5px;color:#1e7d46;background:#e9f7ef;border-radius:8px;' +
      'padding:12px 14px;line-height:1.6;margin-bottom:14px;display:none;}' +
      '#setram-reset-view .back{display:block;text-align:center;margin-top:14px;font-size:11.5px;' +
      'color:#44537a;text-decoration:none;cursor:pointer;background:none;border:none;font-family:inherit;width:100%;}' +
      '#setram-reset-view .back:hover{text-decoration:underline;}' +
      '#setram-picker-view{display:none;}' +
      '#setram-picker-list{margin:0 0 14px;}' +
      '.setram-picker-item{display:flex;align-items:center;gap:12px;width:100%;padding:10px 10px;border:1px solid #e2e8f4;' +
      'border-radius:10px;background:#fff;cursor:pointer;margin-bottom:8px;font-family:inherit;text-align:left;transition:background .15s;}' +
      '.setram-picker-item:hover{background:#f3f7fb;}' +
      '.setram-picker-item:disabled{opacity:.55;cursor:default;}' +
      '.setram-picker-avatar{flex:0 0 auto;width:34px;height:34px;border-radius:50%;background:#2f6690;color:#fff;' +
      'display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;}' +
      '.setram-picker-info{flex:1 1 auto;min-width:0;}' +
      '.setram-picker-name{font-size:13.5px;font-weight:700;color:#0a1930;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}' +
      '.setram-picker-user{font-size:11.5px;color:#7c8aa8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}' +
      '.setram-picker-remove{flex:0 0 auto;border:none;background:none;color:#9aa7c2;font-size:16px;line-height:1;' +
      'cursor:pointer;padding:4px 6px;font-family:inherit;}' +
      '.setram-picker-remove:hover{color:#c0392b;}' +
      '#setram-picker-other{display:block;width:100%;text-align:center;margin-top:2px;font-size:12.5px;' +
      'color:#2f6690;background:none;border:1px dashed #c7d3e8;border-radius:8px;padding:10px;cursor:pointer;font-family:inherit;}' +
      '#setram-picker-other:hover{background:#f3f7fb;}' +
      '#setram-picker-err{color:#c0392b;font-size:12px;margin:0 0 12px;min-height:14px;}' +
      '</style>' +
      '<div class="box">' +
      '<div id="setram-picker-view">' +
      '<h1>Plateforme Maintenance — SETRAM</h1>' +
      '<p class="sub">Sélectionnez votre compte pour continuer</p>' +
      '<div class="err" id="setram-picker-err"></div>' +
      '<div id="setram-picker-list"></div>' +
      '<button type="button" id="setram-picker-other">+ Se connecter avec un autre compte</button>' +
      '</div>' +
      '<div id="setram-login-view">' +
      '<h1>Plateforme Maintenance — SETRAM</h1>' +
      '<p class="sub">Connectez-vous pour accéder à l\'application</p>' +
      '<form id="setram-auth-form" autocomplete="on">' +
      '<label>Nom d\'utilisateur</label>' +
      '<input type="text" id="setram-auth-user" name="username" autocomplete="username" required>' +
      '<label>Mot de passe</label>' +
      '<input type="password" id="setram-auth-pass" name="password" autocomplete="current-password" required>' +
      '<div class="err" id="setram-auth-err"></div>' +
      '<button type="submit" id="setram-auth-submit">Se connecter</button>' +
      '</form>' +
      '<button type="button" class="forgot" id="setram-forgot-link">Mot de passe oublié ?</button>' +
      '</div>' +
      '<div id="setram-reset-view">' +
      '<h1>Mot de passe oublié</h1>' +
      '<p class="info" id="setram-reset-info">Entrez votre nom d\'utilisateur et votre nouveau mot de passe. La première fois sur cet appareil, le navigateur vous demandera de localiser comptes.js une seule fois ; ensuite ce sera automatique (fonctionne sur Chrome / Edge).</p>' +
      '<label>Nom d\'utilisateur</label>' +
      '<input type="text" id="setram-reset-user" autocomplete="username" required>' +
      '<label>Nouveau mot de passe</label>' +
      '<input type="password" id="setram-reset-pass1" autocomplete="new-password" required>' +
      '<label>Confirmer le mot de passe</label>' +
      '<input type="password" id="setram-reset-pass2" autocomplete="new-password" required>' +
      '<div class="err" id="setram-reset-err"></div>' +
      '<div class="ok" id="setram-reset-ok">Mot de passe mis à jour dans comptes.js. Vous pouvez vous reconnecter avec votre nouveau mot de passe.</div>' +
      '<button type="button" id="setram-reset-submit">Changer le mot de passe</button>' +
      '<button type="button" class="back" id="setram-reset-back">← Retour à la connexion</button>' +
      '</div>' +
      '</div>';
    document.body.appendChild(overlay);
    document.documentElement.style.visibility = "visible";

    var loginView = overlay.querySelector("#setram-login-view");
    var resetView = overlay.querySelector("#setram-reset-view");
    var pickerView = overlay.querySelector("#setram-picker-view");
    var pickerList = overlay.querySelector("#setram-picker-list");
    var pickerErr = overlay.querySelector("#setram-picker-err");

    // ---------------------------------------------------------------
    // Comptes mémorisés sur cet ordinateur : évite de retaper le mot
    // de passe. Un clic reconnecte directement (le hash mémorisé est
    // revérifié contre comptes.js à chaque fois, pour rester valide
    // si le mot de passe a été changé entre-temps).
    // ---------------------------------------------------------------
    function initials(nom) {
      var parts = (nom || "").trim().split(/\s+/).filter(Boolean);
      if (parts.length === 0) return "?";
      if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
      return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
    }

    function renderPicker() {
      var remembered = getRememberedAccounts();
      pickerList.innerHTML = "";
      pickerErr.textContent = "";

      remembered.forEach(function (r) {
        var item = document.createElement("button");
        item.type = "button";
        item.className = "setram-picker-item";
        item.innerHTML =
          '<span class="setram-picker-avatar">' + initials(r.nom) + '</span>' +
          '<span class="setram-picker-info">' +
          '<span class="setram-picker-name"></span>' +
          '<span class="setram-picker-user"></span>' +
          '</span>' +
          '<span class="setram-picker-remove" title="Oublier ce compte">&times;</span>';
        item.querySelector(".setram-picker-name").textContent = r.nom || r.username;
        item.querySelector(".setram-picker-user").textContent = r.username;

        item.addEventListener("click", function (e) {
          if (e.target.classList.contains("setram-picker-remove")) return;
          pickerErr.textContent = "";
          var acc = accounts().find(function (a) {
            return a.username && a.username.toLowerCase() === r.username.toLowerCase() && a.actif !== false;
          });
          if (!acc || acc.hash !== r.hash) {
            forgetAccount(r.username);
            renderPicker();
            pickerErr.textContent = acc
              ? "Le mot de passe de ce compte a changé. Reconnectez-vous avec le mot de passe actuel."
              : "Ce compte n'existe plus ou a été désactivé.";
            return;
          }
          setSession(acc.username, acc.role, acc.nom, acc.permissions, acc.email);
          overlay.remove();
          finalize({ username: acc.username, email: acc.email || "", role: acc.role || "user", nom: acc.nom || "", telephone: acc.telephone || "", permissions: acc.permissions || [] });
        });

        item.querySelector(".setram-picker-remove").addEventListener("click", function (e) {
          e.stopPropagation();
          forgetAccount(r.username);
          renderPicker();
        });

        pickerList.appendChild(item);
      });
    }

    function showPicker() {
      renderPicker();
      pickerView.style.display = "block";
      loginView.style.display = "none";
      resetView.style.display = "none";
    }

    function showLoginForm() {
      pickerView.style.display = "none";
      loginView.style.display = "block";
    }

    overlay.querySelector("#setram-picker-other").addEventListener("click", showLoginForm);

    var hasRemembered = getRememberedAccounts().length > 0;
    if (hasRemembered) {
      showPicker();
      // Permet de revenir à la liste des comptes depuis le formulaire complet.
      var backToPicker = document.createElement("button");
      backToPicker.type = "button";
      backToPicker.className = "forgot";
      backToPicker.textContent = "← Retour aux comptes enregistrés";
      backToPicker.style.marginTop = "0";
      backToPicker.style.marginBottom = "14px";
      backToPicker.addEventListener("click", showPicker);
      loginView.querySelector("#setram-auth-form").insertAdjacentElement("afterend", backToPicker);
    }

    if (!window.showOpenFilePicker) {
      overlay.querySelector("#setram-reset-info").innerHTML =
        "Cette fonction nécessite Chrome ou Edge (accès direct au fichier). Sur ce navigateur, contactez un administrateur pour réinitialiser votre mot de passe.";
      overlay.querySelector("#setram-reset-submit").disabled = true;
    }

    overlay.querySelector("#setram-forgot-link").addEventListener("click", function () {
      loginView.style.display = "none";
      resetView.style.display = "block";
      overlay.querySelector("#setram-reset-ok").style.display = "none";
      overlay.querySelector("#setram-reset-err").textContent = "";
    });
    overlay.querySelector("#setram-reset-back").addEventListener("click", function () {
      resetView.style.display = "none";
      loginView.style.display = "block";
    });

    var resetBtn = overlay.querySelector("#setram-reset-submit");
    resetBtn.addEventListener("click", async function () {
      var errEl = overlay.querySelector("#setram-reset-err");
      var okEl = overlay.querySelector("#setram-reset-ok");
      errEl.textContent = "";
      okEl.style.display = "none";

      var username = overlay.querySelector("#setram-reset-user").value.trim();
      var p1 = overlay.querySelector("#setram-reset-pass1").value;
      var p2 = overlay.querySelector("#setram-reset-pass2").value;

      if (!username) { errEl.textContent = "Nom d'utilisateur requis."; return; }
      var acc = accounts().find(function (a) { return a.username && a.username.toLowerCase() === username.toLowerCase() && a.actif !== false; });
      if (!acc) { errEl.textContent = "Aucun compte actif trouvé avec ce nom d'utilisateur."; return; }
      if (p1.length < 6) { errEl.textContent = "6 caractères minimum."; return; }
      if (p1 !== p2) { errEl.textContent = "Les deux mots de passe ne correspondent pas."; return; }

      resetBtn.disabled = true;
      resetBtn.textContent = "Écriture en cours…";
      var newHash = await sha256Hex(p1);
      var result = await writeNewPasswordToFile(acc.username, newHash);
      resetBtn.disabled = false;
      resetBtn.textContent = "Changer le mot de passe";

      if (result.ok) {
        okEl.style.display = "block";
        overlay.querySelector("#setram-reset-pass1").value = "";
        overlay.querySelector("#setram-reset-pass2").value = "";
        return;
      }
      if (result.reason === "cancelled") { return; }
      if (result.reason === "wrong_file") { errEl.textContent = "Ce fichier ne semble pas être comptes.js. Sélectionnez le bon fichier."; return; }
      if (result.reason === "permission_denied") { errEl.textContent = "Permission d'écriture refusée."; return; }
      if (result.reason === "not_found") { errEl.textContent = "Compte introuvable dans ce fichier."; return; }
      if (result.reason === "unsupported") { errEl.textContent = "Navigateur non compatible (utilisez Chrome ou Edge)."; return; }
      errEl.textContent = "Erreur d'écriture" + (result.error && result.error.message ? " (" + result.error.message + ")" : "") + ". Réessayez — le fichier vous sera redemandé si besoin.";
    });

    var form = overlay.querySelector("#setram-auth-form");
    var errEl = overlay.querySelector("#setram-auth-err");
    var btn = overlay.querySelector("#setram-auth-submit");

    form.addEventListener("submit", async function (e) {
      e.preventDefault();
      errEl.textContent = "";
      btn.disabled = true;
      var username = overlay.querySelector("#setram-auth-user").value.trim();
      var pass = overlay.querySelector("#setram-auth-pass").value;

      var acc;
      try {
        var resp = await fetch(window.SETRAM_API_URL + "/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username: username, password: pass })
        });
        var data = await resp.json();
        if (!resp.ok || !data.ok) {
          errEl.textContent = "Nom d'utilisateur ou mot de passe incorrect.";
          btn.disabled = false;
          return;
        }
        acc = data.compte; // { id, username, email, nom, telephone, role, actif, permissions }
        if (typeof acc.permissions === "string") {
          try { acc.permissions = JSON.parse(acc.permissions); } catch (e2) { acc.permissions = []; }
        }
      } catch (err) {
        errEl.textContent = "Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.";
        btn.disabled = false;
        return;
      }

      // Propose au navigateur de mémoriser ces identifiants (Chrome/Edge/Firefox
      // affichent alors leur propre bandeau "Enregistrer le mot de passe ?").
      try {
        if (window.PasswordCredential && navigator.credentials && navigator.credentials.store) {
          var cred = new window.PasswordCredential({
            id: acc.username,
            password: pass,
            name: acc.nom || acc.username
          });
          navigator.credentials.store(cred);
        }
      } catch (e) {}

      setSession(acc.username, acc.role, acc.nom, acc.permissions, acc.email);
      overlay.remove();
      finalize({ username: acc.username, email: acc.email || "", role: acc.role || "user", nom: acc.nom || "", telephone: acc.telephone || "", permissions: acc.permissions || [] });
    });
  }

  function init() {
    var s = getSession();
    if (s) {
      touchHistoryEntry(s.hid);
      finalize({ username: s.username, email: s.email || "", role: s.role, nom: s.nom, permissions: s.permissions || [] });
      return;
    }
    injectOverlay();
  }

  // Heartbeat périodique : met à jour "dernière activité" tant que la page reste
  // ouverte sur la même vue (sans rechargement), pour une estimation fiable de
  // la durée même si l'utilisateur ne se déconnecte jamais explicitement.
  // La sync vers le fichier PARTAGÉ n'est faite que toutes les ~5 minutes
  // (pas à chaque minute) pour limiter le risque de collision d'écriture
  // réseau si plusieurs postes sont actifs en même temps.
  var heartbeatTicks = 0;
  setInterval(function () {
    var s = getSession();
    if (!s) return;
    var touched = touchHistoryEntry(s.hid);
    heartbeatTicks++;
    if (heartbeatTicks % 5 === 0) syncEntrySilently(touched);
  }, 60000);
  window.addEventListener("pagehide", function () {
    var s = getSession();
    if (s) {
      var touched = touchHistoryEntry(s.hid);
      syncEntrySilently(touched);
    }
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
