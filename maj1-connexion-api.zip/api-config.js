/* =========================================================
   api-config.js — Adresse du serveur API back-end
   -----------------------------------------------------------
   ⚠️ À modifier si l'adresse de ton serveur change (ex: nouvelle
   URL de Codespace, ou passage à un vrai serveur d'entreprise).
   ========================================================= */
window.SETRAM_API_URL = "https://REMPLACE-MOI.app.github.dev";
