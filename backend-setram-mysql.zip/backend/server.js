// server.js — point d'entrée du back-end SETRAM
require("dotenv").config();
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json({ limit: "5mb" }));

app.use("/api/auth", require("./routes/auth"));
app.use("/api/comptes", require("./routes/comptes"));
app.use("/api/historique", require("./routes/historique"));
app.use("/api/chat", require("./routes/chat"));
app.use("/api/sdf", require("./routes/sdf"));
app.use("/api", require("./routes/periodiques")); // /api/conso-mensuelle, /api/rh-efficience

app.get("/api/health", (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`✅ Serveur SETRAM démarré sur http://localhost:${PORT}`);
});
