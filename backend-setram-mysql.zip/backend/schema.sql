-- =========================================================
-- schema.sql — Plateforme Maintenance SETRAM
-- Schéma MySQL de remplacement pour les fichiers assets/*.js
-- =========================================================

CREATE DATABASE IF NOT EXISTS setram_app
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE setram_app;

-- ---------------------------------------------------------
-- Comptes utilisateurs (remplace assets/comptes.js)
-- ---------------------------------------------------------
CREATE TABLE comptes (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(100) NOT NULL UNIQUE,
  email         VARCHAR(190) NOT NULL UNIQUE,
  nom           VARCHAR(150) NOT NULL,
  telephone     VARCHAR(30)  DEFAULT '',
  role          VARCHAR(30)  NOT NULL DEFAULT 'user',
  password_hash VARCHAR(255) NOT NULL,
  actif         BOOLEAN NOT NULL DEFAULT TRUE,
  permissions   JSON NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------
-- Historique des connexions (remplace assets/historique-connexions.js)
-- ---------------------------------------------------------
CREATE TABLE historique_connexions (
  id             VARCHAR(64) PRIMARY KEY,
  username       VARCHAR(100) NOT NULL,
  nom            VARCHAR(150),
  role           VARCHAR(30),
  login_at       BIGINT NOT NULL,
  last_seen_at   BIGINT,
  logout_at      BIGINT,
  logout_reason  VARCHAR(50),
  INDEX idx_username (username)
);

-- ---------------------------------------------------------
-- Chat d'équipe (remplace assets/chat-messages.js)
-- ---------------------------------------------------------
CREATE TABLE chat_messages (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  username          VARCHAR(100) NOT NULL,
  nom               VARCHAR(150),
  message_date      DATETIME(3) NOT NULL,
  message           TEXT,
  attachment_name       VARCHAR(255),
  attachment_stored_name VARCHAR(255),
  attachment_size   BIGINT,
  attachment_mime   VARCHAR(150),
  created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_date (message_date)
);

-- ---------------------------------------------------------
-- Suivi des requêtes SDF (remplace assets/sdf-requetes-data.js)
-- ---------------------------------------------------------
CREATE TABLE sdf_requetes (
  id          VARCHAR(64) PRIMARY KEY,
  data        JSON NOT NULL,        -- structure encore variable -> stockée en JSON pour l'instant
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE sdf_requetes_historique (
  id          VARCHAR(64) PRIMARY KEY,
  data        JSON NOT NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------
-- Plan d'action SDF (remplace assets/sdf-plan-action-data.js)
-- ---------------------------------------------------------
CREATE TABLE sdf_plan_action (
  id          VARCHAR(64) PRIMARY KEY,
  data        JSON NOT NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE sdf_historique (
  id          VARCHAR(64) PRIMARY KEY,
  data        JSON NOT NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------
-- Consommations mensuelles (remplace assets/conso-mensuelle.js)
-- Structure d'origine = objet libre {annee: {mois: {...}}}, donc JSON
-- ---------------------------------------------------------
CREATE TABLE conso_mensuelle (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  annee       INT NOT NULL,
  mois        INT NOT NULL,
  data        JSON NOT NULL,
  UNIQUE KEY uniq_periode (annee, mois)
);

-- ---------------------------------------------------------
-- Efficience RH (remplace assets/rh-efficience.js)
-- ---------------------------------------------------------
CREATE TABLE rh_efficience (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  annee       INT NOT NULL,
  mois        INT NOT NULL,
  data        JSON NOT NULL,
  UNIQUE KEY uniq_periode_rh (annee, mois)
);
