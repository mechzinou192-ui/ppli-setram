// routes/sdf.js — remplace sdf-requetes-data.js et sdf-plan-action-data.js
// Les enregistrements sont stockés en colonne JSON car leur structure interne
// est encore amenée à évoluer. Une fois la structure stabilisée, ces tables
// pourront être remplacées par de vraies colonnes typées si besoin.
const express = require("express");
const pool = require("../db");

const router = express.Router();

function makeCrud(table) {
  const r = express.Router();

  r.get("/", async (req, res) => {
    const [rows] = await pool.query(`SELECT id, data FROM ${table}`);
    res.json(rows.map((row) => ({ id: row.id, ...row.data })));
  });

  r.post("/", async (req, res) => {
    const { id, ...data } = req.body;
    if (!id) return res.status(400).json({ error: "id requis" });
    await pool.query(
      `INSERT INTO ${table} (id, data) VALUES (?, ?)
       ON DUPLICATE KEY UPDATE data = VALUES(data)`,
      [id, JSON.stringify(data)]
    );
    res.status(201).json({ ok: true });
  });

  r.delete("/:id", async (req, res) => {
    await pool.query(`DELETE FROM ${table} WHERE id = ?`, [req.params.id]);
    res.json({ ok: true });
  });

  return r;
}

router.use("/requetes", makeCrud("sdf_requetes"));
router.use("/requetes-historique", makeCrud("sdf_requetes_historique"));
router.use("/plan-action", makeCrud("sdf_plan_action"));
router.use("/historique", makeCrud("sdf_historique"));

module.exports = router;
