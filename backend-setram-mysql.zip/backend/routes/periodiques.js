// routes/periodiques.js — remplace conso-mensuelle.js et rh-efficience.js
// Ces deux fichiers stockaient un objet { annee: { mois: {...} } } ;
// on garde une ligne par (annee, mois) avec les données en JSON.
const express = require("express");
const pool = require("../db");

const router = express.Router();

function makeCrud(table) {
  const r = express.Router();

  r.get("/", async (req, res) => {
    const [rows] = await pool.query(`SELECT annee, mois, data FROM ${table}`);
    res.json(rows);
  });

  r.put("/:annee/:mois", async (req, res) => {
    const { annee, mois } = req.params;
    await pool.query(
      `INSERT INTO ${table} (annee, mois, data) VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE data = VALUES(data)`,
      [annee, mois, JSON.stringify(req.body)]
    );
    res.json({ ok: true });
  });

  return r;
}

router.use("/conso-mensuelle", makeCrud("conso_mensuelle"));
router.use("/rh-efficience", makeCrud("rh_efficience"));

module.exports = router;
