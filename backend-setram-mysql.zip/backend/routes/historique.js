// routes/historique.js — remplace assets/historique-connexions.js
const express = require("express");
const pool = require("../db");

const router = express.Router();

// GET /api/historique — dernières connexions (les plus récentes d'abord)
router.get("/", async (req, res) => {
  const [rows] = await pool.query(
    "SELECT * FROM historique_connexions ORDER BY login_at DESC LIMIT 300"
  );
  res.json(rows);
});

// POST /api/historique — ouvrir une nouvelle entrée (login)
router.post("/", async (req, res) => {
  const { id, username, nom, role, loginAt } = req.body;
  await pool.query(
    `INSERT INTO historique_connexions (id, username, nom, role, login_at, last_seen_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [id, username, nom, role, loginAt, loginAt]
  );
  res.status(201).json({ ok: true });
});

// PUT /api/historique/:id — mettre à jour last_seen_at ou fermer (logout)
router.put("/:id", async (req, res) => {
  const { lastSeenAt, logoutAt, logoutReason } = req.body;
  const fields = [];
  const values = [];
  if (lastSeenAt !== undefined) { fields.push("last_seen_at = ?"); values.push(lastSeenAt); }
  if (logoutAt !== undefined) { fields.push("logout_at = ?"); values.push(logoutAt); }
  if (logoutReason !== undefined) { fields.push("logout_reason = ?"); values.push(logoutReason); }
  if (fields.length === 0) return res.status(400).json({ error: "Rien à modifier" });

  values.push(req.params.id);
  await pool.query(`UPDATE historique_connexions SET ${fields.join(", ")} WHERE id = ?`, values);
  res.json({ ok: true });
});

module.exports = router;
