// routes/auth.js — vérifie email + mot de passe contre la table `comptes`
const express = require("express");
const crypto = require("crypto");
const pool = require("../db");

const router = express.Router();

function sha256Hex(str) {
  return crypto.createHash("sha256").update(str, "utf8").digest("hex");
}

// POST /api/auth/login  { email, password }
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: "email et password requis" });
    }

    const [rows] = await pool.query(
      "SELECT * FROM comptes WHERE email = ? AND actif = TRUE LIMIT 1",
      [email]
    );

    if (rows.length === 0) {
      return res.status(401).json({ error: "Identifiants invalides" });
    }

    const compte = rows[0];
    const hash = sha256Hex(password);

    if (hash !== compte.password_hash) {
      return res.status(401).json({ error: "Identifiants invalides" });
    }

    // Ne jamais renvoyer le hash au client
    delete compte.password_hash;

    res.json({ ok: true, compte });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erreur serveur" });
  }
});

module.exports = router;
