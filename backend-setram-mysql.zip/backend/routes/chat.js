// routes/chat.js — remplace assets/chat-messages.js
const express = require("express");
const pool = require("../db");

const router = express.Router();

// GET /api/chat — les 200 derniers messages, dans l'ordre chronologique
router.get("/", async (req, res) => {
  const [rows] = await pool.query(
    `SELECT * FROM (
       SELECT * FROM chat_messages ORDER BY message_date DESC LIMIT 200
     ) t ORDER BY message_date ASC`
  );
  res.json(rows);
});

// POST /api/chat — envoyer un message
router.post("/", async (req, res) => {
  const { username, nom, message, attachment } = req.body;
  const [result] = await pool.query(
    `INSERT INTO chat_messages (username, nom, message_date, message, attachment_name, attachment_stored_name, attachment_size, attachment_mime)
     VALUES (?, ?, NOW(3), ?, ?, ?, ?, ?)`,
    [
      username,
      nom,
      message || "",
      attachment ? attachment.name : null,
      attachment ? attachment.storedName : null,
      attachment ? attachment.size : null,
      attachment ? attachment.mime : null,
    ]
  );
  res.status(201).json({ id: result.insertId });
});

module.exports = router;
