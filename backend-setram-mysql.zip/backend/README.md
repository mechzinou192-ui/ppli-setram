# Backend SETRAM — MySQL + Node.js

Ce dossier remplace les fichiers `assets/comptes.js`, `historique-connexions.js`,
`chat-messages.js`, `sdf-requetes-data.js`, `sdf-plan-action-data.js` par une
vraie base MySQL, servie par une API Node.js/Express.

## 1. Installer MySQL

Si tu n'as pas encore MySQL sur ton PC, le plus simple pour débuter est
**XAMPP** (https://www.apachefriends.org) qui installe MySQL + phpMyAdmin
(interface graphique) en une fois. Alternative : MySQL Community Server +
MySQL Workbench.

## 2. Créer la base de données

Ouvre phpMyAdmin (ou MySQL Workbench, ou le client `mysql` en ligne de
commande) et exécute le contenu du fichier `schema.sql` de ce dossier.
Cela crée la base `setram_app` avec toutes les tables nécessaires.

```bash
mysql -u root -p < schema.sql
```

## 3. Installer les dépendances Node.js

Depuis ce dossier `backend/` :

```bash
npm install
```

## 4. Configurer la connexion

```bash
cp .env.example .env
```

Puis ouvre `.env` et renseigne ton utilisateur / mot de passe MySQL
(par défaut avec XAMPP : utilisateur `root`, mot de passe vide).

## 5. Importer tes données existantes

Ce script lit tes fichiers `assets/*.js` actuels et les copie dans MySQL :

```bash
npm run migrate
```

## 6. Démarrer le serveur

```bash
npm start
```

Le serveur écoute sur `http://localhost:3001`. Teste avec :

```
http://localhost:3001/api/health
```

Tu dois voir `{"ok":true}`.

## Et le front-end (tes fichiers .html) ?

C'est l'étape suivante : il faudra remplacer, dans chaque page HTML, les
`<script src="assets/comptes.js">` etc. par des appels `fetch()` vers ces
routes (`/api/comptes`, `/api/historique`, `/api/chat`, `/api/sdf/...`,
`/api/conso-mensuelle`, `/api/rh-efficience`). Je peux le faire avec toi
fichier par fichier dès que le serveur tourne correctement.

## ⚠️ Point sécurité à corriger ensuite

Les mots de passe sont actuellement hashés en SHA-256 simple (hérité de
l'ancien système), ce qui est rapide à casser par force brute si la base
fuit un jour. Une fois la migration terminée et stable, on pourra basculer
vers **bcrypt**, bien plus sûr pour des mots de passe — je peux t'aider à
faire cette transition en douceur (les comptes se remettront à jour à la
prochaine connexion de chacun, sans réinitialiser tout le monde d'un coup).
