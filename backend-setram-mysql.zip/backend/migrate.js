// migrate.js — importe les données des fichiers assets/*.js vers MySQL
// Usage : node migrate.js   (depuis le dossier backend/)
//
// Principe : chaque fichier JS fait "window.NOM = [...]" ou "= {...}".
// On charge le fichier dans un mini bac-à-sable (vm) pour en extraire
// la valeur JS, sans avoir besoin d'un vrai navigateur.

require("dotenv").config();
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const pool = require("./db");

// Adapte ce chemin si ton dossier "assets" n'est pas à cet endroit
const ASSETS_DIR = path.join(__dirname, "..", "assets");

function loadWindowVar(filename, varName) {
  const filePath = path.join(ASSETS_DIR, filename);
  if (!fs.existsSync(filePath)) {
    console.warn(`⚠️  Fichier introuvable, ignoré : ${filePath}`);
    return undefined;
  }
  const code = fs.readFileSync(filePath, "utf8");
  const sandbox = { window: {} };
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox);
  return sandbox.window[varName];
}

async function migrateComptes() {
  const comptes = loadWindowVar("comptes.js", "SETRAM_COMPTES") || [];
  console.log(`→ ${comptes.length} comptes trouvés`);
  for (const c of comptes) {
    await pool.query(
      `INSERT INTO comptes (username, email, nom, telephone, role, password_hash, actif, permissions)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
         nom = VALUES(nom), telephone = VALUES(telephone), role = VALUES(role),
         password_hash = VALUES(password_hash), actif = VALUES(actif), permissions = VALUES(permissions)`,
      [
        c.username,
        c.email,
        c.nom,
        c.telephone || "",
        c.role || "user",
        c.hash,
        c.actif !== false,
        JSON.stringify(c.permissions || []),
      ]
    );
  }
}

async function migrateHistorique() {
  const list = loadWindowVar("historique-connexions.js", "SETRAM_HISTORIQUE") || [];
  console.log(`→ ${list.length} entrées d'historique de connexion trouvées`);
  for (const h of list) {
    await pool.query(
      `INSERT INTO historique_connexions (id, username, nom, role, login_at, last_seen_at, logout_at, logout_reason)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE last_seen_at = VALUES(last_seen_at), logout_at = VALUES(logout_at), logout_reason = VALUES(logout_reason)`,
      [h.id, h.username, h.nom, h.role, h.loginAt, h.lastSeenAt, h.logoutAt, h.logoutReason]
    );
  }
}

async function migrateChat() {
  const list = loadWindowVar("chat-messages.js", "SETRAM_CHAT") || [];
  console.log(`→ ${list.length} messages de chat trouvés`);
  for (const m of list) {
    const a = m.attachment || {};
    await pool.query(
      `INSERT INTO chat_messages (username, nom, message_date, message, attachment_name, attachment_stored_name, attachment_size, attachment_mime)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [m.username, m.nom, new Date(m.date), m.message || "", a.name || null, a.storedName || null, a.size || null, a.mime || null]
    );
  }
}

async function migrateJsonList(filename, varName, table) {
  const list = loadWindowVar(filename, varName) || [];
  console.log(`→ ${list.length} enregistrements trouvés dans ${filename} (${varName})`);
  for (const item of list) {
    const id = item.id || `${varName}_${Math.random().toString(36).slice(2, 10)}`;
    const { id: _drop, ...rest } = item;
    await pool.query(
      `INSERT INTO ${table} (id, data) VALUES (?, ?) ON DUPLICATE KEY UPDATE data = VALUES(data)`,
      [id, JSON.stringify(rest)]
    );
  }
}

async function main() {
  console.log("=== Migration des données SETRAM vers MySQL ===");
  await migrateComptes();
  await migrateHistorique();
  await migrateChat();
  await migrateJsonList("sdf-requetes-data.js", "SETRAM_SDF_REQUETES", "sdf_requetes");
  await migrateJsonList("sdf-requetes-data.js", "SETRAM_SDF_REQUETES_HISTORIQUE", "sdf_requetes_historique");
  await migrateJsonList("sdf-plan-action-data.js", "SETRAM_SDF_DATA", "sdf_plan_action");
  await migrateJsonList("sdf-plan-action-data.js", "SETRAM_SDF_HISTORIQUE", "sdf_historique");
  console.log("✅ Migration terminée.");
  process.exit(0);
}

main().catch((err) => {
  console.error("❌ Erreur pendant la migration :", err);
  process.exit(1);
});
