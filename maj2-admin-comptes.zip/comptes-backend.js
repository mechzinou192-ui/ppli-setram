// routes/comptes.js — CRUD des comptes utilisateurs (remplace admin.html <-> comptes.js)
const express = require("express");
const crypto = require("crypto");
const pool = require("../db");

const router = express.Router();

function sha256Hex(str) {
  return crypto.createHash("sha256").update(str, "utf8").digest("hex");
}

// GET /api/comptes — liste tous les comptes (sans les hash)
router.get("/", async (req, res) => {
  const [rows] = await pool.query(
    "SELECT id, username, email, nom, telephone, role, actif, permissions, created_at FROM comptes ORDER BY nom"
  );
  res.json(rows);
});

// POST /api/comptes — créer un compte
router.post("/", async (req, res) => {
  try {
    const { username, email, nom, telephone, role, password, permissions } = req.body;
    if (!username || !email || !nom || !password) {
      return res.status(400).json({ error: "Champs requis manquants" });
    }
    const hash = sha256Hex(password);
    const [result] = await pool.query(
      `INSERT INTO comptes (username, email, nom, telephone, role, password_hash, permissions)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [username, email, nom, telephone || "", role || "user", hash, JSON.stringify(permissions || [])]
    );
    res.status(201).json({ id: result.insertId });
  } catch (err) {
    console.error(err);
    if (err.code === "ER_DUP_ENTRY") {
      return res.status(400).json({ error: "Ce nom d'utilisateur ou cet email est déjà utilisé." });
    }
    res.status(500).json({ error: "Erreur serveur" });
  }
});

// PUT /api/comptes/:id — modifier un compte (mot de passe optionnel)
router.put("/:id", async (req, res) => {
  try {
    const { username, email, nom, telephone, role, actif, permissions, password } = req.body;
    const fields = [];
    const values = [];

    if (username !== undefined) { fields.push("username = ?"); values.push(username); }
    if (email !== undefined) { fields.push("email = ?"); values.push(email); }
    if (nom !== undefined) { fields.push("nom = ?"); values.push(nom); }
    if (telephone !== undefined) { fields.push("telephone = ?"); values.push(telephone); }
    if (role !== undefined) { fields.push("role = ?"); values.push(role); }
    if (actif !== undefined) { fields.push("actif = ?"); values.push(actif); }
    if (permissions !== undefined) { fields.push("permissions = ?"); values.push(JSON.stringify(permissions)); }
    if (password) { fields.push("password_hash = ?"); values.push(sha256Hex(password)); }

    if (fields.length === 0) return res.status(400).json({ error: "Rien à modifier" });

    values.push(req.params.id);
    await pool.query(`UPDATE comptes SET ${fields.join(", ")} WHERE id = ?`, values);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    if (err.code === "ER_DUP_ENTRY") {
      return res.status(400).json({ error: "Ce nom d'utilisateur ou cet email est déjà utilisé." });
    }
    res.status(500).json({ error: "Erreur serveur" });
  }
});

// DELETE /api/comptes/:id
router.delete("/:id", async (req, res) => {
  await pool.query("DELETE FROM comptes WHERE id = ?", [req.params.id]);
  res.json({ ok: true });
});

module.exports = router;
