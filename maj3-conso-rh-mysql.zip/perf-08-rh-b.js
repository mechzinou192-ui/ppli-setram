// =============================================================================
// SUIVI DES PERFORMANCES — module 08/10 : perf-08-rh-b.js
// Extrait mecaniquement (meme code, meme ordre) du script principal historique
// pour ameliorer la maintenabilite (le fichier faisait ~8300 lignes en un bloc).
// Contenu : Efficience RH (suite) : resultats detailles par unite / systeme / technicien
// IMPORTANT : ce fichier partage la portee globale avec les autres modules
// perf-XX-*.js et doit rester charge dans l'ORDRE (01 -> 10), car certaines
// fonctions utilisent des constantes/fonctions definies dans les modules precedents.
// =============================================================================
function handleRHFileUnit(file, type, unit) {
  showLoading();
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const wb  = XLSX.read(e.target.result, { type:'binary', cellDates:false });
      const ws  = wb.Sheets[wb.SheetNames[0]];
      const raw = XLSX.utils.sheet_to_json(ws, { raw:false, defval:'', dateNF:'DD/MM/YYYY' });
      if (raw.length === 0) { showToast(`⚠️ ${file.name} vide`, 'error'); hideLoading(); return; }
      const cleaned = raw.map(row => {
        const nr = {}; Object.keys(row).forEach(k => { const ck = k.trim().replace(/\s+/g,' ').normalize('NFC'); nr[ck] = typeof row[k]==='string' ? row[k].trim() : row[k]; });
        nr.__UNIT__ = unit; return nr;
      });
      if (type === 'corr') { RH_DB.corrRows[unit] = cleaned; RH_DB.loadedCorr[unit] = file.name; }
      else                 { RH_DB.prevRows[unit] = cleaned; RH_DB.loadedPrev[unit] = file.name; }
      updateRHCardStatus(unit);
      const badge = document.getElementById('badge-rh'); if (badge) badge.style.display = '';
      updateRHDiag();
      showToast(`✅ RH ${unit} ${type==='corr'?'Correctif':'Preventif'} — ${cleaned.length} lignes`, 'success');
    } catch (err) { console.error(err); showToast(`❌ Erreur : ${err.message}`, 'error'); }
    hideLoading();
  };
  reader.readAsBinaryString(file);
}

document.addEventListener('DOMContentLoaded', () => {
  buildRHUnitCards();
  const navRH = document.querySelector('.nav-item[data-page="rh-import"]');
  if (navRH) navRH.addEventListener('click', () => navigateTo('rh-import'));

  // Écouteurs filtres RH
  ['rh-date-start','rh-date-end','rh-sel-unit','rh-norme'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', () => {
      const loaded = UNITS.some(u =>
        (RH_DB.corrRows[u]||[]).length + (RH_DB.prevRows[u]||[]).length > 0
      );
      const onRHPage = document.getElementById('page-rh-import')?.classList.contains('active');
      if (loaded && onRHPage) {
        renderRHPage();
      }
      // Le graphique Charge RAM / Taux Efficience depend uniquement des saisies
      // manuelles (rh-efficience.js), pas des fichiers GMAO : on le rafraichit
      // toujours quand un filtre du haut change, meme sans donnees GMAO chargees.
      if (onRHPage) rhEffRenderChart();
    });
  });
});

const _origNavigateTo = navigateTo;
navigateTo = function(page, extra) {

  if (page === 'rh-import') {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    const pageEl = document.getElementById('page-rh-import'); if (pageEl) pageEl.classList.add('active');
    const navEl  = document.querySelector('.nav-item[data-page="rh-import"]'); if (navEl) navEl.classList.add('active');
    document.getElementById('page-title').textContent = 'Efficience RH';
    document.body.classList.remove('import-page');
    // ← MASQUER topbar entier + card unites (via classe CSS forcée)
    document.body.classList.add('rh-page');
    const topbar = document.getElementById('topbar');
    if (topbar) topbar.style.display = 'none';
    const uCard = document.querySelector('.card[style*="margin: 16px 32px"]');
    if (uCard) uCard.style.display = 'none';
    const loaded = UNITS.some(u =>
      (RH_DB.corrRows[u]||[]).length + (RH_DB.prevRows[u]||[]).length > 0
    );
    if (loaded) renderRHPage();
    rhEffInitUI();
    rhEffRenderChart();
    return;
  }



  // Toutes les autres pages → RÉAFFICHER topbar + card unites
  document.body.classList.remove('rh-page');
  document.body.classList.remove('import-page');
  const topbar = document.getElementById('topbar');
if (topbar) {
  topbar.style.display = '';
  topbar.querySelector('.filter-card')?.classList.remove('filter-card-hidden');
}
  const uCard = document.querySelector('.card[style*="margin: 16px 32px"]');
  if (uCard) uCard.style.display = '';

  _origNavigateTo(page, extra);

};

// =====================================================================
// HELPERS LECTURE DONNEES RH
// =====================================================================
function rhGetTech(row) {
const candidates = ['Nom_Intervenant','NOM_INTERVENANT','nom_intervenant','Nom Intervenant','NOM INTERVENANT','TECHNICIEN','Technicien','NOM_TECHNICIEN','NOM TECHNICIEN','nom_technicien','Nom Technicien','AGENT','Agent','NOM AGENT','NOM_AGENT','OPERATEUR','Operateur','EXECUTANT','Executant','EXECUTE PAR','REALISE PAR'];  for (const c of candidates) { if (row[c] && String(row[c]).trim() !== '') return String(row[c]).trim(); }
  for (const k of Object.keys(row)) { if (/tech|agent|nom|operat|execut|realise/i.test(k) && row[k]) return String(row[k]).trim(); }
  return 'Inconnu';
}

function rhGetUnit(row) {
  if (row.__UNIT__) return row.__UNIT__;
  const candidates = ['UNITE','Unite','UNITE','unite','UNIT','SITE','Site','AGENCE','Agence','CENTRE','Centre','ANTENNE','Antenne'];
  for (const c of candidates) { if (row[c] && String(row[c]).trim() !== '') return String(row[c]).trim().toUpperCase(); }
  for (const k of Object.keys(row)) { if (/unite|unite|site|centre|agence|antenne/i.test(k) && row[k]) return String(row[k]).trim().toUpperCase(); }
  return 'INCONNUE';
}

function rhParseHours(row) {
  let totalMins = 0;
const dureeFields = ['Durée Intervention (Min)','Durée Intervention (Min)','Durée Intervention_(Min)','Durée Intervention_(Min)','DUREE_INTERVENTION','Durée Intervention(Min)','Durée Intervention (min)','duree_intervention','DUREE INTERVENTION','Durée Interv (Min)','Durée Interv. (Min)','Tps Intervention (Min)','DUREE INTERV (MIN)','Durée intervention (Min)'];
const logFields   = ['Temps Logistique (Min)','Temps Logistique_(Min)','Temps Logistique(Min)','TEMPS_LOGISTIQUE','Temps Logistique (min)','temps_logistique','TEMPS LOGISTIQUE','Tps Logistique (Min)','Tps Log (Min)','Logistique (Min)','TEMPS LOG (MIN)','Temps logistique (Min)'];  
  for (const f of dureeFields) { if (row[f] !== undefined && row[f] !== '') { const v = parseFloat(String(row[f]).replace(',','.')); if (!isNaN(v) && v >= 0) { totalMins += v; break; } } }
  for (const f of logFields)   { if (row[f] !== undefined && row[f] !== '') { const v = parseFloat(String(row[f]).replace(',','.')); if (!isNaN(v) && v >= 0) { totalMins += v; break; } } }
  if (totalMins === 0) { for (const k of Object.keys(row)) { if (/min/i.test(k) && !/date|code|titre|etat|nom/i.test(k)) { const v = parseFloat(String(row[k]).replace(',','.')); if (!isNaN(v) && v > 0) totalMins += v; } } }
  return totalMins / 60;
}


// ══════════════════════════════════════════════════════════════════════
// CHARGE RAM (saisie manuelle mensuelle, par unite) + TAUX EFFICIENCE
// Charge RAM = charge declaree dans le Rapport d'Activite Mensuel (RAM).
// Taux Efficience = Charge Totale (calculee GMAO) / Charge RAM (declaree)
// Donnees PARTAGEES entre tous les utilisateurs via assets/rh-efficience.js
// (meme mecanisme que comptes.js / conso-mensuelle.js — voir admin.html)
// Structure : window.SETRAM_RH_EFFICIENCE[unit][monthKey] =
//   { chargeRAM: number|null, chargeTotale: number|null, updatedAt: iso }
// ══════════════════════════════════════════════════════════════════════

function rhMonthKey(date) {
  const d = (date instanceof Date) ? date : new Date(date);
  if (!d || isNaN(d.getTime())) return 'inconnu';
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
}
function rhEffMonthLabel(ym) {
  if (!ym || ym === 'inconnu') return ym || '';
  const [y, m] = ym.split('-');
  const noms = ['Janv','Fevr','Mars','Avr','Mai','Juin','Juil','Aout','Sept','Oct','Nov','Dec'];
  const idx = parseInt(m, 10) - 1;
  return `${noms[idx] || m} ${y}`;
}

function rhEffLoadData() {
  if (!window.SETRAM_RH_EFFICIENCE || typeof window.SETRAM_RH_EFFICIENCE !== 'object') {
    window.SETRAM_RH_EFFICIENCE = {};
  }
  return window.SETRAM_RH_EFFICIENCE;
}
async function rhEffFetchAll() {
  try {
    const resp = await fetch(window.SETRAM_API_URL + '/api/rh-efficience');
    window.SETRAM_RH_EFFICIENCE = await resp.json();
    return true;
  } catch (e) {
    window.SETRAM_RH_EFFICIENCE = window.SETRAM_RH_EFFICIENCE || {};
    return false;
  }
}
// Chargement automatique depuis la base MySQL, une fois au chargement du script.
// Si la page Efficience RH est déjà affichée quand les données arrivent, on la
// redessine ; sinon rhEffInitUI() re-fetchera de toute façon à l'ouverture de la page.
var rhEffDataReady = false;
rhEffFetchAll().then(function(){
  rhEffDataReady = true;
  try {
    if (document.getElementById('page-rh-import')?.classList.contains('active')) {
      if (typeof renderRHPage === 'function') renderRHPage();
      if (typeof rhEffRenderChart === 'function') rhEffRenderChart();
    }
  } catch (e) {}
});
function rhEffEntry(unit, monthKey) {
  const data = rhEffLoadData();
  return (data[unit] && data[unit][monthKey]) || null;
}
function rhGetChargeRAM(unit, monthKey) {
  const e = rhEffEntry(unit, monthKey);
  return (e && e.chargeRAM !== undefined && e.chargeRAM !== null) ? e.chargeRAM : null;
}
// Enregistre en memoire (session courante) la Charge Totale calculee pour ce mois,
// pour alimenter l'historique/graphique sans avoir a republier le fichier a chaque affichage.
function rhEffSnapshotChargeTotale(unit, monthKey, chargeTotale) {
  if (!unit || monthKey === 'inconnu') return;
  const data = rhEffLoadData();
  if (!data[unit]) data[unit] = {};
  if (!data[unit][monthKey]) data[unit][monthKey] = { chargeRAM:null, chargeTotale:null, updatedAt:null };
  data[unit][monthKey].chargeTotale = chargeTotale;
}

// Extrait la date d'une ligne GMAO (meme logique que rhFilterByDate) afin de pouvoir
// regrouper les heures par mois calendaire reel, quelle que soit la largeur de la
// periode Debut→Fin selectionnee dans les filtres du haut.
function rhGetRowDate(row) {
  const DATE_CANDIDATES = [
    'DATE_CREATION','date_creation','Date_Creation',
    'DATE_DI','DATE_PREVUE','DATE_DEB_INTERVENTION',
    'DATE_EVENEMENT','DATE_CLOTURE','Date','DATE',
    'DATE_DEBUT_PREVU','DATE_DEBUT_PREVUE'
  ];
  for (const f of DATE_CANDIDATES) {
    const v = row[f];
    if (v && String(v).trim() !== '') {
      const d = parseDate(v);
      if (d) return d;
    }
  }
  return null;
}

// Calcule et enregistre la Charge Totale GMAO reelle mois calendaire par mois calendaire,
// pour l'unite donnee. IMPORTANT : contrairement a calcRHEfficienceUnit() qui cumule TOUTES
// les heures de la periode Debut→Fin selectionnee (ex: Juin→Aout) en un seul total, cette
// fonction repartit ce total sur chaque mois reel des interventions (Juin, Juillet, Aout
// separement) — sinon, en filtrant sur plusieurs mois, tout le cumul se retrouvait attribue
// au seul mois de debut (Juin), ce qui faussait le graphique et l'export.
function rhEffSnapshotMonthlyChargeTotale(unit) {
  const { start, end, systeme } = getRHFilters();
  let corrRows = rhFilterByDate(RH_DB.corrRows[unit]||[], start, end);
  let prevRows = rhFilterByDate(RH_DB.prevRows[unit]||[], start, end);

  if (systeme && systeme !== 'all') {
    const sysFilter = r => {
      const parsed = parseCodeEquipement(r['CODE_EQUIPEMENT']||r['EQUIPEMENT']||'');
      return parsed.systeme === systeme || parsed.sousSysteme === systeme ||
             (r['SYSTEME']||'').trim() === systeme;
    };
    corrRows = corrRows.filter(sysFilter);
    prevRows = prevRows.filter(sysFilter);
  }

  const monthTotals = {};
  [...corrRows, ...prevRows].forEach(row => {
    const d = rhGetRowDate(row);
    if (!d) return;
    const mk = rhMonthKey(d);
    monthTotals[mk] = (monthTotals[mk] || 0) + rhParseHours(row);
  });

  Object.entries(monthTotals).forEach(([mk, total]) => {
    rhEffSnapshotChargeTotale(unit, mk, +total.toFixed(2));
  });

  return monthTotals;
}
window.rhEffSnapshotMonthlyChargeTotale = rhEffSnapshotMonthlyChargeTotale;


function rhTauxEfficience(chargeTotale, chargeRAM) {
  if (chargeRAM === null || chargeRAM === undefined || chargeRAM <= 0) return null;
  if (chargeTotale === null || chargeTotale === undefined) return null;
  return chargeTotale / chargeRAM;
}

function rhTauxEfficienceBadge(taux) {
  if (taux === null) return { cls:'badge-yellow', lbl:'— Charge RAM non saisie' };
  const pct = (taux*100).toFixed(1);
  if (taux > 1.05) return { cls:'badge-red',    lbl:`⚠️ ${pct}%` };
  if (taux < 0.85) return { cls:'badge-yellow', lbl:`↘ ${pct}%` };
  return { cls:'badge-green', lbl:`✅ ${pct}%` };
}

// Carte KPI editable pour saisir la Charge RAM (vue detail par unite)
// Le champ reste toujours vide (la valeur enregistree n'est pas ré-affichée) :
// la saisie est enregistree directement dans la base JS partagee au clic sur 💾.
function rhKpiCardRAM(unit, monthKey, value, mode) {
  const savedHint = (value !== null && value !== undefined) ? `Saisir (deja enregistre : ${value}h)` : 'Saisir (h)';
  const inputId = `rh-ram-input-${mode}-${unit}-${monthKey}`;
  return `<div class="kpi-card c9">
    <div class="kpi-label">📝 Chrge RAM</div>
    <div style="display:flex;align-items:center;gap:6px;margin:4px 0 6px">
      <input type="number" step="0.1" min="0" value="" placeholder="${savedHint}"
        id="${inputId}"
        title="Charge declaree dans le Rapport d'Activite Mensuel"
        style="flex:1 1 auto;min-width:0;border:1.5px solid #dde6f5;border-radius:8px;background:#f8faff;
               font-family:'Montserrat',sans-serif;font-size:20px;font-weight:800;color:#0a1930;
               outline:none;padding:4px 8px;box-sizing:border-box"
        onkeydown="if(event.key==='Enter'){event.preventDefault();rhSaveChargeRAMFromInput('${unit}','${monthKey}','${mode}');}">
      <button type="button" class="rh-ram-save-btn" id="${inputId}-btn"
        title="Enregistrer la Charge RAM"
        onclick="rhSaveChargeRAMFromInput('${unit}','${monthKey}','${mode}')"
        style="flex:0 0 auto;border:1.5px solid #dde6f5;border-radius:8px;background:#eef3ff;
               font-size:17px;line-height:1;padding:7px 9px;cursor:pointer">💾</button>
    </div>
    <div class="kpi-sub">rapport RAM · ${unit} · ${rhEffMonthLabel(monthKey)}</div>
  </div>`;
}

// ── Donnees chargees depuis MySQL via l'API (voir backend/routes/periodiques.js) ──
function rhEffSetHint(msg, kind) {
  const el = document.getElementById('rh-eff-conn-hint');
  if (el) { el.textContent = msg; el.className = 'conso-conn-hint' + (kind ? ' ' + kind : ''); }
}
async function rhEffPublishEntry(unit, monthKey) {
  const [annee, mois] = monthKey.split('-');
  const entry = rhEffLoadData()[unit][monthKey];
  try {
    await fetch(window.SETRAM_API_URL + '/api/rh-efficience/' + unit + '/' + annee + '/' + parseInt(mois, 10), {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(entry)
    });
    return true;
  } catch (e) {
    return false;
  }
}

// Callback de sauvegarde + publication + re-render apres saisie de la Charge RAM
async function rhUpdateChargeRAM(unit, monthKey, value, mode) {
  const data = rhEffLoadData();
  if (!data[unit]) data[unit] = {};
  if (!data[unit][monthKey]) data[unit][monthKey] = { chargeRAM:null, chargeTotale:null, updatedAt:null };
  const v = parseFloat(String(value).replace(',', '.'));
  data[unit][monthKey].chargeRAM = (value === '' || isNaN(v) || v < 0) ? null : v;
  data[unit][monthKey].updatedAt = new Date().toISOString();

  const ok = await rhEffPublishEntry(unit, monthKey);
  rhEffSetHint(ok
    ? `Charge RAM enregistree dans la base de donnees (${unit} — ${rhEffMonthLabel(monthKey)}).`
    : `Impossible de contacter le serveur — la saisie n'a pas ete enregistree. Reessayez.`, ok ? 'ok' : 'err');

  if (mode === 'unit') { renderRHUnitResult(unit); } else { renderRHPage(); }
  rhEffRenderChart();
}
window.rhUpdateChargeRAM = rhUpdateChargeRAM;

// Declenche depuis le bouton 💾 explicite a cote du champ Charge RAM
// (saisie manuelle mensuelle : on n'enregistre plus au blur/onchange, seulement au clic ou a la touche Entree)
// Le champ etant toujours vide a l'affichage (valeur enregistree non ré-affichee),
// un clic sans saisie ne doit PAS effacer une valeur deja enregistree.
async function rhSaveChargeRAMFromInput(unit, monthKey, mode) {
  const inputId = `rh-ram-input-${mode}-${unit}-${monthKey}`;
  const input = document.getElementById(inputId);
  const btn = document.getElementById(inputId + '-btn');
  if (!input) return;
  if (input.value === '' || input.value === null) {
    rhEffSetHint('Veuillez saisir une valeur avant de cliquer sur 💾 (le champ vide n\'efface pas la valeur existante).', 'err');
    return;
  }
  if (btn) { btn.disabled = true; btn.textContent = '⏳'; }
  try {
    await rhUpdateChargeRAM(unit, monthKey, input.value, mode);
    // Le re-render (renderRHUnitResult / renderRHPage) reconstruit le DOM,
    // donc le bouton d'origine n'existe plus a ce stade — pas besoin de le restaurer.
  } catch (e) {
    if (btn) { btn.disabled = false; btn.textContent = '💾'; }
  }
}
window.rhSaveChargeRAMFromInput = rhSaveChargeRAMFromInput;

// ── Filtre commun (Unité / Début / Fin) partagé par le graphique et l'export Excel ──
function rhEffGetFilteredUnitsAndMonths() {
  const selUnitEl  = document.getElementById('rh-sel-unit');
  const filterUnit = selUnitEl ? selUnitEl.value : 'all';
  const unitsToShow = (!filterUnit || filterUnit === 'all') ? UNITS : [filterUnit];

  const startVal   = document.getElementById('rh-date-start')?.value || '';
  const endVal     = document.getElementById('rh-date-end')?.value || '';
  const startMonth = startVal ? startVal.slice(0, 7) : null; // 'YYYY-MM'
  const endMonth   = endVal   ? endVal.slice(0, 7)   : null;

  const data = rhEffLoadData();
  const monthSet = new Set();
  unitsToShow.forEach(u => { if (data[u]) Object.keys(data[u]).forEach(m => monthSet.add(m)); });
  let months = Array.from(monthSet).sort();
  months = months.filter(m => (!startMonth || m >= startMonth) && (!endMonth || m <= endMonth));

  return { unitsToShow, months, data };
}

// ── Graphique d'evolution du Taux Efficience (comme les graphiques conso Elec/Eau/Gaz) ──
// Filtre pilote par la barre de filtres du haut de la page (Unité / Début / Fin).
function rhEffRenderChart() {
  const canvas = document.getElementById('chart-rh-efficience');
  if (!canvas || typeof Chart === 'undefined') return;

  const { unitsToShow, months, data } = rhEffGetFilteredUnitsAndMonths();
  const labels = months.map(rhEffMonthLabel);

  const datasets = unitsToShow.map(u => ({
    label: u,
    data: months.map(m => {
      const e = data[u] && data[u][m];
      if (!e) return null;
      const t = rhTauxEfficience(e.chargeTotale, e.chargeRAM);
      return t === null ? null : +(t * 100).toFixed(1);
    }),
    borderColor: UNIT_COLORS[u] || '#888',
    backgroundColor: (UNIT_COLORS[u] || '#888') + '22',
    spanGaps: true, tension: 0.3, fill: false, pointRadius: 3
  }));

  destroyChart('rh-efficience');
  if (typeof charts === 'undefined') return;
  charts['rh-efficience'] = new Chart(canvas, {
    type: 'line',
    data: { labels, datasets },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: true, labels: { boxWidth: 10, font: { size: 10.5 } } } },
      scales: { y: { beginAtZero: true, ticks: { callback: v => v + '%' } } }
    }
  });
}
window.rhEffRenderChart = rhEffRenderChart;

// ── Export Excel : indicateur Efficience RH reparti par mois (Unité / Début / Fin) ──
async function rhEffExportExcel() {
  const { unitsToShow, months, data } = rhEffGetFilteredUnitsAndMonths();

  if (months.length === 0) {
    rhEffSetHint('Aucune donnee de Charge RAM / Efficience a exporter pour la periode et l\'unite selectionnees.', 'err');
    return;
  }

  const rows = [];
  unitsToShow.forEach(u => {
    months.forEach(m => {
      const e = data[u] && data[u][m];
      if (!e) return; // rien de saisi/calcule pour ce couple unite/mois → on ne l'exporte pas
      const chargeRAM    = (e.chargeRAM !== null && e.chargeRAM !== undefined) ? e.chargeRAM : null;
      const chargeTotale = (e.chargeTotale !== null && e.chargeTotale !== undefined) ? e.chargeTotale : null;
      const taux = rhTauxEfficience(chargeTotale, chargeRAM);
      rows.push({
        'Unité': u,
        'Mois': rhEffMonthLabel(m),
        'Mois (AAAA-MM)': m,
        'Charge RAM (h)': chargeRAM !== null ? chargeRAM : '',
        'Charge Totale GMAO (h)': chargeTotale !== null ? chargeTotale : '',
        'Taux Efficience (%)': taux !== null ? +(taux * 100).toFixed(1) : '',
        'Derniere mise a jour': e.updatedAt ? new Date(e.updatedAt).toLocaleString('fr-FR') : ''
      });
    });
  });

  if (rows.length === 0) {
    rhEffSetHint('Aucune donnee de Charge RAM / Efficience a exporter pour la periode et l\'unite selectionnees.', 'err');
    return;
  }

  // Tri : Unite puis Mois chronologique
  rows.sort((a, b) => a['Unité'].localeCompare(b['Unité']) || a['Mois (AAAA-MM)'].localeCompare(b['Mois (AAAA-MM)']));

  const logoBuf = await setramLogoBuffer();
  const wb = new ExcelJS.Workbook(); wb.creator = 'SETRAM — Direction Ingenierie'; wb.created = new Date();
  writeSetramSheet(wb, 'Efficience RH', rows, {
    title: 'Efficience RH — Charge RAM vs Charge GMAO',
    subtitle: `${unitsToShow.length} unité(s), ${months.length} mois`,
    logoBuf
  });

  const dateStr = new Date().toISOString().slice(0, 10);
  await downloadSetramWorkbook(wb, `efficience-rh_${dateStr}.xlsx`);

  rhEffSetHint(`✅ Export Excel genere (${rows.length} ligne(s) — ${unitsToShow.length} unite(s), ${months.length} mois).`, 'ok');
}
window.rhEffExportExcel = rhEffExportExcel;

// ── Initialisation UI (masque les boutons Connecter/Telecharger, devenus inutiles) ──
function rhEffInitUI() {
  if (!rhEffInitUI._wired) {
    rhEffInitUI._wired = true;
    const btnConnect = document.getElementById('rh-eff-btn-connect');
    const btnDownload = document.getElementById('rh-eff-btn-download');
    const btnConnectNewTab = document.getElementById('rh-eff-btn-connect-newtab');
    if (btnConnect) btnConnect.style.display = 'none';
    if (btnDownload) btnDownload.style.display = 'none';
    if (btnConnectNewTab) btnConnectNewTab.style.display = 'none';
  }
  // Rafraîchit les données à chaque ouverture de la page (au cas où un collègue
  // a saisi une Charge RAM entre-temps), sans bloquer l'affichage immédiat.
  rhEffFetchAll().then(function(){
    if (document.getElementById('page-rh-import')?.classList.contains('active')) {
      if (typeof renderRHPage === 'function') renderRHPage();
      if (typeof rhEffRenderChart === 'function') rhEffRenderChart();
    }
  });
}
window.rhEffInitUI = rhEffInitUI;

// ══════════════════════════════════════════════════════════════════════
// MODIF 3 : renderRHUnitResult — avec grandTotal, nouvelles colonnes,
// totaux par sous-systeme et grand total
// ══════════════════════════════════════════════════════════════════════
function renderRHUnitResult(unit) {
  const data = calcRHEfficienceUnit(unit);
  const container = document.getElementById('rh-results');
  if (!data) { showToast(`⚠️ Aucune donnee pour ${unit}`, 'warn'); return; }

  const norme   = data.norme;
 const { start, end } = getFilters();
const allRows = [
    ...filterByDateRH(RH_DB.corrRows[unit]||[], start, end),
    ...filterByDateRH(RH_DB.prevRows[unit]||[], start, end)
];

  // ── Agrégation Technicien × Sous-systeme via CODE_EQUIPEMENT ────
  const techSysMap = {};
  const sysMap     = {};

  allRows.forEach(row => {
    const tech   = rhGetTech(row);
    const heures = rhParseHours(row);

    const parsed      = parseCodeEquipement(row['CODE_EQUIPEMENT'] || row['EQUIPEMENT'] || '');
    const systeme     = parsed.systeme;
    const sousSysteme = parsed.sousSysteme;
    const groupKey    = sousSysteme;

    if (!techSysMap[tech])           techSysMap[tech]           = {};
    if (!techSysMap[tech][groupKey]) techSysMap[tech][groupKey] = { heures:0, nbInterv:0, systeme, sousSysteme };
    techSysMap[tech][groupKey].heures   += heures;
    techSysMap[tech][groupKey].nbInterv += 1;

    if (!sysMap[groupKey]) sysMap[groupKey] = { techs: new Set(), heures:0, nbInterv:0, systeme, sousSysteme };
    sysMap[groupKey].techs.add(tech);
    sysMap[groupKey].heures   += heures;
    sysMap[groupKey].nbInterv += 1;
  });

  // ── Liste sous-systemes triee : systeme puis sousSysteme ──────────
  const sysList = Object.entries(sysMap)
    .map(([key, v]) => ({
      sys:             key,
      systeme:         v.systeme,
      sousSysteme:     v.sousSysteme,
      nbTechActuels:   v.techs.size,
      heures:          v.heures,
      nbInterv:        v.nbInterv,
      besoinEssentiel: Math.ceil(v.heures / norme)
    }))
    .sort((a,b) => a.systeme.localeCompare(b.systeme) || a.sousSysteme.localeCompare(b.sousSysteme));

  const techList  = data.techList;
  const allSys    = sysList.map(s => s.sys);
  const grandTotal = sysList.reduce((s,x) => s + x.heures, 0);

  const dCls = data.deltaUnite > 0.5  ? 'badge-red'
             : data.deltaUnite < -0.5 ? 'badge-yellow' : 'badge-green';
  const dLbl = data.deltaUnite > 0.5
    ? `⚠️ Manque ${data.deltaUnite.toFixed(1)} poste(s)`
    : data.deltaUnite < -0.5
      ? `↘ Excedent ${Math.abs(data.deltaUnite).toFixed(1)}`
      : '✅ Equilibre';

  const uL = unit.toLowerCase();

  const rhMonthKeyUnit  = rhMonthKey(start);
  // Repartit reellement la Charge Totale GMAO mois calendaire par mois calendaire
  // (au lieu de tout attribuer au seul mois de debut de la periode selectionnee)
  rhEffSnapshotMonthlyChargeTotale(unit);
  const chargeRAMUnit   = rhGetChargeRAM(unit, rhMonthKeyUnit);
  const tauxEffUnit     = rhTauxEfficience(data.chargeReelleTotale, chargeRAMUnit);
  const effBadgeUnit    = rhTauxEfficienceBadge(tauxEffUnit);

  let html = `
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:18px;flex-wrap:wrap">
      <span class="unit-tag bg-${uL} u-${uL}" style="font-size:16px;padding:6px 14px">${unit}</span>
      <span class="badge ${dCls}" style="font-size:12px">${dLbl}</span>
      <button class="btn btn-ghost btn-sm" onclick="renderRHPage()" style="margin-left:auto">← Vue globale</button>
    </div>
    <div class="rh-kpi-grid" style="margin-bottom:20px">
      ${rhKpiCard('👷 Techniciens',      data.nbTech,                           'analyses',              'c1')}
      ${rhKpiCard('⏱️ Charge Totale',    data.chargeReelleTotale.toFixed(1)+'h','interv. + logist.',     'c2')}
      ${rhKpiCardRAM(unit, rhMonthKeyUnit, chargeRAMUnit, 'unit')}
      ${rhKpiCard('📊 Taux Efficience',  tauxEffUnit !== null ? (tauxEffUnit*100).toFixed(1)+'%' : '—', 'Charge Totale ÷ Charge RAM', tauxEffUnit===null?'c6':(tauxEffUnit>1.05?'c3':tauxEffUnit<0.85?'c6':'c7'))}
      ${rhKpiCard('📏 Norme',            data.norme+'h',                        'par tech./mois',        'c5')}
      ${rhKpiCard('🎯 Besoin Essentiel', data.besoinEssentiel,                  'postes (H÷'+norme+'h)', 'c4')}
    </div>
    <div class="tab-group" style="margin-bottom:20px">
      <button class="tab active" id="rh-tab-sys"   onclick="rhSwitchTab('sys','${unit}')">🔧 Par Sous-systeme → Techniciens</button>
      <button class="tab"        id="rh-tab-tech"  onclick="rhSwitchTab('tech','${unit}')">👤 Par Technicien</button>
      <button class="tab"        id="rh-tab-cross" onclick="rhSwitchTab('cross','${unit}')">📊 Tableau Croise</button>
    </div>

    <!-- ═══════════════════════════════════════════════════
         VUE 1 : PAR SOUS-SYSTEME → TECHNICIENS (defaut)
    ═══════════════════════════════════════════════════ -->
    <div id="rh-view-sys-${unit}">
      <div class="card" style="margin-bottom:20px">
        <div class="card-title">🔧 Par Sous-systeme → Techniciens — ${unit}</div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th style="min-width:80px">Systeme</th>
                <th style="min-width:120px">Sous-systeme / Technicien</th>
                <th style="text-align:center">Charge (h)</th>
                <th style="text-align:center">% Charge Totale</th>
                <th style="text-align:center">🎯 Besoin<br><small>(H÷${norme})</small></th>
                <th style="text-align:center">Δ Postes</th>
                <th style="text-align:center">Nb Interv.</th>
                <th style="text-align:center">Moy. h/Interv.</th>
                <th style="min-width:140px">Taux Occupation</th>
                <th style="text-align:center">Statut</th>
              </tr>
            </thead>
            <tbody>
              ${sysList.map(s => {
                const techsInSys = Object.keys(techSysMap)
                  .filter(t => techSysMap[t][s.sys])
                  .sort((a,b) => techSysMap[b][s.sys].heures - techSysMap[a][s.sys].heures);
                const delta   = s.besoinEssentiel - s.nbTechActuels;
                const dCls2   = delta > 0 ? 'badge-red' : delta < -1 ? 'badge-yellow' : 'badge-green';
                const dLbl2   = delta > 0 ? `+${delta}` : `${delta}`;
                const pctTotal = grandTotal > 0 ? (s.heures / grandTotal * 100).toFixed(1) : '0';
                const moyInterv = s.nbInterv > 0 ? (s.heures / s.nbInterv).toFixed(2) : '—';

                return `
                  <!-- ── LIGNE SOUS-SYSTEME (en-tete groupe) ── -->
                  <tr style="background:linear-gradient(90deg,rgba(36, 83, 122,0.09),rgba(47, 102, 144,0.05));border-top:2px solid rgba(36, 83, 122,0.18)">
                    <td style="font-weight:800;font-size:11px;padding:10px 14px;color:#1e40af">
                      <span style="display:inline-flex;align-items:center;gap:6px">
                        <span style="width:8px;height:8px;border-radius:3px;background:#2f6690;flex-shrink:0"></span>
                        ${s.systeme}
                      </span>
                    </td>
                    <td style="font-weight:800;font-size:12.5px;padding:10px 14px;color:#4c1d95">
                      <span style="display:inline-flex;align-items:center;gap:7px">
                        <span style="width:8px;height:8px;border-radius:50%;background:#24537a;flex-shrink:0;box-shadow:0 0 6px rgba(36, 83, 122,0.5)"></span>
                        ${s.sousSysteme}
                        <span style="font-size:9px;background:#ede9fe;color:#24537a;padding:1px 6px;border-radius:8px">${s.nbTechActuels} tech.</span>
                      </span>
                    </td>
                    <td style="text-align:center;font-weight:800;color:#4c1d95;font-size:13px">${s.heures.toFixed(1)}h</td>
                    <td style="text-align:center">
                      <div style="display:flex;align-items:center;gap:5px;justify-content:center">
                        <div style="width:40px;height:5px;background:var(--border);border-radius:3px;overflow:hidden">
                          <div style="width:${Math.min(parseFloat(pctTotal),100)}%;height:100%;background:linear-gradient(90deg,#24537a,#2f6690);border-radius:3px"></div>
                        </div>
                        <span style="font-size:11px;font-weight:700;color:#24537a">${pctTotal}%</span>
                      </div>
                    </td>
                    <td style="text-align:center;font-weight:900;color:#24537a;font-size:15px">${s.besoinEssentiel}</td>
                    <td style="text-align:center"><span class="badge ${dCls2}">${dLbl2}</span></td>
                    <td style="text-align:center;font-weight:700;color:#4c1d95">${s.nbInterv}</td>
                    <td style="text-align:center;font-size:11px;color:#6b7fa8">${moyInterv}h</td>
                    <td colspan="2" style="font-size:10px;color:#24537a;font-weight:700;text-align:center">
                      Charge sous-systeme : ${s.heures.toFixed(1)}h / ${norme * s.nbTechActuels}h capacite
                    </td>
                  </tr>

                  <!-- ── LIGNES TECHNICIENS ── -->
                  ${techsInSys.map(tech => {
                    const tc      = techSysMap[tech][s.sys];
                    const taux    = norme > 0 ? tc.heures / norme : 0;
                    const tauxPct = taux * 100;
                    const statut  = taux > 1.05 ? 'surcharge' : taux < 0.75 ? 'sous-charge' : 'equilibre';
                    const barCls  = statut === 'surcharge' ? 'rh-bar-over' : statut === 'sous-charge' ? 'rh-bar-under' : 'rh-bar-ok';
                    const delta2  = tc.heures - norme;
                    const dColor  = delta2 > 0 ? '#dc2626' : delta2 < -10 ? '#d97706' : '#059669';
                    const moyH    = tc.nbInterv > 0 ? (tc.heures / tc.nbInterv).toFixed(2) : '—';
                    const pctTech = grandTotal > 0 ? (tc.heures / grandTotal * 100).toFixed(1) : '0';
                    return `<tr style="background:rgba(248,250,255,0.7);transition:background 0.15s" onmouseover="this.style.background='rgba(237,233,254,0.5)'" onmouseout="this.style.background='rgba(248,250,255,0.7)'">
                      <td style="padding:7px 14px">
                        <span style="font-size:9px;background:#dbeafe;color:#1e40af;padding:1px 6px;border-radius:6px;font-weight:700">${s.systeme}</span>
                      </td>
                      <td style="padding:8px 14px 8px 28px;font-size:12px;color:var(--text2)">
                        <span style="display:inline-flex;align-items:center;gap:8px;flex-wrap:wrap">
                          <span style="width:1px;height:16px;background:rgba(36, 83, 122,0.25);flex-shrink:0"></span>
                          <span style="font-weight:700;color:#0a1930">${tech}</span>
                        </span>
                      </td>
                      <td style="text-align:center;font-size:12px;font-weight:700">
                        <span style="color:#0a1930">${tc.heures.toFixed(2)}h</span>
                        <div style="font-size:9px;color:${dColor};font-weight:700;margin-top:1px">${delta2>0?'+':''}${delta2.toFixed(1)}h vs norme</div>
                      </td>
                      <td style="text-align:center;font-size:11px;color:#6b7fa8">${pctTech}%</td>
                      <td style="text-align:center;color:var(--text3);font-size:11px">—</td>
                      <td style="text-align:center;color:var(--text3);font-size:11px">—</td>
                      <td style="text-align:center;font-size:12px;font-weight:600">${tc.nbInterv}</td>
                      <td style="text-align:center;font-size:11px;color:#6b7fa8">${moyH}h</td>
                      <td>
                        <div style="display:flex;align-items:center;gap:7px;min-width:130px">
                          <div style="flex:1;height:6px;background:var(--border);border-radius:3px;overflow:hidden">
                            <div class="unit-bar-fill ${barCls}" style="width:${Math.min(tauxPct,150)}%"></div>
                          </div>
                          <span style="font-size:10px;font-weight:800;min-width:38px">${tauxPct.toFixed(1)}%</span>
                        </div>
                      </td>
                      <td style="text-align:center">${rhStatutBadge(statut)}</td>
                    </tr>`;
                  }).join('')}

                  <!-- ── TOTAL SOUS-SYSTEME ── -->
                  <tr style="background:rgba(237,233,254,0.4);border-bottom:2px solid rgba(36, 83, 122,0.12)">
                    <td colspan="2" style="padding:6px 14px 6px 28px;font-size:11px;font-weight:800;color:#24537a">
                      Σ ${s.sousSysteme}
                    </td>
                    <td style="text-align:center;font-weight:900;color:#24537a;font-size:12px">${s.heures.toFixed(1)}h</td>
                    <td style="text-align:center;font-size:11px;font-weight:700;color:#24537a">${pctTotal}%</td>
                    <td style="text-align:center;font-weight:900;color:#24537a">${s.besoinEssentiel}</td>
                    <td style="text-align:center"><span class="badge ${dCls2}">${dLbl2}</span></td>
                    <td style="text-align:center;font-weight:700;color:#24537a">${s.nbInterv}</td>
                    <td style="text-align:center;font-size:11px;color:#24537a">${moyInterv}h</td>
                    <td colspan="2" style="font-size:10px;color:#24537a;font-style:italic;text-align:center">
                      Capacite: ${norme * s.nbTechActuels}h · Taux: ${(s.heures/(norme*s.nbTechActuels||1)*100).toFixed(1)}%
                    </td>
                  </tr>`;
              }).join('')}

              <!-- ── GRAND TOTAL ── -->
              <tr style="background:linear-gradient(90deg,rgba(47, 102, 144,0.12),rgba(36, 83, 122,0.08));border-top:3px solid rgba(47, 102, 144,0.3)">
                <td colspan="2" style="padding:10px 14px;font-weight:900;font-size:13px;color:#1e40af">
                  🏁 TOTAL UNITE ${unit}
                </td>
                <td style="text-align:center;font-weight:900;color:#1e40af;font-size:14px">${grandTotal.toFixed(1)}h</td>
                <td style="text-align:center;font-weight:900;color:#1e40af">100%</td>
                <td style="text-align:center;font-weight:900;color:#24537a;font-size:15px">${data.besoinEssentiel}</td>
                <td style="text-align:center">
                  <span class="badge ${data.deltaUnite>0.5?'badge-red':data.deltaUnite<-0.5?'badge-yellow':'badge-green'}">
                    ${data.deltaUnite>0?'+':''}${data.deltaUnite.toFixed(1)}
                  </span>
                </td>
                <td style="text-align:center;font-weight:900;color:#1e40af">
                  ${sysList.reduce((s,x)=>s+x.nbInterv,0)}
                </td>
                <td style="text-align:center;font-size:11px;color:#6b7fa8">
                  ${sysList.reduce((s,x)=>s+x.nbInterv,0)>0?(grandTotal/sysList.reduce((s,x)=>s+x.nbInterv,0)).toFixed(2):'—'}h
                </td>
                <td colspan="2" style="font-size:11px;font-weight:700;color:#1e40af;text-align:center">
                  Capacite totale: ${norme * data.nbTech}h · Taux global: ${(data.tauxMoyenOccupation*100).toFixed(1)}%
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ═══════════════════════════════════════════════════
         VUE 2 : PAR TECHNICIEN
    ═══════════════════════════════════════════════════ -->
    <div id="rh-view-tech-${unit}" style="display:none">
      <div class="card" style="margin-bottom:20px">
        <div class="card-title">👤 Charge par Technicien — ${unit}</div>
        <div class="table-wrap rh-tech-table">
          <table>
            <thead>
              <tr>
                <th>#</th><th>Technicien</th><th>Charge Reelle (h)</th><th>Norme (h)</th>
                <th>Δ Heures</th><th>Taux Occupation</th><th>Nb Interv.</th>
                <th>Sous-systemes couverts</th><th>Statut</th>
              </tr>
            </thead>
            <tbody>
              ${techList.map((t, i) => {
                const barCls = t.statut==='surcharge' ? 'rh-bar-over' : t.statut==='sous-charge' ? 'rh-bar-under' : 'rh-bar-ok';
                const dColor = t.delta > 0 ? '#dc2626' : t.delta < -10 ? '#d97706' : '#059669';
                const techSys  = Object.keys(techSysMap[t.technicien] || {});
                const sysTags  = techSys.slice(0,3).map(s =>
                  `<span style="font-size:9px;background:#f0f4ff;color:#44537a;padding:1px 6px;border-radius:10px;margin:1px;display:inline-block">${s}</span>`
                ).join('') + (techSys.length > 3 ? `<span style="font-size:9px;color:var(--text3)">+${techSys.length-3}</span>` : '');
                return `<tr>
                  <td style="color:var(--text3);font-size:11px">${i+1}</td>
                  <td style="font-weight:700">${t.technicien}</td>
                  <td>${t.chargeReelle.toFixed(2)}h</td>
                  <td style="color:var(--text3)">${t.norme}h</td>
                  <td style="color:${dColor};font-weight:700">${t.delta>0?'+':''}${t.delta.toFixed(1)}h</td>
                  <td>
                    <div style="display:flex;align-items:center;gap:8px;min-width:140px">
                      <div style="flex:1;height:6px;background:var(--border);border-radius:3px;overflow:hidden">
                        <div class="unit-bar-fill ${barCls}" style="width:${Math.min(t.tauxOccupationPct,150)}%"></div>
                      </div>
                      <span style="font-size:11px;font-weight:800;min-width:46px">${t.tauxOccupationPct.toFixed(1)}%</span>
                    </div>
                  </td>
                  <td style="text-align:center">${t.nbInterventions}</td>
                  <td style="max-width:160px;white-space:normal">${sysTags}</td>
                  <td>${rhStatutBadge(t.statut)}</td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ═══════════════════════════════════════════════════
         VUE 3 : TABLEAU CROISE
    ═══════════════════════════════════════════════════ -->
    <div id="rh-view-cross-${unit}" style="display:none">
      <div class="card" style="margin-bottom:20px">
        <div class="card-title">📊 Tableau Croise — Technicien × Sous-systeme (heures) — ${unit}</div>
        <div class="table-wrap" style="overflow-x:auto">
          <table>
            <thead>
              <tr>
                <th style="position:sticky;left:0;background:#f4f7ff;z-index:3;min-width:140px">Technicien</th>
                <th style="text-align:center;min-width:70px">Total (h)</th>
                <th style="text-align:center;min-width:60px">Taux</th>
                ${allSys.map(s => `<th style="text-align:center;min-width:80px;max-width:100px;white-space:normal;font-size:9.5px;color:#5a6e96">${s}</th>`).join('')}
              </tr>
              <tr style="background:#ede9fe">
                <td style="position:sticky;left:0;background:#ede9fe;z-index:3;font-size:10px;font-weight:800;color:#24537a">🎯 Besoin Essentiel</td>
                <td style="text-align:center;font-size:10px;font-weight:800;color:#24537a">${data.besoinEssentiel}</td>
                <td></td>
                ${allSys.map(s => { const be = sysList.find(x=>x.sys===s)?.besoinEssentiel||0; return `<td style="text-align:center;font-size:11px;font-weight:800;color:#24537a">${be}</td>`; }).join('')}
              </tr>
            </thead>
            <tbody>
              ${techList.map(t => {
                const rowData = techSysMap[t.technicien] || {};
                const barCls  = t.statut==='surcharge' ? 'rh-bar-over' : t.statut==='sous-charge' ? 'rh-bar-under' : 'rh-bar-ok';
                return `<tr>
                  <td style="position:sticky;left:0;background:#fff;z-index:2;font-weight:700;font-size:12px">${t.technicien}</td>
                  <td style="text-align:center;font-weight:700">${t.chargeReelle.toFixed(1)}h</td>
                  <td>
                    <div style="display:flex;align-items:center;gap:4px;min-width:70px">
                      <div style="flex:1;height:5px;background:var(--border);border-radius:3px;overflow:hidden">
                        <div class="unit-bar-fill ${barCls}" style="width:${Math.min(t.tauxOccupationPct,150)}%"></div>
                      </div>
                      <span style="font-size:10px;font-weight:700;white-space:nowrap">${t.tauxOccupationPct.toFixed(0)}%</span>
                    </div>
                  </td>
                  ${allSys.map(s => {
                    const cell = rowData[s];
                    if (!cell) return `<td style="text-align:center;color:#e2e8f4">—</td>`;
                    const pct2 = data.chargeReelleTotale > 0 ? (cell.heures/data.chargeReelleTotale*100).toFixed(0) : 0;
                    const bg   = cell.heures > norme*0.5 ? 'rgba(220,38,38,0.08)' : cell.heures > norme*0.2 ? 'rgba(245,158,11,0.08)' : 'rgba(16,185,129,0.06)';
                    return `<td style="text-align:center;background:${bg}">
                      <div style="font-size:11px;font-weight:700">${cell.heures.toFixed(1)}h</div>
                      <div style="font-size:9px;color:var(--text3)">${cell.nbInterv} int. · ${pct2}%</div>
                    </td>`;
                  }).join('')}
                </tr>`;
              }).join('')}
              <tr style="background:#f8faff;font-weight:800;border-top:2px solid var(--border)">
                <td style="position:sticky;left:0;background:#f8faff;z-index:2;font-size:11px;color:#24537a">TOTAL SYSTEME</td>
                <td style="text-align:center;color:#24537a">${data.chargeReelleTotale.toFixed(1)}h</td>
                <td></td>
                ${allSys.map(s => { const tot = sysList.find(x=>x.sys===s)?.heures||0; return `<td style="text-align:center;font-size:11px;color:#24537a;font-weight:800">${tot.toFixed(1)}h</td>`; }).join('')}
              </tr>
            </tbody>
          </table>
        </div>
        <div style="display:flex;gap:16px;margin-top:10px;flex-wrap:wrap;font-size:10.5px;color:var(--text3)">
          <span style="display:flex;align-items:center;gap:5px"><span style="width:12px;height:12px;border-radius:3px;background:rgba(220,38,38,0.15);display:inline-block"></span> Charge elevee (&gt; 50% norme)</span>
          <span style="display:flex;align-items:center;gap:5px"><span style="width:12px;height:12px;border-radius:3px;background:rgba(245,158,11,0.15);display:inline-block"></span> Charge moderee (20–50%)</span>
          <span style="display:flex;align-items:center;gap:5px"><span style="width:12px;height:12px;border-radius:3px;background:rgba(16,185,129,0.10);display:inline-block"></span> Charge faible (&lt; 20%)</span>
        </div>
      </div>
    </div>`;

  container.innerHTML = html;
  rhEffInitUI();
  rhEffRenderChart();
}

function rhSwitchTab(tab, unit) {
  ['tech','sys','cross'].forEach(t => {
    const btn  = document.getElementById(`rh-tab-${t}`);
    const view = document.getElementById(`rh-view-${t}-${unit}`);
    if (btn)  btn.classList.remove('active');
    if (view) view.style.display = 'none';
  });
  const activeBtn  = document.getElementById(`rh-tab-${tab}`);
  const activeView = document.getElementById(`rh-view-${tab}-${unit}`);
  if (activeBtn)  activeBtn.classList.add('active');
  if (activeView) activeView.style.display = '';
}

// ══════════════════════════════════════════════════════════════════════
// MODIF 4 : renderRHUnitBySystemThenTechHTML — avec grandTotalGlobal,
// nouvelles colonnes, totaux par sous-systeme et grand total
// ══════════════════════════════════════════════════════════════════════
function renderRHUnitBySystemThenTechHTML(data) {
  const norme   = data.norme;
  const { start, end } = getFilters();
  const allRows = [
    ...rhFilterByDate(RH_DB.corrRows[data.unit]||[], start, end),
    ...rhFilterByDate(RH_DB.prevRows[data.unit]||[], start, end)
  ];
  const uL = data.unit.toLowerCase();

  // ── Agrégation sysMap[sousSysteme][tech] via CODE_EQUIPEMENT ────
  const sysMap = {};
  allRows.forEach(row => {
    const parsed      = parseCodeEquipement(row['CODE_EQUIPEMENT'] || row['EQUIPEMENT'] || '');
    const systeme     = parsed.systeme;
    const sousSysteme = parsed.sousSysteme;
    const groupKey    = sousSysteme;
    const tech        = rhGetTech(row);
    const heures      = rhParseHours(row);

    if (!sysMap[groupKey]) sysMap[groupKey] = { systeme, sousSysteme, techs:{}, heuresTotal:0 };
    if (!sysMap[groupKey].techs[tech]) sysMap[groupKey].techs[tech] = { heures:0, nbInterv:0 };
    sysMap[groupKey].techs[tech].heures   += heures;
    sysMap[groupKey].techs[tech].nbInterv += 1;
    sysMap[groupKey].heuresTotal           += heures;
  });

  // Tri : systeme puis sous-systeme
  const sysList = Object.entries(sysMap)
    .map(([key, v]) => ({
      key, systeme: v.systeme, sousSysteme: v.sousSysteme,
      techs: v.techs, heuresTotal: v.heuresTotal,
      nbTechActuels:   Object.keys(v.techs).length,
      besoinEssentiel: Math.ceil(v.heuresTotal / norme),
      nbInterv: Object.values(v.techs).reduce((s,t)=>s+t.nbInterv,0)
    }))
    .sort((a,b) => a.systeme.localeCompare(b.systeme) || a.sousSysteme.localeCompare(b.sousSysteme));

  const grandTotalGlobal = sysList.reduce((s,x) => s + x.heuresTotal, 0);

  return `
    <div class="card" style="margin-bottom:20px">
      <div class="card-title">
        <span class="unit-tag bg-${uL} u-${uL}" style="font-size:13px;padding:4px 10px">${data.unit}</span>
        Vue Systeme → Techniciens
        <span style="margin-left:8px;font-size:11px;color:var(--text3);font-weight:500">
          ${data.nbTech} tech · ${data.chargeReelleTotale.toFixed(1)}h ·
          Besoin : <strong style="color:#24537a">${data.besoinEssentiel}</strong> postes
        </span>
        <button class="btn btn-ghost btn-sm" onclick="renderRHUnitResult('${data.unit}')" style="margin-left:auto">Detail complet →</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th style="min-width:70px">Systeme</th>
              <th style="min-width:120px">Sous-systeme / Technicien</th>
              <th style="text-align:center">Charge (h)</th>
              <th style="text-align:center">% Total</th>
              <th style="text-align:center">🎯 Besoin<br><small>(H÷${norme})</small></th>
              <th style="text-align:center">Δ Postes</th>
              <th style="text-align:center">Nb Interv.</th>
              <th style="text-align:center">Moy. h/Interv.</th>
              <th style="min-width:130px">Taux Occupation</th>
            </tr>
          </thead>
          <tbody>
            ${sysList.map(sys => {
              const techKeys    = Object.keys(sys.techs).sort((a,b) => sys.techs[b].heures - sys.techs[a].heures);
              const sysNbInterv = techKeys.reduce((s,t) => s + sys.techs[t].nbInterv, 0);
              const sysNbTech   = techKeys.length;
              const sysDelta    = sys.besoinEssentiel - sysNbTech;
              const sysDeltaCls = sysDelta >  0 ? 'badge-red' : sysDelta < -1 ? 'badge-yellow' : 'badge-green';
              const sysDeltaLbl = sysDelta >  0 ? `+${sysDelta}` : `${sysDelta}`;
              const pctSys  = grandTotalGlobal > 0 ? (sys.heuresTotal / grandTotalGlobal * 100).toFixed(1) : '0';
              const moyInter = sysNbInterv > 0 ? (sys.heuresTotal / sysNbInterv).toFixed(2) : '—';

              return `
                <!-- ── LIGNE SOUS-SYSTEME ── -->
                <tr style="background:linear-gradient(90deg,rgba(36, 83, 122,0.09),rgba(47, 102, 144,0.05));border-top:2px solid rgba(36, 83, 122,0.18)">
                  <td style="font-weight:800;font-size:11px;padding:10px 14px">
                    <span style="font-size:10px;background:#dbeafe;color:#1e40af;padding:2px 8px;border-radius:8px;font-weight:800">${sys.systeme}</span>
                  </td>
                  <td style="font-weight:800;font-size:12px;padding:10px 14px;color:#4c1d95">
                    <span style="display:inline-flex;align-items:center;gap:6px">
                      <span style="width:8px;height:8px;border-radius:50%;background:#24537a;flex-shrink:0;box-shadow:0 0 5px rgba(36, 83, 122,0.5)"></span>
                      ${sys.sousSysteme}
                      <span style="font-size:9px;background:#ede9fe;color:#24537a;padding:1px 6px;border-radius:8px">${sysNbTech} tech.</span>
                    </span>
                  </td>
                  <td style="text-align:center;font-weight:800;color:#4c1d95;font-size:13px">${sys.heuresTotal.toFixed(1)}h</td>
                  <td style="text-align:center">
                    <div style="display:flex;align-items:center;gap:4px;justify-content:center">
                      <div style="width:36px;height:5px;background:var(--border);border-radius:3px;overflow:hidden">
                        <div style="width:${Math.min(parseFloat(pctSys),100)}%;height:100%;background:linear-gradient(90deg,#24537a,#2f6690);border-radius:3px"></div>
                      </div>
                      <span style="font-size:11px;font-weight:700;color:#24537a">${pctSys}%</span>
                    </div>
                  </td>
                  <td style="text-align:center;font-weight:900;color:#24537a;font-size:14px">${sys.besoinEssentiel}</td>
                  <td style="text-align:center"><span class="badge ${sysDeltaCls}">${sysDeltaLbl}</span></td>
                  <td style="text-align:center;font-weight:700;color:#4c1d95">${sysNbInterv}</td>
                  <td style="text-align:center;font-size:11px;color:#6b7fa8">${moyInter}h</td>
                  <td style="font-size:10px;color:#24537a;font-weight:700;text-align:center">
                    ${sys.heuresTotal.toFixed(1)}h / ${norme * sysNbTech}h cap.
                  </td>
                </tr>

                <!-- ── LIGNES TECHNICIENS ── -->
                ${techKeys.map(tech => {
                  const tc      = sys.techs[tech];
                  const taux    = norme > 0 ? tc.heures / norme : 0;
                  const tauxPct = taux * 100;
                  const statut  = taux > 1.05 ? 'surcharge' : taux < 0.75 ? 'sous-charge' : 'equilibre';
                  const barCls  = statut === 'surcharge' ? 'rh-bar-over' : statut === 'sous-charge' ? 'rh-bar-under' : 'rh-bar-ok';
                  const delta   = tc.heures - norme;
                  const dColor  = delta > 0 ? '#dc2626' : delta < -10 ? '#d97706' : '#059669';
                  const moyH    = tc.nbInterv > 0 ? (tc.heures / tc.nbInterv).toFixed(2) : '—';
                  const pctTech = grandTotalGlobal > 0 ? (tc.heures / grandTotalGlobal * 100).toFixed(1) : '0';
                  return `<tr style="background:rgba(248,250,255,0.7)" onmouseover="this.style.background='rgba(237,233,254,0.4)'" onmouseout="this.style.background='rgba(248,250,255,0.7)'">
                    <td style="padding:7px 14px">
                      <span style="font-size:9px;background:#dbeafe;color:#1e40af;padding:1px 6px;border-radius:6px;font-weight:700">${sys.systeme}</span>
                    </td>
                    <td style="padding:8px 14px 8px 28px;font-size:12px">
                      <span style="display:inline-flex;align-items:center;gap:8px">
                        <span style="width:1px;height:16px;background:rgba(36, 83, 122,0.25);flex-shrink:0"></span>
                        <span style="font-weight:700;color:#0a1930">${tech}</span>
                      </span>
                    </td>
                    <td style="text-align:center;font-size:12px;font-weight:700">
                      ${tc.heures.toFixed(2)}h
                      <div style="font-size:9px;color:${dColor};font-weight:700;margin-top:1px">${delta>0?'+':''}${delta.toFixed(1)}h vs norme</div>
                    </td>
                    <td style="text-align:center;font-size:11px;color:#6b7fa8">${pctTech}%</td>
                    <td style="text-align:center;color:var(--text3);font-size:11px">—</td>
                    <td style="text-align:center;color:var(--text3);font-size:11px">—</td>
                    <td style="text-align:center;font-size:12px;font-weight:600">${tc.nbInterv}</td>
                    <td style="text-align:center;font-size:11px;color:#6b7fa8">${moyH}h</td>
                    <td>
                      <div style="display:flex;align-items:center;gap:6px;min-width:120px">
                        <div style="flex:1;height:5px;background:var(--border);border-radius:3px;overflow:hidden">
                          <div class="unit-bar-fill ${barCls}" style="width:${Math.min(tauxPct,150)}%"></div>
                        </div>
                        <span style="font-size:10px;font-weight:800;white-space:nowrap">${tauxPct.toFixed(1)}%</span>
                      </div>
                    </td>
                  </tr>`;
                }).join('')}

                <!-- ── TOTAL SOUS-SYSTEME ── -->
                <tr style="background:rgba(237,233,254,0.35);border-bottom:2px solid rgba(36, 83, 122,0.12)">
                  <td colspan="2" style="padding:5px 14px 5px 28px;font-size:11px;font-weight:800;color:#24537a">
                    Σ ${sys.sousSysteme}
                  </td>
                  <td style="text-align:center;font-weight:900;color:#24537a;font-size:12px">${sys.heuresTotal.toFixed(1)}h</td>
                  <td style="text-align:center;font-size:11px;font-weight:700;color:#24537a">${pctSys}%</td>
                  <td style="text-align:center;font-weight:900;color:#24537a">${sys.besoinEssentiel}</td>
                  <td style="text-align:center"><span class="badge ${sysDeltaCls}">${sysDeltaLbl}</span></td>
                  <td style="text-align:center;font-weight:700;color:#24537a">${sysNbInterv}</td>
                  <td style="text-align:center;font-size:11px;color:#24537a">${moyInter}h</td>
                  <td style="font-size:10px;color:#24537a;font-style:italic;text-align:center">
                    Cap: ${norme*sysNbTech}h · Taux: ${(sys.heuresTotal/(norme*sysNbTech||1)*100).toFixed(1)}%
                  </td>
                </tr>`;
            }).join('')}

            <!-- ── GRAND TOTAL UNITE ── -->
            <tr style="background:linear-gradient(90deg,rgba(47, 102, 144,0.12),rgba(36, 83, 122,0.08));border-top:3px solid rgba(47, 102, 144,0.3)">
              <td colspan="2" style="padding:10px 14px;font-weight:900;font-size:13px;color:#1e40af">
                🏁 TOTAL ${data.unit}
              </td>
              <td style="text-align:center;font-weight:900;color:#1e40af;font-size:14px">${grandTotalGlobal.toFixed(1)}h</td>
              <td style="text-align:center;font-weight:900;color:#1e40af">100%</td>
              <td style="text-align:center;font-weight:900;color:#24537a;font-size:14px">${data.besoinEssentiel}</td>
              <td style="text-align:center">
                <span class="badge ${data.deltaUnite>0.5?'badge-red':data.deltaUnite<-0.5?'badge-yellow':'badge-green'}">
                  ${data.deltaUnite>0?'+':''}${data.deltaUnite.toFixed(1)}
                </span>
              </td>
              <td style="text-align:center;font-weight:900;color:#1e40af">${sysList.reduce((s,x)=>s+x.nbInterv,0)}</td>
              <td style="text-align:center;font-size:11px;color:#6b7fa8">
                ${sysList.reduce((s,x)=>s+x.nbInterv,0)>0?(grandTotalGlobal/sysList.reduce((s,x)=>s+x.nbInterv,0)).toFixed(2):'—'}h
              </td>
              <td style="font-size:11px;font-weight:700;color:#1e40af;text-align:center">
                Cap: ${norme*data.nbTech}h · Global: ${(data.tauxMoyenOccupation*100).toFixed(1)}%
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>`;
}


// =====================================================================
// VUE GLOBALE TOUTES UNITES
// =====================================================================
let RH_ACTIVE_UNITS = [...UNITS];

function renderRHPage() {
  const container   = document.getElementById('rh-results');
  const { start, end, selUnit } = getRHFilters();

if (selUnit !== 'all') {
    // Filtre select → forcer une seule unité
    RH_ACTIVE_UNITS = [selUnit];
  } else {
    // Select = "toutes" → ne pas écraser les checkboxes si déjà actives
    const loaded = UNITS.filter(u =>
      (RH_DB.corrRows[u]||[]).length + (RH_DB.prevRows[u]||[]).length > 0
    );
    // Réinitialiser seulement si RH_ACTIVE_UNITS ne contient aucune unité chargée
    const hasValidActive = RH_ACTIVE_UNITS.some(u => loaded.includes(u));
    if (!hasValidActive) {
      RH_ACTIVE_UNITS = loaded.length > 0 ? loaded : [...UNITS];
    }
  }

  const unitResults = RH_ACTIVE_UNITS.map(u => calcRHEfficienceUnit(u)).filter(Boolean);
  const startFR = start.toLocaleDateString('fr-FR', { day:'2-digit', month:'long', year:'numeric' });
  const endFR   = end.toLocaleDateString('fr-FR',   { day:'2-digit', month:'long', year:'numeric' });
  const periodLabel = `${startFR} → ${endFR}`;
  if (unitResults.length === 0) {
    container.innerHTML = `<div class="empty-state"><div class="es-icon">👥</div><div class="es-title">Aucune donnee RH chargee</div><div class="es-sub">Cliquez sur "Charger tous les fichiers RH" pour importer</div></div>`;
    return;
  }

  const norme          = unitResults[0].norme;
  const totalTech      = unitResults.reduce((s,d) => s + d.nbTech, 0);
  const totalH         = unitResults.reduce((s,d) => s + d.chargeReelleTotale, 0);
  const totalEssentiel = unitResults.reduce((s,d) => s + d.besoinEssentiel, 0);
  const nbSurcharge    = unitResults.reduce((s,d) => s + d.nbSurcharge, 0);
  const nbSousCharge   = unitResults.reduce((s,d) => s + d.nbSousCharge, 0);
  const nbEquilibre    = unitResults.reduce((s,d) => s + d.nbEquilibre, 0);

  // ── Charge RAM (saisie mensuelle, par unite) + Taux Efficience ──────
  const rhMonthKeyGlobal = rhMonthKey(start);
  unitResults.forEach(u => { rhEffSnapshotMonthlyChargeTotale(u.unit); });
  const chargeRamByUnit  = {};
  unitResults.forEach(u => { chargeRamByUnit[u.unit] = rhGetChargeRAM(u.unit, rhMonthKeyGlobal); });
  const ramValues  = Object.values(chargeRamByUnit).filter(v => v !== null);
  const totalRAM   = ramValues.length > 0 ? ramValues.reduce((s,v) => s+v, 0) : null;
  const totalTauxEff = rhTauxEfficience(totalH, totalRAM);
  const effBadgeGlobal = rhTauxEfficienceBadge(totalTauxEff);

  const rhAiTriggerHtml = `
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;padding:14px 18px;
                background:linear-gradient(135deg,rgba(36, 83, 122,0.07),rgba(47, 102, 144,0.05));
                border:1.5px solid rgba(36, 83, 122,0.2);border-radius:var(--radius)">
      <div style="width:42px;height:42px;border-radius:12px;background:var(--grad1);
                  display:flex;align-items:center;justify-content:center;font-size:20px;
                  box-shadow:0 4px 14px rgba(36, 83, 122,0.35);flex-shrink:0">🤖</div>
      <div style="flex:1">
        <div style="font-family:'Montserrat',sans-serif;font-size:14.5px;font-weight:800;color:#0a1930">
          Rapport General d'Efficience RH — IA
        </div>
        <div style="font-size:11.5px;color:#6b7fa8;font-style:italic">
          Analyse complete de la charge par unite, technicien et systeme — telechargement HTML
        </div>
      </div>
      <button class="btn btn-primary" id="btn-gen-rh-report" onclick="generateRHGeneralReport()">
        📥 Generer & Telecharger
      </button>
    </div>
    <div id="rh-general-report-status" style="display:none;margin-bottom:16px"></div>`;

  const unitFilterHtml = selUnit !== 'all' ? `
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;padding:12px 16px;background:rgba(47, 102, 144,0.06);border-radius:12px;border:1.5px solid rgba(47, 102, 144,0.14)">
      <span style="font-size:12px;font-weight:700;color:#1e40af">🏭 Unité filtrée :</span>
      <span class="unit-tag bg-${selUnit.toLowerCase()} u-${selUnit.toLowerCase()}" style="font-size:14px;padding:5px 14px;font-weight:800">${selUnit}</span>
      <button class="btn btn-ghost btn-sm" onclick="document.getElementById('rh-sel-unit').value='all';renderRHPage()" style="margin-left:auto">✕ Voir toutes les unités</button>
      <span style="font-size:11px;color:#6b7fa8">📅 ${periodLabel}</span>
    </div>` : `
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px;flex-wrap:wrap;padding:12px 16px;background:rgba(47, 102, 144,0.06);border-radius:12px;border:1.5px solid rgba(47, 102, 144,0.14)">
      <span style="font-size:12px;font-weight:700;color:#1e40af;margin-right:4px">🏭 Unites :</span>
      ${UNITS.map(u => `
        <label style="display:inline-flex;align-items:center;gap:5px;cursor:pointer;padding:5px 11px;border-radius:20px;font-size:11px;font-weight:700;border:1.5px solid ${RH_ACTIVE_UNITS.includes(u)?UNIT_COLORS[u]:'var(--border)'};background:${RH_ACTIVE_UNITS.includes(u)?UNIT_COLORS[u]+'18':'transparent'};color:${RH_ACTIVE_UNITS.includes(u)?UNIT_COLORS[u]:'var(--text3)'};transition:all 0.15s">
          <input type="checkbox" ${RH_ACTIVE_UNITS.includes(u)?'checked':''} data-unit="${u}"
            onchange="toggleRHUnit('${u}',this.checked)"
            style="display:none">
          <span style="width:7px;height:7px;border-radius:50%;background:${UNIT_COLORS[u]};display:inline-block"></span>
          ${u}
        </label>`).join('')}
      <button class="btn btn-ghost btn-sm" onclick="RH_ACTIVE_UNITS=[...UNITS];renderRHPage()" style="margin-left:8px">Tout</button>
      <span style="margin-left:auto;font-size:11px;color:#6b7fa8">📅 ${periodLabel}</span>
    </div>`;

  let html = rhAiTriggerHtml + unitFilterHtml + `
    <div class="rh-kpi-grid" style="margin-bottom:20px">
      ${rhKpiCard('👷 Techniciens',   totalTech,              'total analyses',    'c1')}
      ${rhKpiCard('⏱️ Charge Totale', totalH.toFixed(1)+'h', 'toutes unites',     'c2')}
      ${rhKpiCard('📝 Chrge RAM',     totalRAM !== null ? totalRAM.toFixed(1)+'h' : '—', `somme saisies · ${rhMonthKeyGlobal}`, 'c9')}
      ${rhKpiCard('📊 Taux Efficience', totalTauxEff !== null ? (totalTauxEff*100).toFixed(1)+'%' : '—', 'Charge Totale ÷ Charge RAM', totalTauxEff===null?'c6':(totalTauxEff>1.05?'c3':totalTauxEff<0.85?'c6':'c7'))}
      ${rhKpiCard('📏 Norme',         norme+'h',              'par tech./mois',    'c5')}
      ${rhKpiCard('🎯 Besoin Essen.', totalEssentiel,         'postes necessaires','c4')}
    </div>
    <div class="card" style="margin-bottom:24px">
      <div class="card-title">🏭 Tableau Recapitulatif Global — Vue par Systeme</div>
      <div class="table-wrap">
        <table><thead><tr>
          <th style="min-width:120px">Unite / 📝 Chrge RAM</th>
          <th>Systeme</th>
          <th style="text-align:center">Charge (h)</th>
          <th style="text-align:center">% Total</th>
          <th style="text-align:center">🎯 Besoin<br><small style="color:var(--text3)">(H÷${norme})</small></th>
          <th style="text-align:center">Nb Tech.</th>
          <th style="text-align:center">Δ Postes</th>
          <th style="text-align:center">Nb Interv.</th>
          <th style="text-align:center">Moy. h/Interv.</th>
          <th style="min-width:130px">Taux Occupation</th>
          <th style="text-align:center">📊 Taux Efficience</th>
          <th style="text-align:center">Détail</th>
        </tr></thead><tbody>
          ${unitResults.map(u => {
            const { start, end } = getRHFilters();
            const allRows2 = [
              ...rhFilterByDate(RH_DB.corrRows[u.unit]||[], start, end),
              ...rhFilterByDate(RH_DB.prevRows[u.unit]||[], start, end)
            ];
            const sysAgg = {};
            allRows2.forEach(row => {
              const parsed = parseCodeEquipement(row['CODE_EQUIPEMENT']||row['EQUIPEMENT']||'');
              const sys = parsed.systeme;
              if (!sysAgg[sys]) sysAgg[sys] = { heures:0, nbInterv:0 };
              sysAgg[sys].heures   += rhParseHours(row);
              sysAgg[sys].nbInterv += 1;
            });
            const sysList2 = Object.entries(sysAgg).sort((a,b)=>b[1].heures-a[1].heures);
            const grandH2  = sysList2.reduce((s,[,v])=>s+v.heures,0);
            const uL = u.unit.toLowerCase();
            const unitRowspan = sysList2.length || 1;

            // ── Charge RAM saisie + Taux Efficience pour cette unite ──
            const chargeRAMu = chargeRamByUnit[u.unit];
            const tauxEffu   = rhTauxEfficience(u.chargeReelleTotale, chargeRAMu);
            const effBadgeU  = rhTauxEfficienceBadge(tauxEffu);
            const ramTableInputId = `rh-ram-input-all-${u.unit}-${rhMonthKeyGlobal}`;
            const unitCellHtml = `
              <span class="unit-tag bg-${uL} u-${uL}">${u.unit}</span>
              <div style="margin-top:8px;display:flex;flex-direction:column;gap:3px">
                <label style="font-size:8.5px;font-weight:700;color:#7a8aaa;text-transform:uppercase;letter-spacing:.4px">📝 Chrge RAM (h)</label>
                <div style="display:flex;align-items:center;gap:4px">
                  <input type="number" step="0.1" min="0" value="" placeholder="${chargeRAMu !== null ? chargeRAMu+'h' : 'Saisir'}"
                    id="${ramTableInputId}"
                    title="Charge declaree dans le Rapport d'Activite Mensuel"
                    style="width:72px;border:1.5px solid #dde6f5;border-radius:7px;padding:4px 6px;
                           font-size:11px;font-family:'Montserrat',sans-serif;font-weight:700;color:#0a1930;
                           background:#f8faff;outline:none"
                    onkeydown="if(event.key==='Enter'){event.preventDefault();rhSaveChargeRAMFromInput('${u.unit}','${rhMonthKeyGlobal}','all');}">
                  <button type="button" class="rh-ram-save-btn" id="${ramTableInputId}-btn"
                    title="Enregistrer la Charge RAM"
                    onclick="rhSaveChargeRAMFromInput('${u.unit}','${rhMonthKeyGlobal}','all')"
                    style="border:1.5px solid #dde6f5;border-radius:7px;background:#eef3ff;
                           font-size:13px;line-height:1;padding:5px 6px;cursor:pointer">💾</button>
                </div>
              </div>`;
            const effCellHtml = `<span class="badge ${effBadgeU.cls}" style="font-size:10px">${effBadgeU.lbl}</span>`;

            if (sysList2.length === 0) {
              const delta = u.besoinEssentiel - u.nbTech;
              const dCls = delta>0.5?'badge-red':delta<-0.5?'badge-yellow':'badge-green';
              return `<tr>
                <td rowspan="1">${unitCellHtml}</td>
                <td style="color:var(--text3);font-style:italic">—</td>
                <td colspan="8" style="color:var(--text3);text-align:center">${u.chargeReelleTotale.toFixed(1)}h · ${u.nbTech} tech · <span class="badge ${dCls}">Δ${delta>0?'+':''}${delta.toFixed(1)}</span></td>
                <td style="text-align:center">${effCellHtml}</td>
              </tr>`;
            }

            return sysList2.map(([sys, sv], idx) => {
              const pct2 = grandH2>0?(sv.heures/grandH2*100).toFixed(1):'0';
              const be   = Math.ceil(sv.heures/norme);
              const nbTechActuels = new Set(allRows2.filter(r=>{
                const p=parseCodeEquipement(r['CODE_EQUIPEMENT']||r['EQUIPEMENT']||'');
                return p.systeme===sys;
              }).map(r=>rhGetTech(r))).size;
              const delta2 = be - nbTechActuels;
              const dCls2  = delta2>0?'badge-red':delta2<-1?'badge-yellow':'badge-green';
              const dLbl2  = delta2>0?`+${delta2}`:String(delta2);
              const moy    = sv.nbInterv>0?(sv.heures/sv.nbInterv).toFixed(2):'—';
              const tauxOcc = norme>0?sv.heures/(norme*Math.max(nbTechActuels,1)):0;
              const barCls2 = tauxOcc>1.05?'rh-bar-over':tauxOcc<0.75?'rh-bar-under':'rh-bar-ok';

              return `<tr>
                ${idx===0?`<td rowspan="${unitRowspan}" style="vertical-align:top;padding-top:10px">${unitCellHtml}</td>`:''}
                <td style="font-size:11px;font-weight:700;color:#1e40af">
                  <span style="display:inline-flex;align-items:center;gap:5px">
                    <span style="width:6px;height:6px;border-radius:2px;background:#2f6690;flex-shrink:0"></span>${sys}
                  </span>
                </td>
                <td style="text-align:center;font-weight:700">${sv.heures.toFixed(1)}h</td>
                <td style="text-align:center">
                  <div style="display:flex;align-items:center;gap:4px;justify-content:center">
                    <div style="width:32px;height:4px;background:var(--border);border-radius:2px;overflow:hidden">
                      <div style="width:${Math.min(parseFloat(pct2),100)}%;height:100%;background:linear-gradient(90deg,#24537a,#2f6690);border-radius:2px"></div>
                    </div>
                    <span style="font-size:10px;font-weight:700;color:#24537a">${pct2}%</span>
                  </div>
                </td>
                <td style="text-align:center;font-weight:900;color:#24537a;font-size:14px">${be}</td>
                <td style="text-align:center;font-weight:700">${nbTechActuels}</td>
                <td style="text-align:center"><span class="badge ${dCls2}">${dLbl2}</span></td>
                <td style="text-align:center;font-weight:600">${sv.nbInterv}</td>
                <td style="text-align:center;font-size:11px;color:#6b7fa8">${moy}h</td>
                <td>
                  <div style="display:flex;align-items:center;gap:6px;min-width:120px">
                    <div style="flex:1;height:5px;background:var(--border);border-radius:3px;overflow:hidden">
                      <div class="unit-bar-fill ${barCls2}" style="width:${Math.min(tauxOcc*100,150)}%"></div>
                    </div>
                    <span style="font-size:10px;font-weight:700">${(tauxOcc*100).toFixed(0)}%</span>
                  </div>
                </td>
                ${idx===0?`<td rowspan="${unitRowspan}" style="text-align:center;vertical-align:top;padding-top:14px">${effCellHtml}</td>`:''}
                <td style="text-align:center">
                  <div style="display:flex;flex-direction:column;gap:4px;align-items:center">
                    <button class="btn btn-ghost btn-sm" style="font-size:10px;padding:4px 9px;width:90px"
                      onclick="showRHSystemDetail('${u.unit}','${sys}')">
                      🔍 + Info
                    </button>
                    <button class="btn btn-ghost btn-sm" style="font-size:10px;padding:4px 9px;width:90px;background:linear-gradient(135deg,rgba(36, 83, 122,0.08),rgba(47, 102, 144,0.07));border-color:rgba(36, 83, 122,0.25);color:#24537a"
                      onclick="showRHTechsBySystem('${u.unit}','${sys}')">
                      👤 Techniciens
                    </button>
                  </div>
                </td>
              </tr>`;
            }).join('');
          }).join('')}
          <tr style="background:#f8faff;font-weight:800;border-top:2px solid var(--border)">
            <td colspan="2"><strong>TOTAL</strong></td>
            <td style="text-align:center;font-weight:700">${totalH.toFixed(1)}h</td>
            <td style="text-align:center;font-weight:700">100%</td>
            <td style="text-align:center;color:#24537a;font-size:15px">${totalEssentiel}</td>
            <td style="text-align:center;font-weight:700">${totalTech}</td>
            <td style="text-align:center">
              <span class="badge ${totalEssentiel>totalTech?'badge-red':totalEssentiel<totalTech?'badge-yellow':'badge-green'}">
                ${totalEssentiel>totalTech?`⚠️ +${totalEssentiel-totalTech}`:totalEssentiel<totalTech?`↘ ${totalEssentiel-totalTech}`:'✅ OK'}
              </span>
            </td>
            <td colspan="3"></td>
            <td style="text-align:center">
              <div style="font-size:10px;color:#6b7fa8;font-weight:600">RAM : ${totalRAM!==null?totalRAM.toFixed(1)+'h':'—'}</div>
              <span class="badge ${effBadgeGlobal.cls}" style="font-size:10px">${effBadgeGlobal.lbl}</span>
            </td>
            <td></td>
          </tr>
        </tbody></table>
      </div>
    </div>
    <div id="rh-system-detail-panel" style="display:none;margin-bottom:20px"></div>
   `;

  container.innerHTML = html;
  rhEffInitUI();
  rhEffRenderChart();
}

// =====================================================================
// ANALYSE IA PAR UNITE
// =====================================================================
