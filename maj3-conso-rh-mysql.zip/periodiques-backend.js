// routes/periodiques.js — remplace conso-mensuelle.js et rh-efficience.js
// Chaque enregistrement est identifié par (unite, annee, mois).
// GET renvoie les données déjà reconstruites sous la forme imbriquée
// { unite: { "AAAA-MM": {...} } } pour coller à ce que le front-end
// (consoLoadData / rhEffLoadData) attend déjà, et minimiser les changements
// côté HTML/JS.
const express = require("express");
const pool = require("../db");

const router = express.Router();

function makeCrud(table) {
  const r = express.Router();

  // GET /api/xxx  →  { ALG: { "2026-01": {...} }, ORN: {...}, ... }
  r.get("/", async (req, res) => {
    const [rows] = await pool.query(`SELECT unite, annee, mois, data FROM ${table}`);
    const out = {};
    for (const row of rows) {
      const monthKey = row.annee + "-" + String(row.mois).padStart(2, "0");
      if (!out[row.unite]) out[row.unite] = {};
      out[row.unite][monthKey] = typeof row.data === "string" ? JSON.parse(row.data) : row.data;
    }
    res.json(out);
  });

  // PUT /api/xxx/:unite/:annee/:mois   body = { ...contenu de l'entrée... }
  r.put("/:unite/:annee/:mois", async (req, res) => {
    const { unite, annee, mois } = req.params;
    try {
      await pool.query(
        `INSERT INTO ${table} (unite, annee, mois, data) VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE data = VALUES(data)`,
        [unite, annee, mois, JSON.stringify(req.body)]
      );
      res.json({ ok: true });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Erreur serveur" });
    }
  });

  // DELETE /api/xxx/:unite/:annee/:mois
  r.delete("/:unite/:annee/:mois", async (req, res) => {
    const { unite, annee, mois } = req.params;
    await pool.query(`DELETE FROM ${table} WHERE unite = ? AND annee = ? AND mois = ?`, [unite, annee, mois]);
    res.json({ ok: true });
  });

  return r;
}

router.use("/conso-mensuelle", makeCrud("conso_mensuelle"));
router.use("/rh-efficience", makeCrud("rh_efficience"));

module.exports = router;
