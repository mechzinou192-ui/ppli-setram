-- migration-unites.sql — ajoute la dimension "unité" (ALG, ORN, CST...) aux
-- tables conso_mensuelle et rh_efficience, qui n'existait pas au départ.

USE setram_app;

ALTER TABLE conso_mensuelle
  DROP INDEX uniq_periode,
  ADD COLUMN unite VARCHAR(10) NOT NULL DEFAULT '' AFTER id,
  ADD UNIQUE KEY uniq_unite_periode (unite, annee, mois);

ALTER TABLE rh_efficience
  DROP INDEX uniq_periode_rh,
  ADD COLUMN unite VARCHAR(10) NOT NULL DEFAULT '' AFTER id,
  ADD UNIQUE KEY uniq_unite_periode_rh (unite, annee, mois);
